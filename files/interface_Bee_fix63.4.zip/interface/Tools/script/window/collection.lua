-- Native collection adapter. Ctrl+A opens settings; Alt+A retains the collection toggle.
local tbAutoEgg = Map.tbAutoEgg or {};
Map.tbAutoEgg = tbAutoEgg;
local nPickState = 0;
tbAutoEgg.nPickState = 0;

function tbAutoEgg:GetGatherController()
    if not Ui.WJXGather or not Ui.WJXGather.Open then
        Require("\\interface\\tool\\gather.lua");
    end
    return assert(Ui.WJXGather, "Chưa nạp bộ Thu Thập.");
end

function tbAutoEgg:OpenSettings()
    local ok, why = pcall(function() self:GetGatherController():Open(); end);
    if not ok then me.Msg("[Thu Thập] " .. tostring(why)); end
end

function tbAutoEgg:OnPickTimer()
    local gather = self:GetGatherController();
    if gather.owner and gather.owner ~= me.szName then
        self:SetGatherState(0);
        return 0;
    end
    if not gather:CanGather() or me.IsDead() == 1 then return; end
    if UiManager:WindowVisible(Ui.UI_SAYPANEL) == 1 or
        UiManager:WindowVisible(Ui.UI_SHOP) == 1 then return; end
	if (nPickState == 0) then
		return 0
	end
	if UiManager:WindowVisible(Ui.UI_SKILLPROGRESS) == 1 then
		return;
	end
	if Map.firedown == 1 then
        self:SetGatherState(0);
		return 0
	end
	--------------range = 100
	local nCurMapId, nWorldPosX, nWorldPosY = me.GetWorldPos();
	local tbAroundNpc	= KNpc.GetAroundNpcList(me, 100);
	for _, pNpc in ipairs(tbAroundNpc) do		
		if (pNpc.nTemplateId == 2701 and gather:Allows(2701)) then  	-- Cờ Tầm Bảo
			gather.blockPickupUntil = GetTime() + 1;
            AutoAi.SetTargetIndex(pNpc.nIndex);
			return;
		elseif (pNpc.nTemplateId == 3622 and gather:Allows(3622)) then  -- Rương Niên thú
			gather.blockPickupUntil = GetTime() + 1;
            AutoAi.SetTargetIndex(pNpc.nIndex);
			return;
		elseif (pNpc.nTemplateId == 2960 and gather:Allows(2960)) then  -- Rương tiền đồng	(Ải Gia Tộc)
			gather.blockPickupUntil = GetTime() + 1;
            AutoAi.SetTargetIndex(pNpc.nIndex);
			return;
		elseif (pNpc.nTemplateId == 1649 and gather:Allows(1649)) then  -- Gỗ thông Vũ Lăng Sơn
			gather.blockPickupUntil = GetTime() + 1;
            AutoAi.SetTargetIndex(pNpc.nIndex);
			return;
		elseif (pNpc.nTemplateId == 1668 and gather:Allows(1668)) then  -- Gỗ
			gather.blockPickupUntil = GetTime() + 1;
            AutoAi.SetTargetIndex(pNpc.nIndex);
			return;
		elseif (pNpc.nTemplateId == 1068 and gather:Allows(1068)) then  -- Tiêu thạch(Tiêu Thạch Cốc)
			gather.blockPickupUntil = GetTime() + 1;
            AutoAi.SetTargetIndex(pNpc.nIndex);
			return;
		elseif (pNpc.nTemplateId == 1667 and gather:Allows(1667)) then  -- Tiêu thạch
			gather.blockPickupUntil = GetTime() + 1;
            AutoAi.SetTargetIndex(pNpc.nIndex);
			return;
		elseif (pNpc.nTemplateId == 4113 and gather:Allows(4113)) then  -- Bảo rương
			gather.blockPickupUntil = GetTime() + 1;
            AutoAi.SetTargetIndex(pNpc.nIndex);
			return;
		elseif (pNpc.nTemplateId == 4668 and gather:Allows(4668)) then  -- Cũi khô TDC
			gather.blockPickupUntil = GetTime() + 1;
            AutoAi.SetTargetIndex(pNpc.nIndex);
			return;	
		elseif (pNpc.nTemplateId == 3303 and gather:Allows(3303)) then  -- Bảo rương lv5
			gather.blockPickupUntil = GetTime() + 1;
            AutoAi.SetTargetIndex(pNpc.nIndex);
			return;
		elseif (pNpc.nTemplateId == 3261 and gather:Allows(3261)) then  -- Bảo rương lv4
			gather.blockPickupUntil = GetTime() + 1;
            AutoAi.SetTargetIndex(pNpc.nIndex);
			return;
		elseif (pNpc.nTemplateId == 4277 and gather:Allows(4277)) then  -- Cửa mật đạo
			gather.blockPickupUntil = GetTime() + 1;
            AutoAi.SetTargetIndex(pNpc.nIndex);
			return;
		elseif (pNpc.nTemplateId == 4023 and gather:Allows(4023)) then  -- Cây phong HPNS
			gather.blockPickupUntil = GetTime() + 1;
            AutoAi.SetTargetIndex(pNpc.nIndex);
			return;
		elseif (pNpc.nTemplateId == 4175 and gather:Allows(4175)) then  -- Bảo rương
			gather.blockPickupUntil = GetTime() + 1;
            AutoAi.SetTargetIndex(pNpc.nIndex);
			return;
		elseif (pNpc.nTemplateId == 4280 and gather:Allows(4280)) then  -- Bảo rương
			gather.blockPickupUntil = GetTime() + 1;
            AutoAi.SetTargetIndex(pNpc.nIndex);
			return;
		elseif (pNpc.nTemplateId == 3691 and gather:Allows(3691)) then  -- Thất Tịch Thủy Ngưu
			gather.blockPickupUntil = GetTime() + 1;
            AutoAi.SetTargetIndex(pNpc.nIndex);
			me.AnswerQestion(0)
			me.AnswerQestion(0)
			me.AnswerQestion(1)
			me.AnswerQestion(0)
			return;
		elseif (pNpc.nTemplateId == 4013 and gather:Allows(4013)) then  -- Dây thừng HPNS
			gather.blockPickupUntil = GetTime() + 1;
            AutoAi.SetTargetIndex(pNpc.nIndex);
			return;
		elseif (pNpc.nTemplateId == 4014 and gather:Allows(4014)) then  -- Tấm gỗ HPNS
			gather.blockPickupUntil = GetTime() + 1;
            AutoAi.SetTargetIndex(pNpc.nIndex);
			return;
		elseif (pNpc.nTemplateId == 1576 and gather:Allows(1576)) then  -- Tuyết Sơn Chi Linh
			gather.blockPickupUntil = GetTime() + 1;
            AutoAi.SetTargetIndex(pNpc.nIndex);
			return;
		elseif (pNpc.nTemplateId == 1651 and gather:Allows(1651)) then  -- Chuột Núi
			gather.blockPickupUntil = GetTime() + 1;
            AutoAi.SetTargetIndex(pNpc.nIndex);
			return;
		elseif (pNpc.nTemplateId == 3707 and gather:Allows(3707)) then  -- Thiềm Cung Thỏ Ngọc
			gather.blockPickupUntil = GetTime() + 1;
            AutoAi.SetTargetIndex(pNpc.nIndex);
			return;
		elseif (pNpc.nTemplateId == 1523 and gather:Allows(1523)) then  -- Liên căn thảo
			gather.blockPickupUntil = GetTime() + 1;
            AutoAi.SetTargetIndex(pNpc.nIndex);
			return;
		elseif (pNpc.nTemplateId == 1524 and gather:Allows(1524)) then  -- Ôn nhuận thảo
			gather.blockPickupUntil = GetTime() + 1;
            AutoAi.SetTargetIndex(pNpc.nIndex);
			return;
		elseif (pNpc.nTemplateId == 1525 and gather:Allows(1525)) then  -- Quả Sồi
			gather.blockPickupUntil = GetTime() + 1;
            AutoAi.SetTargetIndex(pNpc.nIndex);
			return;
		elseif (pNpc.nTemplateId == 1227 and gather:Allows(1227)) then  -- Lam Diệp Thảo(hổ khâu kiếm tri)
			gather.blockPickupUntil = GetTime() + 1;
            AutoAi.SetTargetIndex(pNpc.nIndex);
			return;
		elseif (pNpc.nTemplateId == 845 and gather:Allows(845)) then  -- Cây Khỏe(Cư Diên Trạch)
			gather.blockPickupUntil = GetTime() + 1;
            AutoAi.SetTargetIndex(pNpc.nIndex);
			return;
		elseif (pNpc.nTemplateId == 1240 and gather:Allows(1240)) then  -- Lá Khoai (Hướng Thủy Động)
			gather.blockPickupUntil = GetTime() + 1;
            AutoAi.SetTargetIndex(pNpc.nIndex);
			return;
		elseif (pNpc.nTemplateId == 2958 and gather:Allows(2958)) then  -- Bí Dược (Ải Gia Tộc)
			gather.blockPickupUntil = GetTime() + 1;
            AutoAi.SetTargetIndex(pNpc.nIndex);
			return;
		elseif (pNpc.nTemplateId == 4224 and gather:Allows(4224)) then  --Du long doan so 4224
			gather.blockPickupUntil = GetTime() + 1;
            AutoAi.SetTargetIndex(pNpc.nIndex);
			me.AnswerQestion(1)
			me.AnswerQestion(0)
			return;	
		elseif (pNpc.nTemplateId == 4226 and gather:Allows(4226)) then  --Sau khi đoán số 1-cửa truyền tống
			gather.blockPickupUntil = GetTime() + 1;
            AutoAi.SetTargetIndex(pNpc.nIndex);
			me.AnswerQestion(0)
			me.AnswerQestion(0)
			return;
		elseif (pNpc.nTemplateId == 4227 and gather:Allows(4227)) then  --Sau khi đoán số 2-cửa truyền tống
			gather.blockPickupUntil = GetTime() + 1;
            AutoAi.SetTargetIndex(pNpc.nIndex);
			me.AnswerQestion(0)
			me.AnswerQestion(0)
			return;		
		end
	end
	------------------range = 15
	local nCurMapId, nWorldPosX, nWorldPosY = me.GetWorldPos();
	local tbAroundNpc	= KNpc.GetAroundNpcList(me, 15);
	for _, pNpc in ipairs(tbAroundNpc) do		
		if (pNpc.nTemplateId == 2700 and gather:Allows(2700)) then  	-- Bảo rương môn phái
			gather.blockPickupUntil = GetTime() + 1;
            AutoAi.SetTargetIndex(pNpc.nIndex);
			return;
		elseif (pNpc.nTemplateId == 2680 and gather:Allows(2680)) then  -- Rương Tàng bảo đồ
			gather.blockPickupUntil = GetTime() + 1;
            AutoAi.SetTargetIndex(pNpc.nIndex);
			return;
		elseif (pNpc.nTemplateId == 1629 and gather:Allows(1629)) then  -- Tử Mẫu Đơn:1629
			gather.blockPickupUntil = GetTime() + 1;
            AutoAi.SetTargetIndex(pNpc.nIndex);
			return;	
		elseif (pNpc.nTemplateId == 1630 and gather:Allows(1630)) then  -- Sen Mẫu Đơn:1630
			gather.blockPickupUntil = GetTime() + 1;
            AutoAi.SetTargetIndex(pNpc.nIndex);
			return;
		elseif (pNpc.nTemplateId == 1631 and gather:Allows(1631)) then  -- Bách Hương Quả:1631
			gather.blockPickupUntil = GetTime() + 1;
            AutoAi.SetTargetIndex(pNpc.nIndex);
			return;
		elseif (pNpc.nTemplateId == 1632 and gather:Allows(1632)) then  -- Huyết Phong Đằng:1632
			gather.blockPickupUntil = GetTime() + 1;
            AutoAi.SetTargetIndex(pNpc.nIndex);
			return;
		elseif (pNpc.nTemplateId == 1633 and gather:Allows(1633)) then  -- Hắc Tinh Thạch:1633
			gather.blockPickupUntil = GetTime() + 1;
            AutoAi.SetTargetIndex(pNpc.nIndex);
			return;
		elseif (pNpc.nTemplateId == 1634 and gather:Allows(1634)) then  --Lục Thủy Tinh:1634
			gather.blockPickupUntil = GetTime() + 1;
            AutoAi.SetTargetIndex(pNpc.nIndex);
			return;
		elseif (pNpc.nTemplateId == 1635 and gather:Allows(1635)) then  -- Thất Thái Thạch:1635
			gather.blockPickupUntil = GetTime() + 1;
            AutoAi.SetTargetIndex(pNpc.nIndex);
			return;
		elseif (pNpc.nTemplateId == 4281 and gather:Allows(4281)) then  -- Rương gần Du Long
			gather.blockPickupUntil = GetTime() + 1;
            AutoAi.SetTargetIndex(pNpc.nIndex);
			return;	
		elseif (pNpc.nTemplateId == 1563 and gather:Allows(1563)) then  -- Bất diệt hỏa
			gather.blockPickupUntil = GetTime() + 1;
            AutoAi.SetTargetIndex(pNpc.nIndex);
			return;			
		end
	end
	
end

function tbAutoEgg:SetGatherState(state)
    state = state == 1 and 1 or 0;
    nPickState = state;
    self.nPickState = state;
    if self.gatherTimer then
        Timer:Close(self.gatherTimer);
        self.gatherTimer = nil;
    end
    if state == 1 then
        local gather = self:GetGatherController();
        gather.owner = me.szName;
        self.gatherTimer = Timer:Register(math.max(1, math.floor(Env.GAME_FPS * 0.3)), function()
            local ok, result = pcall(self.OnPickTimer, self);
            if not ok then
                self:SetGatherState(0);
                me.Msg("[Thu Thập] Đã dừng vì lỗi: " .. tostring(result));
                return 0;
            end
            return result;
        end);
    elseif Ui.WJXGather then
        Ui.WJXGather.blockPickupUntil = nil;
    end
end

function tbAutoEgg:AutoPick()
    if self.nPickState == 1 then
        self:AutoPickStop();
    else
        self:AutoPickStart();
    end
end

function tbAutoEgg:AutoPickStart()
    if self.nPickState == 1 then return; end
    local gather = self:GetGatherController();
    if gather:StartGather() then gather:Message("Đã bật Thu Thập theo danh sách đã lưu."); end
end

function tbAutoEgg:AutoPickStop()
    self:SetGatherState(0);
    self:GetGatherController():Message("Đã dừng Thu Thập.");
end

function tbAutoEgg:Eggswitch()
    self:AutoPick();
end
