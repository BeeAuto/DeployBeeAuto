local function Auto6Setting(key)
	local a=Ui.WJXAuto6;
	if a and a.session and a.active then return a.active[key] end
	return Ui(Ui.UI_AUTOFIGHT)[key];
end
local tbConfirm = Ui.tbLogic.tbConfirm

local OnTeamReceiveInvite_Bak		= tbConfirm.OnTeamReceiveInvite
local OnTeamApplyAdd_Bak			= tbConfirm.OnTeamApplyAdd
local OnTradeReceiveRequest_Bak		= tbConfirm.OnTradeReceiveRequest
local OnRelationTmpFriend_Bak		= tbConfirm.OnRelationTmpFriend
local OnPkExerciseInvite_Bak		= tbConfirm.OnPkExerciseInvite

local CFStart = 0

function tbConfirm:Status()
	return CFStart
end

tbConfirm.Switch = function(self)
	if CFStart == 0 then 
		CFStart = 1
		me.Msg("<color=yellow>Bật<color> chặn lời mời.")
	else
		CFStart = 0
		me.Msg("<color=yellow>Tắt<color> chặn lời mời.")
	end
end

-- Party settings are independent of Auto6's native auto-fight state.
local function PartyForInvitation()
 if not Ui.WJXParty then
  local ok=pcall(Require,"\\interface\\tool\\party.lua");
  if not ok then return; end
 end
 return Ui.WJXParty;
end
tbConfirm.OnTeamReceiveInvite = function(self,szKey,szPlayer,nPlayerId)
 if CFStart==1 then return end
 local p=PartyForInvitation();
 if p and p:CanJoin() then me.TeamReplyInvite(1,nPlayerId,szPlayer)
 else return OnTeamReceiveInvite_Bak(self,szKey,szPlayer,nPlayerId) end
end
tbConfirm.OnTeamApplyAdd = function(self,szKey,szPlayer,nPlayerId)
 if CFStart==1 then return end
 local p=PartyForInvitation();
 if p and p:CanAccept() then me.TeamReplyApply(1,nPlayerId,szPlayer)
 else return OnTeamApplyAdd_Bak(self,szKey,szPlayer,nPlayerId) end
end

tbConfirm.OnTradeReceiveRequest = function(self, szKey, szPlayer)
	local bInComp = AutoAi:InPC(szPlayer)
	if (CFStart == 1) and (bInComp ~= 1) then
		me.Msg("<color=green>"..szPlayer.."<color><color=yellow> giao dịch với Bạn đã bị hệ thống tự động từ chối!<color>");
	elseif bInComp == 1 then
		me.TradeResponse(szPlayer, 1)
	else
		OnTradeReceiveRequest_Bak(self, szKey, szPlayer)
	end
end

tbConfirm.OnRelationTmpFriend = function(szKey, szPlayer)
	if (CFStart == 1) and (AutoAi:InPC(szPlayer) ~= 1) then
		me.Msg("<color=green>"..szPlayer.."<color><color=yellow> muốn kết bạn đã bị hệ thống tự động từ chối!<color>");
	else
		OnRelationTmpFriend_Bak(szKey, szPlayer)
	end
end

tbConfirm.OnPkExerciseInvite = function(self,szKey, szPlayer, nPlayerId)
	if (CFStart == 1) and (AutoAi:InPC(szPlayer) ~= 1) then
		me.Msg("<color=green>"..szPlayer.."<color><color=yellow> muốn tỷ thí đã bị hệ thống tự động từ chối!<color>");
	else
		OnPkExerciseInvite_Bak(self,szKey, szPlayer, nPlayerId)
	end
end


