-- Auto Chính Tuyến v0.1 — file vào. Chỉ file này tự chạy khi client nạp plugin; các file wjxct_*.lua có lính gác
-- "loading" và chỉ được nạp qua M:EnsureModules() khi mở cửa sổ lần đầu.
Ui.WJXMainQuest = Ui.WJXMainQuest or {};
local M = Ui.WJXMainQuest;
M.GROUP = "UI_WJXCHINHTUYEN";
M.CLASS = "wjxct_main";
M.INI = "wjxct_main.ini";
M.DIR = "\\interface\\AutoChinhTuyen\\";
M.VERSION = "0.7.9";
M.TOOL_GROUP = "UI_TOOL";
M.TOOL_BUTTON = "BtnChinhTuyen";
M.MODULES = {"wjxct_spawns.lua", "wjxct_model.lua", "wjxct_controller.lua", "wjxct_view.lua"};

function M:Message(text)
    self.status = tostring(text);
    if me and me.Msg then me.Msg("[Chính Tuyến] " .. self.status); end
end

function M:EnsureModules()
    if self.ready then return; end
    local ok, why = pcall(function()
        self.loading = true;
        if not Ui.WJXTransfer then
            pcall(Require, "\\interface\\btssl_autofight\\script\\window\\autofight_transfer.lua");
        end
        for _, name in ipairs(self.MODULES) do
            local path = self.DIR .. name;
            local source = assert(KFile.ReadTxtFile(path), "Không đọc được " .. path);
            assert(loadstring(string.gsub(source, "^\239\187\191", ""), "@" .. path))();
        end
    end);
    self.loading = nil;
    if not ok then error(why); end
    self.ready = true;
end

function M:RegisterWindow()
    self:EnsureModules();
    local native = LoadUiGroup;
    -- Game.exe chép cố định 256 byte từ con trỏ tên INI: đệm NUL như tool/merchant.
    local buffer = self.INI .. string.rep("\0", 256 - string.len(self.INI));
    LoadUiGroup = function(group, name, a, b)
        if group == M.GROUP then name = buffer; end
        return native(group, name, a, b);
    end;
    local ok, why = pcall(Ui.RegisterNewUiWindow, Ui, self.GROUP, self.CLASS,
        {"a", 140, 70}, {"b", 252, 154}, {"c", 380, 220});
    LoadUiGroup = native;
    if not ok then error(why); end
    local w, h = Wnd_GetSize(self.GROUP, "Main");
    assert(w and w > 0 and h and h > 0, "Chưa nạp " .. self.INI .. "; hãy thoát hẳn game rồi vào lại.");
    local v = Ui.tbWnd[self.GROUP];
    assert(v and v.OnOpen and v.OnButtonClick and v.OnComboBoxIndexChange, "Đăng ký cửa sổ Chính Tuyến chưa đầy đủ.");
    if GetUiMode() == "d" then
        Ui:AddExWndConfig(self.GROUP, {"d", 700, 356});
        Ui:LoadExWndConfig(self.GROUP);
    end
    self.windowReady = true;
end

function M:Open()
    local ok, why = pcall(function()
        if not self.windowReady then self:RegisterWindow(); end
        self:Install();
        if UiManager:WindowVisible(self.GROUP) == 1 then Wnd_BringTop(self.GROUP, "Main");
        else UiManager:OpenWindow(self.GROUP); end
    end);
    if not ok then self:Message("Không mở được giao diện: " .. tostring(why)); end
end

-- Nút "Chính Tuyến" nằm trong tool/tool.ini (thanh End). Không sửa tool.lua.
-- Nút thanh End dùng CHUNG một bộ chia (Ui.WJXToolButtons) với Auto Tiêu Dao v2: chỉ bọc UI_TOOL.OnButtonClick
-- đúng 1 lớp; nút nào đăng ký thì bộ chia gọi, nút khác đi tiếp vào hàm gốc. tool.lua chạy lại thì bọc lại 1 lớp.
local D = Ui.WJXToolButtons or {handlers = {}};
Ui.WJXToolButtons = D;
function D:Install()
    local w = Ui.tbWnd and Ui.tbWnd["UI_TOOL"];
    if type(w) ~= "table" or type(w.OnButtonClick) ~= "function" then return false; end
    if w.OnButtonClick == self.hook then return true; end
    local original = w.OnButtonClick;
    local hook;
    hook = function(window, name, param, extra)
        local handler = D.handlers[name];
        if handler then handler(); return; end
        return original(window, name, param, extra);
    end;
    self.hook = hook;
    w.OnButtonClick = hook;
    return true;
end
function D:Watch()
    if self.watch then return; end
    local timer = Ui.tbLogic and Ui.tbLogic.tbTimer;
    if not timer then return; end
    local checks = 0;
    self.watch = timer:Register(Env.GAME_FPS, function()
        checks = checks + 1;
        local ok, hooked = pcall(D.Install, D);
        if (ok and hooked and checks >= 120) or checks >= 600 then D.watch = nil; return 0; end
        return Env.GAME_FPS;
    end);
end

D.handlers[M.TOOL_BUTTON] = function() M:Open(); end;
pcall(D.Install, D);
pcall(D.Watch, D);
