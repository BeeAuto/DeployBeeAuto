-- Auto Chính Tuyến — VIEW: cửa sổ cài đặt + tiến độ. Chỉ đọc Model và gọi Controller; đóng cửa sổ không dừng auto.
if not Ui.WJXMainQuest or not Ui.WJXMainQuest.loading then return; end
local M = Ui.WJXMainQuest;
local V = Ui:GetClass(M.CLASS);
local CHECKS = {BtnTransfer = "transfer", BtnAccept = "accept", BtnQuiz = "quiz", BtnCombat = "combat",
    BtnMount = "mount", BtnDismount = "dismount", BtnDefend = "defend", BtnKeep = "keep",
    BtnGhep = "ghep", BtnGhepBind = "ghepBind", BtnGhepMoney = "ghepBindMoney"};

function V:ReadOptions()
    local o = {award = self.award, lowLevel = self.lowLevel, retry = self.retry, range = self.range, taskId = self.taskId, ghepLv = self.ghepLv};
    for name, key in pairs(CHECKS) do o[key] = Btn_GetCheck(self.UIGROUP, name); end
    return M:Options(o);
end

function V:Fill(options)
    self.updating = true;
    for name, key in pairs(CHECKS) do Btn_Check(self.UIGROUP, name, options[key]); end
    self.award, self.lowLevel, self.retry, self.range = options.award, options.lowLevel, options.retry, options.range;
    ClearComboBoxItem(self.UIGROUP, "CmbAward");
    for i = 1, M.AWARD_SLOTS do ComboBoxAddItem(self.UIGROUP, "CmbAward", i, "Ô " .. i); end
    ClearComboBoxItem(self.UIGROUP, "CmbLowLevel");
    for i, text in ipairs(M.LOW_LEVEL) do ComboBoxAddItem(self.UIGROUP, "CmbLowLevel", i, text); end
    ClearComboBoxItem(self.UIGROUP, "CmbRetry");
    for i = 1, M.RETRY_MAX do ComboBoxAddItem(self.UIGROUP, "CmbRetry", i, i .. " lần"); end
    ComboBoxSelectItem(self.UIGROUP, "CmbAward", self.award - 1);
    ComboBoxSelectItem(self.UIGROUP, "CmbLowLevel", self.lowLevel - 1);
    ComboBoxSelectItem(self.UIGROUP, "CmbRetry", self.retry - 1);
    ClearComboBoxItem(self.UIGROUP, "CmbRange");
    local rangeIndex = 0;
    for i, r in ipairs(M.RANGES) do
        ComboBoxAddItem(self.UIGROUP, "CmbRange", i, r .. " MPS");
        if r == self.range then rangeIndex = i - 1; end
    end
    ComboBoxSelectItem(self.UIGROUP, "CmbRange", rangeIndex);
    self.ghepLv = options.ghepLv or 5;
    ClearComboBoxItem(self.UIGROUP, "CmbGhepLv");
    for lv = 2, 12 do ComboBoxAddItem(self.UIGROUP, "CmbGhepLv", lv - 1, "Cấp " .. lv); end
    ComboBoxSelectItem(self.UIGROUP, "CmbGhepLv", self.ghepLv - 2);
    self.taskId = options.taskId or 0;
    self.updating = nil;
    self.taskKey = nil;
    self:FillTasks();
end

-- Combo tuyến nhiệm vụ: "Tự động" + các tuyến chính tuyến đang nhận / nhận được. Chỉ dựng lại khi danh sách đổi.
function V:FillTasks()
    local ok, list = pcall(M.TaskChoices, M);
    list = ok and list or {};
    local parts = {tostring(self.taskId)};
    for _, c in ipairs(list) do parts[#parts + 1] = c.id .. "=" .. c.label; end
    local key = table.concat(parts, "\1");
    if key == self.taskKey then return; end
    self.taskKey, self.taskList = key, list;
    local found = (self.taskId or 0) == 0;
    for _, c in ipairs(list) do if c.id == self.taskId then found = true; end end
    if not found then
        local name = Task and Task.GetTaskName and Task:GetTaskName(self.taskId) or ("Tuyến " .. self.taskId);
        list[#list + 1] = {id = self.taskId, label = M:Plain(name) .. " — (đã xong / chưa nhận được)"};
    end
    self.updating = true;
    ClearComboBoxItem(self.UIGROUP, "CmbTask");
    ComboBoxAddItem(self.UIGROUP, "CmbTask", 1, "Tự động (tuyến làm được đầu tiên)");
    local index = 0;
    for i, c in ipairs(list) do
        ComboBoxAddItem(self.UIGROUP, "CmbTask", i + 1, c.label);
        if c.id == self.taskId then index = i; end
    end
    ComboBoxSelectItem(self.UIGROUP, "CmbTask", index);
    self.updating = nil;
end

function V:RefreshStatus()
    if not self.tasksAt or GetTime() - self.tasksAt >= 5 then self.tasksAt = GetTime(); self:FillTasks(); end
    M.viewTaskId = self.taskId;
    local s, w = M:ViewState();
    if s then
        local step = s.nCurStep == -1 and "Chờ nhận thưởng" or ("Bước " .. s.nCurStep .. "/" .. (s.nSteps > 0 and s.nSteps or "?"));
        Txt_SetTxt(self.UIGROUP, "TxtRefer", "Chặng: [" .. M:Plain(s.szTaskName) .. "] " .. M:Plain(s.szReferName) .. " (" .. s.nReferId .. ") · " .. step);
    else
        Txt_SetTxt(self.UIGROUP, "TxtRefer", "Chặng: — (tuyến này chưa nhận / đã xong)");
    end
    local work = "—";
    if w then
        local title = w.title or w.reason or "";
        work = "[" .. (M.KIND_TITLE[w.kind] or w.kind or "?") .. "] " .. M:Plain(title);
    end
    Txt_SetTxt(self.UIGROUP, "TxtWork", "Việc: " .. work);
    local status = M.status or "Bấm Lưu và Bắt Đầu để chạy.";
    if self.dirty then status = "Có cài đặt chưa lưu. " .. status; end
    Txt_SetTxt(self.UIGROUP, "TxtStatus", (M.job and "Đang chạy | " or "Đang dừng | ") .. status);
    Wnd_SetEnable(self.UIGROUP, "BtnStop", M.job and 1 or 0);
end

function V:OnOpen()
    Txt_SetTxt(self.UIGROUP, "TxtTitle", "AUTO CHÍNH TUYẾN — v" .. tostring(M.VERSION));   -- tiêu đề theo bản Lua đang chạy
    if self.owner ~= me.szName or self.faction ~= me.nFaction then
        self.owner, self.faction = me.szName, me.nFaction;
        self.draft = M:LoadOptions();
        self.dirty = false;
    end
    -- Ô tick do Game.exe dựng lại khi mở cửa sổ (mất trạng thái): luôn đổ lại từ bản nháp đang giữ trong Lua.
    self:Fill(self.draft or M:LoadOptions());
    self:RefreshStatus();
    if self.timer then Ui.tbLogic.tbTimer:Close(self.timer); end
    local window = self;      -- bản cửa sổ (có UIGROUP), không phải lớp V
    self.timer = Ui.tbLogic.tbTimer:Register(Env.GAME_FPS, function()
        if UiManager:WindowVisible(M.GROUP) ~= 1 then window.timer = nil; return 0; end
        local ok, why = pcall(V.RefreshStatus, window);
        if not ok then
            window.timer = nil;
            M:Message("Lỗi đọc giao diện: " .. tostring(why));
            return 0;
        end
        return Env.GAME_FPS;
    end);
end

function V:OnClose()
    if self.timer then Ui.tbLogic.tbTimer:Close(self.timer); self.timer = nil; end
    -- Auto có Timer riêng ở Controller: đóng cửa sổ không dừng auto.
end

function V:OnEscExclusiveWnd()
    UiManager:CloseWindow(self.UIGROUP);
end

function V:OnComboBoxIndexChange(name, index)
    if self.updating then return; end
    local value = (tonumber(index) or 0) + 1;
    if name == "CmbAward" and value >= 1 and value <= M.AWARD_SLOTS then self.award = value;
    elseif name == "CmbLowLevel" and M.LOW_LEVEL[value] then self.lowLevel = value;
    elseif name == "CmbRetry" and value >= 1 and value <= M.RETRY_MAX then self.retry = value;
    elseif name == "CmbRange" and M.RANGES[value] then self.range = M.RANGES[value];
    elseif name == "CmbGhepLv" and value >= 1 and value <= 11 then self.ghepLv = value + 1;
    elseif name == "CmbTask" then
        local c = self.taskList and self.taskList[value - 1];
        self.taskId = c and c.id or 0;
    else return; end
    self.dirty = true;
    self:RefreshStatus();      -- không dựng lại combo trong lúc đang xổ xuống
    self.draft = self:ReadOptions();
end

function V:OnButtonClick(name)
    if name == "BtnClose" or name == "BtnCloseX" then
        UiManager:CloseWindow(self.UIGROUP);
        return;
    elseif name == "BtnStop" then
        if M.job then M:Stop("Đã dừng Auto Chính Tuyến."); end
    elseif name == "BtnSave" or name == "BtnStart" then
        local options = M:SaveOptions(self:ReadOptions());
        if not options then return; end
        self.dirty, self.draft = false, options;
        if name == "BtnStart" then M:Start(options);
        else M:Message("Đã lưu cài đặt." .. (M.job and " Phiên đang chạy vẫn dùng cài đặt lúc bắt đầu." or "")); end
    elseif CHECKS[name] then
        self.dirty = true;
        self.draft = self:ReadOptions();
    else
        return;      -- nút con của combo giữ hành vi gốc
    end
    self:RefreshStatus();
end
