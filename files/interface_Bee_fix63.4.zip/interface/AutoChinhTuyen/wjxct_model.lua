-- Auto Chính Tuyến — MODEL: cài đặt, đọc nhiệm vụ chính tuyến đang nhận, phân loại target, tách thẻ vị trí, chọn đích.
-- Chỉ đọc dữ liệu client (Task:GetPlayerTask, Task.tbTaskDatas/tbReferDatas); không gọi hàm đổi trạng thái nhiệm vụ.
if not Ui.WJXMainQuest or not Ui.WJXMainQuest.loading then return; end
local M = Ui.WJXMainQuest;

M.CONFIG_KEY = "ChinhTuyen";
M.LOW_LEVEL = {"Dừng và báo", "Chờ đủ cấp (kiểm tra mỗi 10 giây)"};
M.AWARD_SLOTS = 5;
M.RETRY_MAX = 9;
M.RANGES = {300, 400, 500, 600, 700, 800, 900, 1000, 1100, 1200};   -- MPS, như Bách Man Sơn (300–1200, bước 100)
M.RANGE_DEFAULT = 800;

-- ---------------------------------------------------------------- cài đặt (lưu theo nhân vật như các auto khác)
function M:Options(raw)
    raw = type(raw) == "table" and raw or {};
    local function flag(v, default) if v == nil then return default; end return v == 0 and 0 or 1; end
    local award = math.floor(tonumber(raw.award) or 1);
    if award < 1 or award > self.AWARD_SLOTS then award = 1; end
    local retry = math.floor(tonumber(raw.retry) or 3);
    if retry < 1 then retry = 1; elseif retry > self.RETRY_MAX then retry = self.RETRY_MAX; end
    local range = tonumber(raw.range) or self.RANGE_DEFAULT;
    if range ~= range then range = self.RANGE_DEFAULT; end
    range = math.max(300, math.min(1200, math.floor(range / 100) * 100));
    local ghepLv = math.floor(tonumber(raw.ghepLv) or 5);
    if ghepLv < 2 or ghepLv > 12 then ghepLv = 5; end
    return {ghep = flag(raw.ghep, 1), ghepLv = ghepLv, ghepBind = flag(raw.ghepBind, 1), ghepBindMoney = flag(raw.ghepBindMoney, 1),
        transfer = flag(raw.transfer, 1), accept = flag(raw.accept, 1), quiz = flag(raw.quiz, 1),
        award = award, lowLevel = raw.lowLevel == 2 and 2 or 1, combat = flag(raw.combat, 1), retry = retry,
        mount = flag(raw.mount, 1), dismount = flag(raw.dismount, 1), defend = flag(raw.defend, 1), range = range,
        keep = flag(raw.keep, 1), taskId = math.max(0, math.floor(tonumber(raw.taskId) or 0))};
end

function M:ConfigStore()
    local ok, ui = pcall(Ui, Ui.UI_AUTOFIGHT);
    if ok and type(ui) == "table" and ui.Load and ui.Save then return ui; end
end

function M:LoadOptions()
    local ui = self:ConfigStore();
    if not ui then return self:Options(self.memoryOptions); end
    local ok, raw = pcall(ui.Load, ui, self.CONFIG_KEY);
    return self:Options(ok and raw or nil);
end

function M:SaveOptions(raw)
    local options = self:Options(raw);
    local ui = self:ConfigStore();
    if not ui then
        self.memoryOptions = options;
        self:Message("Không có nơi lưu cấu hình Auto6 (btssl_autofight); cài đặt chỉ giữ đến khi thoát game.");
        return options;
    end
    pcall(ui.Load, ui, self.CONFIG_KEY);      -- đọc lại file ngay trước khi ghi để giữ cài đặt của auto khác
    local ok, saved = pcall(ui.Save, ui, self.CONFIG_KEY, options);
    if not ok or saved == false then self:Message("Không ghi được cài đặt."); return nil; end
    return options;
end

-- ---------------------------------------------------------------- chuỗi
function M:Clean(text)
    if Ui.WJXTransfer and Ui.WJXTransfer.Clean then return Ui.WJXTransfer:Clean(text); end
    local s = string.gsub(tostring(text or ""), "<[^>]*>", "");
    s = string.gsub(s, "\194\160", " ");
    s = string.gsub(s, "[A-Z]", string.lower);
    s = string.gsub(s, "[ \t\r\n\f\v]+", " ");
    return (string.gsub(s, "^ *(.-) *$", "%1"));
end

-- Chữ để hiển thị: bỏ thẻ màu/link, gộp khoảng trắng, GIỮ hoa thường (Clean chỉ dùng để so sánh).
function M:Plain(text)
    local s = string.gsub(tostring(text or ""), "<[^>]*>", " ");      -- thẻ màu → dấu cách (tránh dính chữ)
    s = string.gsub(s, " +([%.,:;!%?%)])", "%1");
    s = string.gsub(s, "[ \t\r\n]+", " ");
    return (string.gsub(s, "^ *(.-) *$", "%1"));
end

function M:Contains(haystack, needle)
    if not needle or needle == "" then return false; end
    return string.find(haystack, needle, 1, true) ~= nil;
end

-- ---------------------------------------------------------------- thẻ vị trí trong mô tả bước
-- <pos=Tên,mãBĐ,x,y> (toạ độ thế giới) | <npcpos=Tên,bảnĐồ,mãNPC>. Tên có thể chứa dấu phẩy (nhiệm vụ 2 chặng 19):
-- pos lấy 3 trường CUỐI, npcpos lấy 2 trường cuối.
function M:ParseTags(text)
    local out = {};
    text = tostring(text or "");
    local pos = 1;
    while true do
        local s, e, kind, body = string.find(text, "<(n?p?c?pos)=([^>]*)>", pos);
        if not s then break; end
        pos = e + 1;
        local parts = {};
        for piece in (string.gmatch or string.gfind)(body .. ",", "([^,]*),") do
            parts[#parts + 1] = piece;
        end
        local n = #parts;
        local function trim(x) return (string.gsub(x or "", "^%s*(.-)%s*$", "%1")); end
        if kind == "pos" and n >= 4 then
            local x, y, map = tonumber(trim(parts[n - 1])), tonumber(trim(parts[n])), tonumber(trim(parts[n - 2]));
            if map and x and y then
                out[#out + 1] = {kind = "pos", name = trim(table.concat(parts, ",", 1, n - 3)), map = map, x = x, y = y};
            end
        elseif kind == "npcpos" and n >= 3 then
            local npc = tonumber(trim(parts[n]));
            if npc then
                out[#out + 1] = {kind = "npcpos", name = trim(table.concat(parts, ",", 1, n - 2)),
                    varMap = trim(parts[n - 1]), npc = npc};
            end
        end
    end
    -- Thẻ hỏng thiếu "pos=" có trong dữ liệu gốc, vd <Ân Phương,423,1541,3104> (SimBot TaskPublishCatalog 432).
    pos = 1;
    while true do
        local s, e, name, map, x, y = string.find(text, "<([^<>=:]-),%s*(%d+)%s*,%s*(%d+)%s*,%s*(%d+)%s*>", pos);
        if not s then break; end
        pos = e + 1;
        out[#out + 1] = {kind = "pos", name = (string.gsub(name, "^%s*(.-)%s*$", "%1")), map = tonumber(map), x = tonumber(x), y = tonumber(y)};
    end
    return out;
end

-- ---------------------------------------------------------------- phân loại target (36 loại ở chính tuyến)
M.KIND = {
    TalkWithNpc = "talk", TalkNpc = "talk", SayWithNpc = "talk", GivePlayerItem = "talk", GiveItem = "talk",
    Send2Aim = "send2aim", GoPos = "move",
    AnsewerTheQuestion_A = "quiz", AnsewerTheQuestionWithDesc = "quiz",
    PlayerLevelUp = "wait", ReputeValue = "wait", Timer = "wait",
    StepEvent = "info", TipPopo = "info", UserTrackInfo = "info", AddTaskItem = "info",
    KillNpc = "combat", KillBoss = "combat", KillNpc4Item = "combat", KillBoss4Item = "combat",
    KillNpc4NormalItem = "combat", KillNpcCount = "combat", CatchNpc = "combat",
    FightNpc2DialogNpc = "transform", DialogNpc2FightNpc = "transform",
    WithProcess = "process", WithProcessStatic = "process",
    AddObj = "useitem", CastSkillAtArea = "useitem", CastSkillAtAreaWithDesc = "useitem", CastSkill = "useitem",
    ProductWithProcess = "product",
    SearchItem = "search", SearchItemWithDesc = "search",
    ProtectNpc = "escort", GuardNpc = "guard",
    JoinFaction = "manual",
};
M.KIND_TITLE = {talk = "Đối thoại", move = "Di chuyển", quiz = "Câu hỏi", wait = "Chờ điều kiện", info = "Hướng dẫn",
    combat = "Đánh quái", transform = "Đánh / thoại NPC", process = "Thu thập", useitem = "Dùng vật phẩm",
    product = "Chế tạo", search = "Cần vật phẩm", escort = "Hộ tống", guard = "Bảo vệ", send2aim = "Dẫn đường",
    manual = "Tự chọn", buy = "Mua", craft = "Kỹ năng sống", award = "Nhận thưởng", accept = "Nhận chặng", event = "Mở bước", unknown = "Chưa biết",
    lowlevel = "Thiếu cấp", none = "Không có việc", stop = "Cần xử lý tay", settle = "Chờ máy chủ", unsupported = "Chưa hỗ trợ"};

local function done(tag)
    if type(tag) ~= "table" or type(tag.IsDone) ~= "function" then return false; end
    local ok, v = pcall(tag.IsDone, tag);
    return ok and v and v ~= 0 and true or false;
end
M.TagDone = done;

local function desc(tag)
    for _, f in ipairs({"GetDesc", "GetStaticDesc"}) do
        if type(tag[f]) == "function" then
            local ok, v = pcall(tag[f], tag);
            if ok and type(v) == "string" and v ~= "" then return v; end
        end
    end
    return tag.szTargetName or "?";
end
M.TagDesc = desc;

function M:IsMainTask(nTaskId)
    local data = Task and Task.tbTaskDatas and Task.tbTaskDatas[nTaskId];
    return data and data.tbAttribute and tonumber(data.tbAttribute.TaskType) == 1 and true or false;
end

-- Ảnh chụp một nhiệm vụ chính tuyến đang nhận (nTaskId; bỏ trống = mã nhỏ nhất). Trả nil nếu không có.
function M:Snapshot(t)
    local refer = t.tbReferData or (Task.tbReferDatas and Task.tbReferDatas[t.nReferId]) or {};
    local s = {task = t, nTaskId = t.nTaskId, nReferId = t.nReferId, nCurStep = tonumber(t.nCurStep) or 0,
        szTaskName = Task:GetTaskName(t.nTaskId) or tostring(t.nTaskId), szReferName = refer.szName or tostring(t.nReferId),
        refer = refer, tags = {}};
    local steps = t.tbSubData and t.tbSubData.tbSteps;
    s.nSteps = steps and #steps or 0;
    local stepsDesc = refer.tbDesc and refer.tbDesc.tbStepsDesc;
    s.stepDesc = s.nCurStep > 0 and stepsDesc and stepsDesc[s.nCurStep] or "";
    s.descTags = self:ParseTags(s.stepDesc);
    s.step = s.nCurStep > 0 and steps and steps[s.nCurStep] or nil;
    local progress = {};
    for i, tag in ipairs(t.tbCurTags or {}) do
        local name = tag.szTargetName or "?";
        local kind = self.KIND[name] or "unknown";
        local item = {index = i, tag = tag, name = name, kind = kind, done = done(tag), desc = desc(tag)};
        s.tags[i] = item;
        progress[i] = (item.done and "1" or "0") .. ":" .. tostring(tag.nCount or "");
    end
    s.key = s.nTaskId .. "/" .. s.nReferId .. "/" .. s.nCurStep;
    s.progress = s.key .. "/" .. table.concat(progress, ",");
    return s;
end

-- Mọi nhiệm vụ chính tuyến đang nhận, mã tăng dần (SimBot cũng chọn mã nhỏ nhất trước).
function M:ReadMainTasks()
    if not Task or not Task.GetPlayerTask then return nil, "Chưa nạp khung nhiệm vụ của client."; end
    local tbPT = Task:GetPlayerTask(me);
    local list = {};
    for nTaskId, tbTask in pairs(tbPT and tbPT.tbTasks or {}) do
        if self:IsMainTask(nTaskId) then list[#list + 1] = tbTask; end
    end
    table.sort(list, function(a, b) return (tonumber(a.nTaskId) or 0) < (tonumber(b.nTaskId) or 0); end);
    local out = {};
    for i, t in ipairs(list) do out[i] = self:Snapshot(t); end
    return out;
end

function M:ReadMainTask(nTaskId)
    local list, err = self:ReadMainTasks();
    if not list then return nil, err; end
    if nTaskId then
        for _, s in ipairs(list) do if s.nTaskId == nTaskId then return s; end end
        return nil;
    end
    return list[1];
end

-- Các chặng chính tuyến kế tiếp có thể nhận ở NPC — như Task:AppendNpcMenu của client: refer kế tiếp = phần tử sau refer
-- đã xong (nhóm 1000) trong tbReferIds; điều kiện hiện (tbVisable) phải đạt. Chặng chưa hiện vì thiếu cấp → ghi nhận cấp cần.
-- Trả (danh sách đã sắp: cấp thấp nhất → NPC đang thấy → cùng bản đồ → mã nhỏ), cấp nhỏ nhất của chặng đang bị ẩn.
function M:AcceptableRefers()
    if not Task or not Task.tbTaskDatas then return {}; end
    local tbPT = Task:GetPlayerTask(me);
    local list, hiddenLevel = {}, nil;
    local here = me.GetWorldPos();
    for nTaskId, data in pairs(Task.tbTaskDatas) do
        if self:IsMainTask(nTaskId) and not (tbPT and tbPT.tbTasks and tbPT.tbTasks[nTaskId]) and data.tbReferIds then
            local ok, idx = pcall(Task.GetFinishedIdx, Task, nTaskId);
            local nReferId = ok and data.tbReferIds[(tonumber(idx) or 0) + 1];
            local refer = nReferId and Task.tbReferDatas[nReferId];
            local skipped = self.skipRefer and nReferId and self.skipRefer[nReferId] and GetTime() - self.skipRefer[nReferId] < 600;
            if refer and not skipped and (tonumber(refer.nAcceptNpcId) or 0) > 0 then
                local visible = true;
                for _, cond in ipairs({refer.tbVisable, refer.tbAccept}) do
                    if visible and cond and Lib and Lib.DoTestFuncs then
                        local okv, v = pcall(Lib.DoTestFuncs, Lib, cond);
                        visible = okv and v and v ~= 0 and true or false;
                    end
                end
                local level = tonumber(refer.nLevel) or 0;
                if visible and level <= (me.nLevel or 0) then
                    local npc = tonumber(refer.nAcceptNpcId);
                    local seen = self:FindNpc(npc) and 0 or 1;
                    local tags = self:ParseTags(refer.szIntrDesc);
                    local same = 1;
                    for _, t in ipairs(tags) do if t.kind == "pos" and t.map == here then same = 0; end end
                    list[#list + 1] = {nTaskId = nTaskId, nReferId = nReferId, refer = refer, szTaskName = Task:GetTaskName(nTaskId),
                        szReferName = refer.szName, nLevel = level, npc = npc, descTags = tags, rank = {level, seen, same, nTaskId}};
                elseif level > (me.nLevel or 0) then
                    if not hiddenLevel or level < hiddenLevel then hiddenLevel = level; end
                end
            end
        end
    end
    table.sort(list, function(a, b)
        for k = 1, 4 do if a.rank[k] ~= b.rank[k] then return a.rank[k] < b.rank[k]; end end
        return false;
    end);
    return list, hiddenLevel;
end

function M:NextAcceptable()
    local list = self:AcceptableRefers();
    return list[1];
end

-- ---------------------------------------------------------------- việc cần làm tiếp theo
local function num(v) return tonumber(v) or 0; end

local function itemTuple(t)
    if type(t) ~= "table" then return nil; end
    local g, d, p, l = num(t[1]), num(t[2]), num(t[3]), num(t[4]);
    if g <= 0 then return nil; end
    return {g, d, p, l};
end

-- ---------------------------------------------------------------- cửa hàng NPC theo dữ liệu client
-- setting\shop\goods.txt (Id → vật phẩm) + buysell.txt (cửa hàng → danh sách Id hàng) + setting\npc\dialognpc.txt
-- (lớp NPC + bản đồ → mục hội thoại "Tên","Dialog:OpenShop",mãCửaHàng,…) + setting\npc\npc.txt (mã NPC → ClassName).
-- Kết quả: vật phẩm → các NPC bán, kèm đúng chữ mục hội thoại mở cửa hàng đó.
function M:ShopIndex()
    if self.shopIndex then return self.shopIndex; end
    local idx = {byItem = {}, byShop = {}, byClass = {}};
    self.shopIndex = idx;
    local function load(path)
        local ok, rows = pcall(Lib.LoadTabFile, Lib, path);
        return ok and type(rows) == "table" and rows or {};
    end
    local goods = {};
    for _, r in pairs(load("\\setting\\shop\\goods.txt")) do
        local id = tonumber(r.Id);
        if id then goods[id] = {num(r.Genre), num(r.DetailType), num(r.ParticularType), num(r.Level)}; end
    end
    for _, r in pairs(load("\\setting\\shop\\buysell.txt")) do
        local shop = tonumber(r.ShopId);
        if shop then
            for i = 1, 200 do
                local v = r["Item" .. i];
                if v == nil then break; end
                local g = goods[tonumber(v) or -1];
                if g then
                    local key = g[1] .. "," .. g[2] .. "," .. g[3];
                    idx.byItem[key] = idx.byItem[key] or {};
                    table.insert(idx.byItem[key], {shop = shop, level = g[4]});
                end
            end
        end
    end
    for _, r in pairs(load("\\setting\\npc\\dialognpc.txt")) do
        local class = r.ClassName;
        if class and class ~= "" then
            for i = 1, 20 do
                local o = r["Option" .. i];
                if o == nil then break; end
                local raw = string.gsub(tostring(o), '"', "");
                local _, _, text, shop = string.find(raw, "^(.-)%s*,%s*Dialog:OpenShop%s*,%s*(%d+)");
                if text and shop then
                    shop = tonumber(shop);
                    idx.byShop[shop] = idx.byShop[shop] or {};
                    table.insert(idx.byShop[shop], {class = class, map = tonumber(r.MapId) or 0, option = text});
                end
            end
        end
    end
    for _, r in pairs(load("\\setting\\npc\\npc.txt")) do
        local id, class = tonumber(r.Id), r.ClassName;
        if id and class and class ~= "" then
            idx.byClass[class] = idx.byClass[class] or {};
            table.insert(idx.byClass[class], id);
        end
    end
    return idx;
end
-- NPC bán vật phẩm: NPC có trong mô tả bước trước, rồi NPC có toạ độ trên bản đồ đang đứng, rồi NPC tìm được ở bản đồ khác.
function M:ShopsFor(item, descTags)
    local idx = self:ShopIndex();
    local list = idx.byItem[item[1] .. "," .. item[2] .. "," .. item[3]] or {};
    local here = me.GetWorldPos();
    local wanted = {};
    for _, t in ipairs(descTags or {}) do if t.kind == "npcpos" then wanted[t.npc] = true; end end
    local tiers, seen = {{}, {}, {}}, {};
    for _, g in ipairs(list) do
        if item[4] <= 0 or g.level <= 0 or g.level == item[4] then
            for _, d in ipairs(idx.byShop[g.shop] or {}) do
                for _, npc in ipairs(idx.byClass[d.class] or {}) do
                    local k = npc .. "/" .. d.option;
                    if not seen[k] and (d.map <= 0 or d.map == here or wanted[npc] or self:NpcPoint(d.map, npc)) then
                        seen[k] = true;
                        local sh = {npc = npc, option = d.option, shop = g.shop, map = d.map, menu = {}};
                        if wanted[npc] then table.insert(tiers[1], sh);
                        elseif self:NpcPoint(here, npc) then table.insert(tiers[2], sh);
                        elseif #tiers[3] < 3 and self:FindNpcAnyMap(npc) then table.insert(tiers[3], sh); end
                    end
                end
            end
        end
    end
    local out = {};
    for _, t in ipairs(tiers) do for _, sh in ipairs(t) do out[#out + 1] = sh; end end
    return out;
end

-- NPC nằm trong bản đồ nhiệm vụ sau cổng (vd. Triệu Nhữ Nhu 813 ở Đại sảnh Triệu Phủ 515, cổng to_zhaoruyu ở Lâm An
-- (1576,3809); Hàn Thác Trụ 556 ở Đại sảnh Hàn Phủ 516): mô tả bước chỉ ghi toạ độ cổng ở bản đồ ngoài. Bản đồ ngoài
-- không có NPC mà bản đồ sau cổng có (hoặc cổng nằm sát điểm mô tả) → đích là bên trong bản đồ nhiệm vụ.
function M:NpcBehindTrap(point, npc)
    if not point or not npc or npc <= 0 or self:NpcPoint(point.map, npc) then return nil; end
    local best, bestD;
    for _, r in ipairs(self:TaskTraps()) do
        if r.from == point.map then
            local d = (r.x - point.x) ^ 2 + (r.y - point.y) ^ 2;
            local inside = self:NpcPoint(r.to, npc);
            if inside or d <= 25 then
                local p = inside or {map = r.to, x = r.tx, y = r.ty};
                local score = d - (inside and 1e9 or 0);
                if p.x > 0 and (not best or score < bestD) then best, bestD = {map = r.to, x = p.x, y = p.y, name = point.name, how = "trap"}, score; end
            end
        end
    end
    return best;
end

-- "Tìm thấy <vật phẩm>" mà vật phẩm là thức ăn / thuốc bán ở NPC thành thị: mua ở cửa hàng NPC (như Auto6 hậu cần).
-- 3566 Đại Lão Bạch (chủ tửu lâu, "Thực phẩm"), 3564 Dược phẩm. NPC có trong mô tả bước được ưu tiên.
M.SHOP_NPCS = {
    {npc = 3566, genre = {[17] = true, [19] = true}, menu = {"thực phẩm", "thuc pham", "thức ăn", "mua"}},
    {npc = 3564, genre = {[17] = true}, menu = {"dược phẩm", "duoc pham", "mua"}},
};
function M:BuyWork(s, it)
    local tag = it.tag;
    local item = itemTuple(tag.tbItemId);
    local need = num(tag.nNeedCount);
    if not item or need <= 0 then return nil; end
    local shops = self:ShopsFor(item, s.descTags);
    for _, t in ipairs(s.descTags or {}) do
        for _, sh in ipairs(self.SHOP_NPCS) do
            if t.kind == "npcpos" and t.npc == sh.npc and sh.genre[item[1]] then shops[#shops + 1] = sh; end
        end
    end
    for _, sh in ipairs(self.SHOP_NPCS) do
        local dup = false;
        for _, x in ipairs(shops) do if x == sh then dup = true; end end
        if not dup and sh.genre[item[1]] then shops[#shops + 1] = sh; end
    end
    if #shops == 0 then return nil; end
    return {kind = "buy", item = item, need = need, shops = shops, npc = shops[1].npc, map = 0, descTags = s.descTags,
        title = "Mua " .. self:Plain(tag.szItemName or it.desc) .. " x" .. need, key = s.key .. "/buy/" .. table.concat(item, ",")};
end

-- "Tìm thấy <vật phẩm>" làm được bằng kỹ năng sống (vd. Tầm Sư Học Nghệ 312: mua Đồng khoáng thạch thô ở Điềm Tửu Thúc,
-- gia công thành Thỏi đồng nhẹ, rồi chế Nhuyễn Đồng Kiếm). Phối phương đọc từ LifeSkill.tbRecipeDatas (client), làm bằng
-- me.DoRecipe(id) như nút Chế tạo của cửa sổ kỹ năng sống (uiProduce:MakeProduce). Thiếu nguyên liệu: nguyên liệu cũng chế
-- được thì chế trước; không thì mua ở NPC có <npcpos> trong mô tả bước (thầy dạy nghề) — lựa chọn cửa hàng theo nhóm hàng.
M.CRAFT_MENU = {"khoáng thạch", "khoáng", "da", "gỗ", "dược liệu", "vải", "nguyên liệu", "cửa hàng", "mua"};
local function sameItem(a, b)
    return a and b and num(a[1]) == num(b[1]) and num(a[2]) == num(b[2]) and num(a[3]) == num(b[3]) and
        (num(b[4]) <= 0 or num(a[4]) <= 0 or num(a[4]) == num(b[4]));
end
function M:CountItem(item)
    if not me.GetItemCountInBags then return 0; end
    local ok, n = pcall(me.GetItemCountInBags, item[1], item[2], item[3], item[4] > 0 and item[4] or nil);
    return ok and tonumber(n) or 0;
end
function M:LearnedRecipes()
    local ok, list = pcall(function() return me.GetRecipeList(); end);
    if not ok or type(list) ~= "table" then return nil; end
    local set = {};
    for _, id in pairs(list) do set[tonumber(id) or id] = true; end
    return set;
end
function M:RecipeFor(item, learned)
    local datas = LifeSkill and LifeSkill.tbRecipeDatas;
    if type(datas) ~= "table" then return nil; end
    local best;
    for id, r in pairs(datas) do
        local p = type(r.tbProductSet) == "table" and r.tbProductSet[1];
        if p and sameItem(p.tbItem, item) then
            if not learned or learned[id] then return id, r; end
            best = best or {id, r};
        end
    end
    if best then return best[1], best[2]; end
end
function M:CraftWork(s, it)
    local item = itemTuple(it.tag.tbItemId);
    local need = num(it.tag.nNeedCount);
    if not item or need <= 0 then return nil; end
    local learned = self:LearnedRecipes();
    local teachers = {};
    for _, t in ipairs(s.descTags or {}) do
        if t.kind == "npcpos" then teachers[#teachers + 1] = {npc = t.npc, genre = {[item[1]] = true}, menu = self.CRAFT_MENU}; end
    end
    local function plan(target, count, depth)
        local have = self:CountItem(target);
        if have >= count then return nil; end
        local id, r = self:RecipeFor(target, learned);
        if not id then return nil; end
        if learned and not learned[id] then
            return {kind = "stop", reason = "Bước " .. s.nCurStep .. " cần chế " .. self:Plain(r.Name or "") .. " nhưng nhân vật chưa học phối phương " .. id .. "."};
        end
        local makes = count - have;
        for _, st in ipairs(r.tbStuffSet or {}) do
            local n = num(st.nCount);
            local sid = itemTuple(st.tbItem);
            if n > 0 and sid then
                local want = n * makes;
                if self:CountItem(sid) < want then
                    local sub = depth < 3 and plan(sid, want, depth + 1);
                    if sub then return sub; end
                    local shops = self:ShopsFor(sid, s.descTags);
                    for _, t in ipairs(teachers) do shops[#shops + 1] = {npc = t.npc, genre = {[sid[1]] = true}, menu = t.menu}; end
                    if #shops == 0 then
                        return {kind = "stop", reason = "Bước " .. s.nCurStep .. " thiếu nguyên liệu (" .. table.concat(sid, ",") .. ") x" .. want ..
                            " để chế " .. self:Plain(r.Name or "") .. "; hãy mua rồi Lưu và Bắt Đầu lại."};
                    end
                    return {kind = "buy", item = sid, need = want, shops = shops, npc = shops[1].npc, map = 0, descTags = s.descTags,
                        title = "Mua nguyên liệu (" .. table.concat(sid, ",") .. ") x" .. want .. " để chế " .. self:Plain(r.Name or ""),
                        key = s.key .. "/buy/" .. table.concat(sid, ",")};
                end
            end
        end
        local skill = LifeSkill.tbLifeSkillDatas and LifeSkill.tbLifeSkillDatas[r.Belong];
        local gene = skill and tonumber(skill.Gene);
        local cost = num(r.Cost);
        if cost > 0 and gene == 1 and num(me.dwCurGTP) < cost then
            return {kind = "stop", reason = "Không đủ Hoạt lực để gia công " .. self:Plain(r.Name or "") .. " (cần " .. cost .. ")."};
        elseif cost > 0 and gene == 0 and num(me.dwCurMKP) < cost then
            return {kind = "stop", reason = "Không đủ Tinh lực để chế tạo " .. self:Plain(r.Name or "") .. " (cần " .. cost .. ")."};
        end
        return {kind = "craft", recipe = id, item = target, need = count, makeTime = num(r.MakeTime), descTags = s.descTags,
            teachers = teachers, title = (gene == 1 and "Gia công " or "Chế tạo ") .. self:Plain(r.Name or "") .. " x" .. makes,
            key = s.key .. "/craft/" .. id};
    end
    return plan(item, need, 0);
end

-- Điều kiện kết thúc bước (tbJudge) có TaskCond:HaveRoute mà chưa đạt → cần chọn hệ (SimBot: cộng 1 điểm kỹ năng cấp 20 của hệ).
function M:RouteBlocked(s)
    local judge = s.step and s.step.tbJudge;
    if type(judge) ~= "table" then return false; end
    local text = "";
    for _, f in ipairs(judge) do
        if type(f) == "table" then for _, v in ipairs(f) do text = text .. " " .. tostring(v); end else text = text .. " " .. tostring(f); end
    end
    if not string.find(text, "HaveRoute", 1, true) and not (TaskCond and TaskCond.HaveRoute and string.find(text, tostring(TaskCond.HaveRoute), 1, true)) then
        return false, false;
    end
    if Lib and Lib.DoTestFuncs then
        local ok, v = pcall(Lib.DoTestFuncs, Lib, judge);
        if ok and v and v ~= 0 then return false, true; end
    end
    return true, true;
end

function M:WorkFor(s, item)
    local tag, kind = item.tag, item.kind;
    local base = {kind = kind, tag = tag, item = item, descTags = s.descTags, title = item.desc, key = s.key .. "/" .. item.index};
    local function with(t) for k, v in pairs(t) do base[k] = v; end return base; end
    local function options(opt)
        local list = {};
        if type(opt) == "string" and opt ~= "" and opt ~= "<subtaskname>" then list[#list + 1] = opt; end
        list[#list + 1] = s.szReferName;
        return list;
    end
    if kind == "talk" or kind == "quiz" then
        if item.name == "GivePlayerItem" and me.CountFreeBagCell() < 1 then
            return {kind = "stop", reason = "Cần ít nhất 1 ô trống để nhận vật phẩm nhiệm vụ."};
        end
        return with({npc = num(tag.nNpcTempId), map = num(tag.nMapId), options = options(tag.szOption),
            give = item.name == "GiveItem" and tag.ItemList or nil});
    elseif kind == "send2aim" then
        local aimMap = num(tag.nAimMapId);
        if aimMap > 0 and me.GetWorldPos() == aimMap and aimMap ~= num(tag.nNpcMapId) then
            return with({kind = "move", point = {map = aimMap, x = num(tag.nAimPosX), y = num(tag.nAimPosY),
                r = math.max(2, num(tag.nRange)), name = tag.szStaticDesc}});
        end
        local opts = options(tag.szOption);
        return with({kind = "talk", npc = num(tag.nNpcTempId), map = num(tag.nNpcMapId), options = opts,
            confirm = {tag.szYesOpt}, waitMap = aimMap});
    elseif kind == "move" then
        return with({point = {map = num(tag.nMapId), x = num(tag.nPosX), y = num(tag.nPosY), r = math.max(2, num(tag.nR)),
            name = tag.szPosDesc}});
    elseif kind == "transform" then
        return with({fight = num(tag.nFightNpcTempId), dialog = num(tag.nDialogNpcTempId), npc = num(tag.nDialogNpcTempId),
            options = options(tag.szOption), map = num(tag.nMapId),
            point = {map = num(tag.nMapId), x = num(tag.nMapPosX), y = num(tag.nMapPosY), r = 4}});
    elseif kind == "process" then
        local spawns = {};
        for _, p in ipairs(type(tag.tbNpcSet) == "table" and tag.tbNpcSet or {}) do
            if num(p.nX) > 0 then spawns[#spawns + 1] = {map = num(tag.nMapId), x = num(p.nX), y = num(p.nY)}; end
        end
        return with({npc = num(tag.nNpcTempId), map = num(tag.nMapId), spawns = spawns});
    elseif kind == "useitem" then
        local areas = {};
        if item.name == "AddObj" then
            areas[1] = {map = num(tag.nMapId), x = num(tag.nPosX), y = num(tag.nPosY), r = math.max(1, num(tag.nR))};
        else
            for _, p in ipairs(type(tag.tbPos) == "table" and tag.tbPos or {}) do
                if num(p[2]) > 0 then areas[#areas + 1] = {map = num(p[1]), x = num(p[2]), y = num(p[3]), r = math.max(1, num(p[4]))}; end
            end
        end
        local here = me.GetWorldPos();
        table.sort(areas, function(a, b) return (a.map == here and 0 or 1) < (b.map == here and 0 or 1); end);
        return with({itemId = itemTuple(tag.tbItemId), areas = areas, point = areas[1]});
    elseif kind == "product" then
        local point = num(tag.nMapId) > 0 and {map = num(tag.nMapId), x = num(tag.nPosX), y = num(tag.nPosY), r = math.max(1, num(tag.nRange))} or nil;
        -- Máy chủ kiểm tra đủ nguyên liệu (tbStuffs) TRƯỚC khi mở thanh tiến trình; thiếu thì chỉ báo
        -- "Nguyên liệu không đủ!" → client đọc trước để báo rõ thay vì thử mãi.
        local stuffs = {};
        for _, st in ipairs(type(tag.tbStuffs) == "table" and tag.tbStuffs or {}) do
            local id = type(st) == "table" and itemTuple(st.tbItem);
            if id and num(st.nCount) > 0 then stuffs[#stuffs + 1] = {id = id, count = num(st.nCount)}; end
        end
        return with({itemId = {20, 1, num(tag.nToolParticular), 1}, point = point, areas = point and {point} or {},
            stuffs = #stuffs > 0 and stuffs or nil});
    elseif kind == "escort" then
        return with({npc = num(tag.nDialogNpcTempId), map = num(tag.nMapId), options = options(tag.szOption),
            mover = num(tag.nMoveNpcTempId), maxDistance = num(tag.nMaxDistance),
            point = {map = num(tag.nMapId), x = num(tag.nMapPosX), y = num(tag.nMapPosY), r = 4},
            aim = {map = num(tag.nMapId), x = num(tag.nAimX), y = num(tag.nAimY), r = math.max(2, num(tag.nAimR))}});
    elseif kind == "guard" then
        return with({npc = num(tag.nDialogNpcTempId), map = num(tag.nMapId), options = options(tag.szOption),
            protect = {[num(tag.nDialogNpcTempId)] = true, [num(tag.nFightNpcTempId)] = true},
            point = {map = num(tag.nMapId), x = num(tag.nMapPosX), y = num(tag.nMapPosY), r = 4},
            duration = num(tag.nGuardDuration)});
    end
    return base;
end

-- Gom mọi target đánh quái chưa xong của bước: mẫu rơi đồ (*4Item) trước, nhóm thường sau (SimBot TaskKillProgress 66).
function M:CombatWork(s, first)
    local itemized, plain = {}, {};
    for _, it in ipairs(s.tags) do
        if not it.done and it.kind == "combat" then
            local id = num(it.tag.nNpcTempId);
            if id > 0 then
                if it.tag.tbItemId then itemized[id] = it; else plain[id] = it; end
            end
        end
    end
    local kill = next(itemized) and itemized or plain;
    local ids, lead = {}, nil;
    for id, it in pairs(kill) do ids[id] = true; if not lead or it.index < lead.index then lead = it; end end
    lead = lead or first;
    local w = self:WorkFor(s, lead);
    w.kind, w.kill = "combat", ids;
    -- KillNpc4Item / KillNpc4NormalItem: máy chủ thả vật phẩm XUỐNG ĐẤT ở chỗ quái chết (Task:AddObjAtPos) → phải nhặt.
    -- KillBoss4Item thì máy chủ cho thẳng vào túi, không cần nhặt.
    local pick = {};
    for _, it in pairs(kill) do
        if it.name == "KillNpc4Item" or it.name == "KillNpc4NormalItem" then
            local id = itemTuple(it.tag.tbItemId);
            if id then pick[#pick + 1] = id; end
        end
    end
    w.pick = #pick > 0 and pick or nil;
    w.npc = num(lead.tag.nNpcTempId);
    w.map = num(lead.tag.nMapId);
    return w;
end

-- Danh sách tuyến chính tuyến cho combo: đang nhận (kèm chặng / bước) + chưa nhận nhưng nhận được.
function M:TaskChoices()
    local out, seen = {}, {};
    for _, s in ipairs(self:ReadMainTasks() or {}) do
        seen[s.nTaskId] = true;
        local step = s.nCurStep == -1 and "trả thưởng" or ("bước " .. s.nCurStep .. "/" .. (s.nSteps > 0 and s.nSteps or "?"));
        out[#out + 1] = {id = s.nTaskId, label = self:Plain(s.szTaskName) .. " — " .. self:Plain(s.szReferName) .. " (" .. step .. ")"};
    end
    for _, r in ipairs((self:AcceptableRefers())) do
        if not seen[r.nTaskId] then
            seen[r.nTaskId] = true;
            out[#out + 1] = {id = r.nTaskId, label = self:Plain(r.szTaskName) .. " — nhận: " .. self:Plain(r.szReferName)};
        end
    end
    table.sort(out, function(a, b) return a.id < b.id; end);
    return out;
end

function M:AcceptWork(options, lock)
    local list, hiddenLevel = self:AcceptableRefers();
    if lock then
        local only = {};
        for _, r in ipairs(list) do if r.nTaskId == lock then only[1] = r; end end
        list = only;
        if not list[1] then
            local name = Task and Task.GetTaskName and Task:GetTaskName(lock) or tostring(lock);
            return {kind = "none", reason = "Tuyến " .. self:Plain(name) .. " không còn chặng nào làm / nhận được lúc này (đang Giữ tuyến). Bỏ tick Giữ tuyến hoặc chọn tuyến khác."};
        end
    end
    local nextRefer = list[1];
    if not nextRefer then
        if hiddenLevel then
            return {kind = "lowlevel", level = hiddenLevel, reason = "Chặng chính tuyến kế tiếp cần cấp " .. hiddenLevel .. " (hiện " .. tostring(me.nLevel) .. ")."};
        end
        return {kind = "none", reason = "Không có nhiệm vụ chính tuyến đang nhận hoặc có thể nhận."};
    end
    if options.accept ~= 1 then
        return {kind = "none", reason = "Chưa nhận chặng " .. self:Plain(nextRefer.szReferName) .. " (đang tắt Tự nhận chặng kế tiếp)."};
    end
    return {kind = "accept", npc = nextRefer.npc, map = 0, descTags = nextRefer.descTags,
        options = {"[Nhiệm vụ] " .. nextRefer.szReferName, nextRefer.szReferName},
        title = "Nhận chặng " .. nextRefer.szReferName, key = "accept/" .. nextRefer.nReferId, accept = nextRefer,
        taskId = nextRefer.nTaskId};
end

function M:NextWork(s, options)
    if not s then return self:AcceptWork(options); end
    if s.nCurStep == -1 then
        local npc = num(s.refer.nReplyNpcId);
        if npc <= 0 and s.task.tbSubData and s.task.tbSubData.tbSteps then
            local steps = s.task.tbSubData.tbSteps;
            local last = steps[#steps];
            if last and last.tbEvent and last.tbEvent.nType == 1 then npc = num(last.tbEvent.nValue); end
        end
        if npc <= 0 then return {kind = "stop", reason = "Không xác định được NPC trả thưởng."}; end
        local need = num(s.refer.nBagSpaceCount);
        if need > 0 and me.CountFreeBagCell() < need then
            return {kind = "stop", reason = "Cần " .. need .. " ô trống trong túi để nhận thưởng " .. s.szReferName .. "."};
        end
        return {kind = "award", npc = npc, map = 0, descTags = self:ParseTags(s.refer.szReplyDesc),
            options = {s.szReferName .. "-Nhận thưởng"}, title = "Nhận thưởng " .. s.szReferName, key = s.key .. "/award"};
    end
    -- Lượt 1: việc làm được (AddObj chờ đánh quái xong như SimBot); lượt 2: cần vật phẩm; lượt 3: chờ.
    local combatLeft = false;
    for _, it in ipairs(s.tags) do if not it.done and it.kind == "combat" then combatLeft = true; end end
    local waiting, search;
    for _, it in ipairs(s.tags) do
        if not it.done then
            local kind = it.kind;
            if kind == "combat" then
                if options.combat ~= 1 then
                    return {kind = "unsupported", item = it, reason = "Bước " .. s.nCurStep .. " cần đánh quái (" .. self:Plain(it.desc) ..
                        ") nhưng ô Đánh quái nhiệm vụ đang tắt; hãy bật lại rồi Lưu và Bắt Đầu."};
                end
                return self:CombatWork(s, it);
            elseif kind == "useitem" and it.name == "AddObj" and combatLeft then
                -- để sau
            elseif kind == "wait" then waiting = waiting or it;
            elseif kind == "search" then search = search or it;
            elseif kind == "manual" then
                return {kind = "stop", reason = "Bước " .. s.nCurStep .. " cần bạn tự chọn: " .. self:Plain(it.desc) .. "."};
            elseif kind == "unknown" then
                return {kind = "unsupported", item = it, reason = "Bước " .. s.nCurStep .. " có loại việc chưa biết (" .. it.name .. "): " ..
                    self:Plain(it.desc) .. ". Hãy tự làm bước này rồi Lưu và Bắt Đầu lại."};
            elseif kind ~= "info" then
                if (kind == "escort" or kind == "guard") and options.combat ~= 1 then
                    return {kind = "unsupported", item = it, reason = "Bước " .. s.nCurStep .. " cần hộ tống / bảo vệ (phải đánh quái); hãy bật Đánh quái nhiệm vụ."};
                end
                return self:WorkFor(s, it);
            end
        end
    end
    for _, it in ipairs(s.tags) do
        if not it.done and it.kind == "useitem" then return self:WorkFor(s, it); end
    end
    if search then
        local buy = self:BuyWork(s, search);
        if buy then return buy; end
        local craft = self:CraftWork(s, search);
        if craft then return craft; end
        return {kind = "stop", item = search, reason = "Bước " .. s.nCurStep .. " cần có vật phẩm: " .. self:Plain(search.desc) ..
            ". Hãy kiếm / mua đủ rồi Lưu và Bắt Đầu lại."};
    end
    if waiting then
        local tag = waiting.tag;
        if waiting.name == "PlayerLevelUp" then
            return {kind = "lowlevel", level = num(tag.nLevel), item = waiting,
                reason = ((tonumber(me.nLevel) or 0) >= num(tag.nLevel) and "Đã đủ cấp " or "Cần đạt cấp ") .. tostring(tag.nLevel) .. " (hiện " .. tostring(me.nLevel) .. ")."};
        end
        return {kind = "wait", item = waiting, reason = "Đang chờ: " .. self:Plain(waiting.desc)};
    end
    if self:RouteBlocked(s) then
        return {kind = "stop", reason = "Bước " .. s.nCurStep .. " cần chọn hệ (nhánh) môn phái. Hãy tự chọn hệ trong bảng kỹ năng rồi Lưu và Bắt Đầu lại."};
    end
    -- Mọi target đã xong: bước mở bằng NPC (tbEvent.nType == 1) cần nói chuyện NPC đó; nType 2 = dùng vật phẩm.
    local event = s.step and s.step.tbEvent;
    if event and event.nType == 1 then
        return {kind = "event", npc = num(event.nValue), map = 0, options = {s.szReferName},
            descTags = s.descTags, title = "Báo cáo bước " .. s.nCurStep, key = s.key .. "/event"};
    elseif event and event.nType == 2 then
        return {kind = "useitem", itemId = {20, 1, num(event.nValue), 1}, areas = {}, descTags = s.descTags,
            title = "Dùng vật phẩm để mở bước " .. s.nCurStep, key = s.key .. "/event"};
    end
    local _, routeHint = self:RouteBlocked(s);
    return {kind = "settle", reason = "Đã đủ mục tiêu; chờ máy chủ chuyển bước.", key = s.key .. "/settle", routeHint = routeHint};
end

-- ---------------------------------------------------------------- chọn đích (thứ tự như Task.AutoTest)
-- 1 thẻ có tên khớp NPC · 2 npcpos đúng mã NPC · 3 pos gần toạ độ target · 4 thẻ duy nhất · 5 KNpc.ClientGetNpcPos
-- Bản đồ dạng chữ ("new", "l5", "l15", "s1"…): chọn bản đồ CÙNG CỘT với bản đồ đang đứng trong setting/map/mapid_level.txt
-- (SimBot TaskPublishCatalog 1031-1073); không xác định được cột thì dùng tbAutoPath:GetMapId (gần nhất theo đường).
function M:MapColumn(mapId)
    local types = Map and Map.tbTypeMap;
    if type(types) ~= "table" then return nil; end
    for _, list in pairs(types) do
        for i, id in ipairs(list) do if id == mapId then return i; end end
    end
end

function M:ResolveMap(varMap)
    local n = tonumber(varMap);
    if n then
        if n == 0 then return (me.GetWorldPos()); end
        return n;
    end
    local list = Map and Map.tbTypeMap and Map.tbTypeMap[varMap];
    local column = self:MapColumn(me.GetWorldPos());
    if list and column and list[column] then return list[column]; end
    local path = Ui.tbLogic and Ui.tbLogic.tbAutoPath;
    if path and path.GetMapId then
        local ok, map = pcall(path.GetMapId, path, varMap);
        if ok and tonumber(map) and map > 0 then return map; end
    end
end

function M:NpcPoint(map, npc)
    if not map or map <= 0 or not npc or npc <= 0 or not KNpc.ClientGetNpcPos then return nil; end
    local ok, x, y = pcall(KNpc.ClientGetNpcPos, map, npc);
    if ok and type(x) == "number" and type(y) == "number" and x > 0 and y > 0 then
        return {map = map, x = x, y = y};
    end
end

function M:TagPoint(t, npc)
    if t.kind == "pos" then return {map = t.map, x = t.x, y = t.y, name = t.name}; end
    local map = self:ResolveMap(t.varMap);
    local p = map and self:NpcPoint(map, t.npc or npc);
    if p then p.name = t.name; end
    return p;
end

-- Thứ tự (SimBot AutoTaskAgent 600-616: NPC của TARGET luôn thắng NPC chỉ được nhắc trong mô tả):
-- 1 thẻ có tên khớp NPC target · 2 npcpos đúng mã NPC · 3 toạ độ tĩnh của NPC (map target / map của thẻ / map hiện tại)
-- 4 thẻ pos gần toạ độ target · 5 thẻ duy nhất.
function M:PickDestination(work)
    local tags = work.descTags or {};
    local npc = tonumber(work.npc) or 0;
    local npcName;
    if npc > 0 and KNpc.GetNameByTemplateId then
        local ok, name = pcall(KNpc.GetNameByTemplateId, npc);
        if ok and type(name) == "string" and name ~= "" then npcName = self:Clean(name); end
    end
    local function try(t) local p = self:TagPoint(t, npc); if p then return p; end end
    if npcName then
        for _, t in ipairs(tags) do
            local n = self:Clean(t.name);
            if n ~= "" and (self:Contains(n, npcName) or self:Contains(npcName, n)) then
                local p = try(t); if p then p.how = "name"; return p; end
            end
        end
    end
    if npc > 0 then
        for _, t in ipairs(tags) do
            if t.kind == "npcpos" and t.npc == npc then local p = try(t); if p then p.how = "npcid"; return p; end end
        end
        local maps, seen = {}, {};
        local function add(m) if m and m > 0 and not seen[m] then seen[m] = true; maps[#maps + 1] = m; end end
        add(tonumber(work.map));
        for _, t in ipairs(tags) do
            if t.kind == "pos" then add(t.map); else add(self:ResolveMap(t.varMap)); end
        end
        add((me.GetWorldPos()));
        for _, m in ipairs(maps) do
            local p = self:NpcPoint(m, npc);
            if p then p.how = "static"; return p; end
        end
        local p = self:FindNpcAnyMap(npc);
        if p then p.how = "anymap"; return p; end
    end
    local target = work.point;
    if target and target.map and target.map > 0 then
        for _, t in ipairs(tags) do
            if t.kind == "pos" and t.map == target.map and
                math.abs(t.x - target.x) <= 16 and math.abs(t.y - target.y) <= 24 then
                local p = try(t); if p then p.how = "pos"; return p; end
            end
        end
        if target.x and target.x > 0 then
            return {map = target.map, x = target.x, y = target.y, how = "target"};
        end
    end
    if #tags == 1 then local p = try(tags[1]); if p then p.how = "only"; return p; end end
end

-- NPC không có thẻ và không ở bản đồ đã biết (vd NPC nhận chặng kế tiếp): dò toạ độ tĩnh trên mọi bản đồ trong
-- mapid_level (Map.tbTypeMap) + bản đồ 1..29; ưu tiên cùng cột domain với nơi đang đứng. Có bộ nhớ đệm.
M.npcMapCache = M.npcMapCache or {};
function M:FindNpcAnyMap(npc)
    local cached = self.npcMapCache[npc];
    if cached ~= nil then return cached or nil; end
    local maps, seen = {}, {};
    local function add(m) m = tonumber(m); if m and m > 0 and not seen[m] then seen[m] = true; maps[#maps + 1] = m; end end
    local column = self:MapColumn(me.GetWorldPos());
    local types = Map and Map.tbTypeMap or {};
    if column then for _, list in pairs(types) do add(list[column]); end end
    for _, list in pairs(types) do for _, m in ipairs(list) do add(m); end end
    for m = 1, 29 do add(m); end
    for _, m in ipairs(maps) do
        local p = self:NpcPoint(m, npc);
        if p then self.npcMapCache[npc] = p; return {map = p.map, x = p.x, y = p.y}; end
    end
    self.npcMapCache[npc] = false;
end

-- ---------------------------------------------------------------- vật phẩm trong túi
function M:FindBagItem(itemId)
    if type(itemId) ~= "table" or not me.FindItemInBags then return nil; end
    local l = tonumber(itemId[4]) or 0;
    local rows = me.FindItemInBags(itemId[1], itemId[2], itemId[3], l > 0 and l or nil) or {};
    for _, row in ipairs(rows) do
        if row.pItem then return row.pItem; end
    end
end

-- ---------------------------------------------------------------- quái đánh được
-- pNpc trên Game.exe là userdata: đọc trường lạ qua pcall để không văng lỗi.
local function field(o, k)
    local ok, v = pcall(function() return o[k]; end);
    if ok then return v; end
end
M.Field = field;

function M:Attackable(npc)
    if not npc then return false; end
    local life = field(npc, "nCurLife");
    if life ~= nil and tonumber(life) and tonumber(life) <= 0 then return false; end
    if (tonumber(field(npc, "nDoing")) or 0) == 10 then return false; end
    if AutoAi.AiTargetCanAttack then
        local ok, v = pcall(AutoAi.AiTargetCanAttack, npc.nIndex);
        if ok and v ~= nil then return v == 1; end
    end
    local kind = tonumber(field(npc, "nKind"));
    return kind == nil or kind == 0;
end

-- Quái gần nhất trong vùng (tâm/bán kính toạ độ thế giới). ids = {mã mẫu = true} hoặc nil (mọi quái đánh được);
-- avoid = {mã mẫu = true} không bao giờ đánh (NPC hộ tống / bảo vệ).
function M:NearestFoe(ids, center, radius, avoid)
    local x, y = me.GetNpc().GetMpsPos();
    local best, bestD;
    for _, npc in pairs(KNpc.GetAroundNpcList(me, 400) or {}) do      -- tầm quét như Auto6 SelectTarget
        local isPlayer = (tonumber(field(npc, "bPlayer")) or 0) == 1 or field(npc, "bPlayer") == true or tonumber(field(npc, "nKind")) == 1;
        if npc and not isPlayer then
            local tid = tonumber(field(npc, "nTemplateId")) or 0;
            if (not ids or ids[tid]) and not (avoid and avoid[tid]) and self:Attackable(npc) then
                local nx, ny = npc.GetMpsPos();
                local inArea = true;
                if center and radius then
                    inArea = (nx / 32 - center.x) ^ 2 + (ny / 32 - center.y) ^ 2 <= radius * radius;
                end
                if inArea then
                    local d = (nx - x) ^ 2 + (ny - y) ^ 2;
                    if not bestD or d < bestD then best, bestD = npc, d; end
                end
            end
        end
    end
    return best, bestD and math.sqrt(bestD);
end

-- ---------------------------------------------------------------- NPC quanh mình
-- pNpc trên Game.exe là USERDATA (không phải table) → không kiểm type. Khớp theo mã mẫu; dự phòng khớp tên mẫu.
-- Quét tầm gần trước (như tbAutoPath:CBNpc dùng 20), rộng dần.
function M:FindNpc(id)
    id = tonumber(id) or 0;
    if id <= 0 then return nil; end
    local name;
    if KNpc.GetNameByTemplateId then
        local ok, v = pcall(KNpc.GetNameByTemplateId, id);
        if ok and type(v) == "string" and v ~= "" then name = v; end
    end
    local x, y = me.GetNpc().GetMpsPos();
    local seen = 0;
    for _, range in ipairs({40, 200, 1000}) do
        local closest, distance;
        local list = KNpc.GetAroundNpcList(me, range);
        for _, npc in pairs(list or {}) do
            if npc then
                seen = seen + 1;
                local ok, tid, nm = pcall(function() return npc.nTemplateId, npc.szName; end);
                if ok and (tonumber(tid) == id or (name and nm == name and (tonumber(tid) or 0) <= 0)) and (npc.nDoing or 0) ~= 10 then
                    local nx, ny = npc.GetMpsPos();
                    local d = (nx - x) ^ 2 + (ny - y) ^ 2;
                    if not distance or d < distance then closest, distance = npc, d; end
                end
            end
        end
        if closest then return closest, math.sqrt(distance); end
    end
    self.lastScan = seen;
    return nil;
end

-- ---------------------------------------------------------------- câu hỏi (task_question_lib.txt qua tbQLib của target)
-- Nhiều câu có cùng chữ ("Hình này biểu thị?") và chỉ khác hình <pic:...>: lọc theo chữ, rồi theo 4 đáp án phải có trong
-- danh sách lựa chọn, rồi theo hình. Còn nhiều câu với đáp án đúng khác nhau → không đoán (trả nil).
local function picKey(s)
    s = string.lower(tostring(s or ""));
    s = string.gsub(s, "/", "\\");
    return (string.gsub(s, "^%s*(.-)%s*$", "%1"));
end

function M:QuizAnswer(tag, question, options)
    local lib = type(tag) == "table" and tag.tbQLib;
    if type(lib) ~= "table" then return nil; end
    local raw = tostring(question or "");
    local q = self:Clean(raw);
    local _, _, pic = string.find(raw, "<pic:([^>]*)>");
    local have = {};
    for _, o in ipairs(options or {}) do have[self:Clean(o)] = true; end
    local answer, conflict;
    for _, row in pairs(lib) do
        local content = self:Clean(row.szQuestionContent);
        if content ~= "" and self:Contains(q, content) then
            local answers = {row.szAnswer_A, row.szAnswer_B, row.szAnswer_C, row.szAnswer_D};
            local all = options ~= nil;
            for _, a in ipairs(answers) do if options and not have[self:Clean(a)] then all = false; end end
            local picOk = not pic or not row.szPic or row.szPic == "" or picKey(row.szPic) == picKey(pic);
            local idx = tonumber(row.nCorrectIdx);
            local correct = idx and answers[idx] and self:Clean(answers[idx]);
            if correct and (all or not options) and picOk then
                if answer and answer ~= correct then conflict = true; end
                answer = answer or correct;
            end
        end
    end
    if conflict then return nil; end
    return answer;
end

-- ---------------------------------------------------------------- điểm xuất hiện quái (wjxct_spawns.lua)
-- Trả danh sách {x,y} của các mẫu quái cần đánh trên bản đồ, sắp theo khoảng cách tới điểm tham chiếu; nil nếu chưa có dữ liệu.
-- Cổng nhiệm vụ (setting\map\transmit.txt, Type = "task"): bước vào ô cổng khi đang làm đúng bước nhiệm vụ thì máy chủ
-- chuyển sang bản đồ nhiệm vụ (vd. Hán Thủy Cổ Độ 88 → Soái Trướng Hổ Sư 509). Tự tìm đường của game không đi qua loại cổng này.
function M:TaskTraps()
    if self.taskTraps then return self.taskTraps; end
    local list = {};
    local ok, rows = pcall(Lib.LoadTabFile, Lib, "\\setting\\map\\transmit.txt");
    if ok and type(rows) == "table" then
        for _, r in ipairs(rows) do
            local from, to, x, y = tonumber(r.FromMapId), tonumber(r.ToMapId), tonumber(r.FromPosX), tonumber(r.FromPosY);
            if r.Type == "task" and from and to and x and y and from ~= to then
                list[#list + 1] = {from = from, to = to, x = math.floor(x / 32), y = math.floor(y / 32),
                    tx = math.floor((tonumber(r.ToPosX) or 0) / 32), ty = math.floor((tonumber(r.ToPosY) or 0) / 32)};
            end
        end
    end
    self.taskTraps = list;
    return list;
end

-- Bản đồ nhiệm vụ (maplist: MapType taskfight / tasksafe) — chỉ vào được qua cổng / NPC, không có đường thường.
function M:IsTaskMap(map)
    if not self.taskMaps then
        local set = {};
        local ok, rows = pcall(Lib.LoadTabFile, Lib, "\\setting\\map\\maplist.txt");
        if ok and type(rows) == "table" then
            for _, r in ipairs(rows) do
                local id = tonumber(r.TemplateId);
                if id and type(r.MapType) == "string" and string.sub(r.MapType, 1, 4) == "task" then set[id] = true; end
            end
        end
        self.taskMaps = set;
    end
    return self.taskMaps[tonumber(map) or 0] == true;
end

-- Cổng nhiệm vụ dẫn vào bản đồ nhiệm vụ `map` (ưu tiên cổng ở bản đồ `near`).
function M:TrapTo(map, near)
    if not self:IsTaskMap(map) then return nil; end
    local best;
    for _, r in ipairs(self:TaskTraps()) do
        if r.to == map and (not best or r.from == near) then best = r; end
    end
    return best;
end

-- Quái / NPC mục tiêu không có ở bản đồ `from` nhưng có ở bản đồ nhiệm vụ sau 1 cổng từ `from`: trả (cổng, toạ độ NPC).
function M:TrapTarget(from, ids)
    for pass = 1, 2 do                       -- lượt 1: cổng ngay ở bản đồ mô tả; lượt 2: mọi cổng nhiệm vụ
        for _, r in ipairs(self:TaskTraps()) do
            if (pass == 2 or r.from == from) and self:IsTaskMap(r.to) then
                for id in pairs(ids) do
                    local p = self:NpcPoint(r.to, id);
                    if p then return r, p; end
                end
            end
        end
    end
end

-- Bãi quái của mục tiêu khi bản đồ mô tả không có nó: tìm trong mọi bản đồ đã biết điểm xuất hiện (SPAWNS).
-- Nhiều bản đồ: ưu tiên bản đồ có tên nằm trong mô tả mục tiêu (vd "Đánh bại Hán Thủy Cổ Độ - Kết Doanh Binh" → 88),
-- rồi tới bản đồ có nhiều điểm nhất.
function M:SpawnMap(kill, text)
    local best, bestScore;
    local clean = self:Clean(text or "");
    for map, byTpl in pairs(self.SPAWNS or {}) do
        local count = 0;
        for tid in pairs(kill or {}) do count = count + #(byTpl[tid] or {}); end
        if count > 0 then
            local score = count;
            local name = type(GetMapNameFormId) == "function" and GetMapNameFormId(map) or nil;
            if type(name) == "string" and name ~= "" and self:Contains(clean, self:Clean(name)) then score = score + 100000; end
            if not best or score > bestScore then best, bestScore = map, score; end
        end
    end
    return best;
end

function M:SpawnPoints(map, kill, ref)
    local byTpl = self.SPAWNS and self.SPAWNS[tonumber(map) or 0];
    if not byTpl or type(kill) ~= "table" then return nil; end
    local list = {};
    for tid in pairs(kill) do
        for _, p in ipairs(byTpl[tid] or {}) do list[#list + 1] = {x = p[1], y = p[2]}; end
    end
    if #list == 0 then return nil; end
    local rx, ry = ref and ref.x, ref and ref.y;
    if not rx then local _, x, y = me.GetWorldPos(); rx, ry = x, y; end
    table.sort(list, function(a, b) return (a.x - rx) ^ 2 + (a.y - ry) ^ 2 < (b.x - rx) ^ 2 + (b.y - ry) ^ 2; end);
    return list;
end
