-- Auto Chính Tuyến — CONTROLLER: máy trạng thái chạy bằng Timer, móc SAYPANEL / ITEMGIFT, xử lý GUTTALK / GUTAWARD,
-- đánh quái, thu thập, dùng vật phẩm, hộ tống. Mọi thao tác đi qua hàm người chơi dùng (AutoAi.SetTargetIndex,
-- OnListSel, OnButtonClick, me.UseItem, tbAutoPath:GotoPos, me.StartAutoPath); không gọi Task:Active/SetCurStep/
-- GoNextStep/SetTask/DoAccept, không gửi KTask.* khi cửa sổ chưa mở. Thông báo không chứa tên nhân vật.
-- Cơ chế đánh quái / thu thập / hộ tống tham khảo SimBot C# (AutoTaskAgent, TaskKillProgress, TaskItemUse…), đổi sang
-- thao tác của client.
if not Ui.WJXMainQuest or not Ui.WJXMainQuest.loading then return; end
local M = Ui.WJXMainQuest;
M.TICK = 9;                 -- 0,5 giây (Env.GAME_FPS = 18)
M.FIGHT_RADIUS = 38;        -- bán kính bãi (toạ độ thế giới ≈ 1200 MPS như SimBot)
M.NO_PROGRESS = 180;        -- giây không tiến triển ở bãi / hộ tống → thử lại

M.IDLE_KINDS = {lowlevel = true, wait = true, settle = true, none = true, stop = true, unsupported = true};

local function visible(group)
    return group and UiManager:WindowVisible(group) == 1;
end

local function now() return GetTime(); end

function M:Phase(name, message)
    local j = self.job;
    if j.attacking and name ~= j.phase then
        j.attacking = nil;
        pcall(AutoAi.SetTargetIndex, 0);
    end
    if j.auto6 and name ~= j.phase then self:ReleaseAuto6(j); end
    j.phase, j.at = name, now();
    j.say, j.ownedSay = nil, nil;
    if message then self.status = message; end
end

function M:StopPath(j)
    local path = Ui.tbLogic.tbAutoPath;
    if j.path and path.tbGotoPos == j.path then path:StopGoto("ChinhTuyenStop"); end
    j.path = nil;
end

function M:Stop(reason)
    local j = self.job;
    self.job = nil;
    if self.timer then Ui.tbLogic.tbTimer:Close(self.timer); self.timer = nil; end
    if j then
        if j.transfer and Ui.WJXTransfer then pcall(Ui.WJXTransfer.Cancel, Ui.WJXTransfer, j.transfer); end
        pcall(M.StopPath, M, j);
        if j.attacking then pcall(AutoAi.SetTargetIndex, 0); end
        if j.auto6 then pcall(M.ReleaseAuto6, M, j); end
        local G = Ui.WJXGhepHT;
        if j.ghep and G and G.job == j.ghep then pcall(G.Stop, G, "Auto Chính Tuyến dừng"); end
        if j.ownedSay and visible(Ui.UI_SAYPANEL) then UiManager:CloseWindow(Ui.UI_SAYPANEL); end
        if j.gift and visible(Ui.UI_ITEMGIFT) then pcall(Ui(Ui.UI_ITEMGIFT).OnButtonClick, Ui(Ui.UI_ITEMGIFT), "BtnClose"); end
    end
    if reason then self:Message(reason); end
end

function M:Conflict()
    local old = Ui.tbClass and Ui.tbClass["NhiemVuChinhTuyen"];
    if old and old.state == 1 then return "Hãy tắt auto chính tuyến cũ (Ctrl+Shift+T) trước."; end
    local a, t, p, b = Ui.WJXAuto6, Ui.WJXTongKim, Ui.WJXParty, Ui.WJXCheckBoss;
    local own = self:OwnsAuto6();
    if a and a.session and not own then return "Dừng Auto6 / Theo Sau trước khi chạy Chính Tuyến."; end
    if t and (t.job or t.patrol) then return "Dừng Tống Kim trước khi chạy Chính Tuyến."; end
    if p and p.dispatch and p.dispatch.job then return "Dừng Điều Phối Tổ Đội trước khi chạy Chính Tuyến."; end
    if b and b.job then return "Dừng CheckBOSS trước khi chạy Chính Tuyến."; end
    if Ui.WJXMerchant and Ui.WJXMerchant.job then return "Dừng Thương Hội trước khi chạy Chính Tuyến."; end
    if Ui.WJXThief and Ui.WJXThief.job then return "Dừng Hải Tặc trước khi chạy Chính Tuyến."; end
    if Ui.WJXBaiHuTang and Ui.WJXBaiHuTang.job then return "Dừng Bạch Hổ Đường trước khi chạy Chính Tuyến."; end
    if me.nAutoFightState == 1 and not own then return "Tắt Tự Đánh trước khi chạy Chính Tuyến (auto tự đánh quái nhiệm vụ)."; end
end

function M:Install()
    if self.installed then return; end
    self.installed = true;
    local say = Ui(Ui.UI_SAYPANEL);
    local onSay = say.OnOpen;
    say.OnOpen = function(window, param, a, b)
        local result = onSay(window, param, a, b);     -- luôn để chuỗi hook cũ chạy trước
        local j = M.job;
        if j and j.owner == me.szName then
            if j.transfer and Ui.WJXTransfer then Ui.WJXTransfer:Capture(j.transfer, param);
            elseif (j.phase == "dialog" or j.phase == "ferrytalk" or j.phase == "buy" or j.phase == "trapstep") and j.sayUntil and now() <= j.sayUntil then
                j.say, j.ownedSay = param, true;
            end
        end
        return result;
    end;
    local gift = Ui(Ui.UI_ITEMGIFT);
    if gift and gift.OnOpen then
        local onGift = gift.OnOpen;
        gift.OnOpen = function(window, form, a, b)
            local result = onGift(window, form, a, b);
            local j = M.job;
            if j and j.phase == "dialog" and j.work and j.work.give and j.sayUntil and now() <= j.sayUntil + 10 then
                j.gift = form;
            end
            return result;
        end;
    end
end

-- ---------------------------------------------------------------- mượn Auto6 để đánh (cách CheckBOSS làm)
-- Không sửa / không lưu cài đặt Auto6: đọc cấu hình đã lưu "AutoFight", ghi đè vài cờ CHỈ cho phiên này
-- (tắt Theo Sau / Luyện Công / hậu cần / hồi sinh / quay lại), rồi AutoAi:UpdateCfg như CheckBOSS:StartCombat.
-- Auto6 dùng kỹ năng + thuốc + nhặt đồ theo cài đặt của bạn; Chính Tuyến chỉ chỉ định mục tiêu nhiệm vụ.
function M:OwnsAuto6(job)
    local j, a = job or self.job, Ui.WJXAuto6;
    return j and j.auto6 and a and a.session and a.active == j.auto6 and true or false;
end

function M:Auto6Config(options)
    local a = Ui.WJXAuto6;
    if not a or type(a.Normalize) ~= "function" or type(a.Copy) ~= "function" or not AutoAi.UpdateCfg then return nil, "chưa nạp Auto6"; end
    local ok, config = pcall(function()
        local c = a:Normalize(a:Copy(Ui(Ui.UI_AUTOFIGHT):Load("AutoFight") or {}));
        c.nAutoFight, c.nCombatEnabled, c.nPvpMode = 1, 1, 0;
        c.nFollow, c.nFollowLeader, c.nTrain, c.nAssistLeader = 0, 0, 0, 0;
        c.nSupply, c.nRevive, c.nDead, c.nCreateTeam, c.nJoin = 0, 0, 0, 0, 0;
        c.nLockTarget, c.nSkipNormal = 1, 0;       -- bám mục tiêu nhiệm vụ Chính Tuyến chỉ định
        c.nScanRange = (options and options.range) or M.RANGE_DEFAULT;   -- ô "Phạm vi" (như Bách Man Sơn)
        c.nDismount = (options and options.dismount == 0) and 0 or 1;   -- ô "Đánh dưới ngựa"
        -- Nhặt như Quân Doanh / Bách Man Sơn: bật nhặt bổ sung (Space) với bộ lọc rỗng nếu bạn chưa bật,
        -- giữ nguyên bộ lọc nếu đã bật; vật phẩm nhiệm vụ đang cần luôn được nhận (xem InstallPickFilter).
        c.nPickAll = 0;
        if c.nAutoEnhancePick ~= 1 then c.tbPickModes = {}; end
        c.nAutoEnhancePick = 1;
        return c;
    end);
    if not ok or type(config) ~= "table" then return nil, "không đọc được cài đặt Auto6"; end
    if type(a.SkillPreflight) == "function" then
        local okPre, valid, why = pcall(a.SkillPreflight, a, config, true);
        if not okPre or not valid then return nil, tostring(why or "Auto6 báo chưa có kỹ năng hợp lệ"); end
    end
    return config;
end

-- Bọc Auto6:Pickable (đúng cách bms_session InstallPatrolFilter): chỉ khi phiên Auto6 là của Chính Tuyến và
-- món vừa nhặt là vật phẩm nhiệm vụ của bước đang đánh thì nhận (1); mọi trường hợp khác giữ bộ lọc gốc.
function M:InstallPickFilter()
    local a = Ui.WJXAuto6;
    if self.pickFilterInstalled or not a or type(a.Pickable) ~= "function" then return; end
    self.pickFilterInstalled = true;
    local original = a.Pickable;
    a.Pickable = function(owner, item, x1, x2)
        local j = M.job;
        if j and item and j.work and j.work.pick and owner == Ui.WJXAuto6 and M:OwnsAuto6() then
            for _, id in ipairs(j.work.pick) do
                if item.nGenre == id[1] and item.nDetail == id[2] and item.nParticular == id[3] and
                    (id[4] <= 0 or item.nLevel == id[4]) then return 1; end
            end
        end
        return original(owner, item, x1, x2);
    end;
end

function M:UseAuto6(j, foe)
    local a = Ui.WJXAuto6;
    if j.auto6 then
        if not self:OwnsAuto6() then
            -- Auto6 tự tắt (bạn bấm F / đổi bản đồ / vào vùng an toàn): không bật lại trong lượt đánh này.
            j.auto6, j.auto6Off = nil, true;
            self:Message("Auto6 đã tắt giữa chừng; Chính Tuyến tự đánh bằng kỹ năng tay trái.");
            return false;
        end
    elseif j.auto6Off or j.auto6Tried then
        return false;
    else
        j.auto6Tried = true;
        local function fail(why)
            if not j.auto6Said then j.auto6Said = true; self:Message("Không bật được Auto6 (" .. why .. "); tự đánh bằng kỹ năng tay trái."); end
            return false;
        end
        if me.nFightState ~= 1 then return fail("nhân vật chưa ở trạng thái chiến đấu"); end
        if (a and a.session) or me.nAutoFightState == 1 then return fail("Auto6 / Tự Đánh khác đang chạy"); end
        local config, why = self:Auto6Config(j.options);
        if not config then return fail(why or "?"); end
        self:StopPath(j);
        if j.attacking then j.attacking = nil; pcall(AutoAi.SetTargetIndex, 0); end
        pcall(M.InstallPickFilter, M);
        local ok = pcall(AutoAi.UpdateCfg, AutoAi, config);
        if not ok or not a.session then return fail("Auto6 từ chối bật"); end
        j.auto6 = a.active;
    end
    local id = self.Field(foe, "dwId");
    if id and a.targetId ~= id then a.targetId = id; end
    return true;
end

function M:ReleaseAuto6(j)
    local a = Ui.WJXAuto6;
    local mine = self:OwnsAuto6(j);       -- M:Stop đã xoá self.job trước khi gọi: phải xét theo j
    j.auto6, j.auto6Tried, j.auto6Start = nil, nil, nil;     -- lần sau gặp quái được bật lại (trừ khi bạn đã tự tắt Auto6)
    if mine then pcall(a.Stop, a, "WJXCT_RELEASE"); end
end

-- ---------------------------------------------------------------- tự ghép Huyền Tinh khi túi còn ít ô (Auto Ghép HT)
-- Chỉ xét ở lúc "evaluate" (giữa 2 việc): bật Ghép HT + còn ≤ GHEP_FREE ô + có HT ghép được (đủ bạc) → nhả Auto6, dừng đường,
-- đi ghép (Vô Hạn Phù / đi bộ tới Dã Luyện Đại Sư) rồi làm tiếp. Không ghép được → làm tiếp như cũ (thiếu ô thì dừng như cũ).
M.GHEP_FREE = 5;
function M:GhepOpt(j)
    local o = j.options;
    return {target = o.ghepLv or 5, onlyBind = o.ghepBind or 1, bindMoney = o.ghepBindMoney or 1, owner = "Chính Tuyến", minFree = 1};
end

function M:GhepGate(j)
    local G = Ui.WJXGhepHT;
    if j.options.ghep ~= 1 or not G or type(G.Start) ~= "function" or G:Busy() then return false; end
    if j.ghepNext and now() < j.ghepNext then return false; end
    if G:FreeCells() > self.GHEP_FREE then return false; end
    if visible(Ui.UI_SAYPANEL) or visible(Ui.UI_SKILLPROGRESS) or visible(Ui.UI_SHOP) then return false; end
    j.ghepNext = now() + 30;
    local opt = self:GhepOpt(j);
    local okN, n = pcall(G.CanMerge, G, opt);
    if not okN or (tonumber(n) or 0) <= 0 then return false; end
    pcall(M.StopPath, M, j);
    if j.attacking then pcall(AutoAi.SetTargetIndex, 0); j.attacking = nil; end
    if j.auto6 then pcall(M.ReleaseAuto6, M, j); end
    if me.nAutoFightState == 1 then pcall(AutoAi.ProcessHandCommand, "auto_fight", 0); end
    local ok, why = G:Start(opt, function(r) M:GhepDone(j, r); end);
    if not ok then
        j.ghepNext = now() + 600;
        self:Message("Chưa ghép Huyền Tinh được: " .. tostring(why));
        return false;
    end
    j.ghep = G.job;
    self:Phase("ghep", "Hành trang còn " .. G:FreeCells() .. " ô: đi ghép Huyền Tinh lên cấp " .. opt.target .. " rồi làm tiếp.");
    self:Message(self.status);
    return true;
end

function M:GhepDone(j, r)
    if self.job ~= j then return; end
    j.ghep = nil;
    j.ghepNext = now() + ((r and r.ok) and 60 or 600);
    if r and r.why == Ui.WJXGhepHT.USER_MOVE then
        self:Stop("Dừng Auto Chính Tuyến: bạn tự di chuyển trong lúc đi ghép Huyền Tinh.");
        return;
    end
    if not (r and r.ok) then self:Message("Ghép Huyền Tinh chưa xong (" .. tostring(r and r.why) .. "); làm tiếp chính tuyến."); end
    j.phase = "evaluate";
end

-- ---------------------------------------------------------------- bắt đầu
function M:Start(raw)
    local conflict = self:Conflict();
    if conflict then self:Message(conflict); return false; end
    for _, group in ipairs({Ui.UI_SAYPANEL, Ui.UI_ITEMGIFT, Ui.UI_SHOP, Ui.UI_GUTAWARD, Ui.UI_GUTTALK, Ui.UI_SKILLPROGRESS}) do
        if visible(group) then self:Message("Đóng hội thoại / cửa hàng hoặc chờ tiến trình xong rồi bấm Lưu và Bắt Đầu."); return false; end
    end
    if me.IsDead and me.IsDead() == 1 then self:Message("Nhân vật đang bị hạ gục."); return false; end
    self:Stop();
    self:Install();
    self.job = {options = self:Options(raw), owner = me.szName, faction = me.nFaction, started = now(), attempts = {}};
    self:Phase("evaluate", "Đang đọc nhiệm vụ chính tuyến.");
    self:Message("Bắt đầu Auto Chính Tuyến v" .. self.VERSION .. ".");
    self.timer = Ui.tbLogic.tbTimer:Register(self.TICK, function()
        local ok, result = pcall(M.Tick, M);
        if not ok then M:Stop("Lỗi: " .. tostring(result)); return 0; end
        return result;
    end);
    return true;
end

-- Đếm số lần làm cùng một việc mà tiến độ không đổi (khóa = việc + tiến độ hiện tại).
function M:Attempt(key, title)
    local j = self.job;
    local k = key .. "#" .. tostring(j.startProgress);
    local n = (j.attempts[k] or 0) + 1;
    j.attempts[k] = n;
    if n > j.options.retry then
        self:Stop("Đã thử " .. j.options.retry .. " lần chưa xong: " .. self:Plain(title or key) ..
            (j.failReason and (" (lần cuối: " .. j.failReason .. ")") or "") .. ". Hãy kiểm tra rồi Lưu và Bắt Đầu lại.");
        return false;
    end
    return true;
end

local function distance2(map, x, y, p)
    if not p or (map ~= p.map and not M:SameMap(map, p.map)) then return math.huge; end
    return (x - p.x) ^ 2 + (y - p.y) ^ 2;
end

function M:Evaluate()
    local j = self.job;
    local list, err = self:ReadMainTasks();
    if err then self:Stop(err); return; end
    -- Nhiều nhiệm vụ chính tuyến cùng lúc: làm việc đầu tiên làm được; đang chờ (cấp / máy chủ) thì sang nhiệm vụ khác,
    -- rồi tới nhận chặng mới; không có gì làm được thì báo theo nhiệm vụ đầu tiên.
    -- Bám nhiệm vụ đang làm: đưa nó lên đầu để làm xong hẳn rồi mới sang nhiệm vụ khác (thứ tự đọc không cố định).
    -- Giữ tuyến: chỉ làm 1 nhiệm vụ (tuyến chọn ở combo, hoặc tuyến làm đầu tiên nếu để Tự động) — không nhảy qua lại.
    local lock = j.options.keep == 1 and ((j.options.taskId or 0) > 0 and j.options.taskId or j.taskId) or nil;
    if lock then
        local only = {};
        for _, si in ipairs(list) do if si.nTaskId == lock then only[1] = si; end end
        list = only;
    end
    if j.taskId then
        for i, si in ipairs(list) do
            if si.nTaskId == j.taskId and i > 1 then table.remove(list, i); table.insert(list, 1, si); break; end
        end
    end
    local s, w, firstS, firstW;
    for _, si in ipairs(list) do
        local wi = self:NextWork(si, j.options);
        if not firstW then firstS, firstW = si, wi; end
        if not self.IDLE_KINDS[wi.kind] then s, w = si, wi; break; end
    end
    if not w then
        local aw = self:AcceptWork(j.options, lock);
        if aw.kind == "accept" or not firstW then w, s = aw, nil;
        else w, s = firstW, firstS; end
    end
    j.taskId = s and s.nTaskId or w.taskId;
    j.work, j.snapshot = w, s;
    if not (j.lastWorkKey and j.lastWorkKey == w.key) then j.auto6Tried, j.auto6Off, j.failReason, j.breaks, j.shopIdx, j.buyCount = nil, nil, nil, nil, nil, nil; end
    j.lastWorkKey = w.key;
    j.startProgress = s and s.progress or "none";
    j.stepKey = s and s.key or "none";
    local kind = w.kind;
    if kind == "none" or kind == "stop" or kind == "unsupported" then self:Stop(w.reason); return; end
    if kind == "lowlevel" then
        if (tonumber(me.nLevel) or 0) >= (tonumber(w.level) or 0) and (tonumber(w.level) or 0) > 0 then
            -- Đã đủ cấp, chỉ là máy chủ chưa cập nhật bước: chờ rồi tự làm tiếp (không phụ thuộc tuỳ chọn).
            self:Phase("waitcond", "Đã đủ cấp " .. w.level .. ", chờ máy chủ cập nhật bước."); j.recheck = 3; return;
        end
        if j.options.lowLevel == 2 then self:Phase("waitcond", w.reason .. " Đang chờ đủ cấp."); j.recheck = 10; return; end
        self:Stop(w.reason); return;
    end
    if kind == "wait" then self:Phase("waitcond", w.reason); j.recheck = 5; return; end
    if kind == "settle" then
        local title = w.reason;
        if w.routeHint then title = title .. " Bước này cần đã chọn hệ: nếu đã có hệ mà vẫn kẹt, hãy cộng 1 điểm vào kỹ năng cấp 20 của hệ"; end
        if not self:Attempt(w.key, title) then return; end
        self:Phase("waitserver", w.reason); return;
    end
    if not self:Attempt(w.key, w.title) then return; end
    local map, x, y = me.GetWorldPos();
    j.arriveRadius = 3;
    if kind == "move" then
        local p = w.point;
        if p.map <= 0 then p.map = map; end
        if p.x <= 0 or p.y <= 0 then
            local picked = self:PickDestination(w);
            if not picked then self:Stop("Không có toạ độ cho bước di chuyển: " .. self:Plain(w.title)); return; end
            p = picked;
        end
        j.arriveRadius = math.max(1, math.min(tonumber(w.point.r) or 3, 8) - 1);
        self:Travel(p, "arrive", w.title);
    elseif kind == "combat" then
        local center = self:PickDestination(w);
        if not center then
            if w.map <= 0 or w.map == map then center = {map = map, x = x, y = y, how = "here"};
            else self:Stop("Không tìm được bãi quái cho: " .. self:Plain(w.title)); return; end
        end
        if w.map > 0 and center.map ~= w.map then center.map = w.map; end   -- map của target Kill thắng map trong mô tả (SimBot)
        -- Đang ở trong bản đồ nhiệm vụ mà mô tả trỏ ra bản đồ ngoài (vd. Tân Triều: <pos=Thị Vệ Lý Hậu,29,1440,3891> là cổng
        -- to_lingyinsi vào Linh Ẩn Tự 524, Thị Vệ Lý Hậu ở trong 524): thấy quái mục tiêu quanh đây, hoặc bản đồ đang đứng
        -- chính là đích của cổng nằm sát điểm mô tả → đánh ngay tại đây, không ra ngoài.
        if center.map ~= map and w.map <= 0 and self:IsTaskMap(self.mapAlias[map] or map) then
            local inner = self.mapAlias[map] or map;
            local gate = false;
            for _, r in ipairs(self:TaskTraps()) do
                if r.from == center.map and r.to == inner and (r.x - center.x) ^ 2 + (r.y - center.y) ^ 2 <= 15 * 15 then gate = true; end
            end
            if gate or self:NearestFoe(w.kill, {map = map, x = x, y = y}, 80) then
                center = {map = map, x = x, y = y, name = center.name, how = "inside"};
            end
        end
        -- Điểm xuất hiện thật của quái (map_info máy chủ): vào thẳng bãi gần điểm mô tả nhất thay vì đứng ở đầu bãi.
        local spawns = self:SpawnPoints(center.map, w.kill, center);
        if not spawns and center.how ~= "inside" then
            -- Bản đồ mô tả không có bãi của quái này: lấy bản đồ đã biết điểm xuất hiện (tên bản đồ trong mục tiêu được ưu tiên).
            local other = self:SpawnMap(w.kill, (w.title or "") .. " " .. (w.desc or ""));
            if other and other ~= center.map then
                center = {map = other, x = 0, y = 0, name = center.name};
                spawns = self:SpawnPoints(other, w.kill, nil);
            end
        end
        if not spawns and center.how ~= "inside" then
            -- Quái chỉ có trong bản đồ nhiệm vụ sau cổng (vd. Từ Trường Phúc 824 ở Soái Trướng Hổ Sư 509, cổng ở Hán Thủy Cổ Độ 88).
            local here;
            for id in pairs(w.kill) do if self:NpcPoint(center.map, id) then here = true; end end
            -- Mục tiêu ghi rõ tên bản đồ thường (vd "Hán Thủy Cổ Độ - Kết Doanh Binh"): quái ở ngoài, không vào bản đồ nhiệm vụ.
            local named = type(GetMapNameFormId) == "function" and GetMapNameFormId(center.map);
            if type(named) == "string" and named ~= "" and self:Contains(self:Clean(w.title or ""), self:Clean(named)) then here = true; end
            local r, p = nil, nil;
            if not here then r, p = self:TrapTarget(center.map, w.kill); end
            if r then center = {map = r.to, x = p.x, y = p.y, name = center.name, how = "trap"}; end
        end
        if spawns and center.how ~= "trap" then
            -- Bỏ điểm xuất hiện nằm sát ô cổng nhiệm vụ: đi vòng qua đó là bị đưa vào bản đồ nhiệm vụ (vd. Kết Doanh Binh
            -- cạnh cổng Soái Trướng Hổ Sư ở Hán Thủy Cổ Độ).
            local kept = {};
            for _, p in ipairs(spawns) do
                local near = false;
                for _, r in ipairs(self:TaskTraps()) do
                    if r.from == center.map and (p.x - r.x) ^ 2 + (p.y - r.y) ^ 2 <= 8 * 8 then near = true; end
                end
                if not near then kept[#kept + 1] = p; end
            end
            if #kept > 0 then spawns = kept; end
        end
        j.spawnList, j.spawnIdx, j.spawnAt = spawns, 1, nil;
        if spawns then center = {map = center.map, x = spawns[1].x, y = spawns[1].y, name = center.name, how = "spawn"}; end
        j.center, j.waypoint, j.progressAt, j.lastProgress = center, 0, now(), j.startProgress;
        if distance2(map, x, y, center) <= self.FIGHT_RADIUS ^ 2 then self:Phase("fight", "Đang đánh quái: " .. self:Plain(w.title));
        else self:Travel(center, "fight", center.name or w.title); end
    elseif kind == "transform" then
        if self:FindNpc(w.fight) or self:FindNpc(w.dialog) then self:Phase("transform"); return; end
        local p = self:PickDestination(w);
        if not p then self:Stop("Không tìm được vị trí NPC cho: " .. self:Plain(w.title)); return; end
        self:Travel(p, "transform", p.name or w.title);
    elseif kind == "buy" then
        j.shopIdx, j.menuTried, j.buyTalks, j.buySent = j.shopIdx or 1, {}, 0, nil;
        local sh = w.shops[j.shopIdx];
        if not sh then self:Stop("Không mua được " .. self:Plain(w.title) .. " ở cửa hàng NPC; hãy tự mua rồi Lưu và Bắt Đầu lại."); return; end
        w.npc = sh.npc;
        if self:FindNpc(sh.npc) then self:Phase("buy"); return; end
        -- NPC bán hàng lấy từ dữ liệu cửa hàng có thể không phải NPC trong mô tả bước: ưu tiên toạ độ tĩnh của chính NPC đó.
        local tagged = false;
        for _, t in ipairs(w.descTags or {}) do if t.kind == "npcpos" and t.npc == sh.npc then tagged = true; end end
        local p = self:NpcPoint(map, sh.npc) or (tagged and self:PickDestination(w)) or self:FindNpcAnyMap(sh.npc) or self:PickDestination(w);
        p = p and (self:NpcBehindTrap(p, sh.npc) or p);
        if not p then self:Stop("Không tìm được NPC bán hàng cho: " .. self:Plain(w.title)); return; end
        if p.map <= 0 then p.map = map; end
        self:Travel(p, "buy", w.title);
    elseif kind == "craft" then
        j.crafts, j.craftAt, j.craftBefore, j.craftFails = 0, nil, nil, 0;
        if (tonumber(me.nFightState) or 0) > 0 then
            -- Kỹ năng sống không dùng được khi đang chiến đấu: về chỗ thầy dạy nghề (trong thôn / thành) rồi làm.
            local t = w.teachers and w.teachers[1];
            if t then w.npc = t.npc; end
            local p = t and (self:PickDestination(w) or self:FindNpcAnyMap(t.npc));
            if not p then self:Stop("Đang ở trạng thái chiến đấu, không dùng được kỹ năng sống; hãy về thành / thôn rồi Lưu và Bắt Đầu lại."); return; end
            if p.map <= 0 then p.map = map; end
            self:Travel(p, "craft", w.title);
            return;
        end
        self:Phase("craft", self:Plain(w.title));
    elseif kind == "process" then
        j.spawnIdx = j.spawnIdx or 1;
        if self:FindNpc(w.npc) then self:Phase("process"); j.clicks = 0; return; end
        local p = w.spawns[j.spawnIdx] or self:PickDestination(w);
        if not p then self:Stop("Không tìm được vị trí thu thập cho: " .. self:Plain(w.title)); return; end
        if p.map <= 0 then p.map = map; end
        self:Travel(p, "process", w.title);
    elseif kind == "useitem" or kind == "product" then
        if not w.itemId then self:Stop("Không đọc được vật phẩm cần dùng: " .. self:Plain(w.title)); return; end
        if not self:FindBagItem(w.itemId) then
            self:Stop("Không có vật phẩm nhiệm vụ trong túi để dùng (" .. table.concat(w.itemId, ",") .. "): " .. self:Plain(w.title) .. ".");
            return;
        end
        j.used = nil;
        local area = w.areas and w.areas[1];
        if not area or area.x <= 0 then self:Phase("useitem"); return; end
        if area.map <= 0 then area.map = map; end
        j.arriveRadius = math.max(1, (area.r or 2) - 1);
        j.ring, j.ringBase = nil, nil;
        if distance2(map, x, y, area) <= j.arriveRadius ^ 2 then self:Phase("useitem");
        elseif map == area.map and (area.r or 0) >= 4 then
            -- Cùng bản đồ: đi tới mép vùng phía mình (60% bán kính) thay vì đúng tâm — tâm hay nằm trên vật cản
            -- (tháp lâu, tượng...) khiến tự tìm đường báo "Tìm đường thất bại".
            local a = math.atan2(y - area.y, x - area.x);
            local d = area.r * 0.6;
            local p = {map = map, x = area.x + math.floor(d * math.cos(a) + 0.5), y = area.y + math.floor(d * math.sin(a) + 0.5)};
            j.arriveRadius = 2;
            self:Travel(p, "useitem", w.title);
        else self:Travel(area, "useitem", w.title); end
    elseif kind == "escort" and self:FindNpc(w.mover) then
        self:Phase("escort", "Đang hộ tống.");
    elseif kind == "guard" and j.guardStarted == w.key then
        self:Phase("guard", "Đang bảo vệ.");
    else
        self:GoNpc(w);
    end
end

function M:GoNpc(w)
    local j = self.job;
    j.npcSearched, j.answers, j.awardSent, j.acceptSent, j.otherAsked, j.gift, j.giftDone = nil, 0, nil, nil, nil, nil, nil;
    j.chosenAt, j.gutSeen = nil, nil;
    local npc = w.npc and w.npc > 0 and self:FindNpc(w.npc);
    if npc then self:Phase("npc", "Đã thấy NPC; đang tới nói chuyện."); return; end
    local point = self:PickDestination(w);
    -- NPC ở trong bản đồ nhiệm vụ sau cổng (mô tả chỉ ghi toạ độ cổng): đi thẳng vào trong qua cổng.
    if point then point = self:NpcBehindTrap(point, tonumber(w.npc) or 0) or point; end
    if not point then
        self:Stop("Không tìm được vị trí NPC cho việc: " .. self:Plain(w.title or "") .. ". Hãy đi gần NPC rồi Lưu và Bắt Đầu lại.");
        return;
    end
    self:Travel(point, "npc", point.name or w.title);
end

-- ---------------------------------------------------------------- di chuyển (Vô Hạn Phù nếu bật + tự tìm đường gốc)
function M:BeginTransfer(destination, after)
    local j = self.job;
    local transfer = Ui.WJXTransfer;
    local ok = transfer:Check(destination);
    if ok ~= true then self:NativePath(j.resumePoint, j.resumeAfter, j.resumeLabel); return; end
    local item = transfer:Item();
    if not item then self:NativePath(j.resumePoint, j.resumeAfter, j.resumeLabel); return; end
    self:Phase("transfer", "Đang dùng Vô Hạn Phù tới " .. (destination.label or tostring(destination.map)) .. ".");
    j.afterTransfer = after;
    j.transferDest = destination;
    -- Bị đánh là đứt thanh dùng phù: có quái sát bên thì dọn trước, xong mới dùng phù (không tính lần thử).
    if self:Defend(j) then j.transfer = nil; return; end
    local _, x, y = me.GetWorldPos();
    j.transferStartX, j.transferStartY = x, y;
    j.transfer = transfer:Begin(destination, item);
    if me.UseItem(item) == 0 then
        transfer:Cancel(j.transfer); j.transfer = nil;
        self:NativePath(j.resumePoint, j.resumeAfter, j.resumeLabel);
    end
end

-- ---------------------------------------------------------------- ngựa (như Auto6: Switch("horse") bật/tắt cưỡi)
local function riding()
    local ok, v = pcall(function() return me.GetNpc().nIsRideHorse; end);
    return ok and tonumber(v) == 1;
end

-- Lên ngựa trước chặng đường dài. Trả true khi vừa ra lệnh lên ngựa (chờ ~1 giây rồi mới đi).
function M:Mount(j, far)
    if not far or j.options.mount ~= 1 or riding() or type(Switch) ~= "function" then return false; end
    if me.nAutoFightState == 1 or visible(Ui.UI_SKILLPROGRESS) then return false; end
    if j.horseAt and now() - j.horseAt < (j.horseFailed and 120 or 5) then return false; end
    j.horseAt = now();
    return pcall(Switch, "horse") and true or false;
end

function M:Dismount(j)
    if j.options.dismount ~= 1 or not riding() or type(Switch) ~= "function" then return; end
    if j.dismountAt and now() - j.dismountAt < 2 then return; end
    j.dismountAt = now();
    pcall(Switch, "horse");
end

-- Tự vệ: quái đánh được ở sát bên khi đang cắm cờ / dùng vật phẩm / thu thập (bị đánh là đứt thanh tiến trình)
-- → dọn sạch rồi mới làm tiếp. Dùng Auto6 như khi đánh quái nhiệm vụ, không được thì tự đánh.
M.DEFEND_RADIUS = 15;
M.MOUNT_MPS = 1280;          -- chỉ lên ngựa khi đích xa hơn 1280 MPS (= 40 ô toạ độ thế giới) hoặc ở bản đồ khác
function M:Defend(j)
    if j.options.defend ~= 1 or j.options.combat ~= 1 or me.nFightState ~= 1 then return false; end
    local w = j.work or {};
    local avoid = {};
    for _, id in ipairs({w.npc, w.mover, w.dialog}) do if tonumber(id) then avoid[tonumber(id)] = true; end end
    local _, x, y = me.GetWorldPos();
    j.defendCenter = j.defending and j.defendCenter or {x = x, y = y};
    local foe = self:NearestFoe(nil, j.defendCenter, self.DEFEND_RADIUS, avoid);
    if foe then
        j.defending = true;
        local name = tostring(self.Field(foe, "szName") or "quái");
        if self:UseAuto6(j, foe) then self.status = "Tự vệ (Auto6): dọn " .. name .. " quanh điểm làm nhiệm vụ.";
        else self:Attack(foe); self.status = "Tự vệ: dọn " .. name .. " quanh điểm làm nhiệm vụ."; end
        return true;
    end
    if j.defending then
        j.defending, j.defendCenter = nil, nil;
        if j.attacking then j.attacking = nil; pcall(AutoAi.SetTargetIndex, 0); end
        if j.auto6 then self:ReleaseAuto6(j); end
    end
    return false;
end

-- Bản đồ nhiệm vụ thường là BẢN SAO: mã bản đồ khi chạy khác mã gốc (508 → mã động). Coi là cùng bản đồ khi đã vào
-- qua cổng (mapAlias) hoặc trùng tên với bản đồ nhiệm vụ gốc.
M.mapAlias = M.mapAlias or {};
function M:SameMap(actual, wanted)
    if actual == wanted then return true; end
    if not actual or not wanted or actual <= 0 then return false; end
    if self.mapAlias[actual] == wanted then return true; end
    if self:IsTaskMap(wanted) and type(GetMapNameFormId) == "function" then
        local a, b = GetMapNameFormId(actual), GetMapNameFormId(wanted);
        if type(a) == "string" and a ~= "" and a == b then self.mapAlias[actual] = wanted; return true; end
    end
    return false;
end

function M:NativePath(point, after, label)
    local j = self.job;
    local map, x, y = me.GetWorldPos();
    local path = Ui.tbLogic.tbAutoPath;
    if map ~= point.map and self:SameMap(map, point.map) then
        -- Đang ở bản sao của bản đồ đích: đi bộ trong bản đồ (tự tìm đường của game không biết mã bản sao).
        point = {map = map, x = point.x, y = point.y, name = point.name};
        self:Phase("walkto", "Đang di chuyển tới " .. self:Plain(label or point.name or "điểm nhiệm vụ") .. ".");
        j.point, j.afterPath, j.walkAt, j.progress = point, after, nil, now();
        j.lastX, j.lastY = x, y;
        return;
    end
    self:Phase("travel", "Đang di chuyển tới " .. self:Plain(label or point.name or "điểm nhiệm vụ") .. ".");
    j.point, j.afterPath = point, after;
    j.lastMap, j.lastX, j.lastY, j.progress = map, x, y, now();
    local radius = j.arriveRadius or 3;
    if map == point.map and (x - point.x) ^ 2 + (y - point.y) ^ 2 <= radius * radius then
        self:Phase(after); return;
    end
    -- Lên ngựa khi đi xa: khác bản đồ thật (không tính bản sao bản đồ nhiệm vụ) hoặc xa hơn MOUNT_MPS.
    local farAway = (map ~= point.map and not self:SameMap(map, point.map)) or
        ((x - point.x) ^ 2 + (y - point.y) ^ 2) * 32 * 32 > self.MOUNT_MPS * self.MOUNT_MPS;
    if self:Mount(j, farAway) then
        j.mountResume = {point = point, after = after, label = label};
        j.phase, j.at = "mount", now();
        return;
    end
    path:GotoPos({nMapId = point.map, nX = point.x, nY = point.y});
    j.path = path.tbGotoPos;
    if not j.path and map == point.map then
        -- Cùng bản đồ mà điểm đích nằm trên vật cản (vd. trước tửu lâu ở Ba Lăng Huyện): thử các điểm quanh đích.
        if after == "useitem" then self:Phase("useitem"); return; end      -- UseItemTick tự đi vòng quanh vùng
        for _, o in ipairs({{0, 4}, {4, 0}, {0, -4}, {-4, 0}, {4, 4}, {-4, 4}, {4, -4}, {-4, -4}, {0, 8}, {8, 0}, {0, -8}, {-8, 0}}) do
            path:GotoPos({nMapId = point.map, nX = point.x + o[1], nY = point.y + o[2]});
            j.path = path.tbGotoPos;
            if j.path then
                j.point = {map = point.map, x = point.x + o[1], y = point.y + o[2], name = point.name};
                j.arriveRadius = math.max(j.arriveRadius or 3, 3);
                return;
            end
        end
    end
    if not j.path then
        if map ~= point.map and not j.ferry and self:Ferry(point, after, label) then return; end
        self:Stop("Không tìm được đường tới " .. self:Plain(label or point.name or "điểm nhiệm vụ") .. " (bản đồ " .. tostring(point.map) ..
            ", toạ độ " .. math.floor(point.x / 8) .. "," .. math.floor(point.y / 16) .. "; đang ở bản đồ " .. tostring(map) .. ").");
    end
end

-- Bản đồ chỉ vào được qua NPC chở người (tbAutoPath không biết): SimBot MapTravelCatalog 205-219.
M.FERRIES = {
    {from = 55, to = 400, npc = 8, name = "Thuyền Phu"},            -- vào Khoang Thuyền
    {from = 74, to = 426, npc = 114, name = "Bùi Dực Phi"},          -- nam
    {from = 74, to = 427, npc = 114, name = "Bùi Dực Phi"},          -- nữ
    -- Thạch Hiên Viên 136 (Tây Rừng Nguyên Sinh) hỏi "去参加英雄宴吗？" (máy chủ chưa dịch) → đưa vào Tụ Nghĩa Sảnh (420),
    -- nơi có Thạch Hiên Viên 139 của nhiệm vụ "Vô Phương Hướng" (tiệc mừng chiến thắng). Toạ độ: map_info/*/info.txt.
    {from = 74, to = 420, npc = 136, name = "Thạch Hiên Viên", at = {1723, 3227}, targets = {[139] = {1606, 3216}}},
};

-- Tới nơi mà NPC nhiệm vụ không có ở bản đồ này nhưng có NPC chở người đưa sang bản đồ có NPC đó: đi nhờ.
function M:FerryForNpc(j, npcId, label)
    local map = me.GetWorldPos();
    for _, f in ipairs(self.FERRIES) do
        local t = f.targets and f.targets[npcId];
        if t and f.from == map then
            local dest = self:NpcPoint(f.to, npcId) or {map = f.to, x = t[1], y = t[2]};
            j.ferry = {f = f, point = dest, after = "npc", label = label};
            self.status = "NPC mẫu " .. npcId .. " ở bản đồ " .. f.to .. "; nhờ " .. f.name .. " đưa sang.";
            if self:FindNpc(f.npc) then self:Phase("ferrynpc");
            else
                local np = self:NpcPoint(f.from, f.npc) or (f.at and {map = f.from, x = f.at[1], y = f.at[2]});
                if not np then j.ferry = nil; return false; end
                self:NativePath(np, "ferrynpc", f.name);
            end
            return true;
        end
    end
    return false;
end

function M:Ferry(point, after, label)
    local j = self.job;
    local path = Ui.tbLogic.tbAutoPath;
    local map = me.GetWorldPos();
    for _, f in ipairs(self.FERRIES) do
        local reach = f.to == point.map;
        if not reach and path.CalcPosToPos then
            local ok, route = pcall(path.CalcPosToPos, path, {nMapId = f.to, nX = point.x, nY = point.y},
                {nMapId = point.map, nX = point.x, nY = point.y});
            reach = ok and route ~= nil;
        end
        if reach and map ~= f.to then
            local np = self:NpcPoint(f.from, f.npc);
            if np then
                j.ferry = {f = f, point = point, after = after, label = label};
                self.status = "Cần nhờ " .. f.name .. " đưa sang bản đồ " .. f.to .. ".";
                if map == f.from and self:FindNpc(f.npc) then self:Phase("ferrynpc");
                else self:NativePath(np, "ferrynpc", f.name); end
                return true;
            end
        end
    end
    return false;
end

function M:FerryTick(j)
    local fe = j.ferry;
    local map = me.GetWorldPos();
    if map == fe.f.to then
        j.ferry = nil;
        self:Phase("settle", "Đã sang bản đồ " .. fe.f.to .. "; chờ tải cảnh.");
        j.resumePoint, j.resumeAfter, j.resumeLabel = fe.point, fe.after, fe.label;
        return;
    end
    if j.phase == "ferrynpc" then
        local npc, d = self:FindNpc(fe.f.npc);
        if not npc then
            if now() - j.at > 12 then self:Stop("Không thấy " .. fe.f.name .. " để sang bản đồ " .. fe.f.to .. "."); end
            return;
        end
        if d > 150 then local x, y = npc.GetMpsPos(); self:Step(x / 32, y / 32); return; end
        self:Phase("ferrytalk", "Đang nhờ " .. fe.f.name .. " đưa đi.");
        j.sayUntil, j.lastAction = now() + 8, now();
        AutoAi.SetTargetIndex(npc.nIndex);
        return;
    end
    -- ferrytalk
    if visible(Ui.UI_GUTTALK) then Ui(Ui.UI_GUTTALK):OnButtonClick("Main"); return; end
    if j.say then
        local i = self:Affirmative(j.say[2]) or 1;     -- SimBot: bấm dòng đầu tiên của NPC chở người
        self:Pick(i);
        return;
    end
    if now() - j.at > 25 then self:Stop("Chưa sang được bản đồ " .. fe.f.to .. " qua " .. fe.f.name .. "."); end
end

-- ---------------------------------------------------------------- mua ở cửa hàng NPC (bước "Tìm thấy <vật phẩm>")
-- Nói chuyện NPC → chọn dòng cửa hàng ("[Bạc khóa] Thực phẩm" trước, rồi các dòng cửa hàng khác) → trong cửa hàng tìm đúng
-- (genre, detail, particular, level) → ShopBuyItem đủ số còn thiếu. Cửa hàng không có món đó thì đóng, thử dòng / NPC khác.
function M:BuyTick(j)
    local w = j.work;
    local have = me.GetItemCountInBags and (me.GetItemCountInBags(w.item[1], w.item[2], w.item[3], w.item[4] > 0 and w.item[4] or nil) or 0) or 0;
    if have >= w.need then
        if visible(Ui.UI_SHOP) then UiManager:CloseWindow(Ui.UI_SHOP); end
        j.phase = "evaluate"; self.status = "Đã mua đủ; đang đọc việc tiếp theo."; return;
    end
    local sh = w.shops[j.shopIdx];
    if visible(Ui.UI_SHOP) then
        if not j.shopOwned then self:Stop("Đang mở cửa hàng khác; hãy đóng rồi Lưu và Bắt Đầu lại."); return; end
        if j.buySent then
            if have > j.buySent.before then j.buySent = nil;
            elseif now() - j.buySent.at > 5 then self:Stop("Mua không thành công (kiểm tra tiền / bạc khoá / ô trống)."); end
            return;
        end
        local goodsId;
        for _, goods in ipairs(me.GetShopItemList() or {}) do
            local ok, p = pcall(Shop.GetDemoItem, Shop, me.GetShopId(), goods.nId);
            if ok and p and p.nGenre == w.item[1] and p.nDetail == w.item[2] and p.nParticular == w.item[3] and
                (w.item[4] <= 0 or p.nLevel == w.item[4]) then goodsId = goods.nId; break; end
        end
        if not goodsId then
            UiManager:CloseWindow(Ui.UI_SHOP);
            j.shopOwned, j.at = nil, now();
            self.status = "Cửa hàng này không bán " .. self:Plain(w.title) .. "; thử lựa chọn khác.";
            return;
        end
        j.buyCount = (j.buyCount or 0) + 1;
        if j.buyCount > 5 then self:Stop("Đã thử mua 5 lần chưa đủ; hãy kiểm tra tiền / ô trống."); return; end
        j.buySent = {before = have, at = now()};
        local ok, result = pcall(me.ShopBuyItem, goodsId, w.need - have);
        if not ok or result == 0 then self:Stop("Cửa hàng từ chối bán (thiếu tiền / bạc khoá?)."); end
        self.status = "Đang mua " .. self:Plain(w.title) .. ".";
        return;
    end
    j.shopOwned = nil;
    if j.say and visible(Ui.UI_SAYPANEL) then
        local options = j.say[2] or {};
        local pick;
        local function try(test)
            for i, o in ipairs(options) do
                local c = self:Clean(o);
                if not j.menuTried[c] and test(c) then return i, c; end
            end
        end
        local i, c;
        if sh.option then
            -- Mục hội thoại lấy từ setting\npc\dialognpc.txt: khớp đúng chữ (bỏ thẻ màu).
            local want = self:Clean(sh.option);
            i, c = try(function(c) return c == want; end);
            if not i then i, c = try(function(c) return self:Contains(c, want) and string.len(want) >= 2; end); end
        end
        if not i and not sh.option then i, c = try(function(c) return (self:Contains(c, "[bạc khóa]") or self:Contains(c, "[bạc khoá]")) and (self:Contains(c, "thực phẩm") or self:Contains(c, "dược phẩm")); end); end
        -- Từ khoá theo thứ tự ưu tiên (từ khoá cụ thể trước "mua").
        for _, m in ipairs(sh.menu or {}) do
            if i then break; end
            i, c = try(function(c) return self:Contains(c, m); end);
        end
        if i then
            j.menuTried[c] = true;
            j.shopOwned = true;              -- cửa hàng có thể mở ngay trong lúc chọn
            j.say, j.ownedSay = nil, nil;
            j.at = now();
            Ui(Ui.UI_SAYPANEL):OnListSel("LstSelectArray", i);
            return;
        end
        -- NPC này hết lựa chọn cửa hàng: thử NPC bán hàng kế tiếp.
        UiManager:CloseWindow(Ui.UI_SAYPANEL);
        j.say, j.ownedSay = nil, nil;
        j.shopIdx = j.shopIdx + 1;
        j.phase = "evaluate";
        return;
    end
    if j.talkAt and now() - j.talkAt < 4 then return; end
    j.buyTalks = j.buyTalks + 1;
    if j.buyTalks > 10 then self:Stop("Không mở được cửa hàng của NPC cho: " .. self:Plain(w.title)); return; end
    local npc, d = self:FindNpc(sh.npc);
    if not npc then
        if now() - j.at > 12 then j.shopIdx = j.shopIdx + 1; j.phase = "evaluate"; end
        return;
    end
    j.talkAt, j.sayUntil = now(), now() + 8;
    AutoAi.SetTargetIndex(npc.nIndex);
    self.status = "Nói chuyện với " .. tostring(self.Field(npc, "szName") or "NPC") .. " để mua " .. self:Plain(w.title) .. ".";
end

-- Kỹ năng sống: mỗi lần me.DoRecipe làm 1 món (như nút Chế tạo của cửa sổ kỹ năng sống), chờ thanh tiến trình xong
-- rồi đếm lại túi. 3 lần liền không tăng = máy chủ từ chối (thiếu nguyên liệu / hoạt lực / tinh lực, đang di chuyển...).
function M:CraftTick(j)
    local w = j.work;
    local have = self:CountItem(w.item);
    if have >= w.need then j.phase = "evaluate"; self.status = "Đã chế đủ; đang đọc việc tiếp theo."; return; end
    if visible(Ui.UI_SKILLPROGRESS) then j.craftAt = now(); return; end
    if j.craftAt and now() - j.craftAt < math.max(2, (w.makeTime or 27) / 18 + 1.5) then return; end
    if j.craftBefore then
        if have > j.craftBefore then j.craftFails = 0; else j.craftFails = (j.craftFails or 0) + 1; end
        if j.craftFails >= 3 then
            self:Stop("Chế không thành công: " .. self:Plain(w.title) .. " (đã có " .. have .. "/" .. w.need ..
                "). Hãy xem tin nhắn hệ thống (thiếu nguyên liệu / hoạt lực / tinh lực / chưa học phối phương?).");
            return;
        end
    end
    if (tonumber(me.nFightState) or 0) > 0 then
        self:Stop("Đang ở trạng thái chiến đấu, không dùng được kỹ năng sống; hãy về thành / thôn rồi Lưu và Bắt Đầu lại."); return;
    end
    j.crafts = (j.crafts or 0) + 1;
    if j.crafts > w.need * 2 + 6 then self:Stop("Đã thử chế quá nhiều lần: " .. self:Plain(w.title) .. "."); return; end
    self:StopPath(j);
    j.craftBefore, j.craftAt = have, now();
    self.status = self:Plain(w.title) .. " (" .. have .. "/" .. w.need .. ").";
    local ok, err = pcall(me.DoRecipe, w.recipe);
    if not ok then self:Stop("Không gọi được chế tạo (me.DoRecipe): " .. tostring(err)); end
end

-- Máu vừa giảm trong 4 giây gần nhất = đang bị đánh.
function M:Hurt(j)
    local life = tonumber(me.nCurLife);
    if not life then return true; end
    if j.lastLife and life < j.lastLife then j.hurtAt = now(); end
    j.lastLife = life;
    return j.hurtAt ~= nil and now() - j.hurtAt < 4;
end

-- Bước vào cổng nhiệm vụ: đứng đúng ô cổng tới khi đổi bản đồ (20 giây không qua được = cổng chưa mở cho bước này).
function M:TrapTick(j)
    local t = j.trap;
    if not t then j.phase = "evaluate"; return; end
    local map, x, y = me.GetWorldPos();
    -- Bản đồ nhiệm vụ có thể là bản sao (mã bản đồ khi chạy khác mã gốc): coi "đã đổi bản đồ" là đã qua cổng.
    -- Bản đồ có cổng (vào) là bản đồ thường → lấy đúng mã gốc; tự tìm đường có thể đã đưa qua cổng trước nhịp này.
    t.fromMap = t.fromMap or (not t.exit and t.r.from) or map;
    if map and map > 0 and map ~= t.fromMap then
        if not t.exit and t.r.to and map ~= t.r.to then self.mapAlias[map] = t.r.to; end   -- vào bản sao của bản đồ nhiệm vụ
        j.trap = nil;
        j.resumePoint, j.resumeAfter, j.resumeLabel = t.point, t.after, t.label;
        self:Phase("settle", "Đã qua cổng; chờ tải cảnh.");
        return;
    end
    if j.say and visible(Ui.UI_SAYPANEL) then
        -- NPC "Rời khỏi" hỏi xác nhận: chọn dòng đồng ý / rời đi.
        local i = self:Affirmative(j.say[2]);
        if not i then
            for k, o in ipairs(j.say[2] or {}) do
                local c = self:Clean(o);
                if self:Contains(c, "rời") or self:Contains(c, "ra ngoài") or self:Contains(c, "trở về") then i = k; break; end
            end
        end
        self:Pick(i or 1);
        return;
    end
    -- Chỉ tự vệ khi THẬT SỰ bị đánh (máu giảm), không lao vào quái đứng yên quanh cổng (vd. Thị Vệ Lý Hậu ở Linh Ẩn Tự 524).
    if self:Hurt(j) and self:Defend(j) then t.cellAt, t.onAt = nil, nil; j.at = math.max(j.at, now() - 30); return; end
    -- Cổng chỉ kích hoạt khi BƯỚC VÀO ô cổng (đứng sẵn trên ô thì không): lần lượt lùi ra 3 ô rồi bước vào từng ô quanh tâm cổng.
    -- Tâm cổng: NPC "Điểm rời bản đồ" (2525, lớp blank, không có hội thoại) đứng đúng giữa cổng nếu thấy, không thì điểm transmit.
    if not t.cx then
        t.cx, t.cy = t.r.x, t.r.y;
        local npc = t.exit and self:ExitNpc();
        if npc then
            local nx, ny = npc.GetMpsPos();
            nx, ny = math.floor(nx / 32 + 0.5), math.floor(ny / 32 + 0.5);
            if (nx - t.r.x) ^ 2 + (ny - t.r.y) ^ 2 <= 36 then t.cx, t.cy = nx, ny; end
        end
        local dx, dy = x - t.cx, y - t.cy;
        local len = math.sqrt(dx * dx + dy * dy);
        if len < 1 then dx, dy, len = 1, 1, math.sqrt(2); end
        t.bx, t.by = t.cx + math.floor(dx / len * 3 + 0.5), t.cy + math.floor(dy / len * 3 + 0.5);
        t.seq = 1;
    end
    local OFFS = {{0, 0}, {-1, -1}, {0, -1}, {-1, 0}, {1, 1}, {1, 0}, {0, 1}, {-1, 1}, {1, -1}, {-2, -1}, {-1, -2}, {2, 1}, {1, 2}, {-2, 0}, {0, -2}, {2, 0}, {0, 2}};
    local function target(seq)
        local k = math.floor((seq - 1) / 2) % #OFFS + 1;
        if seq % 2 == 1 and seq > 1 then return t.bx, t.by, false; end          -- lùi ra trước khi bước vào ô kế
        return t.cx + OFFS[k][1], t.cy + OFFS[k][2], true;
    end
    local ox, oy, cell = target(t.seq);
    if (x - ox) ^ 2 + (y - oy) ^ 2 <= 0.5 then t.onAt = t.onAt or now(); else t.onAt = nil; end
    if (t.onAt and now() - t.onAt > (cell and 1 or 0)) or (t.cellAt and now() - t.cellAt > 4) then
        t.seq, t.onAt, t.cellAt, j.trapAt = t.seq + 1, nil, nil, nil;
        ox, oy, cell = target(t.seq);
    end
    t.cellAt = t.cellAt or now();
    if not j.trapAt or now() - j.trapAt >= 1 then
        j.trapAt = now();
        pcall(me.StartAutoPath, ox, oy);
    end
    self.status = t.exit and "Ra khỏi bản đồ nhiệm vụ." or ("Bước vào cổng sang bản đồ " .. tostring(t.r.to) .. ".");
    if now() - j.at > 60 then
        j.trap = nil;
        self:Stop(t.exit and "Không ra được khỏi bản đồ nhiệm vụ; hãy tự ra rồi Lưu và Bắt Đầu lại." or
            ("Cổng sang bản đồ " .. tostring(t.r.to) .. " chưa mở (bước nhiệm vụ chưa cho vào?). Hãy kiểm tra rồi Lưu và Bắt Đầu lại."));
    end
end

-- Đi bộ trong bản sao bản đồ nhiệm vụ: StartAutoPath mỗi giây tới khi tới nơi (hoặc thấy NPC cần gặp).
function M:WalkTick(j)
    local p = j.point;
    local map, x, y = me.GetWorldPos();
    if map ~= p.map then j.phase = "evaluate"; return; end
    local radius = j.arriveRadius or 3;
    if (x - p.x) ^ 2 + (y - p.y) ^ 2 <= radius * radius then self:Phase(j.afterPath); return; end
    if j.afterPath == "npc" and j.work and j.work.npc then
        local npc, d = self:FindNpc(j.work.npc);
        if npc and d <= 150 then self:Phase("npc"); return; end
    end
    if (j.afterPath == "transform") and j.work and (self:FindNpc(j.work.fight) or self:FindNpc(j.work.dialog)) then
        self:Phase("transform"); return;
    end
    if (x - (j.lastX or 0)) ^ 2 + (y - (j.lastY or 0)) ^ 2 > 1 then j.lastX, j.lastY, j.progress = x, y, now(); end
    if not j.walkAt or now() - j.walkAt >= 1 then
        j.walkAt = now();
        pcall(me.StartAutoPath, math.floor(p.x), math.floor(p.y));
    end
    if now() - j.progress > 15 then
        local near = (j.afterPath == "useitem") and (radius + 12) ^ 2 or 100;
        if (x - p.x) ^ 2 + (y - p.y) ^ 2 <= near then self:Phase(j.afterPath);
        else j.phase = "evaluate"; self.status = "Kẹt đường trong bản đồ nhiệm vụ; thử lại."; end
    end
end

-- NPC/ô "Rời khỏi" (mẫu 2525) đặt ở cổng ra của bản đồ nhiệm vụ.
function M:ExitNpc()
    for _, n in ipairs(KNpc.GetAroundNpcList(me, 600) or {}) do
        if tonumber(self.Field(n, "nTemplateId")) == 2525 and self:Contains(self:Clean(self.Field(n, "szName") or ""), "rời") then return n; end
    end
end

function M:Travel(point, after, label)
    local j = self.job;
    j.transferRetries = nil;
    local map = me.GetWorldPos();
    if map ~= point.map and self:SameMap(map, point.map) then return self:NativePath(point, after, label); end
    local exitNpc = map ~= point.map and not j.trap and self:ExitNpc();
    if map ~= point.map and not j.trap and (self:IsTaskMap(map) or exitNpc) then
        -- Đang ở trong bản đồ nhiệm vụ (lỡ bước vào cổng / bước trước để lại): ra bằng cổng ra / NPC "Rời khỏi".
        local exit;
        for _, r in ipairs(self:TaskTraps()) do
            if r.from == map and (not exit or r.to == point.map) then exit = r; end
        end
        if not exit and exitNpc then
            local nx, ny = exitNpc.GetMpsPos();
            exit = {from = map, to = point.map, x = math.floor(nx / 32), y = math.floor(ny / 32)};
        end
        if exit then
            j.trap = {r = exit, point = point, after = after, label = label, exit = true, fromMap = map};
            self:StopPath(j);
            self:Phase("trapstep", "Ra khỏi bản đồ nhiệm vụ.");
            return;
        end
    end
    local trap = map ~= point.map and self:TrapTo(point.map, map);
    if trap and not j.trap then
        -- Bản đồ nhiệm vụ: tới ô cổng (dùng phù / đường thường tới bản đồ có cổng), rồi bước vào cổng.
        j.trap = {r = trap, point = point, after = after, label = label, fromMap = trap.from};
        local gate = {map = trap.from, x = trap.x, y = trap.y, name = "cổng vào bản đồ " .. trap.to};
        if map == trap.from then self:NativePath(gate, "trapstep", gate.name);
        else return self:Travel(gate, "trapstep", gate.name); end
        return;
    end
    if j.options.transfer == 1 and Ui.WJXTransfer and me.GetWorldPos() ~= point.map then
        local ok, dest = pcall(Ui.WJXTransfer.Plan, Ui.WJXTransfer, point.map);
        if ok and dest then
            j.resumePoint, j.resumeAfter, j.resumeLabel = point, after, label;
            self:BeginTransfer(dest, "resume");
            return;
        end
    end
    self:NativePath(point, after, label);
end

-- Bước ngắn trong cùng bản đồ (không huỷ mục tiêu như tbAutoPath:GotoPos). Toạ độ thế giới.
function M:Step(x, y)
    local j = self.job;
    if j.stepAt and now() - j.stepAt < 1 and j.stepX == x and j.stepY == y then return; end
    j.stepAt, j.stepX, j.stepY = now(), x, y;
    pcall(me.StartAutoPath, math.floor(x), math.floor(y));
end

function M:Attack(npc)
    local j = self.job;
    local idx = npc.nIndex;
    if j.attackIdx ~= idx or not j.attackAt or now() - j.attackAt >= 2 then
        j.attackIdx, j.attackAt, j.attacking = idx, now(), true;
        self:Dismount(j);
        -- Như AutoAi:ChangeSkill gốc: chọn kỹ năng tay trái làm kỹ năng chủ động, nếu không AI gốc có thể
        -- chỉ đi tới mục tiêu mà không ra đòn (khi Auto6 / tự chiến đấu đang tắt).
        local skill = tonumber(me.nLeftSkill) or 0;
        if skill > 0 and AutoAi.SetActiveSkill and me.CanCastSkill and me.CanCastSkill(skill) == 1 then
            pcall(AutoAi.SetActiveSkill, skill, 600);
        end
        AutoAi.SetTargetIndex(idx);
    end
end

-- ---------------------------------------------------------------- NPC + hội thoại
function M:TalkTo(npc)
    local j = self.job;
    self:StopPath(j);
    self:Phase("dialog", "Đang nói chuyện với " .. tostring(self.Field(npc, "szName") or "NPC") .. ".");
    j.sayUntil, j.lastAction, j.talkedAt = now() + 15, now(), now();
    AutoAi.SetTargetIndex(npc.nIndex);
end

function M:NpcTick(j)
    local w = j.work;
    local npc, dist = self:FindNpc(w.npc);
    if not npc then
        if not j.npcSearched then
            j.npcSearched = true;
            local point = self:NpcPoint(me.GetWorldPos(), w.npc);
            if point then self:NativePath(point, "npc", "NPC"); return; end
        end
        if not j.ferry and self:FerryForNpc(j, tonumber(w.npc) or 0, w.title) then return; end
        if now() - j.at > 12 then
            j.phase = "evaluate";
            self.status = "Đã tới nơi nhưng chưa thấy NPC mẫu " .. tostring(w.npc) .. " (quanh có " .. tostring(self.lastScan or 0) .. " đối tượng); thử lại.";
            j.failReason = "không thấy NPC mẫu " .. tostring(w.npc) .. " quanh chỗ đứng";
            self:Message(self.status);
        end
        return;
    end
    if dist > 150 then
        local x, y = npc.GetMpsPos();
        self:NativePath({map = me.GetWorldPos(), x = math.floor(x / 32), y = math.floor(y / 32)}, "npc", self.Field(npc, "szName"));
        return;
    end
    self:TalkTo(npc);
end

-- So mục hội thoại: bỏ thẻ màu, tiền tố "[Nhiệm vụ]", mọi khoảng trắng / dấu câu; khớp trọn trước, sau đó khớp đầu chuỗi
-- (vd mục có thêm "(Cấp 20)") nếu chỉ có đúng một mục như vậy.
function M:OptionKey(text)
    local s = self:Clean(text);
    s = string.gsub(s, "%[%s*nhiệm vụ%s*%]", "");
    s = string.gsub(s, "[%s%p]", "");
    return s;
end

function M:Choose(choices)
    local j = self.job;
    if not j.say or not visible(Ui.UI_SAYPANEL) then return false; end
    local exact, prefix, prefixCount;
    prefixCount = 0;
    for i, answer in ipairs(j.say[2] or {}) do
        local key = self:OptionKey(answer);
        for _, choice in ipairs(choices) do
            local want = self:OptionKey(choice);
            if want ~= "" and key ~= "" then
                if key == want then
                    if exact and exact ~= i then self:Stop("Có nhiều lựa chọn trùng tên; hãy đối thoại thủ công."); return false; end
                    exact = i;
                elseif string.len(want) >= 6 and string.sub(key, 1, string.len(want)) == want and prefix ~= i then
                    prefix, prefixCount = i, prefixCount + 1;
                end
            end
        end
    end
    local index = exact or (prefixCount == 1 and prefix) or nil;
    if not index then return false; end
    return self:Pick(index);
end

function M:Pick(index)
    local j = self.job;
    j.answers = (j.answers or 0) + 1;
    if j.answers > 40 then self:Stop("Hội thoại lặp quá nhiều lần; đã dừng để kiểm tra."); return false; end
    j.say, j.ownedSay = nil, nil;
    j.sayUntil, j.lastAction, j.chosenAt = now() + 8, now(), now();
    Ui(Ui.UI_SAYPANEL):OnListSel("LstSelectArray", index);
    return true;
end

-- Dòng còn chữ Hán (byte dẫn UTF-8 0xE4–0xE9: khối CJK) = máy chủ chưa dịch.
function M:Untranslated(text)
    return string.find(self:Plain(text or ""), "[\228-\233][\128-\191][\128-\191]") ~= nil;
end

-- Bảng Vâng/Không sau khi chọn mục nhiệm vụ (SimBot FindAffirmativeTaskAnswer): chỉ chọn khi có dòng từ chối rõ ràng.
local DECLINE = {"không", "chưa muốn", "kết thúc", "rời khỏi", "huỷ", "hủy", "để sau"};
local AGREE = {"vâng", "phải", "đồng ý", "xác nhận", "ta đồng ý", "được", "có", "đi ngay"};
function M:Affirmative(options, extra)
    local cleaned, declines, agrees = {}, 0, {};
    for i, o in ipairs(options or {}) do
        local c = self:Clean(o);
        cleaned[i] = c;
        local isDecline = c == "thôi";
        for _, d in ipairs(DECLINE) do if string.sub(c, 1, string.len(d)) == d or self:Contains(c, d) then isDecline = true; end end
        if isDecline then declines = declines + 1;
        else
            local agree = false;
            for _, a in ipairs(AGREE) do if string.sub(c, 1, string.len(a)) == a then agree = true; end end
            for _, e in ipairs(extra or {}) do if e and e ~= "" and c == self:Clean(e) then agree = true; end end
            if agree then agrees[#agrees + 1] = i; end
        end
    end
    if declines == 0 then return nil; end
    if #agrees == 1 then return agrees[1]; end
    if #agrees == 0 and #cleaned - declines == 1 then
        for i, c in ipairs(cleaned) do
            local isDecline = c == "thôi";
            for _, d in ipairs(DECLINE) do if self:Contains(c, d) then isDecline = true; end end
            if not isDecline then return i; end
        end
    end
end

-- Hộp nhận chặng / nhận thưởng. Chỉ xử lý nhiệm vụ chính tuyến; hộp của nhiệm vụ khác để người chơi tự quyết.
function M:AwardTick(j)
    if not visible(Ui.UI_GUTAWARD) then return false; end
    local window = Ui(Ui.UI_GUTAWARD);
    local nTaskId = tonumber(window.nTaskId) or 0;
    if nTaskId == 0 or not self:IsMainTask(nTaskId) then return false; end
    if window.bTaskAccept == 1 then
        if j.options.accept ~= 1 then self:Stop("Đang chờ bạn nhận chặng mới (Tự nhận chặng kế tiếp đang tắt)."); return true; end
        if j.acceptSent and now() - j.acceptSent < 5 then return true; end
        j.acceptSent, j.lastAction = now(), now();
        self.status = "Đang nhận chặng mới.";
        window:OnButtonClick("zBtnAccept");
        return true;
    end
    if not j.work or j.work.kind ~= "award" then return false; end
    if j.awardSent and now() - j.awardSent < 5 then return true; end
    local awards = window.tbAwards or {};
    local count = awards.tbOpt and #awards.tbOpt or 0;
    if count > 0 then
        local slot = math.min(j.options.award, count);
        if window.IsSpeOptAward and window:IsSpeOptAward(slot) == 1 then
            self:Stop("Thưởng tuỳ chọn ô " .. slot .. " cần trả phí; hãy chọn thưởng thủ công.");
            return true;
        end
        window:OnButtonClick("ObjOptional" .. slot);
        if (tonumber(window.nSelectedAward) or -1) ~= slot then self:Stop("Không chọn được thưởng tuỳ chọn ô " .. slot .. "."); return true; end
    end
    j.awardSent, j.lastAction = now(), now();
    self.status = "Đang nhận thưởng.";
    window:OnButtonClick("zBtnAccept");
    return true;
end

-- ---------------------------------------------------------------- giao vật phẩm (UI_ITEMGIFT, cách làm như tool/merchant)
local function matches(item, req)
    if not item or not req then return false; end
    local g, d, p, l, series = tonumber(req[1]), tonumber(req[2]), tonumber(req[3]), tonumber(req[4]) or -1, tonumber(req[5]) or -1;
    return item.nGenre == g and item.nDetail == d and item.nParticular == p and (l <= 0 or item.nLevel == l) and
        (series < 0 or item.nSeries == series);
end

function M:BagCells()
    local result, seen = {}, {};
    for _, group in ipairs({Ui.UI_ITEMBOX, Ui.UI_EXTBAG1, Ui.UI_EXTBAG2, Ui.UI_EXTBAG3}) do
        local window = group and Ui(group);
        local container = window and (window.tbMainBagCont or window.tbExtBagCont);
        if container then
            for y = 0, container.nLine - 1 do
                for x = 0, container.nRow - 1 do
                    local object = container:GetObj(x, y);
                    if object and object.nType == Ui.OBJ_OWNITEM then
                        local item = me.GetItem(object.nRoom, object.nX, object.nY);
                        local key = item and (item.dwId or item.nIndex or item);
                        if item and not seen[key] then
                            seen[key] = true;
                            result[#result + 1] = {item = item, object = object, container = container, group = group, x = x, y = y};
                        end
                    end
                end
            end
        end
    end
    return result;
end

function M:GiftTick(j)
    local window = Ui(Ui.UI_ITEMGIFT);
    local reqs = j.work.give or {};
    if #reqs == 0 then self:Stop("Không đọc được danh sách vật phẩm cần giao."); return; end
    if not j.bagsOpened then
        j.bagsOpened = true;
        if not visible(Ui.UI_ITEMBOX) then UiManager:OpenWindow(Ui.UI_ITEMBOX); end
        if Ui.tbLogic.tbExtBagLayout then pcall(Ui.tbLogic.tbExtBagLayout.Show, Ui.tbLogic.tbExtBagLayout); end
        return;
    end
    local offered, seen = {}, {};
    for y = 0, 3 do
        for x = 0, 4 do
            local item = me.GetItem(Item.ROOM_GIFT, x, y);
            if item then
                local key = item.dwId or item.nIndex or item;
                if not seen[key] then
                    seen[key] = true;
                    local hit;
                    for i, r in ipairs(reqs) do if matches(item, r) then hit = i; break; end end
                    if not hit then self:Stop("Có vật phẩm khác trong khung giao; đã huỷ giao tự động."); return; end
                    offered[hit] = (offered[hit] or 0) + item.nCount;
                end
            end
        end
    end
    local pending;
    for i, r in ipairs(reqs) do
        local need = tonumber(r[6]) or 1;
        if (offered[i] or 0) > need then self:Stop("Số lượng trong khung giao vượt yêu cầu; đã huỷ giao."); return; end
        if (offered[i] or 0) < need and not pending then pending = i; end
    end
    if not pending then
        j.gift, j.giftDone, j.lastAction = nil, true, now();
        self.status = "Đã đặt đủ vật phẩm; đang giao.";
        window:OnButtonClick("BtnOk");
        return;
    end
    if j.offerAt and now() - j.offerAt < 2 then return; end
    local r = reqs[pending];
    local remaining = (tonumber(r[6]) or 1) - (offered[pending] or 0);
    local cells = self:BagCells();
    table.sort(cells, function(a, b) return a.item.nCount < b.item.nCount; end);
    for _, cell in ipairs(cells) do
        if matches(cell.item, r) then
            if cell.item.nCount > remaining then
                if j.splitAt then
                    if now() - j.splitAt > 8 then self:Stop("Chưa tách được số lượng cần giao."); end
                    return;
                end
                if me.CountFreeBagCell() < 1 then self:Stop("Cần một ô trống để tách vật phẩm giao nhiệm vụ."); return; end
                j.splitAt = now();
                UiManager:SetUiState(UiManager.UIS_ITEM_SPLIT);
                local ok, why = pcall(me.SplitItem, cell.item, remaining);
                UiManager:ReleaseUiState(UiManager.UIS_ITEM_SPLIT);
                if not ok then error(why); end
                return;
            end
            if not visible(cell.group) then UiManager:OpenWindow(cell.group); return; end
            j.offerAt, j.splitAt, j.lastAction = now(), nil, now();
            cell.container:UseObj(cell.object, cell.x, cell.y);
            return;
        end
    end
    self:Stop("Không đủ vật phẩm để giao nhiệm vụ (" .. tostring(r[1]) .. "," .. tostring(r[2]) .. "," .. tostring(r[3]) ..
        " cần " .. tostring(r[6]) .. "). Hãy kiếm đủ rồi Lưu và Bắt Đầu lại.");
end

function M:DialogTick(j, s)
    local w = j.work;
    if visible(Ui.UI_GUTTALK) then
        j.lastAction, j.gutSeen = now(), true;
        Ui(Ui.UI_GUTTALK):OnButtonClick("Main");
        return;
    end
    if self:AwardTick(j) then return; end
    if not self.job then return; end
    if j.gift and visible(Ui.UI_ITEMGIFT) then self:GiftTick(j); return; end
    if j.say then
        if w.kind == "quiz" and j.options.quiz == 1 then
            local answer = self:QuizAnswer(w.tag, j.say[1], j.say[2]);
            if answer and self:Choose({answer}) then self.status = "Đang trả lời câu hỏi."; return; end
            if not self.job then return; end
            local start = {"Bắt đầu trả lời"};
            if w.tag and type(w.tag.szChoice) == "string" then start[2] = w.tag.szChoice; end
            if self:Choose(start) then return; end
            if not self.job then return; end
            for _, o in ipairs(j.say[2] or {}) do
                if self:Clean(o) == self:Clean("Trả lời sau") then
                    j.ownedSay = nil;
                    self:Stop("Không xác định được đáp án câu hỏi này; hãy trả lời tay rồi Lưu và Bắt Đầu lại.");
                    return;
                end
            end
        end
        if self:Choose(w.options or {}) then return; end
        if not self.job then return; end
        if w.confirm and self:Choose(w.confirm) then return; end
        if not self.job then return; end
        do
            -- Vâng/Không: sau khi vừa chọn mục nhiệm vụ; hoặc NPC mở thẳng câu hỏi mà dòng "đồng ý" còn nguyên tiếng Trung
            -- (máy chủ chưa Việt hoá, vd. Thạch Hiên Viên: "去参加英雄宴吗？" / "Ta chưa muốn đi") — client không có chữ để so.
            local i = self:Affirmative(j.say[2], w.confirm);
            if i and ((j.chosenAt and now() - j.chosenAt < 20) or self:Untranslated(j.say[2][i])) then self:Pick(i); return; end
        end
        if w.kind == "quiz" and j.options.quiz ~= 1 then
            j.ownedSay = nil;
            self:Stop("Đến phần câu hỏi; Tự trả lời đang tắt nên đã dừng.");
            return;
        end
        if not j.otherAsked and self:Choose({"Ta muốn hỏi chuyện khác"}) then j.otherAsked = true; return; end
        if not self.job then return; end
        j.ownedSay = nil;
        if s and s.progress ~= j.startProgress or (not s and j.startProgress ~= "none") then
            -- Máy chủ đã chuyển bước (vd. chọn xong "[Nhiệm vụ] ..." thì nhảy sang bước đánh quái) nhưng còn
            -- hội thoại cũ / mới không thuộc việc này: đóng lại và đọc việc tiếp theo thay vì dừng.
            if visible(Ui.UI_SAYPANEL) then UiManager:CloseWindow(Ui.UI_SAYPANEL); end
            j.say, j.phase = nil, "evaluate";
            self.status = "Máy chủ đã chuyển bước; đang đọc việc tiếp theo.";
            return;
        end
        local seen = {};
        for i, o in ipairs(j.say[2] or {}) do if i <= 6 then seen[#seen + 1] = self:Plain(o); end end
        if w.kind == "accept" and w.accept then
            -- Máy chủ chưa mời chặng này ở NPC (điều kiện phía máy chủ khác client): bỏ qua chặng này một lúc, xét chặng khác.
            self.skipRefer = self.skipRefer or {};
            self.skipRefer[w.accept.nReferId] = now();
            self:Message("NPC chưa giao chặng " .. self:Plain(w.accept.szReferName) .. " (lựa chọn: " .. table.concat(seen, " | ") .. "); xét chặng khác.");
            if visible(Ui.UI_SAYPANEL) then UiManager:CloseWindow(Ui.UI_SAYPANEL); end
            j.phase = "evaluate";
            return;
        end
        self:Stop("NPC không có lựa chọn của nhiệm vụ (" .. self:Plain((w.options or {})[1] or w.title or "") .. "). Lựa chọn đang có: " ..
            table.concat(seen, " | ") .. ". Đã giữ nguyên hội thoại.");
        return;
    end
    -- Không còn cửa sổ nào.
    if s and s.progress ~= j.startProgress or (not s and j.startProgress ~= "none") then
        j.phase = "evaluate";
        self.status = "Máy chủ đã ghi nhận; đang đọc việc tiếp theo.";
        return;
    end
    if w.waitMap and w.waitMap > 0 and me.GetWorldPos() == w.waitMap then j.phase = "evaluate"; return; end
    local idle = now() - (j.lastAction or j.at);
    if (w.kind == "transform" or w.kind == "escort" or w.kind == "guard") and idle >= 2 then
        if w.kind == "guard" then j.guardStarted = w.key; end
        self:Phase(w.kind, w.kind == "transform" and "Đang chờ NPC đổi trạng thái." or (w.kind == "escort" and "Đang hộ tống." or "Đang bảo vệ."));
        j.progressAt = now();
        return;
    end
    if idle > 15 then
        j.phase = "evaluate";
        self.status = "Chưa thấy máy chủ ghi nhận; thử lại.";
        if j.gutSeen then j.failReason = "đã xem hết hội thoại cốt truyện nhưng máy chủ chưa chuyển bước";
        elseif j.chosenAt then j.failReason = "đã chọn mục nhiệm vụ nhưng không hiện hội thoại cốt truyện";
        elseif visible(Ui.UI_SAYPANEL) then j.failReason = "bảng hội thoại mở chậm (sau 15 giây) nên chưa được xử lý";
        else j.failReason = "NPC không mở bảng hội thoại khi bấm vào"; end
    end
end

-- ---------------------------------------------------------------- đánh quái (Kill*)
local WAYPOINTS = {{0, 0}, {12, 0}, {0, 12}, {-12, 0}, {0, -12}, {20, 20}, {-20, 20}, {-20, -20}, {20, -20}};

function M:KillsLeft(j, s)
    if not s or s.key ~= j.stepKey then return nil; end
    for _, it in ipairs(s.tags) do
        if it.kind == "combat" and j.work.kill[tonumber(it.tag.nNpcTempId) or 0] and it.done then return nil; end
    end
    return true;
end

-- Nhặt vật phẩm nhiệm vụ rơi dưới đất sau khi hạ quái (như bms_items GatherTick: AutoAi.PickAroundItem mỗi 2 giây).
-- Nhặt trong ~6 giây rồi mới đi tìm quái tiếp; đủ số thì bước tự xong.
M.LOOT_SECONDS = 6;
function M:LootTick(j)
    local w = j.work;
    if not w.pick or not AutoAi.PickAroundItem then return false; end
    j.lootAt = j.lootAt or now();
    if now() - j.lootAt >= self.LOOT_SECONDS then return false; end
    if me.CountFreeBagCell and me.CountFreeBagCell() < 1 then
        if not j.bagFullSaid then j.bagFullSaid = true; self:Message("Hành trang đầy; không nhặt được vật phẩm nhiệm vụ."); end
        return false;
    end
    if not j.pickAt or now() - j.pickAt >= 2 then
        j.pickAt = now();
        pcall(AutoAi.PickAroundItem);
    end
    self.status = "Đang nhặt vật phẩm nhiệm vụ: " .. self:Plain(w.title);
    return true;
end

-- Bán kính tìm quái nhiệm vụ quanh tâm bãi theo ô Phạm vi (MPS → toạ độ thế giới /32) + nửa màn hình.
function M:HuntRadius(j)
    return (tonumber(j.options.range) or M.RANGE_DEFAULT) / 32 + 15;
end

function M:FightTick(j, s)
    if not self:KillsLeft(j, s) then j.phase = "evaluate"; return; end
    if s.progress ~= j.lastProgress then j.lastProgress, j.progressAt = s.progress, now(); end
    -- Bãi rộng quái thưa (mỗi điểm 1-2 con, chờ hồi sinh): có điểm xuất hiện thì kiên nhẫn đi vòng các điểm lâu hơn.
    local patience = j.spawnList and 600 or self.NO_PROGRESS;
    if now() - j.progressAt > patience then j.phase = "evaluate"; self.status = "Lâu không hạ được quái mục tiêu; thử lại."; return; end
    local map, x, y = me.GetWorldPos();
    local c = j.center;
    if map ~= c.map and not self:SameMap(map, c.map) then j.phase = "evaluate"; return; end
    local foe = self:NearestFoe(j.work.kill, c, self:HuntRadius(j));
    if foe then
        j.roamAt, j.lootAt, j.pickAt = nil, nil, nil;
        local fx, fy = foe.GetMpsPos(); fx, fy = fx / 32, fy / 32;
        local range = (j.options.range or self.RANGE_DEFAULT) / 32;
        if j.auto6 and j.auto6Start then
            -- Auto6 neo ở chỗ bật: quái nằm ngoài vòng neo thì Auto6 bỏ qua → nhân vật đứng/đâm vào quái mà không đánh
            -- (bấm lại Lưu và Bắt Đầu chạy được vì neo lại). Tự trả Auto6, tới gần, bật lại ở chỗ mới.
            if (fx - j.auto6X) ^ 2 + (fy - j.auto6Y) ^ 2 > range * range then
                self:ReleaseAuto6(j);
                self:Step(fx, fy);
                self.status = "Quái ngoài vòng của Auto6; tới gần rồi bật lại: " .. self:Plain(j.work.title);
                return;
            end
            -- Bật quá 25 giây mà số quái hạ không tăng: neo lại; lần hai thì tự đánh 20 giây (kỹ năng tay trái).
            if s.progress ~= j.auto6Prog then j.auto6Prog, j.auto6Start = s.progress, now(); j.auto6Stall = nil; end
            if now() - j.auto6Start > 25 then
                j.auto6Stall = (j.auto6Stall or 0) + 1;
                self:ReleaseAuto6(j);
                if j.auto6Stall >= 2 then j.nativeUntil, j.auto6Stall = now() + 20, nil; end
                self.status = "Auto6 không hạ được quái; đổi cách đánh: " .. self:Plain(j.work.title);
                return;
            end
        end
        if not j.auto6 and j.options.auto6 ~= 0 and (fx - x) ^ 2 + (fy - y) ^ 2 > (range * 0.8) ^ 2 and
            not (j.nativeUntil and now() < j.nativeUntil) then
            self:Step(fx, fy);         -- tới gần trước rồi mới bật Auto6, để quái nằm trong vòng neo
            self.status = "Tới gần " .. tostring(self.Field(foe, "szName") or "quái") .. ": " .. self:Plain(j.work.title);
            return;
        end
        if j.nativeUntil and now() < j.nativeUntil then
            self:Attack(foe);
            self.status = "Tự đánh " .. tostring(self.Field(foe, "szName") or "quái") .. ": " .. self:Plain(j.work.title);
            return;
        end
        if self:UseAuto6(j, foe) then
            if not j.auto6Start then
                local _, ax, ay = me.GetWorldPos();
                j.auto6X, j.auto6Y, j.auto6Start, j.auto6Prog = ax, ay, now(), s.progress;
            end
            self.status = "Auto6 đang đánh " .. tostring(self.Field(foe, "szName") or "quái") .. ": " .. self:Plain(j.work.title);
            return;
        end
        self:Attack(foe);
        self.status = "Đang đánh " .. tostring(self.Field(foe, "szName") or "quái") .. ": " .. self:Plain(j.work.title);
        return;
    end
    if j.attacking then j.attacking = nil; pcall(AutoAi.SetTargetIndex, 0); end
    if self:LootTick(j) then return; end
    if j.auto6 then self:ReleaseAuto6(j); end   -- hết quái quanh đây: trả Auto6 rồi mới đi vòng
    -- Biết điểm xuất hiện: đi lần lượt từng điểm của bãi (tâm tìm quái dời theo), gặp quái thì đánh.
    local list = j.spawnList;
    if list and #list > 0 then
        local p = list[j.spawnIdx] or list[1];
        if (x - p.x) ^ 2 + (y - p.y) ^ 2 <= 16 or (j.spawnAt and now() - j.spawnAt > 25) then
            j.spawnIdx = (j.spawnIdx or 1) % #list + 1;
            p, j.spawnAt = list[j.spawnIdx], nil;
        end
        j.spawnAt = j.spawnAt or now();
        j.center = {map = c.map, x = p.x, y = p.y, name = c.name, how = "spawn"};
        self:Step(p.x, p.y);
        self.status = "Đang vào bãi quái (điểm " .. j.spawnIdx .. "/" .. #list .. "): " .. self:Plain(j.work.title);
        return;
    end
    -- Không thấy quái: đi vòng quanh tâm bãi chờ hồi sinh (SimBot: quét quanh tâm, gặp quái thì dừng).
    j.waypoint = j.waypoint or 0;
    local wp = WAYPOINTS[(j.waypoint % #WAYPOINTS) + 1];
    local tx, ty = c.x + wp[1], c.y + wp[2];
    if (x - tx) ^ 2 + (y - ty) ^ 2 <= 9 or (j.roamAt and now() - j.roamAt > 10) then
        j.waypoint, j.roamAt = j.waypoint + 1, now();
        wp = WAYPOINTS[(j.waypoint % #WAYPOINTS) + 1];
        tx, ty = c.x + wp[1], c.y + wp[2];
    end
    j.roamAt = j.roamAt or now();
    self:Step(tx, ty);
    self.status = "Đang tìm quái quanh bãi: " .. self:Plain(j.work.title);
end

-- ---------------------------------------------------------------- NPC đổi trạng thái (Fight↔Dialog)
function M:TransformTick(j, s)
    if s and s.progress ~= j.startProgress then j.phase = "evaluate"; return; end
    local w = j.work;
    local fight = self:FindNpc(w.fight);
    if fight and self:Attackable(fight) then
        local _, d = self:FindNpc(w.fight);
        if d and d > 300 then local fx, fy = fight.GetMpsPos(); self:Step(fx / 32, fy / 32); end
        self:Attack(fight);
        self.status = "Đang đánh " .. tostring(self.Field(fight, "szName") or "NPC") .. ".";
        j.at = now();
        return;
    end
    local talk, d = self:FindNpc(w.dialog);
    if talk and (not j.talkedAt or now() - j.talkedAt >= 12) then
        if d > 150 then local tx, ty = talk.GetMpsPos(); self:Step(tx / 32, ty / 32); return; end
        self:TalkTo(talk);
        return;
    end
    if now() - j.at > 90 then j.phase = "evaluate"; self.status = "Chưa thấy NPC xuất hiện; thử lại."; end
end

-- ---------------------------------------------------------------- thu thập có thanh tiến trình (WithProcess*)
function M:ProcessTick(j, s)
    if s and s.progress ~= j.startProgress then j.phase = "evaluate"; j.spawnIdx = nil; return; end
    local w = j.work;
    if visible(Ui.UI_SKILLPROGRESS) then j.progressSeen, j.at = true, now(); return; end
    if self:Defend(j) then j.clickAt, j.clicks, j.at = nil, 0, now(); return; end
    local npc, d = self:FindNpc(w.npc);
    if npc then
        if d > 150 then local nx, ny = npc.GetMpsPos(); self:Step(nx / 32, ny / 32); return; end
        if not j.clickAt or now() - j.clickAt >= 4 then
            if (j.clicks or 0) >= 2 and not j.progressSeen then
                j.clicks, j.spawnIdx = 0, (j.spawnIdx or 1) + 1;
                j.phase = "evaluate"; self.status = "Không bắt đầu thu thập được ở điểm này; đổi điểm."; return;
            end
            j.clickAt, j.clicks, j.progressSeen = now(), (j.clicks or 0) + 1, nil;
            AutoAi.SetTargetIndex(npc.nIndex);
            self.status = "Đang thu thập: " .. self:Plain(w.title);
        end
        return;
    end
    if now() - j.at > 10 then
        j.spawnIdx = (j.spawnIdx or 1) + 1;
        if w.spawns and j.spawnIdx > #w.spawns then j.spawnIdx = 1; end
        j.phase = "evaluate"; self.status = "Chưa thấy đối tượng thu thập; sang điểm khác.";
    end
end

-- ---------------------------------------------------------------- dùng vật phẩm tại vùng (AddObj, CastSkillAtArea, Product…)
function M:UseItemTick(j, s)
    if s and s.progress ~= j.startProgress then j.phase = "evaluate"; return; end
    local w = j.work;
    if visible(Ui.UI_SKILLPROGRESS) then j.progressSeen, j.usedAt = true, now(); return; end
    if j.progressSeen then
        -- Thanh tiến trình vừa tắt mà bước chưa xong (s.progress chưa đổi) → bị ngắt (bị đánh / di chuyển).
        -- Dùng lại ngay, tối đa 4 lần, không tính vào số lần thử của việc.
        j.progressSeen, j.usedAt, j.standAt = nil, nil, nil;
        j.breaks = (j.breaks or 0) + 1;
        j.failReason = "thanh tiến trình bị ngắt " .. j.breaks .. " lần";
        if j.breaks > 4 then j.breaks = nil; j.phase = "evaluate"; return; end
    end
    if self:Defend(j) then j.standAt, j.usedAt = nil, nil; return; end
    local area = w.areas and w.areas[1];
    if area and area.x > 0 then
        local map, x, y = me.GetWorldPos();
        if map ~= area.map and not self:SameMap(map, area.map) then j.phase = "evaluate"; return; end
        local r = math.max(1, (area.r or 2) - 1);
        if (x - area.x) ^ 2 + (y - area.y) ^ 2 > r * r then
            -- Tâm vùng có thể nằm trên vật cản (tháp lâu, tường...): máy chủ chỉ cần đứng trong bán kính, nên đứng
            -- yên ~2 giây không tới được thì thử lần lượt 8 điểm quanh tâm (cách tâm 60% bán kính).
            if j.useX ~= x or j.useY ~= y then j.useX, j.useY, j.useMoved = x, y, now(); end
            if not j.ring then j.ring = 1; j.ringBase = math.atan2(y - area.y, x - area.x); end   -- đi từ phía mình tới, không vào tâm
            if now() - (j.useMoved or now()) > 2 then
                j.ring, j.useMoved = j.ring + 1, now();
                if j.ring > 16 then
                    j.phase = "evaluate"; j.ring = nil; self.status = "Không tới được vùng dùng vật phẩm; thử lại.";
                    j.failReason = "không đứng được trong bán kính " .. tostring(area.r) .. " ô quanh (" .. area.x .. "," .. area.y .. "), đang ở (" .. x .. "," .. y .. ")";
                    return;
                end
            end
            -- Điểm thử: hướng từ tâm về phía mình trước, rồi lệch dần ±45°, ±90°...; vòng 1 cách tâm 60% bán kính, vòng 2 là 85%.
            local k = (j.ring - 1) % 8;
            local turn = (k == 0) and 0 or (math.floor((k + 1) / 2) * ((k % 2 == 1) and 1 or -1));
            local a = j.ringBase + turn * math.pi / 4;
            local d = math.max(1, (area.r or 2) * ((j.ring <= 8) and 0.6 or 0.85));
            local tx, ty = area.x + math.floor(d * math.cos(a) + 0.5), area.y + math.floor(d * math.sin(a) + 0.5);
            self:Step(tx, ty); j.standAt = nil;
            self.status = "Đang tới vùng dùng vật phẩm: " .. self:Plain(w.title);
            return;
        end
        j.ring, j.ringBase = nil, nil;
    end
    local _, sx, sy = me.GetWorldPos();
    if j.standX ~= sx or j.standY ~= sy then j.standX, j.standY, j.standAt = sx, sy, now(); end   -- còn trôi bước: chờ đứng hẳn
    j.standAt = j.standAt or now();
    if now() - j.standAt < 1 then return; end         -- đứng yên rồi mới dùng (SimBot: 0,75 giây)
    if j.usedAt and now() - j.usedAt < 15 then return; end
    if j.usedAt then
        j.phase = "evaluate"; self.status = "Chưa được ghi nhận sau khi dùng vật phẩm; thử lại.";
        j.failReason = "đã dùng ở (" .. sx .. "," .. sy .. ") nhưng không lên thanh tiến trình" .. (riding() and ", đang cưỡi ngựa" or "");
        return;
    end
    local item = self:FindBagItem(w.itemId);
    if not item then self:Stop("Hết vật phẩm nhiệm vụ cần dùng: " .. self:Plain(w.title)); return; end
    for _, st in ipairs(w.stuffs or {}) do
        local id = st.id;
        local ok, have = pcall(me.GetItemCountInBags, id[1], id[2], id[3], id[4] > 0 and id[4] or nil);
        have = ok and tonumber(have) or nil;
        if have and have < st.count then
            local okName, name = pcall(KItem.GetNameById, id[1], id[2], id[3], id[4]);
            name = okName and name and name ~= "" and name or (id[1] .. "," .. id[2] .. "," .. id[3]);
            self:Stop("Thiếu nguyên liệu chế tạo: " .. self:Plain(name) .. " " .. have .. "/" .. st.count ..
                ". Máy chủ chỉ bù nguyên liệu khi bắt đầu bước (cần hành trang còn chỗ); hãy dọn túi, kiếm đủ rồi Lưu và Bắt Đầu lại.");
            return;
        end
    end
    if riding() and type(Switch) == "function" and not j.useDismounted then
        j.useDismounted, j.standAt = true, nil;     -- xuống ngựa trước khi dùng (tránh máy chủ từ chối khi đang cưỡi)
        pcall(Switch, "horse");
        return;
    end
    j.useDismounted = nil;
    j.usedAt = now();
    self.status = "Đang dùng vật phẩm nhiệm vụ: " .. self:Plain(w.title);
    me.UseItem(item);
end

-- ---------------------------------------------------------------- hộ tống / bảo vệ
function M:EscortTick(j, s)
    if s and s.progress ~= j.startProgress then j.phase = "evaluate"; return; end
    local w = j.work;
    local mover, d = self:FindNpc(w.mover);
    if not mover then
        if now() - j.at > 20 then j.phase = "evaluate"; self.status = "Mất dấu NPC hộ tống; thử lại."; end
        return;
    end
    j.at = now();
    local mx, my = mover.GetMpsPos();
    local follow = math.max(96, math.min(256, (w.maxDistance > 0 and w.maxDistance / 3 or 160)));
    local avoid = {[w.mover] = true, [w.npc] = true};
    local foe = d <= follow * 2 and self:NearestFoe(nil, {x = mx / 32, y = my / 32}, 12, avoid);
    if foe then self:Attack(foe); self.status = "Đang hộ tống: đánh quái chặn đường."; return; end
    if d > follow then self:Step(mx / 32, my / 32); end
    self.status = "Đang hộ tống.";
end

function M:GuardTick(j, s)
    if s and s.progress ~= j.startProgress then j.phase = "evaluate"; j.guardStarted = nil; return; end
    local w = j.work;
    local p = w.point;
    local map, x, y = me.GetWorldPos();
    if p.map > 0 and map ~= p.map and not self:SameMap(map, p.map) then j.phase = "evaluate"; return; end
    local foe = self:NearestFoe(nil, p, 15, w.protect);
    if foe then self:Attack(foe); self.status = "Đang bảo vệ: đánh quái."; j.at = now();
    elseif (x - p.x) ^ 2 + (y - p.y) ^ 2 > 36 then self:Step(p.x, p.y); end
    if now() - j.at > math.max(60, (w.duration or 0) + 60) then j.phase = "evaluate"; j.guardStarted = nil; end
end

-- ---------------------------------------------------------------- nhịp chính
function M:Tick()
    local j = self.job;
    if not j then return 0; end
    -- Chỉ coi là đổi nhân vật khi tên khác hẳn và kéo dài >= 5 s (lúc chuyển bản đồ / lên cấp / vào phái,
    -- me có thể trả tên rỗng hoặc đổi nFaction tạm thời). Không so môn phái vì chính tuyến có bước gia nhập phái.
    local name = me.szName;
    if name and name ~= "" and name ~= j.owner then
        j.otherSince = j.otherSince or now();
        if now() - j.otherSince >= 5 then self:Stop("Đã đổi nhân vật."); return 0; end
        return self.TICK;
    end
    j.otherSince = nil;
    if not name or name == "" then return self.TICK; end
    if me.IsDead and me.IsDead() == 1 then
        if j.phase ~= "dead" then
            pcall(M.StopPath, M, j);
            if j.auto6 then pcall(M.ReleaseAuto6, M, j); end
            self:Phase("dead", "Bị hạ gục; chờ hồi sinh (hãy chọn hồi sinh), auto sẽ làm tiếp.");
            self:Message(self.status);
        elseif now() - j.at > 300 then self:Stop("Bị hạ gục quá 5 phút; đã dừng.");
        end
        return self.job and self.TICK or 0;
    end
    if j.phase == "dead" then
        if now() - j.at >= 3 and not visible(Ui.UI_SKILLPROGRESS) then j.attempts = {}; j.phase = "evaluate"; end
        return self.TICK;
    end
    if j.ghep then
        local G = Ui.WJXGhepHT;
        if G and G.job == j.ghep then
            self.status = "Đang ghép Huyền Tinh: " .. tostring(G.stepText or "…");
            return self.TICK;
        end
        j.ghep, j.phase = nil, "evaluate";          -- lõi đã xong mà không báo về: làm tiếp
    end
    if j.phase == "ghep" then j.phase = "evaluate"; end
    local conflict = self:Conflict();
    if conflict then self:Stop(conflict); return 0; end
    local s = self:ReadMainTask(j.taskId);
    -- Hộp nhận chặng mới có thể mở ở bất kỳ lúc nào sau khi trả thưởng.
    if j.phase ~= "dialog" and j.phase ~= "transfer" and self:AwardTick(j) then return self.job and self.TICK or 0; end
    if j.phase == "evaluate" and self:GhepGate(j) then return self.job and self.TICK or 0; end
    if j.phase == "evaluate" then self:Evaluate();
    elseif j.phase == "transfer" and not j.transfer then
        -- Đang tự vệ trước / sau khi phù bị đánh đứt: dọn xong thì dùng phù lại.
        if not self:Defend(j) then
            if (j.transferRetries or 0) >= 5 then
                self:NativePath(j.resumePoint, j.resumeAfter, j.resumeLabel);   -- bị cắt quá nhiều lần: đi bộ
            else
                j.transferRetries = (j.transferRetries or 0) + 1;
                self:BeginTransfer(j.transferDest, j.afterTransfer);
            end
        end
    elseif j.phase == "transfer" then
        local transfer = j.transfer;
        if not visible(Ui.UI_SKILLPROGRESS) and self:Defend(j) then
            Ui.WJXTransfer:Cancel(transfer); j.transfer = nil;       -- dọn quái rồi dùng phù lại
            return self.job and self.TICK or 0;
        end
        local map, x, y = me.GetWorldPos();
        local sameMapArrived = transfer.phase == "transfer" and transfer.from == transfer.dest.map and map == transfer.dest.map and
            (x - j.transferStartX) ^ 2 + (y - j.transferStartY) ^ 2 > 25;
        local state;
        if sameMapArrived and not visible(Ui.UI_SKILLPROGRESS) then state = "done";
        else state = Ui.WJXTransfer:Tick(transfer); end
        if state == "done" then
            Ui.WJXTransfer:Cancel(transfer);
            j.transfer = nil;
            self:Phase("settle", "Đã truyền tống; chờ tải cảnh.");
        elseif state ~= "wait" then
            Ui.WJXTransfer:Cancel(transfer); j.transfer = nil;
            self:NativePath(j.resumePoint, j.resumeAfter, j.resumeLabel);   -- phù lỗi → đi bộ
        end
    elseif j.phase == "settle" then
        local map, x, y = me.GetWorldPos();
        if visible(Ui.UI_SKILLPROGRESS) or not map or map <= 0 or x <= 0 or y <= 0 then j.quietAt = nil;
        else j.quietAt = j.quietAt or now(); end
        if j.quietAt and now() - j.quietAt >= 2 then
            j.quietAt = nil;
            self:NativePath(j.resumePoint, j.resumeAfter, j.resumeLabel);
        elseif now() - j.at > 30 then self:Stop("Quá thời gian tải cảnh sau truyền tống."); end
    elseif j.phase == "travel" and j.afterPath == "trapstep" and j.trap and me.GetWorldPos() ~= j.trap.fromMap and
        me.GetWorldPos() > 0 and j.point and me.GetWorldPos() ~= j.point.map then
        self:StopPath(j);
        self:Phase("trapstep");                     -- đang đi tới cổng thì đã bị đưa qua cổng: xử lý như đã qua
    elseif j.phase == "travel" then
        local map, x, y = me.GetWorldPos();
        local path = Ui.tbLogic.tbAutoPath;
        if path.tbGotoPos and path.tbGotoPos ~= j.path then self:Stop("Đã nhường quyền cho lệnh di chuyển khác (bạn vừa bấm đường đi)."); return 0; end
        local radius = j.arriveRadius or 3;
        if map == j.point.map and (x - j.point.x) ^ 2 + (y - j.point.y) ^ 2 <= radius * radius then
            self:StopPath(j);
            self:Phase(j.afterPath);
        elseif j.afterPath == "npc" and map == j.point.map and j.work and j.work.npc and (x - j.point.x) ^ 2 + (y - j.point.y) ^ 2 <= 400 then
            local npc, d = self:FindNpc(j.work.npc);           -- đã thấy NPC trong tầm: không cần tới đúng điểm
            if npc and d <= 150 then self:StopPath(j); self:Phase("npc"); end
        elseif j.afterPath == "fight" and map == j.point.map and (x - j.point.x) ^ 2 + (y - j.point.y) ^ 2 <= self.FIGHT_RADIUS ^ 2 and
            self:NearestFoe(j.work.kill, j.point, self.FIGHT_RADIUS) then
            self:StopPath(j); self:Phase("fight");            -- vào bãi thấy quái mục tiêu: để đánh lo (SimBot 797)
        else
            if map ~= j.lastMap or (x - j.lastX) ^ 2 + (y - j.lastY) ^ 2 > 1 then
                j.lastMap, j.lastX, j.lastY, j.progress = map, x, y, now();
            end
            if not path.tbGotoPos and now() - j.progress > 3 then
                -- Tự tìm đường đã dừng (tới sát điểm bị vật cản, thất bại, hoặc bạn tự di chuyển).
                local near = (j.afterPath == "useitem") and (radius + 12) ^ 2 or 100;    -- vùng dùng vật phẩm: để UseItemTick thử vòng quanh
                if map == j.point.map and (x - j.point.x) ^ 2 + (y - j.point.y) ^ 2 <= near then
                    self:Phase(j.afterPath);
                else
                    j.phase = "evaluate"; self.status = "Tự tìm đường đã dừng giữa chừng; thử lại.";
                    j.failReason = "tự tìm đường dừng, còn cách đích " .. math.floor(math.sqrt((x - j.point.x) ^ 2 + (y - j.point.y) ^ 2)) .. " ô";
                end
            elseif now() - j.progress > 30 or now() - j.at > 600 then
                self:StopPath(j); j.phase = "evaluate"; self.status = "Bị kẹt đường; thử lại."; j.failReason = "kẹt đường";
            end
        end
    elseif j.phase == "arrive" then
        -- Đã tới vị trí GoPos / đích Send2Aim: máy chủ kiểm tra mỗi giây.
        if s and s.progress ~= j.startProgress then j.phase = "evaluate";
        elseif now() - j.at > 10 then j.phase = "evaluate"; self.status = "Chưa được ghi nhận tới nơi; thử lại."; end
    elseif j.phase == "npc" then self:NpcTick(j);
    elseif j.phase == "dialog" then self:DialogTick(j, s);
    elseif j.phase == "fight" then self:FightTick(j, s);
    elseif j.phase == "mount" then
        if riding() or now() - j.at >= 1.5 then
            j.horseFailed = not riding() or nil;      -- không có ngựa / bản đồ cấm: đi bộ, 2 phút sau mới thử lại
            local r = j.mountResume; j.mountResume = nil;
            self:NativePath(r.point, r.after, r.label);
        end
    elseif j.phase == "transform" then self:TransformTick(j, s);
    elseif j.phase == "process" then self:ProcessTick(j, s);
    elseif j.phase == "useitem" then self:UseItemTick(j, s);
    elseif j.phase == "escort" then self:EscortTick(j, s);
    elseif j.phase == "guard" then self:GuardTick(j, s);
    elseif j.phase == "ferrynpc" or j.phase == "ferrytalk" then self:FerryTick(j);
    elseif j.phase == "trapstep" then self:TrapTick(j);
    elseif j.phase == "walkto" then self:WalkTick(j);
    elseif j.phase == "buy" then self:BuyTick(j);
    elseif j.phase == "craft" then self:CraftTick(j);
    elseif j.phase == "waitserver" then
        if (s and s.progress or "none") ~= j.startProgress then j.phase = "evaluate";
        elseif now() - j.at > 15 then j.phase = "evaluate"; end
    elseif j.phase == "waitcond" then
        if now() - j.at >= (j.recheck or 5) then j.phase = "evaluate"; end
    end
    return self.job and self.TICK or 0;
end

-- Ảnh chụp cho cửa sổ (không thay đổi gì).
function M:ViewState()
    local j = self.job;
    local pick = j and j.taskId or ((self.viewTaskId or 0) > 0 and self.viewTaskId) or nil;
    local s = (pick and self:ReadMainTask(pick)) or (not pick and self:ReadMainTask()) or nil;
    local w = j and j.work;
    if not w then
        local ok, nw = pcall(M.NextWork, M, s, j and j.options or self:Options(nil));
        w = ok and nw or nil;
    end
    return s, w;
end
