-- Du Long entry/reset state machine. No file logs; options are separate from rewards.
if not Ui.WJXDuLongBoot or not Ui.WJXDuLongBoot.loading then return end
Ui.WJXDuLongReset = Ui.WJXDuLongReset or {}
local R = Ui.WJXDuLongReset
R.PATH = "\\interface\\DuLong\\dulong_reset.txt"
R.OPTIONS = "\\interface\\DuLong\\dulong_reset_options.lua"

function R:Clean(value)
    local text = tostring(value or ""):gsub("<[^>]*>", "")
    local upper = {"Đ", "À", "Á", "Ả", "Ã", "Ạ", "Ă", "Â", "Ấ", "Ầ", "Ẩ", "Ẫ", "Ậ", "Ắ", "Ằ", "Ẳ", "Ẵ", "Ặ", "È", "É", "Ẻ", "Ẽ", "Ẹ", "Ê", "Ế", "Ề", "Ể", "Ễ", "Ệ", "Ì", "Í", "Ỉ", "Ĩ", "Ị", "Ò", "Ó", "Ỏ", "Õ", "Ọ", "Ô", "Ố", "Ồ", "Ổ", "Ỗ", "Ộ", "Ơ", "Ớ", "Ờ", "Ở", "Ỡ", "Ợ", "Ù", "Ú", "Ủ", "Ũ", "Ụ", "Ư", "Ứ", "Ừ", "Ử", "Ữ", "Ự", "Ỳ", "Ý", "Ỷ", "Ỹ", "Ỵ"}
    local lower = {"đ", "à", "á", "ả", "ã", "ạ", "ă", "â", "ấ", "ầ", "ẩ", "ẫ", "ậ", "ắ", "ằ", "ẳ", "ẵ", "ặ", "è", "é", "ẻ", "ẽ", "ẹ", "ê", "ế", "ề", "ể", "ễ", "ệ", "ì", "í", "ỉ", "ĩ", "ị", "ò", "ó", "ỏ", "õ", "ọ", "ô", "ố", "ồ", "ổ", "ỗ", "ộ", "ơ", "ớ", "ờ", "ở", "ỡ", "ợ", "ù", "ú", "ủ", "ũ", "ụ", "ư", "ứ", "ừ", "ử", "ữ", "ự", "ỳ", "ý", "ỷ", "ỹ", "ỵ"}
    for i, value in ipairs(upper) do text = text:gsub(value, lower[i]) end
    return text:lower():gsub("%s+", " "):gsub("^%s+", ""):gsub("[%s%.%?!]+$", "")
end

function R:LoadRules()
    local ok, raw = pcall(KFile.ReadTxtFile, self.PATH)
    if not ok or type(raw) ~= "string" then return nil, "Không đọc được dulong_reset.txt." end
    local c = {}
    for line in raw:gmatch("[^\r\n]+") do
        line = line:gsub("^\239\187\191", "")
        if not line:match("^%s*#") then
            local key, value = line:match("^%s*([%w_]+)%s*=%s*(.-)%s*$")
            if key then
                if c[key] then return nil, "Cấu hình bị lặp: " .. key end
                c[key] = value
            end
        end
    end
    for _, key in ipairs({"TaskGroup", "DateTask", "CountTask", "DailyLimit", "ResetSuccessCount", "PendingAwardTask", "FightNpcId", "NpcId", "ScanRadius", "Timeout", "RoomMin", "RoomMax", "ResetCost", "EntryMapBelow"}) do
        local n = tonumber(c[key])
        if not n or n < 0 or n ~= math.floor(n) then return nil, "Cấu hình số không hợp lệ: " .. key end
        c[key] = n
    end
    if c.ResetCost < 1 or c.Timeout < 5 or c.ScanRadius < 100 or c.RoomMin > c.RoomMax then
        return nil, "Chi phí/thời gian/bán kính/bản đồ trong dulong_reset.txt không hợp lệ."
    end
    for _, key in ipairs({"ResetItem", "EntryItem"}) do
        local a, b, d, e = tostring(c[key]):match("^(%d+),(%d+),(%d+),(%d+)$")
        if not a then return nil, "ID vật phẩm sai: " .. key end
        c[key] = {tonumber(a), tonumber(b), tonumber(d), tonumber(e)}
    end
    for _, key in ipairs({"DateFormat", "ExhaustedText", "ResetMenu1", "ResetMenu2", "ResetMenu3", "EntryPrompt", "EntryAnswer"}) do
        if not c[key] or c[key] == "" then return nil, "Thiếu cấu hình: " .. key end
    end
    if not tonumber(os.date(c.DateFormat, GetTime())) then return nil, "DateFormat phải cho ra ngày dạng số." end
    return c
end

-- Trả: auto, count, bronze, ghep = {on, lv, bind, money} (Ghép HT mặc định bật, cấp 5, chỉ khóa, bạc khóa).
-- Trả: auto, count, bronze, g = {on, lv, bind, money, egg} (Ghép HT mặc định bật, cấp 5, chỉ khóa, bạc khóa;
-- egg: Trứng Du Long mở bằng 1 = Đồng khóa, 2 = Bạc khóa). Đọc dạng "khóa = số" nên file cũ vẫn dùng được.
function R:ReadOptions()
    local ok, raw = pcall(KFile.ReadTxtFile, self.OPTIONS)
    if not ok or type(raw) ~= "string" then raw = "" end
    local v = {}
    local body = raw:match("^%s*return%s*{(.*)}%s*$")
    if body then
        for key, num in body:gmatch("([%a_][%w_]*)%s*=%s*(%d+)") do v[key] = tonumber(num) end
    end
    local function flag(x, default) if x == nil then return default end return x == 1 and 1 or 0 end
    local g = {on = flag(v.ghep, 1), lv = math.max(2, math.min(12, v.ghepLv or 5)), bind = flag(v.ghepBind, 1),
        money = flag(v.ghepMoney, 1), egg = v.egg == 2 and 2 or 1}
    return flag(v.auto, 0), self:ClampCount(v.count), flag(v.bronze, 0), g
end

function R:ClampCount(value)
    return math.max(1, math.min(10, math.floor(tonumber(value) or 1)))
end

function R:SaveOptions(enabled, count, bronze, g)
    if type(g) ~= "table" then local _, _, _, old = self:ReadOptions(); g = old end
    local data = string.format("return { auto = %d, count = %d, bronze = %d, ghep = %d, ghepLv = %d, ghepBind = %d, ghepMoney = %d, egg = %d }\r\n",
        enabled == 1 and 1 or 0, self:ClampCount(count), bronze == 1 and 1 or 0,
        g.on == 1 and 1 or 0, math.max(2, math.min(12, math.floor(tonumber(g.lv) or 5))), g.bind == 1 and 1 or 0, g.money == 1 and 1 or 0,
        g.egg == 2 and 2 or 1)
    KFile.WriteFile(self.OPTIONS, data)
    return KFile.ReadTxtFile(self.OPTIONS) == data
end

function R:Items(id)
    local total, first = 0, nil
    for _, row in pairs(me.FindItemInBags(unpack(id)) or {}) do
        local item = row.pItem
        if item then
            first = first or item
            total = total + (tonumber(item.nCount) or 1)
        end
    end
    return total, first
end

function R:Today(c)
    return tonumber(os.date(c.DateFormat, GetTime()))
end

function R:Counts(c)
    return me.GetTask(c.TaskGroup, c.DateTask), me.GetTask(c.TaskGroup, c.CountTask)
end

function R:InRoom(c)
    local map = me.GetMapTemplateId()
    return map >= c.RoomMin and map <= c.RoomMax
end

function R:HasAward(c)
    if UiManager:WindowVisible(Ui.UI_YOULONGMIBAO) == 1 then return true end
    if c.PendingAwardTask > 0 then
        local ok, value = pcall(me.GetTask, c.TaskGroup, c.PendingAwardTask)
        if ok and type(value) == "number" and value > 0 then return true end
    end
    -- A server can charge a daily turn when combat starts, before the reward UI opens.
    for _, npc in pairs(KNpc.GetAroundNpcList(me, c.ScanRadius) or {}) do
        if c.FightNpcId > 0 and npc.nTemplateId == c.FightNpcId and (npc.nCurLife or 0) > 0 then return true end
    end
    return false
end

function R:Exhausted(c)
    if self:ServerExhausted(c) then return true end
    local ok, date, count = pcall(self.Counts, self, c)
    if not ok or type(count) ~= "number" or date ~= self:Today(c) then return false end
    local ignored = self.session and self.session.ignoreTask
    if ignored and ignored.date == date and ignored.count == count then return false end
    return c.DailyLimit > 0 and count >= c.DailyLimit
end

function R:Tell(message)
    local m = Ui.WJXDuLongSettings
    m:Tell("[Du Long] " .. message)
    m:Notify(message)
end

-- One visible warning per failed action; no per-tick chat or TXT logging.
function R:CheckScroll(c, stop)
    if self:Items(c.EntryItem) > 0 then return true end
    local message = "Đã hết Chiến Thư-Mật Thất Du Long trong hành trang. Auto chưa bắt đầu lượt mới."
    local m = Ui.WJXDuLongSettings
    if stop and m.auto then m.auto:Stop(true) end
    self:Tell(message)
    local tips = Ui.UI_TASKTIPS and Ui(Ui.UI_TASKTIPS)
    if tips and type(tips.Begin) == "function" then
        pcall(tips.Begin, tips, "<bclr=red><color=white>Đã hết Chiến Thư-Mật Thất Du Long!<color>")
    end
    return nil, message
end

function R:CheckStartScroll()
    local c, why = self:LoadRules()
    if not c then return nil, why end
    local award = Ui(Ui.UI_YOULONGMIBAO)
    -- Allow finishing a pending reward even if the last scroll has been consumed.
    if UiManager:WindowVisible(Ui.UI_YOULONGMIBAO) == 1 and award and
        (award.nState == 1 or award.nState == 4) then return true end
    if self:Items(c.EntryItem) > 0 then return true end
    if c.PendingAwardTask > 0 then
        local ok, value = pcall(me.GetTask, c.TaskGroup, c.PendingAwardTask)
        if ok and type(value) == "number" and value > 0 then return true end
    end
    return self:CheckScroll(c, false)
end

function R:RequireChallengeScroll()
    local c, why = self:LoadRules()
    if not c then
        Ui.WJXDuLongSettings.auto:Stop(true)
        self:Tell(why)
        return false
    end
    return self:CheckScroll(c, true)
end

function R:PrepareSession(enabled, count, bronze)
    local c, why = self:LoadRules()
    if not c then return nil, why end
    count = self:ClampCount(count)
    if enabled == 1 and bronze ~= 1 and self:Items(c.ResetItem) < count * c.ResetCost then
        return nil, string.format("Cần %d Kim Nguyên Bảo để reset %d lần; auto chưa chạy.", count * c.ResetCost, count)
    end
    self.exhaustion, self.manualWatch = nil, nil
    self.session = {c = c, enabled = enabled, limit = count, done = 0, bronze = bronze == 1 and 1 or 0}
    return true
end

function R:StopMove(j)
    if j and j.moving then
        j.moving = nil
        pcall(AutoAi.SetTargetIndex, 0)
        local x, y = me.GetNpc().GetMpsPos()
        pcall(AutoAi.AiAutoMoveTo, x, y)
    end
end

function R:Cancel()
    local j = self.job
    self.job = nil
    if self.timer then pcall(Timer.Close, Timer, self.timer); self.timer = nil end
    if j and me and j.owner == me.szName then self:StopMove(j) end
end

function R:Finish(success, message)
    local j = self.job
    self:Cancel()
    if j and j.kind == "reset" then
        if success then
            self.exhaustion = nil
            if j.automatic and self.session then
                self.session.done = self.session.done + 1
                self.session.waitingChallengeAt = nil
                local ok, date, count = pcall(self.Counts, self, j.c)
                if ok then self.session.ignoreTask = {date = date, count = count} end
            end
        elseif Ui.WJXDuLongSettings:IsRunning() then
            Ui.WJXDuLongSettings.auto:Stop(true)
        end
    end
    self:Tell(message)
end

function R:Begin(kind, automatic, bronze)
    if self.job then return nil, "Đang xử lý Vào Mật Thất/Reset; hãy chờ hoặc bấm Dừng." end
    local m = Ui.WJXDuLongSettings
    local c, why = self:LoadRules()
    if not c then return nil, why end
    -- This is a player declaration only; the server still decides eligibility.
    if automatic then bronze = self.session and self.session.bronze end
    bronze = bronze == 1 and 1 or 0
    if kind == "reset" then
        if automatic and not self:CheckScroll(c, false) then
            return nil, "Thiếu Chiến Thư; chưa dùng Kim Nguyên Bảo để reset tự động."
        end
        if not AutoAi or type(AutoAi.AiAutoMoveTo) ~= "function" or type(AutoAi.SetTargetIndex) ~= "function" then
            return nil, "Client chưa nạp API di chuyển/đối thoại NPC."
        end
        if not self:InRoom(c) then return nil, "Hãy vào mật thất trước khi reset." end
        if automatic then
            if self:ResetBusy(c) then return nil, "Hãy nhận xong phần thưởng trước khi reset." end
            if not self:Exhausted(c) then return nil, "Chưa xác nhận đã dùng hết lượt hôm nay; chưa reset." end
        end
        if bronze ~= 1 and self:Items(c.ResetItem) < c.ResetCost then return nil, "Không đủ Kim Nguyên Bảo để reset." end
    elseif kind == "recover" then
        if not self:InRoom(c) then return nil, "Đang không ở trong mật thất Du Long." end
        if not AutoAi or type(AutoAi.AiAutoMoveTo) ~= "function" or type(AutoAi.SetTargetIndex) ~= "function" then
            return nil, "Client chưa nạp API di chuyển/đối thoại NPC."
        end
    elseif kind == "leave" then
        if not self:InRoom(c) then return nil, "Đang không ở trong mật thất Du Long." end
        if not AutoAi or type(AutoAi.AiAutoMoveTo) ~= "function" or type(AutoAi.SetTargetIndex) ~= "function" then
            return nil, "Client chưa nạp API di chuyển/đối thoại NPC."
        end
        if self:HasAward(c) then return nil, "Đang có lượt khiêu chiến / phần thưởng chưa xong; nhận thưởng xong rồi mới Rời Mật Thất." end
        -- Dừng Auto Du Long + Auto6 trước khi nói chuyện với Thiên Thiên.
        if m:IsRunning() then self.tripStopping = true; m.auto:Stop(true); self.tripStopping = nil end
        local a6 = Ui.WJXAuto6
        if a6 and a6.session and type(a6.Stop) == "function" then pcall(a6.Stop, a6, "DULONG_LEAVE") end
    else
        local map = me.GetWorldPos()
        if m:IsRunning() or map <= 0 or map >= c.EntryMapBelow then
            return nil, "Hãy dừng auto và về thôn/thành (Map ID nhỏ hơn " .. c.EntryMapBelow .. ")."
        end
        if self:Items(c.EntryItem) < 1 then return nil, "Không có Chiến Thư-Mật Thất Du Long trong hành trang." end
        if self:Locked() then return nil, self.LOCK_TEXT end
    end
    self:Install()
    self.manualWatch = nil
    local date, count
    if kind == "reset" and automatic then
        local ok, taskDate, taskCount = pcall(self.Counts, self, c)
        date = self:Today(c)
        if ok then count = taskCount end
        if self.session then self.session.waitingChallengeAt = nil end
    elseif kind == "reset" and m:IsRunning() then
        -- Manual reset cannot verify task updates. Stop the old session so it
        -- cannot spend again or restart challenges based on stale task data.
        m.auto:Stop(true)
    end
    local j = {kind = kind, automatic = automatic, bronze = bronze, c = c, owner = me.szName,
        map = me.GetWorldPos(), started = GetTime(), date = date, count = count,
        phase = (kind == "reset" or kind == "leave" or kind == "recover") and "npc" or "entryUse", step = 1, attempts = 0}
    self.job = j
    if automatic and self:ServerExhausted(c) and
        UiManager:WindowVisible(Ui.UI_YOULONGMIBAO) == 1 and not self:HasClaimableAward() then
        UiManager:CloseWindow(Ui.UI_YOULONGMIBAO)
    end
    if m:IsRunning() then m:ReleaseAutoFight(m.auto) end
    if me.nAutoFightState == 1 then AutoAi.ProcessHandCommand("auto_fight", 0) end
    if UiManager:WindowVisible(Ui.UI_SAYPANEL) == 1 then UiManager:CloseWindow(Ui.UI_SAYPANEL) end
    local ok, id = pcall(Timer.Register, Timer, math.max(1, math.floor(Env.GAME_FPS / 2)), self.Tick, self)
    if not ok or not id or id <= 0 then self.job = nil; return nil, "Không tạo được timer Du Long." end
    self.timer = id
    self:Tell(kind == "reset" and "Đang tìm Thiên Thiên để reset lượt." or kind == "leave" and "Đang tìm Thiên Thiên để Rời Mật Thất."
        or kind == "recover" and "Lượt trước chưa nhận thưởng: nói chuyện Thiên Thiên (Tiến hành tỷ thí) để mở bảng thưởng." or "Đang dùng Chiến Thư vào mật thất.")
    return true
end

function R:FindNpc(c)
    local px, py = me.GetNpc().GetMpsPos()
    local best, distance
    for _, npc in pairs(KNpc.GetAroundNpcList(me, c.ScanRadius) or {}) do
        if npc.nTemplateId == c.NpcId then
            local x, y = npc.GetMpsPos()
            local d = (x - px)^2 + (y - py)^2
            if not distance or d < distance then best, distance = npc, d end
        end
    end
    return best, distance and math.sqrt(distance)
end

function R:Answer(j, index, nextPhase)
    j.say, j.phase, j.sent = nil, nextPhase, GetTime()
    Ui(Ui.UI_SAYPANEL):OnListSel("LstSelectArray", index)
end

function R:Process(j)
    local c, now = j.c, GetTime()
    if me.szName ~= j.owner then self:Finish(false, "Đã đổi nhân vật; dừng Du Long."); return end
    if now - j.started > c.Timeout then
        self:Finish(false, "Hết thời gian " .. (j.phase == "verify" and "chờ task xác nhận reset; không bấm lại để tránh trừ thêm vật phẩm." or "tìm NPC/đối thoại; kiểm tra vị trí và lời thoại."))
        return
    end
    if me.GetWorldPos() <= 0 then return end -- Allow the loading gap during a map transfer.
    if j.kind == "entry" and self:InRoom(c) then
        self:Finish(true, self.trip and "Đã vào lại mật thất." or "Đã vào mật thất. Bấm Bắt Đầu để chạy Du Long."); return
    end
    if j.kind == "leave" and not self:InRoom(c) then
        self:Finish(true, "Đã rời mật thất Du Long."); return
    end
    if j.phase == "leaveWait" then return end
    if j.phase == "recoverWait" then
        if UiManager:WindowVisible(Ui.UI_YOULONGMIBAO) == 1 then self:Finish(true, "Đã mở bảng thưởng lượt trước; auto nhận thưởng rồi chạy tiếp."); return end
        if now - (j.sent or now) >= 6 then self:Finish(true, "Đã nói chuyện Thiên Thiên; auto thử khiêu chiến lại.") end
        return
    end
    if me.GetWorldPos() ~= j.map then self:Finish(false, "Đã đổi bản đồ; dừng thao tác Du Long."); return end
    if j.kind == "reset" and j.automatic and self:Today(c) ~= j.date then
        self:Finish(false, "Đã sang ngày mới; kiểm tra lại lượt trước khi reset."); return
    end
    if j.failure then
        self:HandleResetFailure(j, j.failure)
        return
    end
    if j.phase == "verify" then
        self:VerifyReset(j)
        return
    end
    if j.phase == "entryUse" then
        local _, item = self:Items(c.EntryItem)
        j.phase = "entryDialog"
        if not item or me.UseItem(item) == 0 then self:Finish(false, "Không dùng được Chiến Thư.") end
        return
    end
    if j.phase == "entryWait" then return end
    if j.phase == "npc" then
        local npc, distance = self:FindNpc(c)
        if not npc then return end
        if distance <= 160 then
            self:StopMove(j)
            j.phase, j.attempts, j.sent = "dialog", j.attempts + 1, now
            AutoAi.SetTargetIndex(npc.nIndex)
        elseif not j.moveAt or now - j.moveAt >= 2 then
            local x, y = npc.GetMpsPos()
            j.moving, j.moveAt = true, now
            AutoAi.AiAutoMoveTo(x, y)
        end
        return
    end
    if not j.say then
        if j.phase == "dialog" and j.step == 1 and j.sent and now - j.sent >= 5 and j.attempts < 3 then j.phase = "npc" end
        return
    end
    if UiManager:WindowVisible(Ui.UI_SAYPANEL) ~= 1 then return end
    local options = type(j.say[2]) == "table" and j.say[2] or {}
    if j.phase == "entryDialog" then
        if self:Clean(j.say[1]):find(self:Clean(c.EntryPrompt), 1, true) and self:Clean(options[1]) == self:Clean(c.EntryAnswer) then
            self:Answer(j, 1, "entryWait")
        else self:Finish(false, "Đối thoại vào mật thất chưa khớp; chưa chọn Vâng.") end
        return
    end
    if j.kind == "recover" then
        -- Thiên Thiên: dòng đầu "Tiến hành tỷ thí" (server: còn thưởng → mở lại bảng thưởng; không → tỷ thí như thường).
        local pick, other
        for index, text in ipairs(options) do
            local t = self:Clean(text)
            if t:find("tiến hành tỷ thí", 1, true) or t:find("tỷ thí", 1, true) then pick = pick or index end
            if t:find("hỏi chuyện khác", 1, true) then other = other or index end
        end
        if pick then self:Answer(j, pick, "recoverWait")
        elseif other then self:Answer(j, other, "dialog")
        elseif #options >= 1 then self:Answer(j, 1, "recoverWait")
        else self:Finish(false, "Thiên Thiên không có dòng Tiến hành tỷ thí.") end
        return
    end
    if j.kind == "leave" then
        -- Thiên Thiên: "Rời khỏi mật thất" → hỏi lại "… rời khỏi đây?" → dòng đầu (Vâng / Đúng vậy).
        if j.step == 1 then
            local pick, other
            for index, text in ipairs(options) do
                local t = self:Clean(text)
                if t:find("rời khỏi", 1, true) or t:find("rời mật thất", 1, true) then pick = pick or index end
                if t:find("hỏi chuyện khác", 1, true) then other = other or index end
            end
            if pick then j.step = 2; self:Answer(j, pick, "dialog")
            elseif other then self:Answer(j, other, "dialog")
            else self:Finish(false, "Thiên Thiên không có dòng Rời khỏi mật thất; chưa chọn.") end
        else
            if #options < 1 then self:Finish(false, "Bảng xác nhận Rời Mật Thất trống."); return end
            self:Answer(j, 1, "leaveWait")
        end
        return
    end
    local expected, selected = self:Clean(c["ResetMenu" .. j.step]), nil
    for index, text in ipairs(options) do
        if self:Clean(text) == expected then
            if selected then self:Finish(false, "Lời thoại reset trùng dòng; chưa chọn."); return end
            selected = index
        end
    end
    if not selected then self:Finish(false, "Lời thoại reset bước " .. j.step .. " chưa khớp; kiểm tra dulong_reset.txt."); return end
    if j.step == 3 then
        if j.bronze ~= 1 and self:Items(c.ResetItem) < c.ResetCost then
            self:Finish(false, "Không đủ Kim Nguyên Bảo; chưa xác nhận reset.")
            return
        end
        if j.automatic and (not self:Exhausted(c) or self:ResetBusy(c)) then
            self:Finish(false, "Điều kiện/lượt đã thay đổi; chưa xác nhận reset.")
            return
        end
        if j.automatic and not self:CheckScroll(c, false) then
            self:Finish(false, "Thiếu Chiến Thư; chưa xác nhận reset tự động.")
            return
        end
        -- Send once. Automatic mode verifies the task; manual mode delegates
        -- eligibility to the server and does not claim an unconfirmed success.
        if j.automatic then
            self:Answer(j, selected, "verify")
        else
            self:Answer(j, selected, "manualSent")
            if j.failure then
                self:HandleResetFailure(j, j.failure)
                return
            end
            self.manualWatch = {owner = j.owner, map = j.map, c = c, at = GetTime()}
            self:Finish(true, "Đã gửi yêu cầu Reset 1 lần. Xem kết quả từ NPC; bấm Lưu và Bắt Đầu khi muốn chạy auto.")
        end
    else
        j.step = j.step + 1
        self:Answer(j, selected, "dialog")
    end
end

function R:Tick()
    if not self.job then return 0 end
    local ok, why = pcall(self.Process, self, self.job)
    if not ok then self:Finish(false, "Lỗi xử lý: " .. tostring(why)) end
    return self.job and math.max(1, math.floor(Env.GAME_FPS / 2)) or 0
end

function R:BeforeChallenge()
    if self.job then return true end
    local s = self.session
    if not s then return false end
    if not self:Exhausted(s.c) then
        if s.waitingChallengeAt then
            if self:ChallengeVisible(s.c) then
                s.waitingChallengeAt, s.unusedRecovery, s.recoverTried = nil, nil, nil
            elseif GetTime() - s.waitingChallengeAt >= 4 and not s.recoverTried then
                -- Server báo "Bạn chưa nhận thưởng, không thể khiêu chiến" (thường sau khi rời mật thất rồi vào lại):
                -- nói chuyện Thiên Thiên chọn "Tiến hành tỷ thí" để bảng thưởng hiện ra (1 lần cho mỗi lần chờ).
                s.recoverTried, s.waitingChallengeAt = true, nil
                local ok, why = self:Begin("recover", true)
                if not ok then self:Tell("Chưa mở lại được bảng thưởng: " .. tostring(why)) end
            elseif GetTime() - s.waitingChallengeAt >= 15 then
                Ui.WJXDuLongSettings.auto:Stop(true)
                self:Tell("Chưa nhận phản hồi khiêu chiến. Đã dừng, không gửi lặp lệnh tỷ thí.")
                return true
            end
        end
        return false
    end
    if s.unusedRecovery then
        Ui.WJXDuLongSettings.auto:Stop(true)
        self:FailureTip("Server vừa báo còn lượt nhưng lại từ chối khiêu chiến. Đã dừng để tránh lặp reset/tỷ thí.")
        return true
    end
    if self:ResetBusy(s.c) then return false end
    if s.enabled == 1 and s.done < s.limit then
        local ok, why = self:Begin("reset", true)
        if not ok then Ui.WJXDuLongSettings.auto:Stop(true); self:Tell(why) end
    else
        Ui.WJXDuLongSettings.auto:Stop(true)
        self:Tell("Đã hết lượt; đã reset tự động " .. s.done .. "/" .. (s.enabled == 1 and s.limit or 0) .. " lần.")
    end
    return true
end

-- ---------------------------------------------------------------- chuyến Ghép HT (Auto Ghép HT, by HUKT)
-- Trong mật thất (giữa 2 lượt) hoặc trước khi Vào Mật Thất: bật Ghép HT + hành trang còn ≤ GHEP_FREE ô + có HT ghép được
-- (ước tính giải phóng ≥ 1 ô) → Rời Mật Thất (Thiên Thiên) → lõi Ghép HT tới Dã Luyện Đại Sư ghép → dùng Chiến Thư vào lại
-- → chạy lại Auto Du Long (chuyến tự động). Không ghép được → báo, vẫn vào lại / chạy tiếp; 10 phút sau mới xét lại.
R.GHEP_FREE, R.GHEP_COOLDOWN = 5, 600
function R:GhepOpt()
    local _, _, _, g = self:ReadOptions()
    return g, {target = g.lv or 5, onlyBind = g.bind or 1, bindMoney = g.money or 1, owner = "Du Long", minFree = 1}
end

-- true = nên đi ghép ngay (đủ điều kiện)
function R:GhepNeeded()
    local G = Ui.WJXGhepHT
    if not G or type(G.CellEstimate) ~= "function" or G:Busy() then return false end
    if GetTime() < (self.ghepNext or 0) then return false end
    if G:FreeCells() > self.GHEP_FREE then return false end
    local g, opt = self:GhepOpt()
    if g.on ~= 1 then return false end
    local ok, freed, n = pcall(G.CellEstimate, G, opt)
    if not ok or (tonumber(n) or 0) <= 0 then return false end
    if (tonumber(freed) or 0) < 1 then self.ghepNext = GetTime() + 60; return false end
    return true
end

-- Gọi từ nhịp Auto Du Long (trước khi khiêu chiến lượt mới). true = đã dừng auto để đi ghép.
function R:GhepTripCheck(engine)
    if self.job or self.trip then return false end
    local c = self.session and self.session.c or self:LoadRules()
    if not c or not self:InRoom(c) or self:HasAward(c) then return false end
    if not self:GhepNeeded() then return false end
    return self:TripBegin(true)
end

-- Khóa an toàn (khóa tài khoản) đang bật: không dùng được Chiến Thư.
function R:Locked()
    local ok, v = pcall(me.IsAccountLock)
    return ok and tonumber(v) and tonumber(v) ~= 0
end
R.LOCK_TEXT = "Tài khoản đang khóa (Khóa an toàn). Hãy mở khóa rồi bấm lại."

-- Chuyến: trong mật thất → Rời → ghép → vào lại; ngoài mật thất → (ghép nếu cần) → dùng Chiến Thư vào → (tự chạy).
function R:TripBegin(autoStart)
    local c, why = self:LoadRules()
    if not c then return false, why end
    if self.job or self.trip then return false, "Đang xử lý Vào / Rời Mật Thất; hãy chờ hoặc bấm Dừng." end
    local inside = self:InRoom(c)
    if not inside and self:Locked() then return false, self.LOCK_TEXT end
    local s = self.session
    local phase = inside and "leave" or (self:GhepNeeded() and "ghep" or "enter")
    self.trip = {owner = me.szName, autoStart = autoStart, phase = phase, started = GetTime(),
        done = s and s.done, c = c}
    if phase ~= "enter" then self.ghepNext = GetTime() + self.GHEP_COOLDOWN end
    if phase == "enter" then
        self:Tell("Đang dùng Chiến Thư vào mật thất" .. (autoStart and " rồi tự chạy Auto Du Long." or "."))
    elseif self.trip.phase == "leave" then
        local ok, reason = self:Begin("leave", true)
        if not ok then self.trip = nil; self:Tell("Chưa Rời Mật Thất để ghép HT được: " .. tostring(reason)); return false end
        self:Tell("Hành trang còn " .. Ui.WJXGhepHT:FreeCells() .. " ô: Rời Mật Thất đi ghép Huyền Tinh rồi quay lại.")
    else
        self:Tell("Hành trang còn " .. Ui.WJXGhepHT:FreeCells() .. " ô: đi ghép Huyền Tinh trước khi Vào Mật Thất.")
    end
    if self.tripTimer then pcall(Timer.Close, Timer, self.tripTimer) end
    local ok, id = pcall(Timer.Register, Timer, math.max(1, math.floor(Env.GAME_FPS / 2)), self.TripTick, self)
    self.tripTimer = ok and id or nil
    return true
end

function R:TripCancel(reason)
    local t = self.trip
    self.trip = nil
    if self.tripTimer then pcall(Timer.Close, Timer, self.tripTimer); self.tripTimer = nil end
    local G = Ui.WJXGhepHT
    if t and t.job and G and G.job == t.job then pcall(G.Stop, G, "Du Long dừng") end
    if t and reason then self:Tell(reason) end
end

function R:TripTick()
    local t = self.trip
    if not t then self.tripTimer = nil; return 0 end
    local ok, why = pcall(self.TripStep, self, t)
    if not ok then self:TripCancel("Lỗi chuyến ghép HT: " .. tostring(why)) end
    if not self.trip then self.tripTimer = nil; return 0 end
    return math.max(1, math.floor(Env.GAME_FPS / 2))
end

function R:TripStep(t)
    if me.szName ~= t.owner then self:TripCancel("Đã đổi nhân vật; dừng chuyến ghép HT."); return end
    local map = me.GetWorldPos()
    if not map or map <= 0 then return end              -- đang tải bản đồ
    local c = t.c
    if t.phase == "leave" then
        if self.job then return end
        if self:InRoom(c) then
            -- không rời được: chạy lại auto trong mật thất, 10 phút sau xét lại
            t.phase = "start"; self:Tell("Chưa rời được mật thất; chạy tiếp, 10 phút sau xét ghép HT lại.")
            return
        end
        t.phase, t.settleAt = "ghep", GetTime() + 2
        return
    end
    if t.phase == "ghep" then
        if t.settleAt and GetTime() < t.settleAt then return end
        local G = Ui.WJXGhepHT
        local _, opt = self:GhepOpt()
        local okS, why = G:Start(opt, function(r) local cur = R.trip; if cur == t then t.result = r or {ok = false} end end)
        if not okS then
            self:Tell("Chưa ghép Huyền Tinh được: " .. tostring(why) .. ". Vào lại mật thất.")
            t.phase = "enter"
        else
            t.job, t.phase = G.job, "ghepWait"
        end
        return
    end
    if t.phase == "ghepWait" then
        local G = Ui.WJXGhepHT
        if not t.result and G and G.job == t.job then return end
        local r = t.result or {ok = false, why = "lõi Ghép HT đã dừng"}
        if G and r.why == G.USER_MOVE then self:TripCancel("Dừng chuyến ghép HT: bạn tự di chuyển."); return end
        if not r.ok then self:Tell("Ghép Huyền Tinh chưa xong (" .. tostring(r.why) .. "); vẫn vào lại mật thất.") end
        t.phase, t.settleAt = "enter", GetTime() + 1
        return
    end
    if t.phase == "enter" then
        if t.settleAt and GetTime() < t.settleAt then return end
        if self.job then return end
        if self:InRoom(c) then t.phase = "start"; return end
        local okE, why = self:Begin("entry", false)
        if not okE then self:TripCancel("Chưa vào lại mật thất được: " .. tostring(why)); return end
        t.phase = "enterWait"
        return
    end
    if t.phase == "enterWait" then
        if self.job then return end
        if not self:InRoom(c) then self:TripCancel("Chưa vào lại mật thất được; hãy kiểm tra Chiến Thư."); return end
        t.phase, t.settleAt = "start", GetTime() + 2
        return
    end
    if t.phase == "start" then
        if t.settleAt and GetTime() < t.settleAt then return end
        self.trip = nil
        if not t.autoStart then self:Tell("Đã ghép HT và vào mật thất. Bấm Bắt Đầu để chạy Du Long."); return end
        local m = Ui.WJXDuLongSettings
        local ok, why = m:StartSaved()
        if ok and self.session and t.done then self.session.done = t.done end      -- giữ số lần reset đã dùng
        if not ok then self:Tell("Chưa chạy lại Auto Du Long: " .. tostring(why)) end
        return
    end
end

-- ---------------------------------------------------------------- Trứng Du Long (Tự sử dụng)
R.EGG_ID = "18,1,525,1"
function R:EggExhausted()
    local e = self.eggDone
    return e and e.owner == me.szName and e.day == os.date("%y%m%d", GetTime())
end

-- Bảng hội thoại của trứng (bắt ở hook hội thoại, xử lý ở nhịp auto). true = đang xử lý, chưa dùng thêm vật phẩm.
function R:EggTick()
    local e = self.eggSay
    if not e then return false end
    if GetTime() - e.at > 8 or UiManager:WindowVisible(Ui.UI_SAYPANEL) ~= 1 then self.eggSay = nil; return false end
    self.eggSay = nil
    local options = type(e.param[2]) == "table" and e.param[2] or {}
    local caption = self:Clean(e.param[1])
    if caption:find("đã hết", 1, true) then
        self.eggDone = {owner = me.szName, day = os.date("%y%m%d", GetTime())}
        self:Tell("Số lần mở Trứng Du Long hôm nay đã hết; không tự dùng trứng nữa tới ngày mai.")
        local pick
        for index, text in ipairs(options) do if self:Clean(text):find("kết thúc", 1, true) then pick = index end end
        if pick then Ui(Ui.UI_SAYPANEL):OnListSel("LstSelectArray", pick) else UiManager:CloseWindow(Ui.UI_SAYPANEL) end
        return true
    end
    local _, _, _, g = self:ReadOptions()
    local want = g.egg == 2 and "bạc khóa" or "đồng khóa"
    for index, text in ipairs(options) do
        if self:Clean(text):find(want, 1, true) then
            Ui(Ui.UI_SAYPANEL):OnListSel("LstSelectArray", index)
            return true
        end
    end
    UiManager:CloseWindow(Ui.UI_SAYPANEL)
    self:Tell("Bảng mở Trứng Du Long không có lựa chọn " .. want .. "; đã đóng.")
    return true
end

function R:Install()
    if self.hooked then return end
    local panel = Ui(Ui.UI_SAYPANEL)
    local previous = panel.OnOpen
    panel.OnOpen = function(window, param, ...)
        local result = previous(window, param, ...)
        if type(param) == "table" then
            R:CaptureResetFailure(param)
            local j = R.job
            if j and j.owner == me.szName and (j.phase == "dialog" or j.phase == "entryDialog") then j.say = param end
            if R.eggUsedAt and GetTime() - R.eggUsedAt <= 5 and R:Clean(param[1]):find("trứng du long", 1, true) then
                R.eggSay = {param = param, at = GetTime()}
            end
            local c = j and j.c or R.session and R.session.c
            if not c then c = R:LoadRules() end
            if c then
                R:CaptureExhaustion(c, param[1])
                if j and j.automatic and j.phase == "verify" then j.resultSay = param[1] end
            end
        end
        return result
    end
    self.hooked = true
end

-- Explicit server refusal takes precedence over stale/missing task values.
function R:ServerExhausted(c)
    local e = self.exhaustion
    return e and e.owner == me.szName and e.map == me.GetWorldPos() and
        e.today == self:Today(c) and GetTime() - e.at <= 120
end

function R:HasClaimableAward()
    local ui = Ui(Ui.UI_YOULONGMIBAO)
    return UiManager:WindowVisible(Ui.UI_YOULONGMIBAO) == 1 and ui and
        (ui.nState == 1 or ui.nState == 4)
end

function R:ResetBusy(c)
    if self:ServerExhausted(c) then return self:HasClaimableAward() end
    return self:HasAward(c)
end

function R:ChallengeVisible(c)
    if UiManager:WindowVisible(Ui.UI_YOULONGMIBAO) == 1 then return true end
    for _, npc in pairs(KNpc.GetAroundNpcList(me, c.ScanRadius) or {}) do
        if npc.nTemplateId == c.FightNpcId and (npc.nCurLife or 0) > 0 then return true end
    end
    return false
end

function R:CaptureExhaustion(c, text)
    if not self:Clean(text):find(self:Clean(c.ExhaustedText), 1, true) then return end
    if not self:InRoom(c) then return end
    local j = self.job
    if j and j.kind == "reset" and not j.automatic then return end
    self.exhaustion = {owner = me.szName, map = me.GetWorldPos(), today = self:Today(c), at = GetTime()}
    if j and j.automatic and j.phase == "verify" then j.rejected = true end
end

function R:RequestChallenge()
    local s = self.session
    if self.job or not s or self:ServerExhausted(s.c) then return end
    if s.waitingChallengeAt then return end
    -- A request is outstanding until combat/reward appears, a refusal arrives,
    -- or the response timeout stops the auto. Never poll by resending the RPC.
    s.waitingChallengeAt = GetTime()
    me.CallServerScript({"ApplyYoulongmibaoRestart"})
end

function R:VerifyReset(j)
    local c, now = j.c, GetTime()
    local ok, date, count = pcall(self.Counts, self, c)
    if ok and date == j.date and count == c.ResetSuccessCount and
        type(j.count) == "number" and count < j.count then
        self:Finish(true, "Reset thành công; đã xác nhận số lượt mới từ task.")
        return
    end
    if j.rejected then
        self:Finish(false, "Server vẫn báo hết lượt sau yêu cầu reset. Đã dừng, không tự reset thêm.")
        return
    end
    if j.probeAt and self:ChallengeVisible(c) then
        self:Finish(true, "Đã xác nhận lượt khiêu chiến mới sau reset; tiếp tục Auto Du Long.")
        return
    end
    if j.resultSay then
        self:Finish(false, "NPC phản hồi sau reset: " .. tostring(j.resultSay):gsub("<[^>]*>", ""):sub(1,200))
        return
    end
    if j.probeAt then
        if now - j.probeAt >= 15 then
            self:Finish(false, "Chưa xác nhận được lượt mới sau reset. Đã dừng, không gửi lại reset/tỷ thí.")
        end
        return
    end
    if now - (j.sent or now) < 3 then return end
    -- Bronze resets need not consume an item; unreadable task data cannot prove
    -- success. Send ONE normal challenge request and observe the actual result.
    if not self:CheckScroll(c, false) then
        self:Finish(false, "Đã gửi reset nhưng thiếu Chiến Thư để tiếp tục; hãy kiểm tra NPC.")
        return
    end
    if UiManager:WindowVisible(Ui.UI_SAYPANEL) == 1 then UiManager:CloseWindow(Ui.UI_SAYPANEL) end
    j.probeAt = now
    me.CallServerScript({"ApplyYoulongmibaoRestart"})
end

-- Match both the dialogue caption and disabled/informational option rows.
function R:ResetFailure(c, param)
    if type(param) ~= "table" then return end
    local parts = {tostring(param[1] or "")}
    for _, option in ipairs(type(param[2]) == "table" and param[2] or {}) do
        parts[#parts + 1] = tostring(option)
    end
    local text = self:Clean(table.concat(parts, " "))
    local function contains(key, fallback)
        return text:find(self:Clean(c[key] or fallback), 1, true) ~= nil
    end
    if contains("ResetNoMoneyText", "Hành trang không đủ") and
        contains("ResetCurrencyText", "Kim Nguyên Bảo") then return "money" end
    if contains("ResetLimitText", "đã tham gia đủ số lần khiêu chiến") and
        contains("ResetLimitDetail", "không thể mua lại số lượt khiêu chiến bỏ lỡ") then return "limit" end
    if contains("ResetUnusedText", "Còn số lần khiêu chiến du long trong ngày chưa dùng hết") and
        contains("ResetUnusedDetail", "cần dùng hết mới có thể tiến hành làm mới") then return "unused" end
end

function R:FailureTip(message)
    self:Tell(message)
    local tips = Ui.UI_TASKTIPS and Ui(Ui.UI_TASKTIPS)
    if tips and type(tips.Begin) == "function" then
        pcall(tips.Begin, tips, "<bclr=red><color=white>" .. message .. "<color>")
    end
end

function R:HandleResetFailure(j, reason)
    self.manualWatch = nil
    local active = self.job == j
    local resume = active and j.automatic and reason == "unused" and self.session
    if active then self:Cancel() end
    -- The server uses a no-op option to dismiss these refusals. Closing the UI
    -- has the same effect without treating subtype 1 as a reset confirmation.
    if UiManager:WindowVisible(Ui.UI_SAYPANEL) == 1 then
        UiManager:CloseWindow(Ui.UI_SAYPANEL)
    end
    if resume then
        self.exhaustion = nil
        local s = self.session
        s.waitingChallengeAt = nil
        local ok, date, count = pcall(self.Counts, self, j.c)
        if ok then s.ignoreTask = {date = date, count = count} end
        s.unusedRecovery = true
        self:FailureTip("Chưa dùng hết lượt hôm nay; tiếp tục khiêu chiến, chưa reset.")
        return
    end
    if active and Ui.WJXDuLongSettings:IsRunning() then Ui.WJXDuLongSettings.auto:Stop(true) end
    local messages = {
        money = "Reset thất bại: Hành trang không đủ Kim Nguyên Bảo.",
        limit = "Đã hết số lượt reset được phép trên server. Auto Du Long đã dừng.",
        unused = "Chưa dùng hết lượt hôm nay, chưa thể reset.",
    }
    self:FailureTip(messages[reason] or "Server từ chối reset; hãy kiểm tra đối thoại NPC.")
end

function R:CaptureResetFailure(param)
    local j = self.job
    if j and j.kind == "reset" and j.owner == me.szName then
        j.failure = self:ResetFailure(j.c, param) or j.failure
        return
    end
    -- Manual reset returns after sending, so retain a brief read-only observer
    -- for a delayed server refusal. A new command/session clears this observer.
    local watch = self.manualWatch
    if not watch then return end
    if watch.owner ~= me.szName or watch.map ~= me.GetWorldPos() or
        GetTime() - watch.at > 15 or Ui.WJXDuLongSettings:IsRunning() then
        self.manualWatch = nil
        return
    end
    local reason = self:ResetFailure(watch.c, param)
    if reason then self:HandleResetFailure(watch, reason) end
end
