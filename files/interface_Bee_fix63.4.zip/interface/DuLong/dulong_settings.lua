-- Native Lua/INI settings window. No DLL, injector, polling UI timer or file logging.
-- LoadScriptDir may enumerate this before the game UI is ready.
-- Bootstrap loads it explicitly on Ctrl+Y, without Require's cache/order dependency.
if not Ui.WJXDuLongBoot or not Ui.WJXDuLongBoot.loading then return end
Ui.WJXDuLongSettings = Ui.WJXDuLongSettings or {}
Ui.WJXDuLongSettings.VERSION = "1.9.1"
Ui.WJXDuLongSettings.GROUP = "UI_WJX_DULONG_SETTINGS"
local M, Model = Ui.WJXDuLongSettings, Ui.WJXDuLongModel
local View = Ui:GetClass("dulong_settings")
local Reset = Ui.WJXDuLongReset

function M:IsRunning()
    return self.auto and (self.auto.nTimerId or 0) > 0
end

function M:Tell(text)
    if me and type(me.Msg) == "function" then pcall(me.Msg, text) end
end

function M:Notify(text)
    local wnd = Ui.tbWnd and Ui.tbWnd[self.GROUP]
    if wnd and UiManager:WindowVisible(self.GROUP) == 1 then
        wnd:RefreshDetail()
        wnd:RefreshStatus()
        if text then wnd:SetMessage(text) end
    end
end

function M:CanStart()
    if not self.auto then return nil, "Auto Du Long chưa được nạp. Hãy khởi động lại game." end
    if not me or type(me.GetMapTemplateId) ~= "function" then return nil, "Hãy đăng nhập nhân vật trước." end
    local ok, map = pcall(me.GetMapTemplateId)
    local rules, why = Reset:LoadRules()
    if not rules then return nil, why end
    if not ok or type(map) ~= "number" or map < rules.RoomMin or map > rules.RoomMax then
        return nil, "Đã lưu; hãy vào mật thất Du Long rồi bấm Lưu và Bắt Đầu."
    end
    return 1
end

function M:Open()
    if UiManager:WindowVisible(self.GROUP) ~= 1 then
        UiManager:OpenWindow(self.GROUP)
    else
        self:Notify()
    end
end

function M:FightApiReady()
    local data = Ui.tbLogic and Ui.tbLogic.tbAutoFightData
    return AutoAi and type(AutoAi.UpdateCfg) == "function"
        and type(AutoAi.ProcessHandCommand) == "function"
        and data and type(data.ShortKey) == "function"
end

-- Cấu hình đánh RIÊNG cho Du Long (by HUKT, như Chính Tuyến mượn Auto6): kỹ năng / thuốc / nhặt đồ lấy từ Auto6 đã lưu,
-- nhưng tắt Luyện Công / Theo Sau / PvP / Hậu cần / Ghép HT / Quay lại điểm chết và đánh MỌI NPC (kể cả BOSS: NPC tỷ thí
-- Du Long máu ≥ ngưỡng BOSS) — tránh trường hợp đang lưu chế độ Luyện Công hoặc "Bỏ qua BOSS / quái thường" làm nhân vật
-- chỉ chạy quanh NPC mà không đánh. Chỉ áp dụng cho phiên này, không ghi đè cài đặt Auto6.
function M:DuLongFightConfig()
    local a6 = Ui.WJXAuto6
    if not a6 or type(a6.Normalize) ~= "function" then return Ui.tbLogic.tbAutoFightData:ShortKey() end
    local okL, raw = pcall(function() return Ui(Ui.UI_AUTOFIGHT):Load("AutoFight") end)
    local cfg = a6:Normalize(okL and raw or {})
    for key, value in pairs({nTrain = 0, nFollow = 0, nPvpMode = 0, nSkipNormal = 0, nSupply = 0, nGhep = 0,
        nAssistLeader = 0, nCombatEnabled = 1, nPreferPlayer = 0, nStayFire = 0, nDead = 0}) do
        cfg[key] = value
    end
    cfg.tbGoldModes = {}
    cfg.nScanRange = math.max(tonumber(cfg.nScanRange) or 1200, 1200)
    cfg.nAutoFight = 1
    return cfg
end

function M:EnsureAutoFight(engine)
    if not self:FightApiReady() then return nil, "Chưa nạp chức năng tự chiến đấu Ctrl+F." end
    local a6 = Ui.WJXAuto6
    -- Auto6 do người chơi / plugin khác bật (cấu hình của họ có thể bỏ qua BOSS, Luyện Công…): dừng 1 lần để bật lại đúng cấu hình Du Long.
    if a6 and a6.session and not engine._fightOwned and type(a6.Stop) == "function" then
        pcall(a6.Stop, a6, "DULONG_MODE")
        self:Tell("[Du Long] Đã dừng Auto6 đang chạy để bật lại với cấu hình đánh NPC tỷ thí Du Long.")
    end
    if me.nAutoFightState == 1 then engine._fightAttempts = 0; return 1 end
    -- Starting a challenge may change fight state on a later server update.
    -- Wait for that state using the existing Du Long timer, not another timer.
    if me.nFightState ~= 1 then engine._fightAttempts = 0; return 1 end
    if (engine._fightAttempts or 0) >= 3 then
        return nil, "Không bật được tự chiến đấu sau 3 lần thử. Kiểm tra cài đặt Ctrl+F."
    end
    local cfg = self:DuLongFightConfig()
    if type(cfg) ~= "table" then return nil, "Cấu hình Ctrl+F chưa sẵn sàng." end
    local requested = {}
    for key, value in pairs(cfg) do requested[key] = value end
    requested.nAutoFight = 1 -- Never toggle an already-enabled mode off.
    engine._fightOwned, engine._fightOwner = true, me.szName
    engine._fightAttempts = (engine._fightAttempts or 0) + 1
    AutoAi:UpdateCfg(requested)
    return 1
end

function M:ReleaseAutoFight(engine)
    local owned, owner = engine._fightOwned, engine._fightOwner
    engine._fightOwned, engine._fightOwner, engine._fightAttempts = nil, nil, 0
    -- Do not switch off auto-fight which was already enabled by the player.
    if owned and me and owner == me.szName and me.nAutoFightState == 1 then
        if AutoAi and type(AutoAi.ProcessHandCommand) == "function" then
            local ok = pcall(AutoAi.ProcessHandCommand, "auto_fight", 0)
            if not ok then self:Tell("Du Long đã dừng; hãy kiểm tra/tắt Ctrl+F thủ công.") end
        end
    end
end

function M:LoadRuntime(auto, expectedRaw)
    local doc, err = Model:Read()
    if not doc then return nil, err end
    if expectedRaw and doc.token ~= expectedRaw then
        return nil, "File đã thay đổi sau khi lưu. Auto chưa chạy; hãy Tải lại."
    end
    -- Replace the entire old map; deleted rows must not remain active.
    auto.tbDate = Model:ToRuntime(doc)
    return 1
end

function M:Install(auto)
    if not auto then return end
    self.auto = auto
    Reset:Install()
    if auto.OnStart == self.startWrapper then return end
    local originalTick = assert(auto._settingsOriginalTick, "Missing original Du Long timer")
    local originalHistory = auto.PrintAwardHistory

    auto.Stop = function(engine, silent)
        Reset:Cancel()
        if not Reset.tripStopping and Reset.trip then Reset:TripCancel() end     -- bấm Dừng: hủy cả chuyến ghép HT
        local id = engine.nTimerId or 0
        engine.nTimerId = 0
        engine._settingsPermit = nil
        if id > 0 then pcall(Timer.Close, Timer, id) end
        M:ReleaseAutoFight(engine)
        if id > 0 and not silent then
            local count = 0
            for _, value in pairs(engine.tbAwardHistory or {}) do count = count + (tonumber(value) or 0) end
            if count > 0 and originalHistory then pcall(originalHistory, engine) end
        end
        engine.tbAwardHistory, engine.nStartTime, engine._settingsOwner = {}, 0, nil
        M:Notify("Auto Du Long đã dừng.")
    end

    auto.AutoUseItem = function(engine)
        if Reset:EggTick() then return end
        if UiManager:WindowVisible(Ui.UI_SAYPANEL) == 1 then return end          -- đang có hội thoại: không dùng thêm
        for szId, row in pairs(engine.tbDate or {}) do
            if row[4] == 1 and not (szId == Reset.EGG_ID and (Reset:EggExhausted() or
                (Reset.eggUsedAt and GetTime() - Reset.eggUsedAt < 3))) then
                local g, d, p, l = string.match(szId, "^(%d+),(%d+),(%d+),(%d+)$")
                local items = g and me.FindItemInBags(tonumber(g), tonumber(d), tonumber(p), tonumber(l)) or {}
                if #items ~= 0 then
                    if szId == Reset.EGG_ID then Reset.eggUsedAt = GetTime() end
                    me.UseItem(items[1].nRoom, items[1].nX, items[1].nY)
                    return
                end
            end
        end
    end

    auto.ReadFile = function(engine)
        local ok, err = M:LoadRuntime(engine)
        if not ok then M:Tell(err) end
        return ok
    end

    self.startWrapper = function(engine)
        local permittedRaw = engine._settingsPermit
        engine._settingsPermit = nil
        -- Legacy hotkeys/calls are routed to settings, never to an implicit start.
        if type(permittedRaw) ~= "string" then Ui.WJXDuLongBoot:Open(); return 0 end
        if M:IsRunning() then return 1 end
        local allowed, why = M:CanStart()
        if not allowed then return 0, why end
        local hasScroll, scrollError = Reset:CheckStartScroll()
        if not hasScroll then return 0, scrollError end
        local loaded, err = M:LoadRuntime(engine, permittedRaw)
        if not loaded then return 0, err end
        if not M:FightApiReady() then return 0, "Chưa nạp chức năng tự chiến đấu Ctrl+F." end
        local enabled, count, bronze = Reset:ReadOptions()
        local ready, resetError = Reset:PrepareSession(enabled, count, bronze)
        if not ready then return 0, resetError end
        engine.tbAwardHistory, engine.szLastMsg = {}, ""
        engine.nStartTime, engine._settingsOwner = GetTime(), me.szName
        local ok, id = pcall(Timer.Register, Timer, Env.GAME_FPS, engine.OnTimer, engine)
        if not ok or type(id) ~= "number" or id <= 0 then
            engine.nTimerId, engine.nStartTime, engine._settingsOwner = 0, 0, nil
            return 0, "Không tạo được timer Du Long. Auto chưa chạy."
        end
        engine.nTimerId = id
        local called, enabled, fightError = pcall(M.EnsureAutoFight, M, engine)
        if not called or not enabled then
            engine:Stop(true)
            return 0, called and fightError or "Lỗi khi bật Ctrl+F. Auto Du Long đã dừng."
        end
        return 1
    end
    auto.OnStart = self.startWrapper

    auto.OnTimer = function(engine)
        if (engine.nTimerId or 0) <= 0 then return 0 end
        local allowed = M:CanStart()
        if not allowed or not me or me.szName ~= engine._settingsOwner then
            engine:Stop(true)
            M:Notify("Auto đã dừng vì đổi nhân vật hoặc rời mật thất.")
            return 0
        end
        -- Ghép HT giữa 2 lượt: Rời Mật Thất → ghép → vào lại → chạy tiếp (Reset tự dừng auto khi bắt đầu chuyến).
        local tripOk, tripStarted = pcall(Reset.GhepTripCheck, Reset, engine)
        if tripOk and tripStarted then return 0 end
        local checked, blocked = pcall(Reset.BeforeChallenge, Reset)
        if not checked then
            engine:Stop(true)
            M:Tell("Lỗi kiểm tra lượt Du Long: " .. tostring(blocked))
            return 0
        end
        if blocked then return (engine.nTimerId or 0) > 0 and Env.GAME_FPS or 0 end
        local called, enabled, fightError = pcall(M.EnsureAutoFight, M, engine)
        if not called or not enabled then
            engine:Stop(true)
            M:Tell(called and fightError or "Lỗi khi bật tự chiến đấu. Du Long đã dừng.")
            return 0
        end
        local ok, result = pcall(originalTick, engine)
        if not ok then
            engine:Stop(true)
            M:Tell("Auto Du Long đã dừng do dữ liệu chưa sẵn sàng. Ctrl+Y để kiểm tra cài đặt.")
            M:Notify("Auto đã dừng an toàn. Kiểm tra vật phẩm/cửa sổ thưởng rồi thử lại.")
            return 0
        end
        if (engine.nTimerId or 0) <= 0 then return 0 end
        if result == 0 then engine:Stop(true); return 0 end
        return result
    end

    -- Chain the existing lifecycle, rather than replacing other plugins' cleanup.
    if not self.leaveHook and type(Ui.LeaveGame) == "function" then
        local prior = Ui.LeaveGame
        Ui.LeaveGame = function(ui)
            if M.auto then M.auto:Stop(true) end
            local wnd = Ui.tbWnd and Ui.tbWnd[M.GROUP]
            if wnd then wnd.doc = nil end
            return prior(ui)
        end
        self.leaveHook = true
    end
end

-- Chạy Auto Du Long theo cấu hình đã lưu (chuyến ghép HT vào lại mật thất xong gọi). Trả ok, lý do.
function M:StartSaved()
    local engine = self.auto
    if not engine then return nil, "Auto Du Long chưa được nạp." end
    if self:IsRunning() then return true end
    local doc, err = Model:Read()
    if not doc then return nil, err end
    engine._settingsPermit = doc.token
    local started, result, why = pcall(engine.OnStart, engine)
    engine._settingsPermit = nil
    if not started then engine:Stop(true); return nil, "Không khởi động được auto." end
    if result ~= 1 then return nil, why or "Auto chưa chạy." end
    self:Notify("Đã chạy lại Auto Du Long.")
    return true
end

function View:Init()
    self.busy = false
    self.binding = false
end

function View:SetMessage(text)
    Txt_SetTxt(self.UIGROUP, "TxtMessage", text or "")
end

function View:RefreshStatus()
    local running = M:IsRunning()
    local working = Reset.job ~= nil or Reset.trip ~= nil
    local kind = Reset.job and Reset.job.kind
    local state = (running and "ĐANG CHẠY" or "ĐÃ DỪNG")
    if Reset.trip and not Reset.job then state = "ĐANG GHÉP HUYỀN TINH"
    elseif kind then state = kind == "entry" and "ĐANG VÀO MẬT THẤT" or kind == "leave" and "ĐANG RỜI MẬT THẤT" or "ĐANG RESET" end
    Txt_SetTxt(self.UIGROUP, "TxtState", state)
    Txt_SetTxt(self.UIGROUP, "TxtDirty", self:HasChanges() and "Có thay đổi chưa lưu" or "Không có thay đổi chưa lưu")
    -- 1 nút Bắt Đầu / Dừng theo trạng thái; 1 nút Vào / Rời Mật Thất theo vị trí nhân vật.
    Btn_SetTxt(self.UIGROUP, "BtnStart", (running or working) and "Dừng" or "Bắt Đầu")
    Wnd_SetEnable(self.UIGROUP, "BtnStart", ((running or working) or (self.doc and not self.busy)) and 1 or 0)
    local rules = Reset:LoadRules()
    local inside = rules and Reset:InRoom(rules)
    Btn_SetTxt(self.UIGROUP, "BtnEnter", inside and "Rời Mật Thất" or "Vào Mật Thất")
    Wnd_SetEnable(self.UIGROUP, "BtnSave", self.doc and not running and not working and not self.busy and 1 or 0)
    Wnd_SetEnable(self.UIGROUP, "BtnReload", not running and not working and not self.busy and 1 or 0)
    Wnd_SetEnable(self.UIGROUP, "BtnEnter", not working and (inside or not running) and 1 or 0)
    Wnd_SetEnable(self.UIGROUP, "BtnResetOnce", not working and 1 or 0)
    Wnd_SetEnable(self.UIGROUP, "BtnAutoReset", not running and not working and 1 or 0)
    Wnd_SetEnable(self.UIGROUP, "BtnBronze", not running and not working and 1 or 0)
    Wnd_SetEnable(self.UIGROUP, "EdtResetCount", not running and not working and 1 or 0)
end

function View:ResetControls()
    local enabled, count, bronze, g = Reset:ReadOptions()
    self.binding = true
    Btn_Check(self.UIGROUP, "BtnAutoReset", enabled)
    Btn_Check(self.UIGROUP, "BtnBronze", bronze)
    Edt_SetTxt(self.UIGROUP, "EdtResetCount", tostring(count))
    self.ghep = {on = g.on, lv = g.lv, bind = g.bind, money = g.money}
    self.eggMode = g.egg or 1
    ClearComboBoxItem(self.UIGROUP, "CmbEgg")
    ComboBoxAddItem(self.UIGROUP, "CmbEgg", 1, "Trứng Du Long (Đồng Khóa)")
    ComboBoxAddItem(self.UIGROUP, "CmbEgg", 2, "Trứng Du Long (Bạc Khóa)")
    ComboBoxSelectItem(self.UIGROUP, "CmbEgg", self.eggMode - 1)
    Btn_Check(self.UIGROUP, "BtnGhep", g.on)
    Btn_Check(self.UIGROUP, "BtnGhepBind", g.bind)
    Btn_Check(self.UIGROUP, "BtnGhepMoney", g.money)
    ClearComboBoxItem(self.UIGROUP, "CmbGhepLv")
    for lv = 2, 12 do ComboBoxAddItem(self.UIGROUP, "CmbGhepLv", lv - 1, "Cấp " .. lv) end
    ComboBoxSelectItem(self.UIGROUP, "CmbGhepLv", (g.lv or 5) - 2)
    self.binding = false
    self.resetLoaded, self.resetDirty = true, false
end

function View:HasChanges()
    return Model:IsDirty(self.doc) or self.resetDirty
end

function View:OnComboBoxIndexChange(name, index)
    if self.binding then return end
    if name == "CmbEgg" then
        local mode = (tonumber(index) or 0) + 1
        if (mode == 1 or mode == 2) and mode ~= self.eggMode then
            self.eggMode, self.resetDirty = mode, true
            self:RefreshStatus()
            self:SetMessage("Bấm Lưu hoặc Bắt Đầu để lưu cách mở Trứng Du Long.")
        end
        return
    end
    if name ~= "CmbGhepLv" or not self.ghep then return end
    local lv = (tonumber(index) or 0) + 2
    if lv >= 2 and lv <= 12 and lv ~= self.ghep.lv then
        self.ghep.lv, self.resetDirty = lv, true
        self:RefreshStatus()
        self:SetMessage("Bấm Lưu hoặc Bắt Đầu để lưu lựa chọn Ghép HT.")
    end
end

function View:GhepDraft()
    local g = self.ghep or {lv = 5}
    return {on = Btn_GetCheck(self.UIGROUP, "BtnGhep") == 1 and 1 or 0, lv = g.lv or 5, egg = self.eggMode or 1,
        bind = Btn_GetCheck(self.UIGROUP, "BtnGhepBind") == 1 and 1 or 0,
        money = Btn_GetCheck(self.UIGROUP, "BtnGhepMoney") == 1 and 1 or 0}
end

function View:OnEditChange(name)
    if self.binding or name ~= "EdtResetCount" then return end
    local text = Edt_GetTxt(self.UIGROUP, name)
    self.resetDirty = true
    if text == "" then return end
    local count = tostring(Reset:ClampCount(text))
    if text ~= count then
        self.binding = true
        Edt_SetTxt(self.UIGROUP, name, count)
        self.binding = false
    end
    self:RefreshStatus()
end

function View:RefreshDetail()
    local group = self.doc and self.doc.groups[self.selectedId]
    self.binding = true
    Txt_SetTxt(self.UIGROUP, "TxtItem", group and group.name or "Chọn vật phẩm bên trái")
    Txt_SetTxt(self.UIGROUP, "TxtItemId", group and ("ID: " .. group.id) or "")
    Btn_Check(self.UIGROUP, "BtnReceiveItem", group and group.reward == 1 and 1 or 0)
    Btn_Check(self.UIGROUP, "BtnReceiveCoin", group and group.reward == 0 and 1 or 0)
    Btn_Check(self.UIGROUP, "BtnUseful", group and group.useful > 0 and 1 or 0)
    Btn_Check(self.UIGROUP, "BtnAutoUse", group and group.auto == 1 and 1 or 0)
    -- Trứng Du Long: hiện chọn Đồng khóa / Bạc khóa ngay dưới "Tự sử dụng khi có trong túi"
    local egg = group and group.id == Reset.EGG_ID
    for _, name in ipairs({"TxtEgg", "CmbEgg"}) do
        if egg then Wnd_Show(self.UIGROUP, name) else Wnd_Hide(self.UIGROUP, name) end
    end
    local controls = {"BtnReceiveItem", "BtnReceiveCoin", "BtnUseful", "BtnAutoUse"}
    for _, name in ipairs(controls) do
        Wnd_SetEnable(self.UIGROUP, name, group and not M:IsRunning() and not self.busy and 1 or 0)
    end
    local hint = "Bật = 1: thấy vật phẩm này thì tiếp tục.\nTắt = 0: không lấy nó làm điều kiện tiếp tục."
    if group and group.useful > 1 then
        hint = "Ngưỡng cũ: " .. group.useful .. " (đang giữ nguyên).\nBấm ô để chuyển về chế độ 0 / 1."
    end
    Txt_SetTxt(self.UIGROUP, "TxtUsefulHint", hint)
    self.binding = false
end

function View:RefreshList()
    self.binding = true
    local query = string.lower(Edt_GetTxt(self.UIGROUP, "EdtSearch") or "")
    query = string.gsub(string.gsub(query, "^%s+", ""), "%s+$", "")
    self.visibleRows = {}
    Lst_Clear(self.UIGROUP, "LstItems")
    local selectIndex
    for _, group in ipairs(self.doc and self.doc.order or {}) do
        if query == "" or string.find(string.lower(group.name .. " " .. group.id), query, 1, true) then
            local index = #self.visibleRows + 1
            self.visibleRows[index] = group.id
            Lst_SetCell(self.UIGROUP, "LstItems", index, 0, group.name)
            if group.id == self.selectedId then selectIndex = index end
        end
    end
    selectIndex = selectIndex or (#self.visibleRows > 0 and 1 or nil)
    self.selectedId = selectIndex and self.visibleRows[selectIndex] or nil
    if selectIndex then Lst_SetCurKey(self.UIGROUP, "LstItems", selectIndex) end
    Txt_SetTxt(self.UIGROUP, "TxtCount", #self.visibleRows .. " vật phẩm")
    self.binding = false
    self:RefreshDetail()
    self:RefreshStatus()
end

function View:Reload()
    self:ResetControls()
    local doc, err = Model:Read()
    self.doc = doc
    if not doc then
        self.selectedId = nil
        self:SetMessage(err)
    else
        self:SetMessage("Chỉnh cài đặt rồi bấm Lưu và Bắt Đầu. Chỉ lưu không chạy auto.")
    end
    self:RefreshList()
end

function View:OnOpen()
    if not self.resetLoaded then self:ResetControls() end
    if self.doc and self:HasChanges() then
        self:RefreshList()
        self:SetMessage("Đang giữ bản chỉnh chưa lưu. Tải lại để bỏ bản chỉnh này.")
    else
        Edt_SetTxt(self.UIGROUP, "EdtSearch", "")
        self:Reload()
    end
    return 1
end

function View:OnClose()
    -- Hiding the settings window must not stop the background auto or Ctrl+F.
    self.busy = false
end

function View:OnListSel(name, index)
    if self.binding or name ~= "LstItems" then return end
    self.selectedId = self.visibleRows and self.visibleRows[index]
    self:RefreshDetail()
end

function View:AskDiscard(callback)
    if not self:HasChanges() then callback(); return end
    local msg = {szMsg = "Bỏ các thay đổi Du Long chưa lưu và đọc lại file?", nOptCount = 2}
    function msg:Callback(option)
        if option == 2 then callback() end
    end
    UiManager:OpenWindow(Ui.UI_MSGBOX, msg)
end

function View:SaveSettings(start)
    if self.busy or M:IsRunning() or Reset.job then return end
    local enabled = Btn_GetCheck(self.UIGROUP, "BtnAutoReset") == 1 and 1 or 0
    local bronze = Btn_GetCheck(self.UIGROUP, "BtnBronze") == 1 and 1 or 0
    local count = Reset:ClampCount(Edt_GetTxt(self.UIGROUP, "EdtResetCount"))
    Edt_SetTxt(self.UIGROUP, "EdtResetCount", tostring(count))
    if start then
        local hasScroll, scrollError = Reset:CheckStartScroll()
        if not hasScroll then self:SetMessage(scrollError); return end
        local ready, why = Reset:PrepareSession(enabled, count, bronze)
        if not ready then self:SetMessage(why); M:Tell(why); return end
    end
    self.busy = true
    self:RefreshStatus()
    local ok, doc, err = pcall(Model.Save, Model, self.doc)
    self.busy = false
    if not ok then
        self:SetMessage("Lỗi khi lưu. Auto chưa chạy; kiểm tra file và quyền ghi.")
    elseif not doc then
        self:SetMessage(err)
    else
        self.doc = doc
        local saved, verified = pcall(Reset.SaveOptions, Reset, enabled, count, bronze, self:GhepDraft())
        if not saved or not verified then
            self:SetMessage("Không lưu được cài đặt reset; auto chưa chạy.")
            self:RefreshStatus()
            return
        end
        self.resetDirty = false
        self:SetMessage("Đã lưu cấu hình. Auto vẫn đang dừng.")
        local rules = start and Reset:LoadRules()
        if start and rules and not Reset:InRoom(rules) then
            -- Ở ngoài: tự dùng Chiến Thư vào mật thất (ghép HT trước nếu cần) rồi tự chạy.
            local ok, res, why = pcall(Reset.TripBegin, Reset, true)
            if not ok then self:SetMessage("Lỗi Du Long: " .. tostring(res))
            elseif not res then self:SetMessage(why); M:Tell(why)
            else self:SetMessage("Đã lưu. Đang vào mật thất rồi tự chạy; đóng cửa sổ vẫn tiếp tục.") end
            self:RefreshDetail()
            self:RefreshStatus()
            return
        end
        if start then
            local engine = M.auto
            if not engine then
                self:SetMessage("Đã lưu; auto chưa nạp. Hãy khởi động lại game.")
            else
                engine._settingsPermit = doc.token
                local started, result, why = pcall(engine.OnStart, engine)
                engine._settingsPermit = nil
                if not started then
                    engine:Stop(true)
                    self:SetMessage("Không khởi động được auto. Cấu hình đã lưu.")
                elseif result ~= 1 then
                    self:SetMessage(why or "Auto chưa chạy.")
                else
                    self:SetMessage("Đã chạy. Đóng cửa sổ vẫn tiếp tục. Ctrl+Y mở lại; bấm Dừng để dừng auto.")
                end
            end
        end
    end
    self:RefreshDetail()
    self:RefreshStatus()
end

function View:OnButtonClick(name)
    -- Closing is always allowed, including during a save/rebind/reset.
    if name == "BtnClose" then
        UiManager:CloseWindow(self.UIGROUP)
        return
    end
    if self.binding or self.busy then return end
    if name == "BtnStart" and (M:IsRunning() or Reset.job or Reset.trip) then          -- nút đang là Dừng
        Reset:TripCancel()
        Reset:Cancel()
        if M.auto then M.auto:Stop() end
        self:SetMessage("Đã dừng Auto Du Long.")
        self:RefreshStatus()
        return
    end
    if name == "BtnFind" then self:RefreshList(); return end
    if name == "BtnEnter" then
        local rules = Reset:LoadRules()
        local inside = rules and Reset:InRoom(rules)
        if not inside and Reset:Locked() then self:SetMessage(Reset.LOCK_TEXT); M:Tell(Reset.LOCK_TEXT); return end
        if not inside and not Reset.job and not Reset.trip and Btn_GetCheck(self.UIGROUP, "BtnGhep") == 1 then
            -- Trước khi Vào Mật Thất: còn ít ô và ghép được → ghép trước (dùng lựa chọn đang hiện; chưa lưu thì lưu tùy chọn ghép)
            if self.resetDirty then pcall(Reset.SaveOptions, Reset, Btn_GetCheck(self.UIGROUP, "BtnAutoReset"), Edt_GetTxt(self.UIGROUP, "EdtResetCount"), Btn_GetCheck(self.UIGROUP, "BtnBronze"), self:GhepDraft()); self.resetDirty = false end
            if Reset:GhepNeeded() then
                local ok, result = pcall(Reset.TripBegin, Reset, false)
                if ok and result then self:RefreshStatus(); return end
            end
        end
        local ok, result, why = pcall(Reset.Begin, Reset, inside and "leave" or "entry", false, Btn_GetCheck(self.UIGROUP, "BtnBronze"))
        if not ok then
            Reset:Cancel()
            self:SetMessage("Lỗi Du Long: " .. tostring(result))
        elseif not result then
            self:SetMessage(why)
            M:Tell(why)
        end
        self:RefreshStatus()
        return
    end
    if name == "BtnResetOnce" then
        local ok, result, why = pcall(Reset.Begin, Reset, "reset", false, Btn_GetCheck(self.UIGROUP, "BtnBronze"))
        if not ok then
            Reset:Cancel()
            self:SetMessage("Lỗi Du Long: " .. tostring(result))
        elseif not result then
            self:SetMessage(why)
            M:Tell(why)
        end
        self:RefreshStatus()
        return
    end
    if Reset.job then return end
    if name == "BtnGhep" or name == "BtnGhepBind" or name == "BtnGhepMoney" then
        self.resetDirty = true
        self:RefreshStatus()
        self:SetMessage("Bấm Lưu hoặc Bắt Đầu để lưu lựa chọn Ghép HT.")
        return
    end
    if name == "BtnAutoReset" or name == "BtnBronze" then
        self.resetDirty = true
        self:RefreshStatus()
        self:SetMessage("Bấm Lưu hoặc Bắt Đầu để lưu lựa chọn reset.")
        return
    end
    if M:IsRunning() then return end
    if name == "BtnReload" then
        local wnd = self
        self:AskDiscard(function() wnd:Reload() end)
        return
    end
    if name == "BtnSave" then self:SaveSettings(false); return end
    if name == "BtnStart" then
        if Reset:Locked() then self:SetMessage(Reset.LOCK_TEXT); M:Tell(Reset.LOCK_TEXT); return end
        self:SaveSettings(true)
        return
    end
    if not self.doc or not self.selectedId then return end
    local field, value
    if name == "BtnReceiveItem" then field, value = "reward", 1
    elseif name == "BtnReceiveCoin" then field, value = "reward", 0
    elseif name == "BtnUseful" then field, value = "useful", Btn_GetCheck(self.UIGROUP, name) == 1 and 1 or 0
    elseif name == "BtnAutoUse" then field, value = "auto", Btn_GetCheck(self.UIGROUP, name) == 1 and 1 or 0
    end
    if field then
        Model:Set(self.doc, self.selectedId, field, value)
        self:SetMessage("Đang giữ thay đổi tạm. Bấm Chỉ lưu hoặc Lưu và Bắt Đầu.")
        self:RefreshDetail()
        self:RefreshStatus()
    end
end

-- Registration follows the existing Compose/native plugin pattern.
Ui:RegisterNewUiWindow(M.GROUP, "dulong_settings", {"a", 90, 60}, {"b", 200, 120}, {"c", 320, 160})
local width, height = Wnd_GetSize(M.GROUP, "Main")
if not width or width <= 0 or not height or height <= 0 then
    -- Some clients do not resolve newly added plugin INIs by basename.
    LoadUiGroup(M.GROUP, "\\interface\\DuLong\\dulong_settings.ini")
    width, height = Wnd_GetSize(M.GROUP, "Main")
end
assert(width and width > 0 and height and height > 0, "Khong nap duoc dulong_settings.ini")
if GetUiMode() == "d" then
    Ui:AddExWndConfig(M.GROUP, {"d", 380, 180})
    Ui:LoadExWndConfig(M.GROUP)
end
-- Refresh wrappers after editing/reloading the UI source; retain the single leave hook.
M.startWrapper = nil
