-- Du Long overrides. TXT remains read-only. Flags: 0 or 1.
-- Example: ["18,1,114,8"] = { DuiHuan = 1, Useful = 0, AutoUse = 0 },
-- Remove an entry/field to inherit the base TXT value. Click Tai lai after editing.
return {
}
