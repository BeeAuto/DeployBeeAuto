-- Embedded at the TOP of youlong.lua. No module/INI dependency before hotkey registration.
-- The engine predeclares Ui and Youlongmibao in setting/scripttable.txt.
-- Never create globals: client preload.lua rejects them.
assert(type(Youlongmibao) == "table", "Du Long engine module is not loaded")
Ui.WJXDuLongBoot = Ui.WJXDuLongBoot or {}
local Boot = Ui.WJXDuLongBoot
Boot.VERSION = "1.8.2"
function Boot:Tell(message)
    if me and me.Msg then pcall(me.Msg, "[DuLong 1.8.2] " .. tostring(message)) end
end
function Boot:Stop()
    if Ui.WJXDuLongReset then Ui.WJXDuLongReset:Cancel() end
    local engine = Youlongmibao.tbYoulongG
    if engine then
        local settings = Ui.WJXDuLongSettings
        if settings and settings.auto == engine and engine.OnStart == settings.startWrapper then
            engine:Stop(true)
            return
        end
        local id = engine.nTimerId or 0
        engine.nTimerId, engine._settingsPermit = 0, nil
        if id > 0 then pcall(Timer.Close, Timer, id) end
        engine._settingsOwner, engine.nStartTime = nil, 0
    end
end
function Boot:Open()
    local ok, why = pcall(function()
        local sources, changed = {}, false
        for _, name in ipairs({"dulong_settings_model.lua", "dulong_reset.lua", "dulong_settings.lua"}) do
            local path = "\\interface\\DuLong\\" .. name
            local source = KFile.ReadTxtFile(path)
            assert(type(source) == "string" and #source > 0, "Khong doc duoc " .. path)
            sources[name] = source
            if not self.sources or self.sources[name] ~= source then changed = true end
        end
        if changed or not Ui.WJXDuLongSettings or not Ui.tbWnd[Ui.WJXDuLongSettings.GROUP] then
            self:Stop() -- Code reload, not ordinary opening/closing, ends a session.
            if Ui.WJXDuLongSettings then
                local old = Ui.tbWnd[Ui.WJXDuLongSettings.GROUP]
                -- Keep edits in memory while refreshing code; closing/reloading never saves.
                self.draft = old and old.doc or self.draft
                UiManager:CloseWindow(Ui.WJXDuLongSettings.GROUP)
            end
            self.loading = true
            for _, name in ipairs({"dulong_settings_model.lua", "dulong_reset.lua", "dulong_settings.lua"}) do
                local source = string.gsub(sources[name], "^\239\187\191", "")
                local fn, problem = loadstring(source, "@\\interface\\DuLong\\" .. name)
                assert(fn, problem)
                fn()
            end
            self.sources = sources
            local wnd = Ui.tbWnd[Ui.WJXDuLongSettings.GROUP]
            if wnd then wnd.doc = self.draft end
            self.draft = nil
        end
        self.loading = nil
        local settings = assert(Ui.WJXDuLongSettings, "Chua nap duoc giao dien")
        settings:Install(assert(Youlongmibao.tbYoulongG, "Chua nap duoc auto"))
        settings:Open()
        assert(UiManager:WindowVisible(settings.GROUP) == 1, "Cua so chua hien. Kiem tra dulong_settings.ini va khoi dong lai game.")
    end)
    self.loading = nil
    if not ok then
        self.sources = nil -- Retry on next key press; never cache a partial initialization.
        self:Tell(why)
        return 0
    end
    return 1
end
-- RegisterKeys clears native bindings and recreates them from m_tKeyList.
-- Keep an entry there as well as the immediate native binding. Do not rebuild
-- every other plugin's keys here, and never add a duplicate on Lua reload.
function Boot:RegisterHotkey()
    local list = UiShortcutAlias.m_tKeyList or {}
    UiShortcutAlias.m_tKeyList = list
    local row = {"Ui.WJXDuLongBoot:Open()", "DLSettings", "", "CTRL+Y", "CTRL+Y",
        "Auto Du Long settings", UiShortcutAlias.emKSTATE_INGAME}
    local found = false
    for index, entry in ipairs(list) do
        if entry[2] == "DLSettings" then list[index] = row; found = true; break end
    end
    if not found then list[#list + 1] = row end
    UiShortcutAlias:AddAlias(row[2], row[1])
    AddCommand(row[4], row[3], row[2], row[7])
end
Boot:Stop() -- Reloading the entry script never resumes an old timer.
UiShortcutAlias:AddAlias("DLSettings", "Ui.WJXDuLongBoot:Open()")
-- Redirect an old cached alias too, but do not register a second key.
UiShortcutAlias:AddAlias("WJX_DULONG_SETTINGS_OPEN", "Ui.WJXDuLongBoot:Open()")
Boot:RegisterHotkey()

-- code by jzw
-- modify by zy

--?? DoScript("\\ui\\youlong.lua")
-- Youlongmibao.tbYoulongG:SwitchState()
-- ?? Youlongmibao.tbYoulongG:PrintAwardHistory()

Youlongmibao.tbYoulongG = Youlongmibao.tbYoulongG or {};
local tbYoulongG = Youlongmibao.tbYoulongG;


tbYoulongG.tbDate = tbYoulongG.tbDate or {};
tbYoulongG.nTimerId = tbYoulongG.nTimerId or 0;
tbYoulongG.tbItem = {{18,1,524,1}}; -- Exact scroll; do not retain the legacy level-0 wildcard on reload.
tbYoulongG.szLastMsg  = tbYoulongG.szLastMsg or "";
tbYoulongG.tbAwardHistory = tbYoulongG.tbAwardHistory or {};
tbYoulongG.nStartTime = tbYoulongG.nStartTime or 0;

tbYoulongG.Msg=function(self, szMsg)
--function tbYoulongG:Msg(szMsg)
	if tbYoulongG.szLastMsg == szMsg then
		return;
	end
	me.Msg(szMsg);
	tbYoulongG.szLastMsg = szMsg;
end

tbYoulongG.SwitchState=function(self)
--function tbYoulongG:SwitchState()
	if self.nTimerId > 0 then
		self:Stop();
	else
		self:OnStart();
	end
end

tbYoulongG.OnStart=function(self)
--function tbYoulongG:OnStart()
	-- Status is shown in the settings window.
	self.nStartTime = GetTime();
	local nMyMapId	= me.GetMapTemplateId();
	if (nMyMapId >1692 or nMyMapId < 1665) then
		me.Msg("Tới mật thất mới chạy được auto");
		return;
	end
	self = tbYoulongG;
	self:ReadFile();
	if (self.nTimerId == 0) then
		self.nTimerId = Timer:Register(1 * Env.GAME_FPS, self.OnTimer, self);
	end	
end

tbYoulongG.Stop=function(self)
--function tbYoulongG:Stop()
	self:PrintAwardHistory();
	self.tbAwardHistory = {};
	Timer:Close(Youlongmibao.tbYoulongG.nTimerId);
	self.nTimerId = 0;
	self.nStartTime = 0;
end

tbYoulongG.CheckUsefulItem=function(self)
--function tbYoulongG:CheckUsefulItem()
	local tbItemList = {};
	local tbItemObjList = {};
	local uiYoulongmibao = Ui(Ui.UI_YOULONGMIBAO);
	for i = 1, uiYoulongmibao.GRID_COUNT - 1 do
		if uiYoulongmibao.tbGridCont[i] and uiYoulongmibao.tbGridCont[i]:GetObj() then
			local pItem = uiYoulongmibao.tbGridCont[i]:GetObj().pItem;
			if pItem then
				local szId = string.format("%s,%s,%s,%s", pItem.nGenre, pItem.nDetail, pItem.nParticular, pItem.nLevel);
				tbItemList[szId] = (tbItemList[szId] or 0) + 1;
				tbItemObjList[szId] = pItem;
			end
		end
	end
	for szId, nCount in pairs(tbItemList) do
		if nCount >= self.tbDate[szId][3] and self.tbDate[szId][3] > 0 then
			local pItem = tbItemObjList[szId];
			self:Msg(string.format("<color=gray>Đã tìm thấy %s:%d/%d tiếp tục, đóng<color>", pItem.szName, tbItemList[szId], self.tbDate[szId][3]));
			return 1;
		end
	end
	self:Msg("Quá xui ,AG")
	return 0;
end

tbYoulongG.OnTimer=function(self)
--function tbYoulongG:OnTimer()
	-- No per-tick console logging.
	local uiGutAward = Ui(Ui.UI_YOULONGMIBAO);
	local nState = 0;
	if UiManager:WindowVisible(Ui.UI_YOULONGMIBAO) == 1 then	--选奖励
		if uiGutAward.nState == 1 then
			uiGutAward.OnButtonClick(uiGutAward,"BtnGetAward");
		elseif uiGutAward.nState == 2 then
            if not Ui.WJXDuLongReset:RequireChallengeScroll() then return 0 end
			if self:CheckUsefulItem() == 1 then
				uiGutAward.OnButtonClick(uiGutAward,"BtnContinue");
			else
				uiGutAward.OnButtonClick(uiGutAward,"BtnRestart");
			end
		elseif uiGutAward.nState == 3 then
            if not Ui.WJXDuLongReset:RequireChallengeScroll() then return 0 end
			uiGutAward.OnButtonClick(uiGutAward,"BtnRestart");
		elseif uiGutAward.nState == 4 then
			if self:GetAward() == 1 then
				uiGutAward.OnButtonClick(uiGutAward,"BtnConfirmAward");
			else
				uiGutAward.OnButtonClick(uiGutAward,"BtnChangeCoin");
			end
			nState = 1;
		end
	else
		local nId = self:GetAroundNpcId(3690);
		if nId then
            if not Ui.WJXDuLongReset:RequireChallengeScroll() then return 0 end
			--接任务
			Ui.WJXDuLongReset:RequestChallenge();			
		end
	end
	self:AutoUseItem();
end


tbYoulongG.Split=function(self, szFullString, szSeparator)
--function tbYoulongG:Split(szFullString, szSeparator)
	local nFindStartIndex = 1
	local nSplitIndex = 1
	local nSplitArray = {}
	while true do
	   local nFindLastIndex = string.find(szFullString, szSeparator, nFindStartIndex)
	   if not nFindLastIndex then
	    nSplitArray[nSplitIndex] = string.sub(szFullString, nFindStartIndex, string.len(szFullString))
	    break
	   end
	   nSplitArray[nSplitIndex] = string.sub(szFullString, nFindStartIndex, nFindLastIndex - 1)
	   nFindStartIndex = nFindLastIndex + string.len(szSeparator)
	   nSplitIndex = nSplitIndex + 1
	end
	return nSplitArray
end

tbYoulongG.AutoUseItem=function(self)
--function tbYoulongG:AutoUseItem()
	for szId, tbRow in pairs(self.tbDate) do
		if (tbRow[4] == 1) then
			local G, D, P, L = unpack(self:Split(szId, ","));			
			local tbItems = me.FindItemInBags(tonumber(G), tonumber(D), tonumber(P), tonumber(L));
			if #tbItems ~= 0 then
				me.UseItem(tbItems[1].nRoom, tbItems[1].nX, tbItems[1].nY);
				return;
			end
		end
	end
end


--function tbYoulongG:FindItem()
tbYoulongG.FindItem=function(self)	
	local tbFind = nil;
	for i = 1, #self.tbItem do
		tbFind =  me.FindItemInBags(unpack(self.tbItem[i]));
		if #tbFind > 0 then
			return 1;
		end
	end
	return 0;	
end

--function tbYoulongG:GetAward()
tbYoulongG.GetAward=function(self)
	--me.Msg("生成奖励");
	local pItem = Ui(Ui.UI_YOULONGMIBAO).tbGridCont[26]:GetObj().pItem;
	if pItem then
		local szId = string.format("%s,%s,%s,%s", pItem.nGenre, pItem.nDetail, pItem.nParticular, pItem.nLevel);
		self.tbAwardHistory[pItem.szName] = (self.tbAwardHistory[pItem.szName] or 0) + 1;
		if self.tbDate[szId] then
			if self.tbDate[szId][1] == 1 then
				self:Msg("<color=gray>Phần thưởng : " .. pItem.szName);
			else
				self:Msg("<color=gray>Đổi tiền : " .. pItem.szName);
			end
			return self.tbDate[szId][1];
		end
	end
	self:Msg("Mặc định khen thưởng :" .. pItem.szName);
	return 1;
end

--function tbYoulongG:PrintAwardHistory()
tbYoulongG.PrintAwardHistory=function(self)
	local nTotalCount = 0;
	local nTime = GetTime() - self.nStartTime;
	local nHours = math.floor(nTime / 3600);
	local nMinutes = math.floor(nTime % 3600 / 60);
	local nSeconds = math.floor(nTime % 60);
	local szTime = string.format("%d:%d:%d", nHours, nMinutes, nSeconds);
	me.Msg("Kết quả");
	for szName, nCount in pairs(self.tbAwardHistory) do
		me.Msg(string.format("%s:%d个", szName, nCount));
		nTotalCount = nTotalCount + nCount;
	end
	me.Msg(string.format("Tổng số:%d tháng , sử dụng:%s, một thời gian nhất định:%d giây", nTotalCount, szTime, nTime / nTotalCount));
end

--function tbYoulongG:GetAroundNpcId(nTempId)
tbYoulongG.GetAroundNpcId=function(self, nTempId)
	local tbAroundNpc	= KNpc.GetAroundNpcList(me, 20);
	for _, pNpc in ipairs(tbAroundNpc) do
		if (pNpc.nTemplateId == nTempId) then
			return pNpc.nIndex;
		end
	end
	return;
end

--function tbYoulongG:ReadFile()
tbYoulongG.ReadFile=function(self)
	local tbFile = Lib:LoadTabFile("\\interface\\DuLong\\youlongmibao.txt");
	if not tbFile then
		print("Lỗi các tập tin không tồn tại",szFileName);
		return;
	end
	for nId, tbParam in ipairs(tbFile) do
		if nId >= 1 then
			local szName = tbParam.Name or "";
			local szId = tbParam.Id or "";
			local nDuiHuan = tonumber(tbParam.DuiHuan) or 1;
			local nUseful = tonumber(tbParam.Useful) or 1;
			local nAutoUse = tonumber(tbParam.AutoUse) or 0;
			if not self.tbDate then
				self.tbDate = {};
			end
			if szName ~= "" and szId ~= "" and nDuiHuan then				
				if string.find(szId, '"') then
					local nEnd = string.len(szId);
					if (nEnd) then
						szId = string.sub(szId, 2, nEnd-1);
					end					
				end
				self.tbDate[szId] = { nDuiHuan, szName, nUseful, nAutoUse}; 
			end
		end
	end
	local tbStr = {" - Nhận vật phẩm", " - Đổi Tiền Du Long"}
	for szId,tbItem in pairs(self.tbDate) do
		local nFlag = 2 - tbItem[1];	
		me.Msg(string.format("<color=yellow>[Du Long]<color><color=pink>%s<color>%s",tbItem[2], tbStr[nFlag]));		
	end	
end

--------注册按键

-- Block all legacy start routes, even if loading the settings fails.
tbYoulongG._settingsOriginalTick = tbYoulongG.OnTimer;
tbYoulongG.OnStart = function(self) return Ui.WJXDuLongBoot:Open() end;
tbYoulongG.SwitchState = tbYoulongG.OnStart;
if Ui.WJXDuLongSettings and Ui.WJXDuLongSettings.Install then Ui.WJXDuLongSettings:Install(tbYoulongG) end;
