-- Du Long settings v1.1. Read-only base TXT plus validated literal Lua overrides.
-- This module never starts the auto. Executable config statements are rejected.
Ui.WJXDuLongModel = Ui.WJXDuLongModel or {}
Ui.WJXDuLongModel.VERSION = "1.3"
local Model = Ui.WJXDuLongModel
Model.PATH = "\\interface\\DuLong\\youlongmibao.txt"
Model.CONFIG = "\\interface\\DuLong\\dulong_config.lua"
Model.BACKUP = "\\interface\\DuLong\\dulong_config.bak"

local function trim(s)
    return (string.gsub(string.gsub(s or "", "^%s+", ""), "%s+$", ""))
end

local function cells(s)
    local out, pos = {}, 1
    while true do
        local at = string.find(s, "\t", pos, true)
        if not at then out[#out + 1] = string.sub(s, pos); break end
        out[#out + 1] = string.sub(s, pos, at - 1)
        pos = at + 1
    end
    return out
end

local function lines(raw)
    local out, pos = {}, 1
    while pos <= #raw do
        local at = string.find(raw, "\n", pos, true)
        local text, eol
        if at then
            text, eol = string.sub(raw, pos, at - 1), "\n"
            if string.sub(text, -1) == "\r" then
                text, eol = string.sub(text, 1, -2), "\r\n"
            end
            pos = at + 1
        else
            text, eol, pos = string.sub(raw, pos), "", #raw + 1
        end
        out[#out + 1] = {text = text, eol = eol}
    end
    return out
end

function Model:ReadText(path)
    if not KFile or type(KFile.ReadTxtFile) ~= "function" then
        return nil, "Client không có KFile.ReadTxtFile."
    end
    local ok, value = pcall(KFile.ReadTxtFile, path or self.PATH)
    if not ok or type(value) ~= "string" then
        return nil, "Không đọc được file cấu hình Du Long."
    end
    return value
end

function Model:Parse(raw)
    if type(raw) ~= "string" or #raw == 0 then return nil, "File cấu hình trống." end
    if #raw > 262144 or string.find(raw, "\000", 1, true) then
        return nil, "File cấu hình không phải TXT hợp lệ hoặc quá lớn."
    end
    local doc = {raw = raw, lines = lines(raw), groups = {}, order = {}, rowCount = 0}
    local header = cells(doc.lines[1].text)
    if string.sub(header[1], 1, 3) == "\239\187\191" then
        header[1] = string.sub(header[1], 4)
    end
    doc.columns = {}
    for i, name in ipairs(header) do
        if name ~= "" then
            if doc.columns[name] then return nil, "Cột bị lặp: " .. name end
            doc.columns[name] = i
        end
    end
    local required = {"Index", "Name", "Id", "DuiHuan", "Useful", "AutoUse"}
    for _, name in ipairs(required) do
        if not doc.columns[name] then return nil, "Thiếu cột " .. name end
    end
    local c = doc.columns
    for i = 2, #doc.lines do
        local line = doc.lines[i]
        if trim(line.text) ~= "" then
            local row = cells(line.text)
            for _, name in ipairs(required) do
                if row[c[name]] == nil then return nil, "Dòng " .. i .. " thiếu cột " .. name end
            end
            local id = trim(row[c.Id])
            if string.sub(id, 1, 1) == '"' and string.sub(id, -1) == '"' then
                id = string.sub(id, 2, -2)
            end
            if not string.match(id, "^%d+,%d+,%d+,%d+$") or trim(row[c.Name]) == "" then
                return nil, "Tên hoặc ID không hợp lệ ở dòng " .. i
            end
            local reward, useful, auto = tonumber(row[c.DuiHuan]), tonumber(row[c.Useful]), tonumber(row[c.AutoUse])
            if (reward ~= 0 and reward ~= 1) or (auto ~= 0 and auto ~= 1) then
                return nil, "DuiHuan / AutoUse phải là 0 hoặc 1 (dòng " .. i .. ")."
            end
            if not useful or useful < 0 or useful > 2147483647 or useful ~= math.floor(useful) then
                return nil, "Useful không hợp lệ ở dòng " .. i
            end
            line.cells, line.id = row, id
            local group = doc.groups[id]
            if not group then
                group = {id = id, members = {}, changed = {}}
                doc.groups[id], doc.order[#doc.order + 1] = group, group
            end
            group.members[#group.members + 1] = i
            -- Match original engine behavior: the last row for an ID wins.
            group.name, group.reward, group.useful, group.auto = row[c.Name], reward, useful, auto
            group.original = {reward = reward, useful = useful, auto = auto}
            doc.rowCount = doc.rowCount + 1
        end
    end
    if #doc.order == 0 then return nil, "Không có vật phẩm hợp lệ trong cấu hình." end
    return doc
end

function Model:Read()
    local raw, err = self:ReadText()
    if not raw then return nil, err end
    local doc, why = self:Parse(raw)
    if not doc then return nil, why end
    local ok, config = pcall(KFile.ReadTxtFile, self.CONFIG)
    if not ok then return nil, "Không đọc được dulong_config.lua." end
    if config == nil then config = "" end
    if type(config) ~= "string" then return nil, "Không đọc được dulong_config.lua." end
    local overrides, problem = self:ParseConfig(config)
    if not overrides then return nil, problem end
    doc.configRaw, doc.overrides = config, overrides
    local fields = {DuiHuan = "reward", Useful = "useful", AutoUse = "auto"}
    for _, group in ipairs(doc.order) do
        group.base = {reward = group.reward, useful = group.useful, auto = group.auto}
        for column, field in pairs(fields) do
            local value = overrides[group.id] and overrides[group.id][column]
            if value ~= nil then group[field] = value end
        end
        group.original = {reward = group.reward, useful = group.useful, auto = group.auto}
    end
    doc.token = raw .. "\000" .. config
    return doc
end

-- Only literal tables, integer flags and item IDs are accepted. No executable Lua.
-- This permits hand editing/reloading without executing arbitrary configuration code.
function Model:ParseConfig(raw)
    if raw == "" then return {} end
    if #raw > 262144 then return nil, "dulong_config.lua quá lớn." end
    local source = string.gsub(raw, "^\239\187\191", "")
    source = string.gsub(source, "%-%-[^\r\n]*", "")
    local lex = string.gsub(source, '"%d+,%d+,%d+,%d+"', "")
    lex = string.gsub(lex, "[%a_][%w_]*", function(word)
        if word == "return" or word == "DuiHuan" or word == "Useful" or word == "AutoUse" then return "" end
        return "!"
    end)
    lex = string.gsub(lex, "[%d%s{},%[%]=;]", "")
    if lex ~= "" then return nil, "dulong_config.lua chỉ được chứa bảng ID và cờ 0/1." end
    local fn, why = loadstring(source, "@dulong_config.lua")
    if not fn then return nil, "Sai cú pháp dulong_config.lua: " .. tostring(why) end
    setfenv(fn, {})
    local ok, values = pcall(fn)
    if not ok or type(values) ~= "table" then return nil, "dulong_config.lua phải return một bảng." end
    for id, entry in pairs(values) do
        if type(id) ~= "string" or not string.match(id, "^%d+,%d+,%d+,%d+$") or type(entry) ~= "table" then
            return nil, "ID hoặc dòng tùy chỉnh Lua không hợp lệ."
        end
        for field, value in pairs(entry) do
            if (field ~= "DuiHuan" and field ~= "Useful" and field ~= "AutoUse") or (value ~= 0 and value ~= 1) then
                return nil, "Tùy chỉnh Lua chỉ nhận DuiHuan / Useful / AutoUse = 0 hoặc 1."
            end
        end
    end
    return values
end

function Model:SerializeConfig(doc)
    local values, ids = {}, {}
    -- Keep overrides for IDs temporarily absent from the base TXT.
    for id, entry in pairs(doc.overrides or {}) do
        if not doc.groups[id] then values[id] = entry end
    end
    local fields = {DuiHuan = "reward", Useful = "useful", AutoUse = "auto"}
    for _, group in ipairs(doc.order) do
        local entry = {}
        for column, field in pairs(fields) do
            if group[field] ~= group.base[field] then entry[column] = group[field] end
        end
        if next(entry) then values[group.id] = entry end
    end
    for id in pairs(values) do ids[#ids + 1] = id end
    table.sort(ids)
    local out = {"-- Du Long overrides. TXT remains read-only. Flags: 0 or 1.\r\n",
        "-- Example: [\"18,1,114,8\"] = { DuiHuan = 1, Useful = 0, AutoUse = 0 },\r\n",
        "-- Remove an entry/field to inherit the base TXT value. Click Tai lai after editing.\r\nreturn {\r\n"}
    for _, id in ipairs(ids) do
        local entry, flags = values[id], {}
        for _, field in ipairs({"DuiHuan", "Useful", "AutoUse"}) do
            if entry[field] ~= nil then flags[#flags + 1] = field .. " = " .. entry[field] end
        end
        out[#out + 1] = '    ["' .. id .. '"] = { ' .. table.concat(flags, ", ") .. " },\r\n"
    end
    out[#out + 1] = "}\r\n"
    return table.concat(out)
end

function Model:Set(doc, id, field, value)
    local group = doc and doc.groups[id]
    if not group or (field ~= "reward" and field ~= "useful" and field ~= "auto") then
        return nil, "Không tìm thấy cài đặt cần sửa."
    end
    if value ~= 0 and value ~= 1 then return nil, "Tùy chọn chỉ nhận 0 hoặc 1." end
    group[field] = value
    group.changed[field] = value ~= group.original[field] and true or nil
    return 1
end

function Model:IsDirty(doc)
    if not doc then return false end
    for _, group in ipairs(doc.order) do
        if next(group.changed) then return true end
    end
    return false
end

function Model:WriteVerified(path, data)
    if not KFile or type(KFile.WriteFile) ~= "function" then return nil end
    local ok = pcall(KFile.WriteFile, path, data)
    if not ok then return nil end
    local actual = self:ReadText(path)
    return actual == data and 1 or nil
end

function Model:Save(doc)
    if not doc then return nil, "Chưa có cấu hình để lưu." end
    local current, err = self:Read()
    if not current then return nil, err end
    if current.token ~= doc.token then
        return nil, "TXT hoặc Lua đã đổi bên ngoài. Bấm Tải lại trước khi lưu."
    end
    if not self:IsDirty(doc) then return current end
    local output = self:SerializeConfig(doc)
    local verified, parseError = self:ParseConfig(output)
    if not verified then return nil, parseError end
    if not self:WriteVerified(self.BACKUP, doc.configRaw) then
        return nil, "Không tạo/xác minh được bản sao cấu hình. Chưa ghi file chính."
    end
    current = self:Read()
    if not current or current.token ~= doc.token then
        return nil, "File vừa thay đổi bên ngoài. Chưa ghi đè; hãy Tải lại."
    end
    if not self:WriteVerified(self.CONFIG, output) then
        return nil, "Không xác minh được Lua đã lưu. Auto KHÔNG chạy. Bản cũ: dulong_config.bak"
    end
    current, err = self:Read()
    if not current or current.raw ~= doc.raw or current.configRaw ~= output then
        return nil, err or "File thay đổi trong khi lưu. Auto KHÔNG chạy."
    end
    return current
end

function Model:ToRuntime(doc)
    local values = {}
    for _, group in ipairs(doc.order) do
        values[group.id] = {group.reward, group.name, group.useful, group.auto}
    end
    return values
end
