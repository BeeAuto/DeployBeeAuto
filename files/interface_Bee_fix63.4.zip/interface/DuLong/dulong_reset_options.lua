return { auto = 1, count = 1, bronze = 1, ghep = 1, ghepLv = 12, ghepBind = 1, ghepMoney = 1 }
