-- Auto Ghép Huyền Tinh (by HUKT) — file vào. Nạp cùng plugin: lõi (wjxght_core.lua) luôn sẵn sàng để plugin khác gọi;
-- giao diện (wjxght_view.lua) chỉ nạp khi bấm nút "Ghép HT" trên thanh tool (End).
--
-- ================================ API cho plugin khác (Auto6 / Luyện Công / Hải Tặc / Bao Vạn Đồng …) ================================
--   local G = Ui.WJXGhepHT;
--   G:Plan(opt)                → bảng dự tính {steps = {{level, have, haveFree, make, cost, skip}}, cost, money, free, ok, why}
--   G:CanMerge(opt)            → số lần ghép làm được ngay (0 = không có gì để ghép / thiếu bạc / thiếu ô)
--   G:CellEstimate(opt)        → số ô hành trang ước tính được giải phóng, số viên ghép được, bảng dự tính
--   G:Start(opt, fnDone)       → true | false, lý do.  Tự đi tới Dã Luyện Đại Sư (Tân Thủ Thôn / Thành Thị) rồi ghép.
--   G:Stop(why)                → dừng việc đang ghép (gọi fnDone với ok = false).
--   G:Busy()                   → tên người đang dùng (opt.owner) khi đang ghép, nil khi rảnh.
--   G:FreeCells()              → số ô trống hành trang.
--   opt = {target = 12, from = 1, onlyBind = true, bindMoney = true, owner = "Auto6", quiet = false,
--          minFree = 5 (ô trống tối thiểu; plugin đang đầy túi truyền 1), scroll = 1 (dùng Vô Hạn Phù về thành / thôn)}
--   Người chơi tự bấm đi khi đang tới NPC → dừng, result.why == G.USER_MOVE.
--         (bỏ trống → lấy cài đặt người chơi chọn trên giao diện Auto Ghép HT)
--   fnDone(result): result = {ok = true/false, why = "…", made = {[cấp] = số viên}, owner = opt.owner}
-- Ví dụ (đầy rương khi Luyện Công):
--   if G and not G:Busy() and G:FreeCells() < 5 and G:CanMerge({owner = "Auto6"}) > 0 then
--       <tạm dừng auto của mình>; G:Start({owner = "Auto6"}, function(r) <bật lại auto của mình> end);
--   end
-- =====================================================================================================================================
Ui.WJXGhepHT = Ui.WJXGhepHT or {};
local G = Ui.WJXGhepHT;
G.GROUP = "UI_WJXGHEPHT";
G.CLASS = "wjxght_main";
G.INI = "wjxght_main.ini";
G.DIR = "\\interface\\AutoGhepHT\\";
G.VERSION = "1.2.0";

function G:Message(text)
    self.status = tostring(text);
    if me and me.Msg and not (self.job and self.job.opt.quiet) then me.Msg("[Ghép HT] " .. self.status); end
end

local function load(file)
    local path = G.DIR .. file;
    local source = assert(KFile.ReadTxtFile(path), "Không đọc được " .. path);
    assert(loadstring(string.gsub(source, "^\239\187\191", ""), "@" .. path))();
end

-- Lõi nạp ngay (để plugin khác gọi API không cần mở giao diện)
if not G.coreReady then
    G.loading = true;
    local ok, why = pcall(load, "wjxght_core.lua");
    G.loading = nil;
    if ok then G.coreReady = true; elseif me and me.Msg then me.Msg("[Ghép HT] " .. tostring(why)); end
end

function G:EnsureView()
    if self.viewReady then return; end
    self.loading = true;
    local ok, why = pcall(function() load("wjxght_view.lua"); load("wjxght_calc.lua"); end);
    self.loading = nil;
    if not ok then error(why); end
    self.viewReady = true;
end

function G:RegisterWindow()
    self:EnsureView();
    local native = LoadUiGroup;
    -- Game.exe chép cố định 256 byte từ con trỏ tên INI: đệm NUL như các plugin khác.
    local buffer = self.INI .. string.rep("\0", 256 - string.len(self.INI));
    LoadUiGroup = function(group, name, a, b)
        if group == G.GROUP then name = buffer; end
        return native(group, name, a, b);
    end;
    local ok, why = pcall(Ui.RegisterNewUiWindow, Ui, self.GROUP, self.CLASS, {"a", 200, 80}, {"b", 300, 140}, {"c", 420, 180});
    LoadUiGroup = native;
    if not ok then error(why); end
    local w, h = Wnd_GetSize(self.GROUP, "Main");
    assert(w and w > 0 and h and h > 0, "Chưa nạp " .. self.INI .. "; hãy thoát hẳn game rồi vào lại.");
    self.windowReady = true;
end

function G:Open()
    local ok, why = pcall(function()
        if not self.windowReady then self:RegisterWindow(); end
        if UiManager:WindowVisible(self.GROUP) == 1 then Wnd_BringTop(self.GROUP, "Main");
        else UiManager:OpenWindow(self.GROUP); end
    end);
    if not ok then self:Message("Không mở được giao diện: " .. tostring(why)); end
end

function G:Toggle()
    if self.windowReady and UiManager:WindowVisible(self.GROUP) == 1 then UiManager:CloseWindow(self.GROUP); return; end
    self:Open();
end

-- ---------------------------------------------------------------- nhịp chạy (~0,5 giây)
if not G.service and Ui.tbLogic and Ui.tbLogic.tbTimer then
    G.service = Ui.tbLogic.tbTimer:Register(9, function()
        local T = Ui.WJXGhepHT;
        if T and T.TOWN_SET then          -- nhớ thành / thôn ghé gần nhất (Dã Luyện Đại Sư gần nhất để quay về)
            local okMap, map = pcall(me.GetWorldPos);
            if okMap and T.TOWN_SET[map] then T.lastTown = map; end
        end
        if T and T.coreReady and T.job and T.Tick then
            local ok, why = pcall(T.Tick, T);
            if not ok then
                T.tickErr = (T.tickErr or 0) + 1;
                if T.tickErr >= 3 then pcall(T.Stop, T, "Dừng vì lỗi: " .. tostring(why)); T.tickErr = 0; end
            else
                T.tickErr = 0;
            end
        end
        return 9;
    end);
end

-- ---------------------------------------------------------------- nút "Ghép HT" trên thanh tool (End)
-- Dùng CHUNG bộ chia nút thanh End (Ui.WJXToolButtons): bọc UI_TOOL.OnButtonClick đúng 1 lớp. Không sửa tool.lua.
-- Tên nút BtnAutoGhepHT (tool.lua tự ẩn nút cũ BtnGhepHT khi mở thanh tool nên không dùng lại tên đó).
local D = Ui.WJXToolButtons or {handlers = {}};
Ui.WJXToolButtons = D;
D.handlers = D.handlers or {};
if not D.Install then
    function D:Install()
        local w = Ui.tbWnd and Ui.tbWnd["UI_TOOL"];
        if type(w) ~= "table" or type(w.OnButtonClick) ~= "function" then return false; end
        if w.OnButtonClick == self.hook then return true; end
        local original = w.OnButtonClick;
        local hook;
        hook = function(window, name, param, extra)
            local handler = D.handlers[name];
            if handler then handler(); return; end
            return original(window, name, param, extra);
        end;
        self.hook = hook;
        w.OnButtonClick = hook;
        return true;
    end
end
D.handlers.BtnAutoGhepHT = function()
    local ok, why = pcall(function() Ui.WJXGhepHT:Toggle(); end);
    if not ok and me and me.Msg then me.Msg("[Ghép HT] " .. tostring(why)); end
end;
if not G.toolWatch and Ui.tbLogic and Ui.tbLogic.tbTimer then
    local checks = 0;
    G.toolWatch = Ui.tbLogic.tbTimer:Register(Env.GAME_FPS, function()
        checks = checks + 1;
        local ok, hooked = pcall(D.Install, D);
        if (ok and hooked and checks >= 120) or checks >= 600 then G.toolWatch = nil; return 0; end
        return Env.GAME_FPS;
    end);
end
pcall(D.Install, D);
