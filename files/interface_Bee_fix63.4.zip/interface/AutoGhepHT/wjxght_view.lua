-- Auto Ghép Huyền Tinh — GIAO DIỆN: Cấp mục tiêu / Từ cấp, Nguyên liệu (Huyền Tinh: Tất cả | Chỉ Khóa · Bạc: Không Khóa | Bạc Khóa),
-- bảng dự tính từng cấp, tổng bạc / ô trống, Bắt Đầu Ghép / Dừng. Mọi việc ghép đi qua lõi (G:Start) như plugin khác gọi.
if not Ui.WJXGhepHT or not Ui.WJXGhepHT.loading then return; end
local G = Ui.WJXGhepHT;
local V = Ui:GetClass(G.CLASS);
V.ROWS = 12;

local function paint(color, text) return "<color=" .. color .. ">" .. text .. "<color>"; end

local function num(n)
    n = math.floor(tonumber(n) or 0);
    local s = tostring(n);
    while true do
        local t, k = string.gsub(s, "^(-?%d+)(%d%d%d)", "%1.%2");
        s = t;
        if k == 0 then break; end
    end
    return s;
end

local function short(s, n)
    s = tostring(s or "");
    if string.len(s) <= n then return s; end
    local cut = n;
    while cut > 0 and string.byte(s, cut + 1) and string.byte(s, cut + 1) >= 128 and string.byte(s, cut + 1) < 192 do cut = cut - 1; end
    return string.sub(s, 1, cut) .. "…";
end

-- ---------------------------------------------------------------- combo / ô chọn
function V:FillCombos()
    local o = G:LoadOptions();
    self.updating = true;
    ClearComboBoxItem(self.UIGROUP, "CmbTarget");
    for l = 2, G.MAX_LEVEL do ComboBoxAddItem(self.UIGROUP, "CmbTarget", l - 1, "Cấp " .. l); end
    ComboBoxSelectItem(self.UIGROUP, "CmbTarget", o.target - 2);
    ClearComboBoxItem(self.UIGROUP, "CmbFrom");
    for l = 1, o.target - 1 do ComboBoxAddItem(self.UIGROUP, "CmbFrom", l, "Cấp " .. l); end
    ComboBoxSelectItem(self.UIGROUP, "CmbFrom", math.min(o.from, o.target - 1) - 1);
    self.updating = nil;
end

function V:RenderChecks()
    local o = G:LoadOptions();
    self.updating = true;
    Btn_Check(self.UIGROUP, "ChkHtAll", o.onlyBind == 1 and 0 or 1);
    Btn_Check(self.UIGROUP, "ChkHtBind", o.onlyBind == 1 and 1 or 0);
    Btn_Check(self.UIGROUP, "ChkCash", o.bindMoney == 1 and 0 or 1);
    Btn_Check(self.UIGROUP, "ChkBind", o.bindMoney == 1 and 1 or 0);
    self.updating = nil;
end

-- Danh sách thả xuống của combo đè lên các nút: vừa chọn thì bỏ qua cú bấm lọt xuống (~0,4 giây).
function V:GuardCombo()
    self.comboGuard = true;
    if self.comboTimer then pcall(Ui.tbLogic.tbTimer.Close, Ui.tbLogic.tbTimer, self.comboTimer); end
    local window = self;
    self.comboTimer = Ui.tbLogic.tbTimer:Register(8, function() window.comboGuard, window.comboTimer = nil, nil; return 0; end);
end

-- ---------------------------------------------------------------- bảng dự tính
function V:RenderPlan(force)
    local plan = G:Plan();
    local o = plan.opt;
    local parts = {o.target, o.from, o.onlyBind, o.bindMoney, plan.money, plan.free, plan.cost, plan.makes};
    for l = 1, G.MAX_LEVEL do parts[#parts + 1] = plan.have[l].bind .. "/" .. plan.have[l].free; end
    local key = table.concat(parts, ":");
    if key == self.planKey and not force then return; end
    self.planKey = key;
    local rows = {};
    for _, s in ipairs(plan.steps) do
        local src = s.level - 1;
        local text = "Cấp " .. src .. " → " .. s.level .. ": có " .. s.haveBind .. " khóa / " .. s.haveFree .. " không khóa";
        if s.skip then
            rows[#rows + 1] = paint("red", short(text .. " · BỎ QUA (" .. s.skip .. ")", 74));
        elseif s.make > 0 then
            rows[#rows + 1] = paint("white", short(text .. " → ghép " .. s.make .. " viên · " .. G:FormatMoney(s.cost) .. " bạc", 74));
        else
            rows[#rows + 1] = paint("gray", short(text .. " → chưa đủ " .. s.ratio .. " viên", 74));
        end
    end
    for i = 1, self.ROWS do Txt_SetTxt(self.UIGROUP, "TxtPlan" .. i, rows[i] or ""); end
    local moneyName = G:MoneyName(o.bindMoney);
    Txt_SetTxt(self.UIGROUP, "TxtSum1", paint(plan.cost > plan.money and "red" or "white",
        "Tổng: " .. plan.makes .. " lần ghép · cần " .. G:FormatMoney(plan.cost) .. " " .. moneyName .. " · đang có " .. G:FormatMoney(plan.money)
        .. (plan.cost > plan.money and " — THIẾU" or "")));
    Txt_SetTxt(self.UIGROUP, "TxtSum2", paint(plan.free < o.minFree and "red" or "white",
        "Ô trống hành trang: " .. plan.free .. " (cần ít nhất " .. o.minFree .. ") · sau khi ghép có " .. plan.result.bind .. " HT khóa cấp " .. o.target));
end

function V:RenderStatus()
    local j = G.job;
    local text;
    if j then
        local made = 0;
        for _, n in pairs(j.made) do made = made + n; end
        text = "Đang ghép" .. (j.opt.owner and (" (" .. j.opt.owner .. ")") or "") .. ": " .. tostring(G.stepText or "…") .. " · đã ghép " .. made .. " viên";
    else
        text = G.status or "Chọn cấp mục tiêu rồi bấm Bắt Đầu Ghép. Thành phẩm luôn là Huyền Tinh KHÓA.";
    end
    if text ~= self.statusText then
        self.statusText = text;
        Txt_SetTxt(self.UIGROUP, "TxtStatus", short(text, 120));
    end
    local busy = j and 1 or 0;
    if busy ~= self.busyShown then
        self.busyShown = busy;
        Wnd_SetEnable(self.UIGROUP, "BtnStart", busy == 1 and 0 or 1);
        Wnd_SetEnable(self.UIGROUP, "BtnStop", busy);
    end
end

function V:Refresh(force)
    self:RenderPlan(force);
    self:RenderStatus();
end

-- ---------------------------------------------------------------- sự kiện
function V:OnOpen()
    Txt_SetTxt(self.UIGROUP, "TxtTitle", "AUTO GHÉP HUYỀN TINH — by HUKT — v" .. tostring(G.VERSION));
    self.planKey, self.statusText, self.busyShown = nil, nil, nil;
    self:FillCombos();
    self:RenderChecks();
    self:Refresh(true);
    if self.timer then Ui.tbLogic.tbTimer:Close(self.timer); end
    local window = self;
    self.timer = Ui.tbLogic.tbTimer:Register(Env.GAME_FPS, function()
        if UiManager:WindowVisible(G.GROUP) ~= 1 then window.timer = nil; return 0; end
        local ok, why = pcall(V.Refresh, window);
        if not ok then window.timer = nil; G:Message("Lỗi giao diện: " .. tostring(why)); return 0; end
        return Env.GAME_FPS;
    end);
end

function V:OnClose()
    if self.timer then Ui.tbLogic.tbTimer:Close(self.timer); self.timer = nil; end
    if self.comboTimer then pcall(Ui.tbLogic.tbTimer.Close, Ui.tbLogic.tbTimer, self.comboTimer); self.comboTimer = nil; end
    self.comboGuard = nil;
end

function V:OnEscExclusiveWnd() UiManager:CloseWindow(self.UIGROUP); end

function V:OnComboBoxIndexChange(name, index)
    if self.updating then return; end
    self:GuardCombo();
    local o = G:LoadOptions();
    local i = (tonumber(index) or 0) + 1;
    if name == "CmbTarget" then
        o.target = math.max(2, math.min(G.MAX_LEVEL, i + 1));
        o.from = math.min(o.from, o.target - 1);
        G:SaveOptions(o);
        self:FillCombos();
    elseif name == "CmbFrom" then
        o.from = math.max(1, math.min(o.target - 1, i));
        G:SaveOptions(o);
    end
    self:Refresh(true);
end

-- 2 cặp ô loại trừ nhau: Huyền Tinh (Tất cả | Chỉ Khóa), Bạc (Không Khóa | Bạc Khóa)
function V:ClickCheck(name)
    local o = G:LoadOptions();
    if name == "ChkHtAll" then o.onlyBind = 0;
    elseif name == "ChkHtBind" then o.onlyBind = 1;
    elseif name == "ChkCash" then o.bindMoney = 0;
    elseif name == "ChkBind" then o.bindMoney = 1; end
    G:SaveOptions(o);
    self:RenderChecks();
    self:Refresh(true);
end

function V:OnButtonClick(name)
    if self.updating then return; end
    if self.comboGuard then
        if string.sub(name, 1, 3) == "Chk" then self:RenderChecks(); end
        return;
    end
    if name == "BtnClose" or name == "BtnCloseX" then UiManager:CloseWindow(self.UIGROUP); return; end
    if string.sub(name, 1, 3) == "Chk" then
        if G.job then self:RenderChecks(); G:Message("Đang ghép: dừng trước khi đổi nguyên liệu."); return; end
        self:ClickCheck(name);
        return;
    end
    if name == "BtnStart" then
        local ok, why = G:Start(nil, function(result)
            local w = Ui(G.GROUP);
            if w and w.Refresh and UiManager:WindowVisible(G.GROUP) == 1 then pcall(w.Refresh, w, true); end
        end);
        if not ok then G:Message(why); end
    elseif name == "BtnStop" then
        G:Stop("người chơi dừng");
    elseif name == "BtnFormula" then
        local ok, why = pcall(G.OpenCalc, G);
        if not ok then G:Message("Không mở được Công Thức: " .. tostring(why)); end
        return;
    elseif name == "BtnRefresh" then
        self.planKey = nil;
    end
    self:Refresh(true);
end
