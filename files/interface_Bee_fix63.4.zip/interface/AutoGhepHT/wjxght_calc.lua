-- Auto Ghép Huyền Tinh — cửa sổ "TEST Ghép Huyền Tinh" (nút Công Thức): tính công thức / số lượng giữa 2 cấp Huyền Tinh.
--   Huyền Tinh Nguồn: [cấp] [số lượng] · Huyền Tinh Mục Tiêu: [cấp] [số lượng]
--   Cách tính theo: [ ] Số lượng nguồn  [ ] Số lượng Mục Tiêu (loại trừ nhau, bỏ trống cả 2 = chỉ xem công thức)
--   Tỉ lệ và phí lấy theo NPC Dã Luyện Đại Sư (G:Ratio, G.PRICE): ra cấp 2–4 cần 4 viên cấp dưới, cấp ≥ 5 cần 3.
if not Ui.WJXGhepHT or not Ui.WJXGhepHT.loading then return; end
local G = Ui.WJXGhepHT;

G.CALC_GROUP = "UI_WJXGHEPHT_CALC";
G.CALC_CLASS = "wjxght_calc";
G.CALC_INI = "wjxght_calc.ini";
G.CALC_MAX = 9999999;

local C = Ui:GetClass(G.CALC_CLASS);
C.ROWS = 13;

local function paint(color, text) return "<color=" .. color .. ">" .. text .. "<color>"; end
local function num(n)
    n = math.floor(tonumber(n) or 0);
    local s = tostring(n);
    while true do
        local t, k = string.gsub(s, "^(-?%d+)(%d%d%d)", "%1.%2");
        s = t;
        if k == 0 then break; end
    end
    return s;
end

-- ---------------------------------------------------------------- công thức
-- Số viên cấp `src` cần cho 1 viên cấp `dst`, và phí ghép (bạc) cho 1 viên cấp `dst` đi từ `src`.
function G:Recipe(src, dst)
    local need, fee = 1, 0;
    local per = {};                 -- per[L] = số viên cấp L phải TẠO RA cho 1 viên cấp dst
    for l = dst, src + 1, -1 do
        per[l] = need;
        fee = fee + need * self.PRICE[l];
        need = need * self:Ratio(l);
    end
    return need, fee, per;
end

-- Có q viên cấp src: ghép lần lượt lên dst (phần dư mỗi cấp giữ lại). Trả số viên dst + từng bước.
function G:FromSource(src, dst, q)
    local have, steps, fee = q, {}, 0;
    for l = src + 1, dst do
        local r = self:Ratio(l);
        local make = math.floor(have / r);
        local left = have - make * r;
        steps[#steps + 1] = {level = l, use = make * r, left = left, make = make, fee = make * self.PRICE[l]};
        fee = fee + make * self.PRICE[l];
        have = make;
    end
    return have, steps, fee;
end

function G:OpenCalc(anchor)
    self:EnsureView();
    if not self.calcReady then
        local native = LoadUiGroup;
        local buffer = self.CALC_INI .. string.rep("\0", 256 - string.len(self.CALC_INI));
        LoadUiGroup = function(group, name, a, b)
            if group == G.CALC_GROUP then name = buffer; end
            return native(group, name, a, b);
        end;
        local ok, why = pcall(Ui.RegisterNewUiWindow, Ui, self.CALC_GROUP, self.CALC_CLASS, {"a", 250, 100}, {"b", 350, 160}, {"c", 470, 200});
        LoadUiGroup = native;
        if not ok then error(why); end
        local w, h = Wnd_GetSize(self.CALC_GROUP, "Main");
        assert(w and w > 0 and h and h > 0, "Chưa nạp " .. self.CALC_INI .. "; hãy thoát hẳn game rồi vào lại.");
        self.calcReady = true;
    end
    if UiManager:WindowVisible(self.CALC_GROUP) == 1 then Wnd_BringTop(self.CALC_GROUP, "Main");
    else UiManager:OpenWindow(self.CALC_GROUP); end
end

-- ---------------------------------------------------------------- cửa sổ
function C:Fill()
    self.updating = true;
    ClearComboBoxItem(self.UIGROUP, "CmbSrc");
    for l = 1, G.MAX_LEVEL - 1 do ComboBoxAddItem(self.UIGROUP, "CmbSrc", l, "Cấp " .. l); end
    ComboBoxSelectItem(self.UIGROUP, "CmbSrc", self.src - 1);
    ClearComboBoxItem(self.UIGROUP, "CmbDst");
    for l = self.src + 1, G.MAX_LEVEL do ComboBoxAddItem(self.UIGROUP, "CmbDst", l - self.src, "Cấp " .. l); end
    ComboBoxSelectItem(self.UIGROUP, "CmbDst", self.dst - self.src - 1);
    self.updating = nil;
end

function C:RenderChecks()
    self.updating = true;
    Btn_Check(self.UIGROUP, "ChkBySrc", self.mode == "src" and 1 or 0);
    Btn_Check(self.UIGROUP, "ChkByDst", self.mode == "dst" and 1 or 0);
    self.updating = nil;
end

local function readInt(group, name)
    local raw = Edt_GetTxt(group, name) or "";
    local n = tonumber((string.gsub(raw, "[^%d]", "")));
    return n and math.min(G.CALC_MAX, math.floor(n)) or nil, raw;
end

-- Ghi số vào ô KHÔNG phải ô người chơi đang nhập (nhớ giá trị đã ghi để không coi là người chơi gõ).
function C:Put(name, value)
    local text = value and tostring(value) or "";
    if (Edt_GetTxt(self.UIGROUP, name) or "") ~= text then Edt_SetTxt(self.UIGROUP, name, text); end
    self.written = self.written or {};
    self.written[name] = text;
end

function C:Have(level)
    return G:Count(level, G.HT_BIND), G:Count(level, G.HT_FREE);
end

function C:Render()
    local src, dst, mode = self.src, self.dst, self.mode;
    local qs = readInt(self.UIGROUP, "EdtSrc");
    local qd = readInt(self.UIGROUP, "EdtDst");
    local hb, hf = self:Have(src);
    local key = table.concat({src, dst, mode or "-", qs or "", qd or "", hb, hf}, ":");
    if key == self.key then return; end
    self.key = key;
    local need, fee, per = G:Recipe(src, dst);
    local lines = {};
    local function add(color, text) lines[#lines + 1] = paint(color, text); end
    if not mode then
        add("gold", "Công thức: " .. num(need) .. " HT" .. src .. " → 1 HT" .. dst .. " · phí " .. G:FormatMoney(fee) .. " bạc / 1 viên");
        for l = src + 1, dst do
            add("white", "  Cấp " .. (l - 1) .. " → " .. l .. ": " .. G:Ratio(l) .. " HT" .. (l - 1) .. " → 1 HT" .. l
                .. " · phí " .. G:FormatMoney(G.PRICE[l]) .. " bạc / lần (cần ghép " .. num(per[l]) .. " lần)");
        end
    elseif mode == "src" then
        if not qs or qs <= 0 then
            add("gray", "Nhập số lượng Huyền Tinh Nguồn (cấp " .. src .. ").");
            self:Put("EdtDst", nil);
        else
            local out, steps, total = G:FromSource(src, dst, qs);
            self:Put("EdtDst", out);
            add("gold", num(qs) .. " HT" .. src .. " → " .. num(out) .. " HT" .. dst .. " · tổng phí " .. G:FormatMoney(total) .. " bạc");
            for _, s in ipairs(steps) do
                add(s.make > 0 and "white" or "gray", "  Cấp " .. (s.level - 1) .. " → " .. s.level .. ": dùng " .. num(s.use) .. ", dư " .. num(s.left)
                    .. " HT" .. (s.level - 1) .. " → ra " .. num(s.make) .. " HT" .. s.level .. " · phí " .. G:FormatMoney(s.fee));
            end
            if out == 0 then add("red", "Chưa đủ để ra 1 HT" .. dst .. ": cần ít nhất " .. num(need) .. " HT" .. src .. "."); end
        end
    else
        if not qd or qd <= 0 then
            add("gray", "Nhập số lượng Huyền Tinh Mục Tiêu (cấp " .. dst .. ").");
            self:Put("EdtSrc", nil);
        else
            local want = need * qd;
            self:Put("EdtSrc", want);
            add("gold", "Để có " .. num(qd) .. " HT" .. dst .. " cần " .. num(want) .. " HT" .. src .. " · tổng phí " .. G:FormatMoney(fee * qd) .. " bạc");
            for l = src + 1, dst do
                add("white", "  Cấp " .. (l - 1) .. " → " .. l .. ": ghép " .. num(per[l] * qd) .. " lần (dùng " .. num(per[l] * qd * G:Ratio(l))
                    .. " HT" .. (l - 1) .. ") · phí " .. G:FormatMoney(per[l] * qd * G.PRICE[l]));
            end
            local have = hb + hf;
            if have < want then add("red", "Trong túi có " .. num(have) .. " HT" .. src .. ": còn thiếu " .. num(want - have) .. " viên.");
            else add("green", "Trong túi có " .. num(have) .. " HT" .. src .. ": đủ."); end
        end
    end
    while #lines > self.ROWS do table.remove(lines); end
    for i = 1, self.ROWS do Txt_SetTxt(self.UIGROUP, "TxtRes" .. i, lines[i] or ""); end
    Txt_SetTxt(self.UIGROUP, "TxtHave", "Trong túi: HT" .. src .. " " .. num(hb) .. " khóa / " .. num(hf) .. " không khóa · HT" .. dst .. " "
        .. num(G:Count(dst, G.HT_BIND) + G:Count(dst, G.HT_FREE)) .. " viên");
    local tip = not mode and "Tick 1 ô Cách tính theo để nhập số lượng. Bỏ Chọn = về xem công thức." or (mode == "src" and "Nhập ô Số lượng nguồn; ô Mục Tiêu tự tính." or "Nhập ô Số lượng Mục Tiêu; ô Nguồn tự tính.");
    Txt_SetTxt(self.UIGROUP, "TxtHint", tip);
end

function C:OnOpen()
    Txt_SetTxt(self.UIGROUP, "TxtTitle", "TEST GHÉP HUYỀN TINH — Công Thức");
    self.src = self.src or 1;
    self.dst = self.dst or 2;
    self.key = nil;
    self:Fill();
    self:RenderChecks();
    self:Render();
    if self.timer then Ui.tbLogic.tbTimer:Close(self.timer); end
    local window = self;
    self.timer = Ui.tbLogic.tbTimer:Register(6, function()
        if UiManager:WindowVisible(G.CALC_GROUP) ~= 1 then window.timer = nil; return 0; end
        local ok, why = pcall(C.Render, window);
        if not ok then window.timer = nil; G:Message("Lỗi Công Thức: " .. tostring(why)); return 0; end
        return 6;
    end);
end

function C:OnClose()
    if self.timer then Ui.tbLogic.tbTimer:Close(self.timer); self.timer = nil; end
    if self.comboTimer then pcall(Ui.tbLogic.tbTimer.Close, Ui.tbLogic.tbTimer, self.comboTimer); self.comboTimer = nil; end
    self.comboGuard = nil;
end

function C:OnEscExclusiveWnd() UiManager:CloseWindow(self.UIGROUP); end

function C:GuardCombo()
    self.comboGuard = true;
    if self.comboTimer then pcall(Ui.tbLogic.tbTimer.Close, Ui.tbLogic.tbTimer, self.comboTimer); end
    local window = self;
    self.comboTimer = Ui.tbLogic.tbTimer:Register(8, function() window.comboGuard, window.comboTimer = nil, nil; return 0; end);
end

function C:OnComboBoxIndexChange(name, index)
    if self.updating then return; end
    self:GuardCombo();
    local i = (tonumber(index) or 0) + 1;
    if name == "CmbSrc" then
        self.src = math.max(1, math.min(G.MAX_LEVEL - 1, i));
        if self.dst <= self.src then self.dst = self.src + 1; end
        self:Fill();
    elseif name == "CmbDst" then
        self.dst = math.max(self.src + 1, math.min(G.MAX_LEVEL, self.src + i));
    end
    self.key = nil;
    self:Render();
end

function C:OnButtonClick(name)
    if self.updating then return; end
    if self.comboGuard then
        if string.sub(name, 1, 3) == "Chk" then self:RenderChecks(); end
        return;
    end
    if name == "BtnClose" or name == "BtnCloseX" then UiManager:CloseWindow(self.UIGROUP); return; end
    if name == "ChkBySrc" or name == "ChkByDst" then
        -- 2 ô loại trừ nhau. Đọc trạng thái ô SAU khi bấm (như ô chế độ của Auto Chế Tạo): tick → chọn cách tính đó,
        -- bỏ tick ô đang chọn → về chế độ xem công thức (cả 2 ô trống).
        local m = name == "ChkBySrc" and "src" or "dst";
        local on = Btn_GetCheck(self.UIGROUP, name) == 1;
        if on then self.mode = m; elseif self.mode == m then self.mode = nil; end
        self:RenderChecks();
        self.key = nil;
        self:Render();
        return;
    end
    if name == "BtnClear" then
        -- bỏ tick cả 2 ô, xoá số lượng → xem công thức như lúc mới mở
        self.mode = nil;
        Edt_SetTxt(self.UIGROUP, "EdtSrc", "");
        Edt_SetTxt(self.UIGROUP, "EdtDst", "");
        self:RenderChecks();
        self.key = nil;
        self:Render();
        return;
    end
end
