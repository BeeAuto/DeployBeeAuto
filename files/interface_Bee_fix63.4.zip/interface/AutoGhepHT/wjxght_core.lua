-- Auto Ghép Huyền Tinh — LÕI: tính dự kiến + máy trạng thái đi tới Dã Luyện Đại Sư và bấm hội thoại Ghép HT.
-- Theo script\npc\yeliandashi.lua (server): Ghép Huyền Tinh → Bạc thường / Bạc khóa → "Ghép thành Huyền Tinh Cấp L"
--   → "Ghép hết trong Hành Trang được N viên" → "Đồng ý ghép" → server mở lại danh sách cấp.
--   Tỉ lệ: ra cấp 2–4 cần 4 viên cấp dưới, cấp ≥ 5 cần 3. Đếm CẢ HT thường (18,1,1,L) lẫn HT khóa (18,1,114,L),
--   trừ HT khóa trước; thành phẩm luôn là HT khóa 18,1,114,L. Giá mỗi viên tạo ra = tbListPay[L].
--   Nhánh "Ghép hết" của server KHÔNG kiểm tra ô trống → plugin tự giữ tối thiểu MIN_FREE ô.
if not Ui.WJXGhepHT or not Ui.WJXGhepHT.loading then return; end
local G = Ui.WJXGhepHT;

G.PRICE = {[2] = 30, [3] = 108, [4] = 389, [5] = 1400, [6] = 5039, [7] = 18140, [8] = 65304, [9] = 235093,
    [10] = 846333, [11] = 3046799, [12] = 10969729};
G.MIN_LEVEL, G.MAX_LEVEL = 1, 12;
G.HT_FREE = 1;          -- 18,1,1,L   Huyền Tinh (không khóa)
G.HT_BIND = 114;        -- 18,1,114,L Huyền Tinh (khóa)
G.MIN_FREE = 5;         -- ô trống tối thiểu trước mỗi lần ghép
G.NPC_TEMPLATE = 3574;  -- Dã Luyện Đại Sư (setting\npc\npc.txt, lớp yeliandashi)
G.NPC_MAPS = {23, 24, 25, 26, 27, 28, 29, 1, 2, 3, 4, 5, 6, 7, 8};   -- Thành Thị rồi Tân Thủ Thôn
G.WALK_TIMEOUT = 300;
G.SAY_WAIT = 8;
G.CONFIG_KEY = "GhepHT";
G.DEFAULTS = {target = 8, from = 1, onlyBind = 1, bindMoney = 1};
G.USER_MOVE = "bạn tự di chuyển nhân vật";          -- lý do khi người chơi tự bấm đi (plugin gọi so sánh để dừng theo)
G.TOWN_SET = {};
for _, m in ipairs(G.NPC_MAPS) do G.TOWN_SET[m] = true; end

local function now() return GetTime(); end
local function num(v) return tonumber(v) or 0; end
local function visible(group) return group and UiManager:WindowVisible(group) == 1; end

-- Đếm số lần tự tìm đường bị NGƯỜI CHƠI dừng (bấm đất / phím di chuyển): bọc tbAutoPath.OnStop đúng 1 lớp, chung khóa
-- wjxStopHook / wjxUserStops với Home Bar (không bọc chồng).
local function hookUserStop()
    local path = Ui.tbLogic and Ui.tbLogic.tbAutoPath;
    if type(path) ~= "table" or type(path.OnStop) ~= "function" then return; end
    if path.wjxStopHook and path.OnStop == path.wjxStopHook then return; end
    local onStop = path.OnStop;
    local hook = function(self, reason, ...)
        if reason == "User" then self.wjxUserStops = (self.wjxUserStops or 0) + 1; end
        return onStop(self, reason, ...);
    end;
    path.OnStop, path.wjxStopHook = hook, hook;
end
local function userStops()
    hookUserStop();
    local path = Ui.tbLogic and Ui.tbLogic.tbAutoPath;
    return path and path.wjxUserStops or 0;
end

function G:Ratio(level) return level < 5 and 4 or 3; end

local function rawCount(particular, level)
    local ok, n = pcall(me.GetItemCountInBags, 18, 1, particular, level);
    return ok and num(n) or 0;
end

-- Khóa / không khóa theo TỪNG VIÊN (pItem.IsBind), không theo mã: 18,1,1,L có thể đã bị khóa bằng Bind(1)
-- (thưởng nhiệm vụ / Bao Vạn Đồng …) → tính là HT khóa. 18,1,114,L luôn là HT khóa.
-- Trả: số HT khóa, số HT không khóa của cấp L.
function G:Split(level)
    local total = rawCount(self.HT_FREE, level);
    local bound = 0;
    if total > 0 then
        local okF, list = pcall(me.FindItemInBags, 18, 1, self.HT_FREE, level);
        if okF and type(list) == "table" then
            for _, e in ipairs(list) do
                local it = type(e) == "table" and e.pItem or e;
                local okB, b, n = pcall(function() return it.IsBind(), it.nCount; end);
                if okB and tonumber(b) == 1 then bound = bound + math.max(1, num(n)); end
            end
        end
        bound = math.min(bound, total);
    end
    return rawCount(self.HT_BIND, level) + bound, total - bound;
end

-- particular = HT_BIND → số HT khóa (kể cả 18,1,1 đã khóa); HT_FREE → số HT không khóa.
function G:Count(level, particular)
    local b, u = self:Split(level);
    if particular == self.HT_BIND then return b; end
    return u;
end

function G:FreeCells()
    local ok, n = pcall(me.CountFreeBagCell);
    return ok and num(n) or 0;
end

function G:Money(bindMoney)
    if bindMoney == 1 or bindMoney == true then
        local ok, n = pcall(me.GetBindMoney);
        return ok and num(n) or 0;
    end
    return num(me.nCashMoney);
end

-- Bạc kiểu Vạn / Ức như game (Item:FormatMoney): 1.234.567 → "123Vạn4567", 0 → "0".
function G:FormatMoney(n)
    n = math.floor(tonumber(n) or 0);
    if n < 0 then return "Vô hiệu"; end
    local s = "";
    if n >= 100000000 then s = s .. tostring(math.floor(n / 100000000)) .. "Ức"; n = n - math.floor(n / 100000000) * 100000000; end
    if n >= 10000 then s = s .. tostring(math.floor(n / 10000)) .. "Vạn"; n = n - math.floor(n / 10000) * 10000; end
    if n > 0 then s = s .. tostring(n); end
    if s == "" then s = "0"; end
    return s;
end

function G:MoneyName(bindMoney) return (bindMoney == 1 or bindMoney == true) and "Bạc khóa" or "Bạc thường"; end

-- ---------------------------------------------------------------- cài đặt (lưu theo nhân vật, kho btssl_autofight)
function G:Store()
    local ok, ui = pcall(Ui, Ui.UI_AUTOFIGHT);
    if ok and type(ui) == "table" and ui.Load and ui.Save then return ui; end
end

function G:LoadOptions()
    if self.options and self.optionsOwner == me.szName then return self.options; end
    local o = {};
    local ui = self:Store();
    local raw;
    if ui then local ok, v = pcall(ui.Load, ui, self.CONFIG_KEY); if ok and type(v) == "table" then raw = v; end end
    for k, d in pairs(self.DEFAULTS) do o[k] = raw and tonumber(raw[k]) or d; end
    o.target = math.max(2, math.min(self.MAX_LEVEL, o.target));
    o.from = math.max(1, math.min(o.target - 1, o.from));
    self.options, self.optionsOwner = o, me.szName;
    return o;
end

function G:SaveOptions(o)
    self.options, self.optionsOwner = o, me.szName;
    local ui = self:Store();
    if not ui then return o; end
    pcall(ui.Load, ui, self.CONFIG_KEY);     -- đọc lại ngay trước khi ghi để giữ cài đặt của auto khác
    pcall(ui.Save, ui, self.CONFIG_KEY, {target = o.target, from = o.from, onlyBind = o.onlyBind, bindMoney = o.bindMoney});
    return o;
end

-- opt của người gọi + phần còn thiếu lấy từ cài đặt trên giao diện
function G:Opt(opt)
    local base = self:LoadOptions();
    opt = opt or {};
    local o = {};
    for k, v in pairs(opt) do o[k] = v; end
    o.target = math.max(2, math.min(self.MAX_LEVEL, num(opt.target ~= nil and opt.target or base.target)));
    o.from = math.max(1, math.min(o.target - 1, num(opt.from ~= nil and opt.from or base.from)));
    local function flag(v, d) if v == nil then return d; end return (v == true or v == 1) and 1 or 0; end
    o.onlyBind = flag(opt.onlyBind, base.onlyBind);
    o.bindMoney = flag(opt.bindMoney, base.bindMoney);
    o.minFree = num(opt.minFree ~= nil and opt.minFree or self.MIN_FREE);
    o.scroll = flag(opt.scroll, 1);         -- khác bản đồ: dùng Vô Hạn Phù tới Thành Thị / Tân Thủ Thôn có Dã Luyện Đại Sư
    return o;
end

-- ---------------------------------------------------------------- dự tính
-- Giả lập từ cấp `from` lên `target` (HT vừa ghép được cộng vào để ghép tiếp, phần dư giữ lại).
-- onlyBind: cấp nguồn còn HT không khóa thì BỎ QUA bước đó (vì "Ghép hết" của server dùng cả 2 loại).
function G:Plan(opt)
    local o = self:Opt(opt);
    local b, u = {}, {};
    for l = self.MIN_LEVEL, self.MAX_LEVEL do b[l], u[l] = self:Split(l); end
    local plan = {opt = o, steps = {}, cost = 0, makes = 0, money = self:Money(o.bindMoney), free = self:FreeCells(), have = {}};
    for l = self.MIN_LEVEL, self.MAX_LEVEL do plan.have[l] = {bind = b[l], free = u[l]}; end
    for l = o.from + 1, o.target do
        local src = l - 1;
        local step = {level = l, haveBind = b[src], haveFree = u[src], make = 0, cost = 0, ratio = self:Ratio(l)};
        local avail = b[src] + u[src];
        if o.onlyBind == 1 and u[src] > 0 then
            step.skip = "cấp " .. src .. " có " .. u[src] .. " HT không khóa";
            avail = 0;
        end
        step.make = math.floor(avail / step.ratio);
        if step.make > 0 then
            local use = step.make * step.ratio;
            local fromBind = math.min(b[src], use);
            b[src], u[src] = b[src] - fromBind, u[src] - (use - fromBind);
            b[l] = b[l] + step.make;
            step.cost = step.make * self.PRICE[l];
            plan.cost, plan.makes = plan.cost + step.cost, plan.makes + step.make;
        end
        step.left = b[src] + u[src];
        plan.steps[#plan.steps + 1] = step;
    end
    plan.result = {bind = b[o.target], free = u[o.target]};
    plan.after = {bind = b, free = u};          -- số HT mỗi cấp sau khi ghép hết chuỗi (để ước tính ô trống)
    if plan.makes == 0 then plan.ok, plan.why = false, "Không có Huyền Tinh nào ghép được lên cấp " .. o.target .. ".";
    elseif plan.free < o.minFree then plan.ok, plan.why = false, "Hành trang cần ít nhất " .. o.minFree .. " ô trống (đang có " .. plan.free .. ").";
    else
        local first;
        for _, s in ipairs(plan.steps) do if s.make > 0 then first = s; break; end end
        if first.cost > plan.money then
            plan.ok, plan.why = false, "Thiếu " .. self:MoneyName(o.bindMoney) .. " cho bước đầu (cấp " .. first.level .. ": cần " .. self:FormatMoney(first.cost) .. ").";
        elseif plan.cost > plan.money then
            plan.ok, plan.why = true, "Không đủ " .. self:MoneyName(o.bindMoney) .. " cho cả chuỗi: auto sẽ dừng ở cấp đầu tiên thiếu bạc.";
        else
            plan.ok = true;
        end
    end
    return plan;
end

-- Số viên ghép được ngay (đủ bạc từng bước, đủ ô) — cho plugin khác hỏi nhanh.
function G:CanMerge(opt)
    local plan = self:Plan(opt);
    if plan.free < plan.opt.minFree then return 0, plan; end
    local money, n = plan.money, 0;
    for _, s in ipairs(plan.steps) do
        if s.make > 0 then
            if s.cost > money then break; end
            money, n = money - s.cost, n + s.make;
        end
    end
    return n, plan;
end

-- Ước tính số ô hành trang được giải phóng nếu ghép ngay (số ô HT đang chiếm − số ô HT sau ghép).
-- Trả: số ô giải phóng, số viên ghép được (như CanMerge), bảng dự tính.
function G:CellEstimate(opt)
    local n, plan = self:CanMerge(opt);
    if n <= 0 then return 0, n, plan; end
    local before, stack = 0, 1;
    for l = self.MIN_LEVEL, self.MAX_LEVEL do
        for _, particular in ipairs({self.HT_FREE, self.HT_BIND}) do
            local ok, list = pcall(me.FindItemInBags, 18, 1, particular, l);
            if ok and type(list) == "table" then
                for _, e in ipairs(list) do
                    before = before + 1;
                    local it = type(e) == "table" and e.pItem or e;
                    local okM, m, c = pcall(function() return it.nMaxCount, it.nCount; end);
                    if okM then stack = math.max(stack, num(m), num(c)); end
                end
            end
        end
    end
    local after = 0;
    for l = self.MIN_LEVEL, self.MAX_LEVEL do
        local b, u = num(plan.after.bind[l]), num(plan.after.free[l]);
        after = after + math.ceil(b / stack) + math.ceil(u / stack);
    end
    return math.max(0, before - after), n, plan;
end

function G:Busy() return self.job and (self.job.opt.owner or "Auto Ghép HT") or nil; end

-- ---------------------------------------------------------------- bắt đầu / dừng
function G:Start(opt, fnDone)
    if self.job then return false, "Đang ghép Huyền Tinh (" .. tostring(self:Busy()) .. ")."; end
    local o = self:Opt(opt);
    if not o.owner and me.nAutoFightState == 1 then return false, "Đang bật Tự Đánh: tắt trước khi ghép."; end
    if me.IsDead and me.IsDead() == 1 then return false, "Nhân vật đang bị hạ gục."; end
    local plan = self:Plan(o);
    if not plan.ok then return false, plan.why; end
    self:InstallSay();
    self.job = {opt = o, cb = fnDone, phase = "go", made = {}, started = now(), others = 0, plan = plan, userStops = userStops()};
    self:Message("Bắt đầu ghép lên cấp " .. o.target .. " (" .. self:MoneyName(o.bindMoney) .. (o.onlyBind == 1 and ", chỉ HT khóa" or ", cả HT không khóa") .. ")."
        .. (plan.why and (" " .. plan.why) or ""));
    return true;
end

function G:Finish(ok, why)
    local j = self.job;
    if not j then return; end
    self:StopWalk(j);
    if j.transfer and Ui.WJXTransfer then pcall(Ui.WJXTransfer.Cancel, Ui.WJXTransfer, j.transfer); j.transfer = nil; end
    if visible(Ui.UI_SAYPANEL) and j.phase ~= "go" then pcall(UiManager.CloseWindow, UiManager, Ui.UI_SAYPANEL); end
    self.job, self.lastJob = nil, j;
    local made, parts = 0, {};
    for l = 2, self.MAX_LEVEL do
        if (j.made[l] or 0) > 0 then made = made + j.made[l]; parts[#parts + 1] = j.made[l] .. " viên cấp " .. l; end
    end
    local text = (ok and "Xong" or "Dừng") .. (why and why ~= "" and (": " .. why) or "") .. (made > 0 and (" · đã ghép " .. table.concat(parts, ", ")) or "") .. ".";
    j.result = {ok = ok and true or false, why = why, made = j.made, owner = j.opt.owner};
    self:Message(text);
    if j.cb then
        local okCb, err = pcall(j.cb, j.result);
        if not okCb then self:Message("Lỗi báo về " .. tostring(j.opt.owner) .. ": " .. tostring(err)); end
    end
end

function G:Stop(why) if self.job then self:Finish(false, why or "người chơi dừng"); end end

-- ---------------------------------------------------------------- NPC
function G:NpcPoint(map)
    if not KNpc.ClientGetNpcPos then return nil; end
    local ok, x, y = pcall(KNpc.ClientGetNpcPos, map, self.NPC_TEMPLATE);
    if ok and type(x) == "number" and type(y) == "number" and x > 0 and y > 0 then return {map = map, x = x, y = y}; end
end

-- Bản đồ đang đứng (nếu có Dã Luyện Đại Sư) → thành / thôn ghé gần nhất (lastTown) → Thành Thị → Tân Thủ Thôn.
-- Bật Vô Hạn Phù: ưu tiên nơi phù tới được (theo cùng thứ tự); không có thì đi bộ theo thứ tự cũ.
function G:PickNpcPoint(scroll)
    local here = me.GetWorldPos();
    local p = self:NpcPoint(here);
    if p then return p; end
    local order = {};
    if self.lastTown and self.TOWN_SET[self.lastTown] then order[1] = self.lastTown; end
    for _, m in ipairs(self.NPC_MAPS) do if m ~= self.lastTown then order[#order + 1] = m; end end
    local T = Ui.WJXTransfer;
    if scroll == 1 and T and type(T.Plan) == "function" then
        for _, m in ipairs(order) do
            local ok, dest, item = pcall(T.Plan, T, m);
            if ok and dest and item then
                p = self:NpcPoint(m);
                if p then return p; end
            end
        end
    end
    for _, m in ipairs(order) do
        p = self:NpcPoint(m);
        if p then return p; end
    end
end

-- Dùng Vô Hạn Phù tới bản đồ có Dã Luyện Đại Sư (1 lần mỗi phiên). true = đang dùng phù.
function G:TryScroll(j)
    local T = Ui.WJXTransfer;
    if j.opt.scroll ~= 1 or j.scrollTried or not T or type(T.Plan) ~= "function" then return false; end
    j.scrollTried = true;
    local ok, dest, item = pcall(T.Plan, T, j.point.map);
    if not ok or not dest or not item then return false; end
    self:StopWalk(j);
    j.transfer = T:Begin(dest, item);
    local okUse, used = pcall(me.UseItem, item);
    if not okUse or used == 0 then
        pcall(T.Cancel, T, j.transfer); j.transfer = nil;
        return false;
    end
    j.phase = "transfer";
    self.stepText = "Dùng Vô Hạn Phù về thành / thôn";
    return true;
end

function G:FindNpc()
    if not KNpc or not KNpc.GetAroundNpcList then return nil; end
    local okPos, x, y = pcall(function() return me.GetNpc().GetMpsPos(); end);
    if not okPos then return nil; end
    local best, bestD;
    for _, npc in pairs(KNpc.GetAroundNpcList(me, 1000) or {}) do
        local ok, tid = pcall(function() return npc.nTemplateId; end);
        if ok and tonumber(tid) == self.NPC_TEMPLATE then
            local nx, ny = npc.GetMpsPos();
            local d = (nx - x) ^ 2 + (ny - y) ^ 2;
            if not bestD or d < bestD then best, bestD = npc, d; end
        end
    end
    if best then return best, math.sqrt(bestD); end
end

function G:StopWalk(j)
    local path = Ui.tbLogic and Ui.tbLogic.tbAutoPath;
    if j and j.path and path and path.tbGotoPos == j.path then pcall(path.StopGoto, path, "WJXGHT"); end
    if j then j.path = nil; end
end

-- ---------------------------------------------------------------- hội thoại (bắt bảng hội thoại do mình mở)
function G:InstallSay()
    local ok, say = pcall(Ui, Ui.UI_SAYPANEL);
    if not ok or type(say) ~= "table" or type(say.OnOpen) ~= "function" then return; end
    if say.wjxghtHooked == say.OnOpen then return; end
    local onSay = say.OnOpen;
    local hooked = function(window, param, a, b)
        local result = onSay(window, param, a, b);      -- luôn để chuỗi hook cũ chạy trước
        local T = Ui.WJXGhepHT;
        local j = T and T.job;
        if j and j.transfer and Ui.WJXTransfer then
            pcall(Ui.WJXTransfer.Capture, Ui.WJXTransfer, j.transfer, param);
        elseif j and j.sayUntil and now() <= j.sayUntil then
            T.saySeq = (T.saySeq or 0) + 1;
            j.say, j.sayAt, j.saySeq = param, now(), T.saySeq;
        end
        return result;
    end;
    say.OnOpen = hooked;
    say.wjxghtHooked = hooked;
end

local function fold(text)
    local s = string.gsub(tostring(text or ""), "<[^>]*>", " ");
    s = string.gsub(s, "[ \t\r\n]+", " ");
    s = string.gsub(s, "^ *(.-) *$", "%1");
    local T = Ui.WJXCheTao;                 -- dùng bảng bỏ dấu của Auto Chế Tạo nếu có
    if T and T.Fold then local ok, f = pcall(T.Fold, T, s); if ok and f then return f; end end
    return string.lower(s);
end

function G:Option(opts, wanted, exact)
    local w = fold(wanted);
    for i, o in ipairs(opts or {}) do
        local f = fold(o);
        if (exact and f == w) or (not exact and string.find(f, w, 1, true)) then return i, o; end
    end
end

function G:Pick(j, index, label)
    j.say, j.sayUntil, j.sayAt, j.pickAt = nil, now() + self.SAY_WAIT, nil, now();
    j.lastPick = label;
    Ui(Ui.UI_SAYPANEL):OnListSel("LstSelectArray", index);
end

-- Bước kế tiếp cần ghép theo số HT HIỆN TẠI trong túi
function G:NextStep(j)
    local plan = self:Plan(j.opt);
    for _, s in ipairs(plan.steps) do if s.make > 0 then return s, plan; end end
    return nil, plan;
end

-- Kiểm tra trước khi ghép 1 cấp: đủ bạc, đủ ô, (chỉ khóa) không còn HT không khóa ở cấp nguồn
function G:CheckStep(j, level, n)
    local o = j.opt;
    local cost = n * self.PRICE[level];
    local money = self:Money(o.bindMoney);
    if cost > money then return "thiếu " .. self:MoneyName(o.bindMoney) .. " để ghép " .. n .. " viên cấp " .. level .. " (cần " .. self:FormatMoney(cost) .. ", có " .. self:FormatMoney(money) .. ")"; end
    local free = self:FreeCells();
    if free < o.minFree then return "hành trang còn " .. free .. " ô trống (cần ít nhất " .. o.minFree .. ")"; end
    if o.onlyBind == 1 then
        local u = self:Count(level - 1, self.HT_FREE);
        if u > 0 then return "cấp " .. (level - 1) .. " có " .. u .. " HT không khóa (đang chọn Chỉ Khóa)"; end
    end
end

-- Xử lý 1 bảng hội thoại vừa mở. Trả true nếu đã bấm / xử lý xong.
function G:OnSay(j, param)
    local text, opts = param and param[1], param and param[2] or {};
    local i;
    -- 1. danh sách cấp
    if self:Option(opts, "Ghép thành Huyền Tinh Cấp") then
        local step = self:NextStep(j);
        if not step or step.level > j.opt.target then return self:Finish(true, "đã ghép tới cấp " .. j.opt.target); end
        local why = self:CheckStep(j, step.level, step.make);
        if why then return self:Finish(false, why); end
        i = self:Option(opts, "Ghép thành Huyền Tinh Cấp " .. step.level, true);
        if not i then return self:Finish(false, "không thấy dòng Ghép thành Huyền Tinh Cấp " .. step.level); end
        j.level, j.expect = step.level, step.make;
        self.stepText = "Chọn cấp " .. step.level .. " (dự kiến " .. step.make .. " viên)";
        return self:Pick(j, i, "cấp " .. step.level);
    end
    -- 2. chọn số lượng: chỉ dùng "Ghép hết" (1…6 viên phải kéo tay vào bảng Gift)
    i = self:Option(opts, "Ghép hết trong Hành Trang");
    if i and j.level then
        local _, _, n = string.find(fold(opts[i]), "(%d+)");
        n = tonumber(n) or j.expect or 0;
        local why = self:CheckStep(j, j.level, n);
        if why then return self:Finish(false, why); end
        j.expect = n;
        return self:Pick(j, i, "ghép hết " .. n);
    end
    -- 3. xác nhận
    i = self:Option(opts, "Đồng ý ghép");
    if i and j.level then
        j.before = self:Count(j.level, self.HT_BIND);
        j.phase, j.verifyUntil = "verify", now() + self.SAY_WAIT;
        self.stepText = "Ghép " .. (j.expect or "?") .. " viên cấp " .. j.level;
        return self:Pick(j, i, "đồng ý");
    end
    -- 4. chọn loại bạc
    i = self:Option(opts, j.opt.bindMoney == 1 and "Bạc khóa" or "Bạc thường", true);
    if i and self:Option(opts, "Bạc khóa", true) and self:Option(opts, "Bạc thường", true) then return self:Pick(j, i, "loại bạc"); end
    -- 5. menu gốc của NPC
    i = self:Option(opts, "Ghép Huyền Tinh", true);
    if i then return self:Pick(j, i, "Ghép Huyền Tinh"); end
    -- 6. NPC đang có nhiệm vụ / hoạt động: bấm qua bảng "Đến thật đúng lúc…" (script\npc\npc.lua)
    for _, w in ipairs({"Ta muốn hỏi chuyện khác", "Không muốn tham gia", "Không muốn làm"}) do
        i = self:Option(opts, w, true);
        if i and j.others < 3 then j.others = j.others + 1; return self:Pick(j, i, w); end
    end
    -- 7. bảng số lượng mà không có "Ghép hết" → server tính 0 viên
    if self:Option(opts, "Quay lại", true) and j.level then return self:Finish(false, "không đủ Huyền Tinh cấp " .. (j.level - 1) .. " để ghép"); end
    -- 8. thông báo của server (thiếu bạc / thiếu HT …)
    return self:Finish(false, "NPC báo: " .. string.sub(fold(text), 1, 120));
end

-- ---------------------------------------------------------------- nhịp chạy
function G:Tick()
    local j = self.job;
    if not j then return; end
    local t = now();
    if me.IsDead and me.IsDead() == 1 then return self:Finish(false, "nhân vật bị hạ gục"); end
    if j.phase == "transfer" then
        local T = Ui.WJXTransfer;
        local ok, state = pcall(T.Tick, T, j.transfer);
        if ok and state == "wait" then return; end
        pcall(T.Cancel, T, j.transfer);
        j.transfer = nil;
        if ok and state == "done" then j.phase, j.settleAt = "settle", t;
        else j.phase = "go"; self:Message("Vô Hạn Phù chưa được; đi bộ tới Dã Luyện Đại Sư."); end
        return;
    end
    if j.phase == "settle" then
        local map, x = me.GetWorldPos();
        if not map or map <= 0 or (x or 0) <= 0 or visible(Ui.UI_SKILLPROGRESS) then j.settleAt = t; end
        if t - (j.settleAt or t) < 2 then self.stepText = "Chờ tải cảnh"; return; end
        j.phase, j.point, j.path, j.walkStart, j.walkAt = "go", nil, nil, nil, nil;
        j.userStops = userStops();
        return;
    end
    if j.phase == "go" then
        if userStops() > (j.userStops or 0) then return self:Finish(false, self.USER_MOVE); end
        local npc, d = self:FindNpc();
        if npc and d <= 300 then self:StopWalk(j); j.phase, j.talks = "talk", 0; return; end
        local path = Ui.tbLogic.tbAutoPath;
        if not j.point then
            j.point = self:PickNpcPoint(j.opt.scroll);
            if not j.point then return self:Finish(false, "không tìm được Dã Luyện Đại Sư ở Tân Thủ Thôn / Thành Thị"); end
        end
        if j.point.map ~= me.GetWorldPos() and self:TryScroll(j) then return; end
        if not j.path or path.tbGotoPos ~= j.path then
            if j.walkAt and t - j.walkAt < 3 then return; end
            j.walkAt, j.walkStart = t, j.walkStart or t;
            path:GotoPos({nMapId = j.point.map, nX = j.point.x, nY = j.point.y});
            j.path = path.tbGotoPos;
        end
        if t - (j.walkStart or t) > self.WALK_TIMEOUT then return self:Finish(false, "đi tới Dã Luyện Đại Sư quá lâu"); end
        self.stepText = "Đi tới Dã Luyện Đại Sư";
        return;
    end
    if j.phase == "talk" then
        if j.talkAt and t - j.talkAt < 4 then
            if j.say then j.phase = "dialog"; end
            return;
        end
        j.talks = (j.talks or 0) + 1;
        if j.talks > 3 then return self:Finish(false, "Dã Luyện Đại Sư không mở hội thoại"); end
        local npc = self:FindNpc();
        if not npc then j.phase, j.point = "go", nil; return; end
        j.talkAt, j.sayUntil, j.say = t, t + self.SAY_WAIT, nil;
        pcall(AutoAi.SetTargetIndex, npc.nIndex);
        self.stepText = "Nói chuyện với Dã Luyện Đại Sư";
        return;
    end
    if j.phase == "verify" then
        local after = self:Count(j.level, self.HT_BIND);
        if after > (j.before or 0) then
            j.made[j.level] = (j.made[j.level] or 0) + (after - j.before);
            j.before = after;
            j.phase, j.level, j.expect = "dialog", nil, nil;
            self.stateChanged = true;
            -- server mở lại danh sách cấp: xử lý ở nhịp sau
            if not j.say then j.sayUntil = t + self.SAY_WAIT; j.waitSay = t; end
            return;
        end
        if t > (j.verifyUntil or t) then return self:Finish(false, "không thấy Huyền Tinh cấp " .. j.level .. " tăng sau khi ghép"); end
        return;
    end
    if j.phase == "dialog" then
        if j.say and j.saySeq ~= j.doneSeq then
            j.doneSeq = j.saySeq;
            local param = j.say;
            j.say = nil;
            return self:OnSay(j, param);
        end
        -- không có bảng mới: nói chuyện lại
        if t > (j.sayUntil or t) then j.phase, j.talkAt, j.talks = "talk", nil, 0; end
        return;
    end
end
