-- Auto Vượt Ải Gia Tộc — ĐỘI: lệnh riêng [WJXKG:...] trên kênh Đội.
--   AS (đội trưởng → thành viên): gán 1 trong 4 tuyến (1 Trái · Phản Đòn / 2 Giữa · Bí văn 1–4 / 3 Giữa · Bí văn 5–8 /
--      4 Phải · Choáng) cho từng người (ô chuỗi cũ luôn gửi 0).
--   RM (đội trưởng → thành viên): bật / dừng Auto, cả đội hoặc 1 người.
--   OP (ai cũng gửi): phòng vừa biết là đã mở (kèm phòng có bia mở ra nó) — người khác khỏi phải dò cửa.
--   RP (thành viên → đội trưởng): trạng thái, phòng, % máu, tuyến / chuỗi đang nhận.
--   GO (đội trưởng → cả đội): vào ải — tới Mã Xuyên Sơn ở thành của đội trưởng (tự tìm đường liên bản đồ) rồi vào.
--   MX (đội trưởng → cả đội): tới đứng cạnh Mã Xuyên Sơn ở thành hậu cần đã chọn (không vào ải).
--   (PT Chuẩn Bị Dược Phẩm dùng lệnh hậu cần của CheckBOSS — xem M:SendSupply.)
--   EX (đội trưởng → cả đội): rời ải — tới Phòng bảo rương rồi bước vào lối ra (Điểm Rời Bản Đồ).
--   GT (đội trưởng → cả đội): tập trung về phòng + toạ độ của đội trưởng, đi theo đúng cửa (thay PT Tập Trung của Tổ Đội).
-- Lệnh không chứa tên nhân vật: mỗi người là mã 4 chữ cái (băm tên); chữ số mã thành a–j.
if not Ui.WJXVuotAi or not Ui.WJXVuotAi.loading then return; end
local M = Ui.WJXVuotAi;

M.REPORT_BEAT = 15;     -- giây: báo lại dù không đổi
M.REPORT_MIN = 3;       -- giây: tối thiểu giữa 2 lần báo
M.STATES = {[0] = "Đã dừng", [1] = "Đang chạy", [2] = "Quan sát (auto khác)", [3] = "Bị hạ gục", [4] = "Ngoài ải",
    [5] = "Phòng Tâm Ma"};

local A = string.byte("a");
local gmatch = string.gmatch or string.gfind;
local function mod(a, b) return a - math.floor(a / b) * b; end
local function now() return GetTime(); end

function M:EncNum(n)
    n = math.max(0, math.floor(tonumber(n) or 0));
    return (string.gsub(tostring(n), "%d", function(d) return string.char(A + tonumber(d)); end));
end

function M:DecNum(s)
    if type(s) ~= "string" or s == "" or string.find(s, "[^a-j]") then return nil; end
    return tonumber((string.gsub(s, ".", function(c) return tostring(string.byte(c) - A); end)));
end

function M:NameKey(name)
    local h = 5381;
    name = tostring(name or "");
    for i = 1, string.len(name) do h = mod(h * 33 + string.byte(name, i), 456976); end
    local s = "";
    for _ = 1, 4 do s = s .. string.char(A + mod(h, 26)); h = math.floor(h / 26); end
    return s;
end

-- Đội: {members (không gồm mình), tên đội trưởng}.
function M:Team()
    local ok, list = pcall(me.GetTeamMemberInfo);
    local members, leader = {}, nil;
    if ok and type(list) == "table" then
        for _, m in ipairs(list) do
            if type(m) == "table" and m.szName and m.szName ~= "" then
                if m.szName ~= me.szName then members[#members + 1] = m; end
                if m.nLeader == 1 then leader = m.szName; end
            end
        end
    end
    if #members > 0 and not leader then leader = me.szName; end
    return members, leader;
end

function M:IsLeader()
    local members, leader = self:Team();
    return #members > 0 and leader == me.szName;
end

function M:NextSeq()
    self.seq = math.max((self.seq or 0) + 1, math.floor(now()));
    return self.seq;
end

function M:SendTeam(text)
    if type(SendChannelMsg) ~= "function" then return false; end
    if #(self:Team()) == 0 then return false; end
    SendChannelMsg("Team", text);
    return true;
end

-- ---------------------------------------------------------------- mã hoá
function M:EncodeAssign(seq, rows)
    local parts = {};
    for _, r in ipairs(rows) do parts[#parts + 1] = r.key .. self:EncNum(r.route) .. self:EncNum(r.chain); end
    return self.PREFIX .. "AS:" .. self:EncNum(seq) .. ":" .. table.concat(parts, "_") .. "]";
end

function M:EncodeRun(seq, on, name)
    return self.PREFIX .. "RM:" .. self:EncNum(seq) .. ":" .. (on and "b" or "a") .. (name and (":" .. self:NameKey(name)) or "") .. "]";
end

function M:EncodeOpen(seq, map, room, from)
    return self.PREFIX .. "OP:" .. table.concat({self:EncNum(seq), self:EncNum(map), self:EncNum(room), self:EncNum(from)}, "_") .. "]";
end

function M:EncodeReport(r)
    return self.PREFIX .. "RP:" .. self:NameKey(r.name) .. ":" ..
        table.concat({self:EncNum(r.seq), self:EncNum(r.state), self:EncNum(r.room), self:EncNum(r.hp), self:EncNum(r.route), self:EncNum(r.chain)}, "_") .. "]";
end

function M:EncodeGo(seq, city)
    return self.PREFIX .. "GO:" .. self:EncNum(seq) .. "_" .. self:EncNum(city) .. "]";
end

function M:EncodeEntry(seq, city)
    return self.PREFIX .. "MX:" .. self:EncNum(seq) .. "_" .. self:EncNum(city) .. "]";
end

function M:EncodeExit(seq, map)
    return self.PREFIX .. "EX:" .. self:EncNum(seq) .. "_" .. self:EncNum(map) .. "]";
end

function M:EncodeGather(seq, map, room, x, y)
    return self.PREFIX .. "GT:" .. table.concat({self:EncNum(seq), self:EncNum(map), self:EncNum(room), self:EncNum(x), self:EncNum(y)}, "_") .. "]";
end

local function nums(self, body)
    local v = {};
    for piece in gmatch(body, "([^_]+)") do v[#v + 1] = self:DecNum(piece); end
    return v;
end

function M:Decode(msg)
    if type(msg) ~= "string" then return nil; end
    local _, _, kind, rest = string.find(msg, "^%[WJXKG:(%u%u):(.-)%]$");
    if kind == "AS" then
        local _, _, s, body = string.find(rest, "^([a-j]+):([a-z_]+)$");
        local seq = self:DecNum(s);
        if not seq then return nil; end
        local rows = {};
        for piece in gmatch(body, "([^_]+)") do
            local _, _, key, r, c = string.find(piece, "^(%l%l%l%l)([a-e])([a-c])$");
            if not key then return nil; end
            rows[key] = {route = self:DecNum(r), chain = self:DecNum(c)};
        end
        return {kind = "AS", seq = seq, rows = rows};
    elseif kind == "RM" then
        local _, _, s, on, key = string.find(rest, "^([a-j]+):([ab]):?(%l*)$");
        local seq = self:DecNum(s);
        if seq and (key == "" or string.len(key) == 4) then return {kind = "RM", seq = seq, on = on == "b", key = key ~= "" and key or nil}; end
    elseif kind == "OP" then
        if string.find(rest, "[^a-j_]") then return nil; end
        local v = nums(self, rest);
        if #v ~= 4 then return nil; end
        return {kind = "OP", seq = v[1], map = v[2], room = v[3], from = v[4]};
    elseif kind == "GO" or kind == "GT" or kind == "MX" or kind == "EX" then
        if string.find(rest, "[^a-j_]") then return nil; end
        local v = nums(self, rest);
        if kind == "EX" and #v == 2 then return {kind = "EX", seq = v[1], map = v[2]}; end
        if (kind == "GO" or kind == "MX") and #v == 2 then return {kind = kind, seq = v[1], city = v[2]}; end
        if kind == "GT" and #v == 5 then return {kind = "GT", seq = v[1], map = v[2], room = v[3], x = v[4], y = v[5]}; end
    elseif kind == "RP" then
        local _, _, key, body = string.find(rest, "^(%l%l%l%l):([a-j_]+)$");
        if not key then return nil; end
        local v = nums(self, body);
        if #v ~= 6 then return nil; end
        return {kind = "RP", key = key, seq = v[1], state = v[2], room = v[3], hp = v[4], route = v[5], chain = v[6]};
    end
end

-- ---------------------------------------------------------------- trạng thái bản thân
function M:SelfState()
    local j = self.job;
    if not j then return 0; end
    if me.IsDead and me.IsDead() == 1 then return 3; end
    if not self:InGame() then return 4; end
    local _, x, y = me.GetWorldPos();
    if self:InHeart(x, y) then return 5; end
    if self:OtherOwner() then return 2; end
    return 1;
end

function M:SelfReport(state)
    local hp = 0;
    if (tonumber(me.nMaxLife) or 0) > 0 then hp = math.floor((tonumber(me.nCurLife) or 0) * 100 / me.nMaxLife); end
    local mine = self:Mine();
    return {name = me.szName, seq = self:NextSeq(), state = state or self:SelfState(), room = (self.job and self.job.room) or 0,
        hp = math.max(0, math.min(100, hp)), route = mine.route or 0, chain = 0, at = now()};
end

-- Thành viên báo cho đội trưởng (đổi trạng thái / phòng thì báo ngay, không đổi thì ~15 giây).
function M:Report(state, force)
    local members, leader = self:Team();
    if #members == 0 or leader == me.szName then return; end
    local r = self:SelfReport(state);
    local key = r.state .. ":" .. r.room .. ":" .. r.route .. ":" .. r.chain;
    local last = self.reportAt or -1000;
    if not force then
        if key == self.reportKey and now() - last < self.REPORT_BEAT then return; end
        if now() - last < self.REPORT_MIN then return; end
    end
    self.reportAt, self.reportKey = now(), key;
    self:SendTeam(self:EncodeReport(r));
end

-- Gửi các phòng vừa biết là mở (gom lại, tối đa 1 tin / giây).
function M:FlushOpen()
    local q = self.openQueue;
    if not q or #q == 0 then return; end
    if self.openAt and now() - self.openAt < 1 then return; end
    if #(self:Team()) == 0 then self.openQueue = {}; return; end
    local row = table.remove(q, 1);
    self.openAt = now();
    local map = me.GetWorldPos();
    self:SendTeam(self:EncodeOpen(self:NextSeq(), map, row[1], row[2]));
end

-- ---------------------------------------------------------------- lệnh đội trưởng
-- plan[tên] = {route, chain} do đội trưởng chọn ở tab Phân Công (chỉ giữ trong bộ nhớ, không ghi file).
function M:Plan4(name) self.plan = self.plan or {}; self.plan[name] = self.plan[name] or {route = 0, chain = 0}; return self.plan[name]; end

function M:SendAssign()
    local members = self:Team();
    if #members == 0 then
        self:Message("Không có tổ đội: tuyến / chuỗi của bản thân chọn ở tab Phân Công và có hiệu lực ngay.");
        return false;
    end
    if not self:IsLeader() then self:Message("Chỉ đội trưởng được gửi phân công."); return false; end
    if self.sentAt and now() - self.sentAt < 2 then self:Message("Gửi chậm lại một chút (2 giây/lệnh)."); return false; end
    self.sentAt = now();
    local rows, missing = {}, 0;
    for _, m in ipairs(members) do
        local p = self:Plan4(m.szName);
        if (p.route or 0) == 0 then missing = missing + 1; end
        rows[#rows + 1] = {key = self:NameKey(m.szName), route = p.route or 0, chain = 0};
    end
    local own = self:Plan4(me.szName);
    self.mine = {route = own.route or 0};
    self:SendTeam(self:EncodeAssign(self:NextSeq(), rows));
    self:Message("Đã gửi phân công cho " .. #rows .. " thành viên" .. (missing > 0 and (" (" .. missing .. " người chưa gán tuyến).") or "."));
    return true;
end

-- Chia cả đội vào 4 tuyến: lần lượt Trái, Phải, Giữa 1–4, Giữa 5–8; bia trái / phải / giữa mỗi bia tối đa
-- ceil(N/3) người (2 nhánh giữa chung 1 bia). keep = giữ người đã gán, chỉ chia người chưa gán.
M.ASSIGN_ORDER = {1, 4, 2, 3};
function M:AutoAssign(keep)
    local members = self:Team();
    local names = {me.szName};
    for _, m in ipairs(members) do names[#names + 1] = m.szName; end
    local cap = math.ceil(#names / 3);
    local gate = {[1] = "L", [4] = "R", [2] = "M", [3] = "M"};
    local used = {L = 0, R = 0, M = 0};
    local count = {[1] = 0, [2] = 0, [3] = 0, [4] = 0};
    local todo = {};
    for _, n in ipairs(names) do
        local p = self:Plan4(n);
        if keep and (p.route or 0) > 0 then
            used[gate[p.route]] = used[gate[p.route]] + 1; count[p.route] = count[p.route] + 1;
        else
            p.route = 0; todo[#todo + 1] = p;
        end
    end
    local filled = 0;
    for _, p in ipairs(todo) do
        -- tuyến ít người nhất theo thứ tự ưu tiên, còn suất ở bia
        local best;
        for _, r in ipairs(self.ASSIGN_ORDER) do
            if used[gate[r]] < cap and (not best or count[r] < count[best]) then best = r; end
        end
        if best then
            p.route = best; used[gate[best]] = used[gate[best]] + 1; count[best] = count[best] + 1; filled = filled + 1;
        end
    end
    local own = self:Plan4(me.szName);
    self.mine = {route = own.route or 0};
    return filled, #names;
end

function M:Unassigned()
    local n = 0;
    for _, m in ipairs((self:Team())) do if (self:Plan4(m.szName).route or 0) == 0 then n = n + 1; end end
    if (self:Plan4(me.szName).route or 0) == 0 then n = n + 1; end
    return n;
end

function M:SendRun(on, name)
    if not self:IsLeader() then self:Message("Chỉ đội trưởng trong tổ đội được gọi PT."); return false; end
    if self.sentAt and now() - self.sentAt < 2 then self:Message("Gửi chậm lại một chút (2 giây/lệnh)."); return false; end
    if on and not name and self:Unassigned() > 0 then
        if self:LoadOptions().autoAssign == 1 then
            self:AutoAssign(true);
            self.sentAt = nil;
            self:SendAssign();
        else
            self:Message(self:Unassigned() .. " người chưa gán tuyến: bấm Tự Động Phân Công hoặc bật ô Tự Phân Công.");
        end
    end
    self.sentAt = now();
    self:SendTeam(self:EncodeRun(self:NextSeq(), on, name));
    if not name then
        if on then
            if not self.job then self:Start(self:LoadOptions()); end
            self:Message("Đã gọi cả đội bật Auto Vượt Ải.");
        else
            if self.job then self:Stop(); end
            self:Message("Đã gọi cả đội dừng Auto Vượt Ải.");
        end
    else
        self:Message("Đã gọi 1 thành viên " .. (on and "bật" or "dừng") .. " Auto Vượt Ải.");
    end
    return true;
end

function M:LeaderSendOk()
    if not self:IsLeader() then self:Message("Chỉ đội trưởng trong tổ đội được gọi PT."); return false; end
    if self.sentAt and now() - self.sentAt < 2 then self:Message("Gửi chậm lại một chút (2 giây/lệnh)."); return false; end
    self.sentAt = now();
    return true;
end

-- PT Vào Ải: cả đội tới Mã Xuyên Sơn ở thành đội trưởng đang đứng (hoặc thành vừa rời) rồi vào ải.
function M:SendGo()
    if not self:LeaderSendOk() then return false; end
    local city = self:City() or self:LoadOptions().hcCity or self.lastCity or 0;
    self:SendTeam(self:EncodeGo(self:NextSeq(), city));
    if not self:InGame() and not self.job then self:StartCommand({enterOnly = true, goCity = city > 0 and city or nil}); end
    if city > 0 then self:Message("Đã gọi cả đội vào ải ở " .. self.CITY[city].vn .. ".");
    else self:Message("Đã gọi cả đội vào ải (bạn không đứng ở thành nào: mỗi người vào ở thành đang đứng)."); end
    return true;
end

-- PT Mã Xuyên Sơn: cả đội (hoặc bản thân khi đi một mình) tới đứng cạnh Mã Xuyên Sơn ở thành hậu cần.
function M:SendEntry(city)
    city = self.CITY[city] and city or self:LoadOptions().hcCity;
    local members = self:Team();
    if #members > 0 then
        if not self:LeaderSendOk() then return false; end
        self:SendTeam(self:EncodeEntry(self:NextSeq(), city));
    end
    self:GoEntry(city);
    return true;
end

function M:GoEntry(city)
    if self:InGame() then self:Message("Tới Mã Xuyên Sơn " .. self.CITY[city].vn .. ": bạn đang ở trong ải, bỏ qua."); return; end
    self:Message("Tới Mã Xuyên Sơn ở " .. self.CITY[city].vn .. ".");
    local j = self.job;
    if j then j.goCity, j.toEntry, j.enterFail, j.travelN = city, true, nil, 0; j.options.enter = 1; self:TakeOver();
    else self:StartCommand({toEntry = true, goCity = city}); end
end

-- PT Chuẩn Bị Dược Phẩm / PT Về Dược Phẩm: mượn hậu cần của CheckBOSS (tự tìm đường tới NPC Dược Phẩm 3564,
-- mua HP / MP bằng bạc khóa qua Auto6, đồng bộ cả đội trên kênh của CheckBOSS). Uống thuốc theo cấu hình CheckBOSS.
function M:SendSupply(o, buy)
    local C = Ui.WJXCheckBoss;
    if type(C) ~= "table" or type(C.CommandSupport) ~= "function" or type(C.LoadOptions) ~= "function" then
        self:Message("Chưa nạp CheckBOSS (interface\\tool): không gọi được hậu cần."); return false;
    end
    if not Ui.WJXAuto6 then self:Message("Chưa nạp Auto6: không mua được thuốc."); return false; end
    local raw = C:LoadOptions();
    local members = self:Team();
    raw.city, raw.hpType, raw.hpCount, raw.mpType, raw.mpCount = o.hcCity, o.hpType, o.hpCount, o.mpType, o.mpCount;
    raw.party, raw.applySelf = #members > 0 and 1 or 0, 1;
    local ok, result = pcall(C.CommandSupport, C, raw, buy);
    if not ok then self:Message("Hậu cần CheckBOSS báo lỗi: " .. tostring(result)); return false; end
    if result then
        self:Message((#members > 0 and "Đã gọi cả đội " or "") .. (buy and "chuẩn bị Dược Phẩm" or "về Dược Phẩm") .. " ở " .. self.CITY[o.hcCity].vn .. ".");
    end
    return result;
end

-- PT Tập Trung: gửi phòng + toạ độ của đội trưởng.
function M:SendGather()
    if not self:InGame() then self:Message("PT Tập Trung chỉ dùng trong Thần Bí Bảo Khố."); return false; end
    if not self:LeaderSendOk() then return false; end
    local map, x, y = me.GetWorldPos();
    local room = self:RoomAt(x, y) or (self.job and self.job.lastRoom) or self:NearestRoom(x, y) or 0;
    self:SendTeam(self:EncodeGather(self:NextSeq(), map, room, math.floor(x), math.floor(y)));
    self:Message("Đã gọi cả đội tập trung về " .. ((self.ROOMS[room] or {}).vn or "chỗ bạn") .. ".");
    return true;
end

-- PT Rời VAGT: cả đội (hoặc bản thân khi đi một mình) tới Điểm Rời Bản Đồ trong Phòng bảo rương.
function M:SendExit()
    if not self:InGame() then self:Message("PT Rời VAGT chỉ dùng trong Thần Bí Bảo Khố."); return false; end
    local members = self:Team();
    if #members > 0 then
        if not self:LeaderSendOk() then return false; end
        self:SendTeam(self:EncodeExit(self:NextSeq(), (me.GetWorldPos())));
    end
    self:GoExit();
    return true;
end

function M:GoExit()
    if not self:InGame() then return; end
    self:Message("Rời Vượt Ải: tới Điểm Rời Bản Đồ.");
    local j = self.job;
    if j then j.exitOnly, j.way = true, nil; self:TakeOver();
    else self:StartCommand({exitOnly = true}); end
end

function M:OnGo(cmd)
    if self:InGame() then self:Message("Đội trưởng gọi vào ải: bạn đã ở trong ải."); return; end
    local city = cmd.city > 0 and self.CITY[cmd.city] and cmd.city or nil;
    self:Message("Đội trưởng gọi vào ải" .. (city and (" ở " .. self.CITY[city].vn) or "") .. ".");
    local j = self.job;
    if j then
        j.goCity, j.enterFail, j.travelN = city, nil, 0;
        j.options.enter = 1;
        self:TakeOver();
    else
        self:StartCommand({enterOnly = true, goCity = city});
    end
end

function M:OnGather(cmd)
    if not self:InGame() then self:Message("Đội trưởng gọi tập trung nhưng bạn chưa ở trong ải."); return; end
    if self:Know().map ~= cmd.map then self:Message("Đội trưởng gọi tập trung nhưng không cùng lượt ải với bạn."); return; end
    local g = {map = cmd.map, room = cmd.room, x = cmd.x, y = cmd.y, at = now()};
    self:Message("Đội trưởng gọi tập trung về " .. ((self.ROOMS[cmd.room] or {}).vn or "chỗ đội trưởng") .. ".");
    if self.job then self.job.gather, self.job.way = g, nil; self:TakeOver();
    else self:StartCommand({gatherOnly = true, gather = g}); end
end

function M:Receive(sender, msg)
    if not sender or sender == me.szName then return; end
    local cmd = self:Decode(msg);
    if not cmd then return; end
    local members, leader = self:Team();
    local inTeam = false;
    for _, m in ipairs(members) do if m.szName == sender then inTeam = true; end end
    if not inTeam then return; end
    if cmd.kind == "RP" then
        if leader ~= me.szName or self:NameKey(sender) ~= cmd.key then return; end
        cmd.name, cmd.at = sender, now();
        self.reports = self.reports or {};
        self.reports[sender] = cmd;
        return;
    end
    if cmd.kind == "OP" then
        local k = self:Know();
        if k.map ~= cmd.map then return; end
        self.receiving = true;
        pcall(self.MarkOpen, self, cmd.room, cmd.from > 0 and cmd.from or nil);
        self.receiving = nil;
        return;
    end
    if sender ~= leader or self.lastSeq == cmd.seq then return; end
    self.lastSeq = cmd.seq;
    if cmd.kind == "AS" then
        local row = cmd.rows[self:NameKey(me.szName)];
        if not row then return; end
        self.mine = {route = row.route or 0};
        self:Message("Đội trưởng gán tuyến: " .. (self.ROUTE_NAME[self.mine.route] or "?") .. ".");
        self:Report(nil, true);
        return;
    end
    if cmd.kind == "GO" then return self:OnGo(cmd); end
    if cmd.kind == "GT" then return self:OnGather(cmd); end
    if cmd.kind == "EX" then
        if self:InGame() and self:Know().map == cmd.map then self:GoExit(); end
        return;
    end
    if cmd.kind == "MX" then
        if self.CITY[cmd.city] then self:GoEntry(cmd.city); end
        return;
    end
    if cmd.key and cmd.key ~= self:NameKey(me.szName) then return; end
    if cmd.on then
        if self.job then self:Report(1, true); return; end
        self:StartCommand();
        self:Message("Đội trưởng gọi bật Auto Vượt Ải.");
        self:Report(nil, true);
    elseif self.job then
        self:Stop("Đội trưởng gọi dừng Auto Vượt Ải.");
        self:Report(0, true);
    end
end
