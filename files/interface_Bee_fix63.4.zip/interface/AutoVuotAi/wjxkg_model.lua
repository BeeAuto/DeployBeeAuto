-- Auto Vượt Ải Gia Tộc — MODEL: cài đặt, nhận diện ải / phòng, quét NPC, bộ nhớ "phòng nào đã mở" của lượt ải hiện tại.
-- Chỉ đọc dữ liệu client; dữ liệu phòng sinh sẵn từ máy chủ trong wjxkg_data.lua.
if not Ui.WJXVuotAi or not Ui.WJXVuotAi.loading then return; end
local M = Ui.WJXVuotAi;

M.CONFIG_KEY = "VuotAi";
M.RANGES = {300, 400, 500, 600, 700, 800, 900, 1000, 1100, 1200};   -- MPS
M.RANGE_DEFAULT = 800;
M.KEY_COUNTS = {1, 2, 3, 4, 5, 6, 8, 10, 12, 15, 20, 25, 30};
M.ITEM_MIYAO = {18, 1, 107, 1};
M.ITEM_KEY = {18, 1, 106, 1};
M.STATE_MIYAO = 764;

-- ---------------------------------------------------------------- cài đặt (lưu theo nhân vật, kho btssl_autofight)
-- 3 lựa chọn Bí dược / Tâm Ma / Đổi tiền mặc định TẮT.
function M:Options(raw)
    raw = type(raw) == "table" and raw or {};
    local function flag(v, default) if v == nil then return default; end return v == 0 and 0 or 1; end
    local range = tonumber(raw.range) or self.RANGE_DEFAULT;
    if range ~= range then range = self.RANGE_DEFAULT; end
    range = math.max(300, math.min(1200, math.floor(range / 100) * 100));
    local keyCount = tonumber(raw.keyCount) or 6;
    if keyCount ~= keyCount then keyCount = 6; end
    keyCount = math.max(1, math.min(40, math.floor(keyCount)));
    local function int(v, lo, hi, default)
        v = tonumber(v);
        if not v or v ~= v then return default; end
        return math.max(lo, math.min(hi, math.floor(v)));
    end
    local level = tonumber(me and me.nLevel) or 1;
    local drug = math.min(5, math.max(1, math.floor((level + 10) / 20)));
    local hcCity = tonumber(raw.hcCity);
    if not (hcCity and self.CITY and self.CITY[hcCity]) then hcCity = 23; end
    return {miyao = flag(raw.miyao, 0), heart = flag(raw.heart, 0), exchange = flag(raw.exchange, 0),
        enter = flag(raw.enter, 1), key = flag(raw.key, 0), coinbox = flag(raw.coinbox, 1),
        auto6 = flag(raw.auto6, 1), dismount = flag(raw.dismount, 1), range = range, keyCount = keyCount,
        autoAssign = flag(raw.autoAssign, 0),
        -- Hậu Cần: thành (chỉ 7 thành có Mã Xuyên Sơn), loại + số lượng HP / MP cần có
        hcCity = hcCity, hpType = int(raw.hpType, 1, 5, drug), mpType = int(raw.mpType, 1, 5, drug),
        hpCount = int(raw.hpCount, 0, 500, 0), mpCount = int(raw.mpCount, 0, 500, 0)};
end

function M:ConfigStore()
    local ok, ui = pcall(Ui, Ui.UI_AUTOFIGHT);
    if ok and type(ui) == "table" and ui.Load and ui.Save then return ui; end
end

function M:LoadOptions()
    local ui = self:ConfigStore();
    if not ui then return self:Options(self.memoryOptions); end
    local ok, raw = pcall(ui.Load, ui, self.CONFIG_KEY);
    return self:Options(ok and raw or nil);
end

function M:SaveOptions(raw)
    local options = self:Options(raw);
    local ui = self:ConfigStore();
    if not ui then
        self.memoryOptions = options;
        self:Message("Không có nơi lưu cấu hình (btssl_autofight); cài đặt chỉ giữ đến khi thoát game.");
        return options;
    end
    pcall(ui.Load, ui, self.CONFIG_KEY);      -- đọc lại ngay trước khi ghi để giữ cài đặt của auto khác
    local ok, saved = pcall(ui.Save, ui, self.CONFIG_KEY, options);
    if not ok or saved == false then self:Message("Không ghi được cài đặt."); return nil; end
    return options;
end

-- ---------------------------------------------------------------- chuỗi
function M:Plain(text)
    local s = string.gsub(tostring(text or ""), "<[^>]*>", " ");
    s = string.gsub(s, "[ \t\r\n]+", " ");
    return (string.gsub(s, "^ *(.-) *$", "%1"));
end

-- Tên phòng (Trung từ máy chủ hoặc Việt) xuất hiện trong chuỗi → số phòng. Tên dài so trước (tránh "1" khớp "10").
function M:RoomInText(text)
    local s = tostring(text or "");
    if not self.nameOrder then
        local list = {};
        for name, id in pairs(self.NAME2ROOM) do list[#list + 1] = {name, id}; end
        table.sort(list, function(a, b) return string.len(a[1]) > string.len(b[1]); end);
        self.nameOrder = list;
    end
    for _, row in ipairs(self.nameOrder) do
        if string.find(s, row[1], 1, true) then return row[2]; end
    end
end

function M:Has(text, ...)
    local s = tostring(text or "");
    for _, w in ipairs({...}) do if string.find(s, w, 1, true) then return true; end end
    return false;
end

-- ---------------------------------------------------------------- NPC (pNpc trên Game.exe là userdata → đọc qua pcall)
local function field(o, k)
    local ok, v = pcall(function() return o[k]; end);
    if ok then return v; end
end
M.Field = field;

function M:Tpl(npc) return tonumber(field(npc, "nTemplateId")) or 0; end

function M:IsPlayer(npc)
    return (tonumber(field(npc, "nKind")) or 0) == 1 or field(npc, "bPlayer") == true or (tonumber(field(npc, "bPlayer")) or 0) == 1;
end

function M:Alive(npc)
    local life = tonumber(field(npc, "nCurLife"));
    if life and life <= 0 then return false; end
    return (tonumber(field(npc, "nDoing")) or 0) ~= 10;
end

function M:Attackable(npc)
    if not npc or not self:Alive(npc) or self:IsPlayer(npc) then return false; end
    if self.NPC_ROLE[self:Tpl(npc)] then return false; end      -- trụ / bia / bí dược / rương / NPC: không đánh
    if AutoAi.AiTargetCanAttack then
        local ok, v = pcall(AutoAi.AiTargetCanAttack, npc.nIndex);
        if ok and v ~= nil then return v == 1; end
    end
    return (tonumber(field(npc, "nKind")) or 0) == 0;
end

-- NPC quanh mình (không gồm người chơi) và số người chơi quanh mình (gồm cả mình).
function M:Around()
    local list, players = {}, 1;
    for _, npc in pairs(KNpc.GetAroundNpcList(me, 400) or {}) do
        if npc then
            if self:IsPlayer(npc) then players = players + 1; else list[#list + 1] = npc; end
        end
    end
    return list, players;
end

function M:Pos(npc)
    local x, y = npc.GetMpsPos();
    return x / 32, y / 32;
end

function M:Dist(npc)
    local x, y = self:Pos(npc);
    local _, mx, my = me.GetWorldPos();
    return math.sqrt((x - mx) ^ 2 + (y - my) ^ 2);
end

function M:DistXY(x, y)
    local _, mx, my = me.GetWorldPos();
    return math.sqrt((x - mx) ^ 2 + (y - my) ^ 2);
end

function M:CountItem(g)
    local ok, list = pcall(me.FindItemInBags, g[1], g[2], g[3], g[4]);
    if ok and type(list) == "table" then return #list, list; end
    return 0, {};
end

-- ---------------------------------------------------------------- nhận diện
function M:InGame()
    local ok, t = pcall(function() return me.nTemplateMapId; end);
    if ok and tonumber(t) then return tonumber(t) == self.MAP_TEMPLATE; end
    local map = me.GetWorldPos();
    local okName, name = pcall(GetMapNameFormId, map);
    name = okName and tostring(name or "") or "";
    return string.find(name, "Thần Bí Bảo Khố", 1, true) ~= nil or string.find(name, "神秘宝库", 1, true) ~= nil;
end

function M:City()
    local map = me.GetWorldPos();
    return self.CITY[map] and map or nil;
end

function M:InHeart(x, y)
    local b = self.HEART_BOX;
    return x >= b[1] and x <= b[3] and y >= b[2] and y <= b[4];
end

-- Phòng đang đứng: khung dữ liệu nới rộng; trùng nhiều khung thì lấy khung nhỏ nhất. Lối vào / Phòng nghỉ nới rộng hơn.
local PAD = {[1] = 22, [26] = 26, [28] = 10};
function M:RoomAt(x, y)
    local best, area;
    for id, r in pairs(self.ROOMS) do
        if r.box then
            local p = PAD[id] or 6;
            local b = r.box;
            if x >= b[1] - p and x <= b[3] + p and y >= b[2] - p and y <= b[4] + p then
                local a = (b[3] - b[1] + 2 * p) * (b[4] - b[2] + 2 * p);
                if not area or a < area then best, area = id, a; end
            end
        end
    end
    return best;
end

-- Phòng có khung chứa đúng toạ độ (không nới) — đứng trong đó thì phòng chắc chắn đã mở.
function M:RoomStrict(x, y)
    local best, area;
    for id, r in pairs(self.ROOMS) do
        local b = r.box;
        if b and id ~= 26 and x >= b[1] and x <= b[3] and y >= b[2] and y <= b[4] then
            local a = (b[3] - b[1]) * (b[4] - b[2]);
            if not area or a < area then best, area = id, a; end
        end
    end
    return best;
end

-- ---------------------------------------------------------------- bộ nhớ của lượt ải (theo ID bản đồ động)
-- open[r]   = phòng đã mở (thấy quái / không còn bia chặn cửa / thông báo / đồng đội báo)
-- closed[r] = lúc vừa thấy phòng còn đóng (bia chặn cửa / bị trap đẩy lùi)
-- next[r]   = phòng mà bia của phòng r mở ra (đọc từ chữ trên bia / thông báo)
-- done[r]   = phòng mình coi như xong; used[dwId] = cơ quan đã bật / không bật lại được
function M:Know()
    local map = me.GetWorldPos();
    local k = self.know;
    if not k or k.map ~= map then
        k = {map = map, open = {[1] = true}, closed = {}, next = {}, done = {}, used = {}, pressed = {}, pillar = {}, at = GetTime()};
        self.know = k;
    end
    return k;
end

function M:MarkOpen(r, from)
    if not r or not self.ROOMS[r] then return; end
    local k = self:Know();
    if k.open[r] then return; end
    k.open[r], k.closed[r] = true, nil;
    -- phòng đã mở thì các phòng đứng trước (đệ quy) chắc chắn đã xong
    local stack = {r};
    while #stack > 0 do
        local q = table.remove(stack);
        for _, p in ipairs(self.ROOMS[q].pre or {}) do
            if not k.open[p] then k.open[p], k.closed[p] = true, nil; stack[#stack + 1] = p; end
        end
    end
    if from and from ~= r and self.ROOMS[from] then k.next[from] = r; end
    if self.OnRoomOpened then pcall(self.OnRoomOpened, self, r, from); end
end

function M:IsOpen(r) local k = self:Know(); return k.open[r] == true; end

-- Phòng tiếp theo của chuỗi c (1 = A, 2 = B) mà mình nên làm: đi dọc next[] từ phòng đầu.
-- Trả: phòng hiện tại của chuỗi, phòng kế (nil nếu chưa biết), danh sách phòng ngẫu nhiên còn có thể là phòng kế.
function M:ChainCursor(c)
    local k, ch = self:Know(), self.CHAIN[c];
    if not ch or not k.open[ch.first] then return nil; end
    local cur, seen, steps = ch.first, {}, 0;
    while cur and k.next[cur] and k.open[k.next[cur]] and steps < 12 do seen[cur] = true; cur = k.next[cur]; steps = steps + 1; end
    seen[cur] = true;
    -- Phòng ngẫu nhiên đã dùng trong chuỗi
    local used = {};
    local walk = ch.first;
    while walk do used[walk] = true; walk = k.next[walk]; if walk and used[walk] then break; end end
    local cand = {};
    local isMid = false;
    for _, m in ipairs(ch.mids) do if m == cur then isMid = true; end end
    if isMid then for _, r in ipairs(ch.rand) do if not used[r] then cand[#cand + 1] = r; end end end
    return cur, k.next[cur], cand, isMid;
end

-- ---------------------------------------------------------------- ai đang điều khiển nhân vật?
function M:OtherOwner()
    local a = Ui.WJXAuto6;
    local own = self.OwnsAuto6 and self:OwnsAuto6();
    local party = Ui.WJXParty;
    local dispatch = party and party.dispatch;
    if dispatch and dispatch.job then return "Điều Phối Tổ Đội"; end
    if Ui.WJXTieuDao and Ui.WJXTieuDao.job then return "Auto Tiêu Dao Cốc"; end
    if Ui.WJXXoyo and Ui.WJXXoyo.job then return "TDC (lệnh đội trưởng)"; end
    local b = Ui.WJXCheckBoss;
    if b and (b.job or b.patrol or b.gather) then return "CheckBOSS"; end
    if Ui.WJXMainQuest and Ui.WJXMainQuest.job then return "Auto Chính Tuyến"; end
    local t = Ui.WJXTongKim;
    if t and (t.job or t.patrol) then return "Tống Kim"; end
    if a and a.session and not own then return "Auto6 / Theo Sau"; end
    if me.nAutoFightState == 1 and not own then return "Tự Đánh"; end
    if Map and Map.tbAutoAim and Map.tbAutoAim.nFollowState == 1 then return "Hộ Tống / Theo Sau cũ"; end
end
