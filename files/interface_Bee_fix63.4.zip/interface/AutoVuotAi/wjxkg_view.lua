-- Auto Vượt Ải Gia Tộc — VIEW: 4 tab.
--   0 Phân Công: 6 hàng thành viên (hàng 1 = bản thân), đội trưởng chọn 1 trong 4 tuyến cho từng người → Gửi Phân Công;
--                PT Bật / Dừng Auto, PT Vào Ải, PT Tập Trung. Không có đội thì hàng 1 là lựa chọn của bản thân, có hiệu lực ngay.
--   1 Trong Ải: phòng đang đứng, kế hoạch, việc, phòng đã biết là mở.
--   2 Cài Đặt: Tự hái bí dược / Đánh Tâm Ma / Đổi tiền xu lấy rương (mặc định tắt), vào ải, chìa, cách đánh.
--   3 Hướng Dẫn: đường đi trong ải, chuỗi A / B, cách dùng.
--   4 Hậu Cần: chọn 1 trong 7 thành có Mã Xuyên Sơn; PT Mã Xuyên Sơn, PT Chuẩn Bị / Về Dược Phẩm (hậu cần CheckBOSS).
-- Đóng cửa sổ không dừng auto.
if not Ui.WJXVuotAi or not Ui.WJXVuotAi.loading then return; end
local M = Ui.WJXVuotAi;
local V = Ui:GetClass(M.CLASS);
local CHECKS = {ChkMiyao = "miyao", ChkHeart = "heart", ChkExchange = "exchange", ChkEnter = "enter", ChkKey = "key",
    ChkAutoAssign = "autoAssign",
    ChkCoin = "coinbox", ChkAuto6 = "auto6", ChkDismount = "dismount"};
local ROUTES = {"Chưa gán", "Trái · Phản Đòn (Thiên Địa Nhật Nguyệt)", "Giữa · Bí văn 1–4", "Giữa · Bí văn 5–8",
    "Phải · Choáng (Tứ Tượng)"};
local SIZE = 6;

local PAGES = {
    [0] = {"TxtAssignLabel", "ChkAutoAssign", "BtnAutoAssign", "BtnAssign", "BtnPTOn", "BtnPTOff", "BtnPTGo", "BtnPTGather", "BtnPTExit", "TxtTeamNote"},
    [1] = {"TxtRoom", "TxtPlan", "TxtWork", "TxtMine", "TxtOpenHead", "TxtOpened", "TxtChains", "TxtInNote"},
    [2] = {"TxtHeadOpt", "ChkMiyao", "ChkHeart", "ChkExchange", "TxtHeadIn", "ChkEnter", "ChkKey", "CmbKey", "TxtKeyUnit",
        "TxtHeadFight", "ChkAuto6", "ChkDismount", "ChkCoin", "TxtRangeLabel", "CmbRange", "TxtOptNote"},
    [3] = {"TxtGHead1", "TxtG1", "TxtGHead2", "TxtG2a", "TxtG2b", "TxtG2c", "TxtGHead3", "TxtG3", "TxtGHead4", "TxtG4"},
    [4] = {"TxtHcHead", "TxtHcCity", "CmbHcCity", "BtnHcEntry", "TxtHcHP", "CmbHcHP", "TxtHcHPCount", "EdtHcHPBg", "EdtHcHP",
        "TxtHcMP", "CmbHcMP", "TxtHcMPCount", "EdtHcMPBg", "EdtHcMP", "BtnHcPrepare", "BtnHcGo", "TxtHcNote"},
};
local CITY_ORDER = {23, 24, 25, 26, 27, 28, 29};

local function show(group, list, on) for _, n in ipairs(list) do (on and Wnd_Show or Wnd_Hide)(group, n); end end

local function short(s, n)
    s = tostring(s or "");
    if string.len(s) <= n then return s; end
    local cut = n;
    while cut > 0 and string.byte(s, cut + 1) and string.byte(s, cut + 1) >= 128 and string.byte(s, cut + 1) < 192 do cut = cut - 1; end
    return string.sub(s, 1, cut) .. "…";
end

local function fill(group, name, items, selected)
    ClearComboBoxItem(group, name);
    for i, text in ipairs(items) do ComboBoxAddItem(group, name, i, text); end
    ComboBoxSelectItem(group, name, math.max(0, (selected or 1) - 1));
end

-- ---------------------------------------------------------------- cài đặt
function V:ReadOptions()
    local d = self.draft or {};
    local o = {range = self.range, keyCount = self.keyCount, hcCity = d.hcCity, hpType = d.hpType, mpType = d.mpType,
        hpCount = d.hpCount, mpCount = d.mpCount};
    if self.editsReady then
        o.hpCount = tonumber(Edt_GetTxt(self.UIGROUP, "EdtHcHP")) or 0;
        o.mpCount = tonumber(Edt_GetTxt(self.UIGROUP, "EdtHcMP")) or 0;
    end
    for name, key in pairs(CHECKS) do o[key] = Btn_GetCheck(self.UIGROUP, name); end
    return M:Options(o);
end

-- Danh sách thuốc lấy từ Auto6 (giống CheckBOSS); thiếu Auto6 thì ghi Loại 1–5.
function V:FillSupport()
    local d = self.draft;
    local cities, ci = {}, 1;
    for i, id in ipairs(CITY_ORDER) do cities[i] = M.CITY[id].vn; if id == d.hcCity then ci = i; end end
    fill(self.UIGROUP, "CmbHcCity", cities, ci);
    local a = Ui.WJXAuto6;
    for name, rows in pairs({CmbHcHP = {"CmbHP", d.hpType}, CmbHcMP = {"CmbMP", d.mpType}}) do
        local list = a and (rows[1] == "CmbHP" and a.hpNames or a.mpNames);
        local labels = {};
        for i = 1, 5 do
            local row = type(list) == "table" and list[i];
            local label = "Loại " .. i;
            if row then
                local okLv, lv = pcall(a.SupplyLevel, a, rows[1], i);
                label = type(row) == "table" and tostring(row[2]) or (tostring(row) .. (okLv and lv and (" (Lv " .. lv .. ")") or ""));
            end
            labels[i] = label;
        end
        fill(self.UIGROUP, name, labels, rows[2]);
    end
    Edt_SetTxt(self.UIGROUP, "EdtHcHP", tostring(d.hpCount));
    Edt_SetTxt(self.UIGROUP, "EdtHcMP", tostring(d.mpCount));
    self.editsReady = true;
end

-- ---------------------------------------------------------------- tab
function V:Render()
    for t = 0, 4 do
        Btn_Check(self.UIGROUP, "Tab" .. t, t == self.tab and 1 or 0);
        show(self.UIGROUP, PAGES[t], t == self.tab);
    end
    self.rowKey = nil;
    self:RefreshTeam();
    self:RefreshStatus();
end

-- ---------------------------------------------------------------- Phân Công
-- Ai được sửa combobox: đội trưởng (mọi hàng) hoặc người đi một mình (hàng 1).
function V:CanEdit(i)
    local members = M:Team();
    if #members == 0 then return i == 1; end
    return M:IsLeader();
end

function V:Assignment(i, name)
    local members = M:Team();
    if i == 1 and (#members == 0 or not M:IsLeader()) then return M:Mine(); end
    return M:Plan4(name);
end

function V:RefreshTeam()
    local members, leader = M:Team();
    local names = {me.szName};
    for _, m in ipairs(members) do names[#names + 1] = m.szName; end
    self.names = names;
    local on = self.tab == 0;
    local lead = M:IsLeader();
    -- Đổi danh sách / đổi vai thì đổ lại combobox (không đổ mỗi giây để khỏi đóng danh sách đang mở)
    local key = table.concat(names, "|") .. (lead and "#L" or "#M") .. (on and "1" or "0");
    local refill = key ~= self.rowKey;
    self.rowKey = key;
    for i = 1, SIZE do
        local name = names[i];
        local row = {"TxtMem" .. i, "TxtMemState" .. i, "CmbRoute" .. i};
        show(self.UIGROUP, row, on and name ~= nil);
        if on and name then
            local r = i == 1 and M:SelfReport() or (M.reports and M.reports[name]);
            local roomName = r and r.room and r.room > 0 and M.ROOMS[r.room] and M.ROOMS[r.room].vn;
            Txt_SetTxt(self.UIGROUP, row[1], i .. ". " .. (i == 1 and "Bản thân" or short(name, 16)) .. (leader == name and " [ĐT]" or ""));
            local line;
            if not r then line = "Chưa có tin (cần cài Auto Vượt Ải).";
            else
                line = (M.STATES[r.state] or "?") .. (roomName and (" · " .. short(roomName, 18)) or "") .. " · HP " .. (r.hp or 0) .. "%";
                if i > 1 and r.route ~= (M:Plan4(name).route or 0) then line = line .. " · chưa nhận"; end
            end
            Txt_SetTxt(self.UIGROUP, row[2], short(line, 60));
            if refill then
                local a = self:Assignment(i, name);
                self.updating = true;
                fill(self.UIGROUP, row[3], ROUTES, (a.route or 0) + 1);
                self.updating = nil;
            end
            local edit = self:CanEdit(i) and 1 or 0;
            Wnd_SetEnable(self.UIGROUP, row[3], edit);
        end
    end
    Wnd_SetEnable(self.UIGROUP, "BtnAssign", (lead or #members == 0) and 1 or 0);
    Wnd_SetEnable(self.UIGROUP, "BtnAutoAssign", (lead or #members == 0) and 1 or 0);
    -- Trạng thái PT: bao nhiêu người đang bật Auto (theo báo cáo kênh Đội; bản thân đọc trực tiếp)
    local on, total, noRoute = 0, #names, 0;
    for i, name in ipairs(names) do
        local r = i == 1 and M:SelfReport() or (M.reports and M.reports[name]);
        if r and (r.state or 0) > 0 then on = on + 1; end
        if (self:Assignment(i, name).route or 0) == 0 then noRoute = noRoute + 1; end
    end
    local note = "PT Auto: " .. (on == 0 and "đang dừng" or (on .. "/" .. total .. " người đang bật"));
    if noRoute > 0 then note = note .. " · " .. noRoute .. " chưa gán tuyến"; end
    Txt_SetTxt(self.UIGROUP, "TxtTeamNote", note);
    Wnd_SetEnable(self.UIGROUP, "BtnPTOn", lead and 1 or 0);
    Wnd_SetEnable(self.UIGROUP, "BtnPTOff", lead and 1 or 0);
    Wnd_SetEnable(self.UIGROUP, "BtnPTGo", lead and 1 or 0);
    Wnd_SetEnable(self.UIGROUP, "BtnPTGather", lead and 1 or 0);
    Wnd_SetEnable(self.UIGROUP, "BtnPTExit", (lead or #members == 0) and 1 or 0);
end

-- ---------------------------------------------------------------- trạng thái
local function roomsText(list)
    local out = {};
    for _, r in ipairs(list or {}) do
        local room = M.ROOMS[r];
        if room and r <= 28 then out[#out + 1] = r .. " " .. room.vn; end
    end
    return #out > 0 and table.concat(out, ", ") or "—";
end

function V:RefreshStatus()
    if self.tab == 1 then
        local room, plan, opened = M:ViewState();
        local inGame = M:InGame();
        Txt_SetTxt(self.UIGROUP, "TxtRoom", "Phòng: " .. (room and (room .. " · " .. M.ROOMS[room].vn) or (inGame and "chưa nhận ra" or "chưa ở trong Thần Bí Bảo Khố")));
        Txt_SetTxt(self.UIGROUP, "TxtPlan", "Kế hoạch: " .. (M.job and (plan or "—") or "auto đang dừng"));
        Txt_SetTxt(self.UIGROUP, "TxtWork", "Việc: " .. (M.job and M:Plain(M.work or "—") or "—"));
        local mine = M:Mine();
        Txt_SetTxt(self.UIGROUP, "TxtMine", "Được gán: tuyến " .. (M.ROUTE_NAME[mine.route or 0] or "?"));
        Txt_SetTxt(self.UIGROUP, "TxtOpened", short(roomsText(opened), 420));
        local parts = {};
        if M.know and inGame then
            local k = M.know;
            for _, side in ipairs({{"Bí văn 1–4", {15, 16, 17, 18}}, {"Bí văn 5–8", {19, 20, 21, 22}}}) do
                local cur = "chưa mở";
                for _, r in ipairs(side[2]) do if k.open[r] then cur = M.ROOMS[r].vn; end end
                parts[#parts + 1] = side[1] .. ": " .. cur;
            end
        end
        Txt_SetTxt(self.UIGROUP, "TxtChains", table.concat(parts, "  ·  "));
    end
    if self.tab == 0 then self:RefreshTeam(); end
    local status = M.status or "Bấm Lưu và Bắt Đầu để bật Auto Vượt Ải.";
    if self.dirty then status = "Có cài đặt chưa lưu. " .. status; end
    Txt_SetTxt(self.UIGROUP, "TxtStatus", short((M.job and "Auto: đang chạy | " or "Auto: đang dừng | ") .. M:Plain(status), 200));
    Wnd_SetEnable(self.UIGROUP, "BtnStop", M.job and 1 or 0);
end

-- ---------------------------------------------------------------- sự kiện
function V:OnOpen()
    Txt_SetTxt(self.UIGROUP, "TxtTitle", "AUTO VƯỢT ẢI GIA TỘC — by HUKT — v" .. tostring(M.VERSION));
    if self.owner ~= me.szName or not self.draft then
        self.owner = me.szName;
        self.draft = M:LoadOptions();
        self.dirty = false;
        self.tab = self.tab or 0;
    end
    self.updating = true;
    for name, key in pairs(CHECKS) do Btn_Check(self.UIGROUP, name, self.draft[key]); end
    self.range, self.keyCount = self.draft.range, self.draft.keyCount;
    local ranges, index = {}, 1;
    for i, r in ipairs(M.RANGES) do ranges[i] = r .. " MPS"; if r == self.range then index = i; end end
    fill(self.UIGROUP, "CmbRange", ranges, index);
    local keys, kindex = {}, 1;
    for i, n in ipairs(M.KEY_COUNTS) do keys[i] = tostring(n); if n == self.keyCount then kindex = i; end end
    fill(self.UIGROUP, "CmbKey", keys, kindex);
    self.editsReady = nil;
    self:FillSupport();
    self.updating = nil;
    self:Render();
    if self.timer then Ui.tbLogic.tbTimer:Close(self.timer); end
    local window = self;
    self.timer = Ui.tbLogic.tbTimer:Register(Env.GAME_FPS, function()
        if UiManager:WindowVisible(M.GROUP) ~= 1 then window.timer = nil; return 0; end
        local ok, why = pcall(V.RefreshStatus, window);
        if not ok then window.timer = nil; M:Message("Lỗi đọc giao diện: " .. tostring(why)); return 0; end
        return Env.GAME_FPS;
    end);
end

function V:OnClose()
    if self.timer then Ui.tbLogic.tbTimer:Close(self.timer); self.timer = nil; end
end

function V:OnEscExclusiveWnd()
    UiManager:CloseWindow(self.UIGROUP);
end

local function slot(name, prefix)
    if string.sub(name, 1, string.len(prefix)) ~= prefix then return nil; end
    return tonumber(string.sub(name, string.len(prefix) + 1));
end

function V:OnComboBoxIndexChange(name, index)
    if self.updating then return; end
    local value = (tonumber(index) or 0) + 1;
    local ri = slot(name, "CmbRoute");
    if ri then
        local i = ri;
        local who = self.names and self.names[i];
        if not who or not self:CanEdit(i) then return; end
        local members = M:Team();
        local a = (#members == 0 and i == 1) and M:Mine() or M:Plan4(who);
        a.route = math.max(0, math.min(4, value - 1));
        if i == 1 then M:Mine().route = a.route; end
        self:RefreshStatus();
        return;
    end
    if name == "CmbRange" and M.RANGES[value] then
        self.range = M.RANGES[value];
    elseif name == "CmbKey" and M.KEY_COUNTS[value] then
        self.keyCount = M.KEY_COUNTS[value];
    elseif name == "CmbHcCity" and CITY_ORDER[value] then
        self.draft.hcCity = CITY_ORDER[value];
    elseif (name == "CmbHcHP" or name == "CmbHcMP") and value >= 1 and value <= 5 then
        self.draft[name == "CmbHcHP" and "hpType" or "mpType"] = value;
    else
        return;
    end
    self.draft = self:ReadOptions();
    self.dirty = true;
    self:RefreshStatus();
end

function V:OnButtonClick(name)
    local tab = string.sub(name, 1, 3) == "Tab" and tonumber(string.sub(name, 4)) or nil;
    if name == "BtnClose" or name == "BtnCloseX" then
        UiManager:CloseWindow(self.UIGROUP);
        return;
    elseif tab and PAGES[tab] then
        self.tab = tab;
        self:Render();
        return;
    elseif name == "BtnStop" then
        if M.job then M:Stop("Đã dừng Auto Vượt Ải."); end
    elseif name == "BtnSave" or name == "BtnStart" then
        local options = M:SaveOptions(self:ReadOptions());
        if not options then return; end
        self.dirty, self.draft = false, options;
        if name == "BtnStart" then M:Start(options);
        else M:Message("Đã lưu cài đặt." .. (M.job and " Phiên đang chạy vẫn dùng cài đặt lúc bắt đầu." or "")); end
    elseif name == "ChkAutoAssign" then
        -- ô của tab Phân Công: lưu ngay, không cần bấm Lưu
        local saved = M:LoadOptions();
        saved.autoAssign = Btn_GetCheck(self.UIGROUP, name) == 1 and 1 or 0;
        M:SaveOptions(saved);
        self.draft.autoAssign = saved.autoAssign;
        M:Message(saved.autoAssign == 1 and "Bật Tự Phân Công khi PT Bật Auto." or "Tắt Tự Phân Công.");
    elseif CHECKS[name] then
        self.dirty = true;
        self.draft = self:ReadOptions();
    elseif name == "BtnAutoAssign" then
        local members = M:Team();
        if #members > 0 and not M:IsLeader() then M:Message("Chỉ đội trưởng được phân công.");
        else
            local filled, total = M:AutoAssign(false);
            M:Message("Đã chia " .. filled .. "/" .. total .. " người vào 4 tuyến; xem lại rồi bấm Gửi Phân Công.");
        end
        self.rowKey = nil;
    elseif name == "BtnAssign" then
        M:SendAssign();
        self.rowKey = nil;
    elseif name == "BtnPTOn" or name == "BtnPTOff" then
        M:SendRun(name == "BtnPTOn");
    elseif name == "BtnPTGo" then
        M:SendGo();
    elseif name == "BtnPTExit" then
        M:SendExit();
    elseif name == "BtnPTGather" then
        M:SendGather();
    elseif name == "BtnHcEntry" or name == "BtnHcPrepare" or name == "BtnHcGo" then
        local o = self:ReadOptions();
        self.draft = o;
        if name == "BtnHcEntry" then M:SendEntry(o.hcCity);
        else
            if name == "BtnHcPrepare" and o.hpCount + o.mpCount == 0 then
                M:Message("Nhập số lượng HP hoặc MP cần có lớn hơn 0 trước khi PT Chuẩn Bị Dược Phẩm.");
            else M:SendSupply(o, name == "BtnHcPrepare"); end
        end
    else
        return;
    end
    self:RefreshStatus();
end
