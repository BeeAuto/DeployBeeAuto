-- Auto Vượt Ải Gia Tộc — ĐƯỜNG ĐI: 4 tuyến, toạ độ đi / chạy vòng đánh quái do người chơi khảo sát trong ải
-- (Research_Kin\Research_VuotAiGiaToc.txt). Tự tìm đường của client không biết trap cửa, nên auto đi theo
-- đồ thị phòng: tâm phòng → các điểm cửa → tâm phòng kế, chỉ qua phòng đã mở.
if not Ui.WJXVuotAi or not Ui.WJXVuotAi.loading then return; end
local M = Ui.WJXVuotAi;

-- ---------------------------------------------------------------- 4 tuyến
-- room = phòng tuyến (bia chọn tuyến của máy chủ: trái 4 / giữa 5 / phải 6; giữa chung 1 suất 1/3 số người)
-- rand = phòng ngẫu nhiên phe này đánh (bia Bí văn mở); mids = phòng Bí văn phe này bật bia; final = phòng cuối trước Phòng nghỉ
M.ROUTES = {
    [1] = {name = "Trái · Phản Đòn", room = 4, rand = {10, 9, 8, 7}, final = 23},
    [2] = {name = "Giữa · Bí văn 1–4", room = 5, mids = {15, 16, 17, 18}, final = 24},
    [3] = {name = "Giữa · Bí văn 5–8", room = 5, mids = {19, 20, 21, 22}, final = 24},
    [4] = {name = "Phải · Choáng", room = 6, rand = {14, 13, 12, 11}, final = 25},
};
M.ROUTE_NAME = {[0] = "Chưa gán"};
for i, r in ipairs(M.ROUTES) do M.ROUTE_NAME[i] = r.name; end
M.ROUTE_TRAP_ROOM = {[4] = true, [5] = true, [6] = true};

-- Điểm đứng / đích đi của mỗi phòng (31, 32 = 2 góc hái Bí dược trong Phòng bùa chú: trái / phải)
M.WALK = {
    [1] = {1625, 3204}, [2] = {1669, 3156}, [3] = {1703, 3121},
    [4] = {1647, 2982}, [5] = {1826, 2993}, [6] = {1837, 3183},
    [7] = {1799, 2743}, [8] = {1746, 2793}, [9] = {1696, 2845}, [10] = {1643, 2896},
    [11] = {2062, 3043}, [12] = {2014, 3091}, [13] = {1964, 3142}, [14] = {1915, 3190},
    [15] = {1789, 2942}, [16] = {1754, 2978}, [17] = {1766, 2904}, [18] = {1827, 2890},
    [19] = {1876, 3029}, [20] = {1947, 3008}, [21] = {1913, 3059}, [22] = {1842, 3071},
    [23] = {1876, 2742}, [24] = {1907, 2904}, [25] = {2073, 2948},
    [26] = {1967, 2842}, [27] = {2027, 2775}, [28] = {2125, 2664},
    [31] = {1964, 2702}, [32] = {2088, 2841},
};
M.EXIT_POS = {2152, 2633};       -- trap ra (cạnh Điểm Rời Bản Đồ, NPC 2525 ở 2149,2637)
M.EXIT_NPC = {2149, 2637};

-- Cạnh: {a, b, các điểm đi từ a sang b (không gồm tâm), need = phòng phải mở, oneway = chỉ đi a → b}
M.EDGES = {
    -- Lối vào → Phòng Thủ Vệ (Khu quái nhỏ) → cửa Phòng tuyển chọn
    {1, 2, {{1622, 3209}, {1633, 3202}, {1642, 3191}}}, {2, 3, {{1684, 3146}}},
    -- trap chọn tuyến: bước vào là được đưa vào tuyến; quay ra phải trả 5 tiền → không đi ngược
    {3, 4, {{1697, 3084}, {1692, 3076}, {1688, 3069}}, oneway = true},
    {3, 5, {{1736, 3090}, {1740, 3085}, {1743, 3079}}, oneway = true},
    {3, 6, {{1741, 3129}, {1744, 3139}, {1749, 3142}}, oneway = true},
    -- trái: Phản Đòn → Nguyệt / Nhật / Địa / Thiên Tự, Vực thẳm → Phòng nghỉ
    {4, 10, {{1682, 2940}}}, {4, 9, {{1733, 2889}}}, {4, 8, {{1785, 2839}}}, {4, 7, {{1836, 2786}}},
    {4, 23, {{1853, 2771}}}, {23, 26, {{1894, 2765}}},
    -- phải: Choáng → Huyền Vũ / Chu Tước / Bạch Hổ / Thanh Long, Siêu Tốc → Phòng nghỉ
    {6, 14, {{1879, 3150}}}, {6, 13, {{1929, 3100}}}, {6, 12, {{1979, 3051}}}, {6, 11, {{2028, 3001}}},
    {6, 25, {{2037, 2988}}}, {25, 26, {{2054, 2932}}},
    -- giữa: Cơ Quan → Bí văn 1 → 2 → 3 → 4 → (ra) Bí văn 1; Bí văn 5 → 6 → 7 → 8 → (ra) Bí văn 5; Phục chế → Phòng nghỉ
    {5, 15, {}}, {15, 16, {}}, {16, 17, {}}, {17, 18, {}}, {18, 15, {}, need = 29},
    {5, 19, {}}, {19, 20, {}}, {20, 21, {}}, {21, 22, {}}, {22, 19, {}, need = 30},
    {5, 24, {{1855, 2965}}}, {24, 26, {{1925, 2887}}},
    -- Phòng nghỉ → Phòng bùa chú (boss) → 2 góc Bí dược / Phòng bảo rương
    {26, 27, {{1982, 2824}}}, {27, 31, {{2004, 2749}}}, {27, 32, {{2052, 2802}}}, {27, 28, {{2050, 2751}}},
};

-- Chạy vòng quanh các điểm này để kéo / tìm quái thay vì đứng 1 chỗ
M.PATROL = {
    [2] = {{1666, 3141}, {1684, 3165}, {1672, 3177}, {1652, 3154}},
    [5] = {{1760, 3065}, {1785, 3037}, {1810, 3012}, {1826, 2993}},
    [4] = {{1648, 2964}, {1663, 2982}, {1644, 2999}, {1629, 2982}},
    [10] = {{1646, 2881}, {1656, 2890}, {1642, 2904}, {1631, 2894}},
    [9] = {{1697, 2831}, {1709, 2842}, {1694, 2854}, {1682, 2843}},
    [8] = {{1747, 2779}, {1759, 2789}, {1745, 2803}, {1733, 2793}},
    [7] = {{1799, 2727}, {1811, 2739}, {1796, 2752}, {1784, 2742}},
    [23] = {{1875, 2726}, {1894, 2743}, {1877, 2754}, {1859, 2737}},
    [6] = {{1838, 3164}, {1853, 3182}, {1835, 3200}, {1819, 3185}},
    [14] = {{1919, 3179}, {1929, 3188}, {1915, 3201}, {1904, 3193}},
    [13] = {{1967, 3130}, {1978, 3140}, {1965, 3152}, {1952, 3142}},
    [12] = {{2018, 3078}, {2029, 3089}, {2013, 3106}, {2000, 3094}},
    [11] = {{2066, 3028}, {2076, 3040}, {2062, 3054}, {2051, 3045}},
    [25] = {{2070, 2927}, {2090, 2948}, {2073, 2963}, {2053, 2944}},
    [24] = {{1922, 2904}, {1908, 2917}, {1891, 2899}, {1906, 2888}},
};

-- 4 Đồ Đằng Trụ ở Phòng tuyển chọn (phải tới gần mới thấy để bấm); bật đủ 4 thì 3 tuyến mở
M.PILLARS = {{1712, 3074}, {1691, 3099}, {1744, 3107}, {1725, 3133}};

function M:PillarIndex(x, y)
    local best, bd;
    for i, p in ipairs(self.PILLARS) do
        local d = (p[1] - x) ^ 2 + (p[2] - y) ^ 2;
        if not bd or d < bd then best, bd = i, d; end
    end
    if bd and bd <= 64 then return best; end
end

-- Điểm Auto6 Luyện Công của phòng: các điểm chạy vòng, không có thì tâm phòng
function M:TrainPoints(r)
    local list = self.PATROL[r] or (self.WALK[r] and {self.WALK[r]});
    if not list then return nil; end
    local map = me.GetWorldPos();
    local out = {};
    for i, p in ipairs(list) do
        if i > 12 then break; end
        out[i] = {map = map, x = p[1], y = p[2], ax = p[1] * 32 + 16, ay = p[2] * 32 + 16};
    end
    return out;
end

function M:Adjacency()
    if self.adj then return self.adj; end
    local adj = {};
    local function add(a, b, pts, need)
        adj[a] = adj[a] or {};
        adj[a][#adj[a] + 1] = {to = b, pts = pts, need = need};
    end
    for _, e in ipairs(self.EDGES) do
        add(e[1], e[2], e[3], e.need);
        if not e.oneway then
            local back = {};
            for i = #e[3], 1, -1 do back[#back + 1] = e[3][i]; end
            add(e[2], e[1], back, e.need);
        end
    end
    self.adj = adj;
    return adj;
end

-- Phòng đi qua được: đã mở (2 góc Bí dược đi được khi phòng bùa chú đã mở).
function M:Passable(r)
    local k = self:Know();
    if r == 31 or r == 32 then return k.open[27] == true; end
    return k.open[r] == true;
end

-- Các điểm cần đi từ phòng a tới tâm phòng b (BFS ít cửa nhất, chỉ qua phòng đã mở; b được phép chưa mở = dò cửa).
function M:Path(a, b)
    if not a or not b then return nil, "Không rõ đang ở phòng nào."; end
    if a == b then local w = self.WALK[b]; return w and {{w[1], w[2]}} or {}; end
    local k, adj = self:Know(), self:Adjacency();
    local R = self.ROUTES[(self:Mine()).route or 0];
    local prev, queue, head = {[a] = false}, {a}, 1;
    while queue[head] do
        local x = queue[head];
        head = head + 1;
        if x == b then break; end
        for _, e in ipairs(adj[x] or {}) do
            local y = e.to;
            -- bia chọn tuyến: chỉ vào tuyến của mình (tuyến khác: đầy suất / quay ra mất 5 tiền); Phòng nghỉ mở thì đi tự do
            local gate = x == 3 and self.ROUTE_TRAP_ROOM[y] and not k.open[26] and not (R and R.room == y);
            if prev[y] == nil and not gate and (y == b or self:Passable(y)) and (not e.need or k.open[e.need]) then
                prev[y] = {x, e};
                queue[#queue + 1] = y;
            end
        end
    end
    if not prev[b] then
        local room = self.ROOMS[b];
        if self.ROUTE_TRAP_ROOM[a] or (self.ROUTES[(self:Mine()).route or 0] and a ~= 1 and a ~= 2 and a ~= 3) then
            return nil, "Không có đường đã mở tới " .. (room and room.vn or ("phòng " .. b)) .. " (khác tuyến: quay ra qua bia tuyến mất 5 tiền)."; end
        return nil, "Chưa có đường đã mở tới " .. (room and room.vn or ("phòng " .. b)) .. ".";
    end
    local steps, n = {}, b;
    while n ~= a do table.insert(steps, 1, {prev[n][2], n}); n = prev[n][1]; end
    local pts = {};
    for _, s in ipairs(steps) do
        for _, p in ipairs(s[1].pts) do pts[#pts + 1] = {p[1], p[2]}; end
        local w = self.WALK[s[2]];
        pts[#pts + 1] = {w[1], w[2]};
    end
    return pts;
end

-- Phòng gần toạ độ nhất (khung phòng trước, rồi điểm đứng gần nhất) — khi đứng ở hành lang.
function M:NearestRoom(x, y)
    local r = self:RoomAt(x, y);
    if r then return r; end
    local best, bd;
    for id, w in pairs(self.WALK) do
        if id <= 28 then
            local d = (w[1] - x) ^ 2 + (w[2] - y) ^ 2;
            if not bd or d < bd then best, bd = id, d; end
        end
    end
    return best;
end

-- Phòng thuộc phe của tuyến (đứng trong đó coi như đã vào tuyến, không phải qua bia chọn tuyến nữa).
function M:RouteRooms(route)
    local R = self.ROUTES[route or 0];
    if not R then return {}; end
    local set = {[R.room] = true, [R.final] = true};
    for _, r in ipairs(R.rand or {}) do set[r] = true; end
    for _, r in ipairs(R.mids or {}) do set[r] = true; end
    if R.mids then for r = 15, 22 do set[r] = true; end end
    return set;
end
