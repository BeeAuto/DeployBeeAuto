-- Auto Vượt Ải Gia Tộc (by HUKT) — file vào. Chỉ file này tự chạy khi client nạp plugin; các file wjxkg_*.lua
-- có lính gác "loading" và chỉ được nạp qua M:EnsureModules() khi mở cửa sổ / bấm menu / nhận lệnh đội lần đầu.
-- Mở từ nút "Vượt Ải" ở khung Hoạt Động (interface\HoatDong). Điều phối qua kênh Đội: đội trưởng gán tay tuyến
-- (4 tuyến: Trái · Phản Đòn / Giữa · Bí văn 1–4 / Giữa · Bí văn 5–8 / Phải · Choáng) cho từng thành viên, gọi PT Vào Ải / Bật / Dừng Auto / Tập Trung.
-- Khi một auto khác đang điều khiển nhân vật thì chỉ quan sát.
Ui.WJXVuotAi = Ui.WJXVuotAi or {};
local M = Ui.WJXVuotAi;
M.GROUP = "UI_WJXVUOTAI";
M.CLASS = "wjxkg_main";
M.INI = "wjxkg_main.ini";
M.DIR = "\\interface\\AutoVuotAi\\";
M.VERSION = "0.5.0";
M.MODULES = {"wjxkg_data.lua", "wjxkg_model.lua", "wjxkg_path.lua", "wjxkg_controller.lua", "wjxkg_team.lua", "wjxkg_view.lua"};
M.PREFIX = "[WJXKG:";

function M:Message(text)
    self.status = tostring(text);
    if me and me.Msg then me.Msg("[Vượt Ải] " .. self.status); end
end

function M:EnsureModules()
    if self.ready then return; end
    local ok, why = pcall(function()
        self.loading = true;
        for _, name in ipairs(self.MODULES) do
            local path = self.DIR .. name;
            local source = assert(KFile.ReadTxtFile(path), "Không đọc được " .. path);
            assert(loadstring(string.gsub(source, "^\239\187\191", ""), "@" .. path))();
        end
    end);
    self.loading = nil;
    if not ok then error(why); end
    self.ready = true;
end

function M:RegisterWindow()
    self:EnsureModules();
    local native = LoadUiGroup;
    -- Game.exe chép cố định 256 byte từ con trỏ tên INI: đệm NUL như các plugin khác.
    local buffer = self.INI .. string.rep("\0", 256 - string.len(self.INI));
    LoadUiGroup = function(group, name, a, b)
        if group == M.GROUP then name = buffer; end
        return native(group, name, a, b);
    end;
    local ok, why = pcall(Ui.RegisterNewUiWindow, Ui, self.GROUP, self.CLASS,
        {"a", 140, 70}, {"b", 252, 154}, {"c", 380, 220});
    LoadUiGroup = native;
    if not ok then error(why); end
    local w, h = Wnd_GetSize(self.GROUP, "Main");
    assert(w and w > 0 and h and h > 0, "Chưa nạp " .. self.INI .. "; hãy thoát hẳn game rồi vào lại.");
    local v = Ui.tbWnd[self.GROUP];
    assert(v and v.OnOpen and v.OnButtonClick and v.OnComboBoxIndexChange, "Đăng ký cửa sổ Vượt Ải chưa đầy đủ.");
    if GetUiMode() == "d" then
        Ui:AddExWndConfig(self.GROUP, {"d", 700, 356});
        Ui:LoadExWndConfig(self.GROUP);
    end
    self.windowReady = true;
end

function M:Open()
    local ok, why = pcall(function()
        if not self.windowReady then self:RegisterWindow(); end
        self:Install();
        if UiManager:WindowVisible(self.GROUP) == 1 then Wnd_BringTop(self.GROUP, "Main");
        else UiManager:OpenWindow(self.GROUP); end
    end);
    if not ok then self:Message("Không mở được giao diện: " .. tostring(why)); end
end

-- ---------------------------------------------------------------- menu nút Vượt Ải (khung Hoạt Động)
M.MENU = {
    {"Mở Giao Diện", "open"}, {"Bật Auto (bản thân)", "start"}, {"Dừng Auto (bản thân)", "stop"},
    {"PT Gửi Phân Công", "assign"}, {"PT Vào Ải", "ptgo"}, {"PT Bật Auto", "pton"}, {"PT Dừng Auto", "ptoff"},
    {"PT Tập Trung", "ptgather"}, {"PT Rời VAGT", "ptexit"},
};

function M:ShowMenu(group, button)
    self.menuContext = {owner = me.szName, time = GetTime(), group = group, button = button};
    local args = {};
    for i, row in ipairs(self.MENU) do args[#args + 1] = row[1]; args[#args + 1] = i; end
    DisplayPopupMenu(group, button, #self.MENU, 0, unpack(args));
end

function M:SelectMenu(group, button, id)
    local m = self.menuContext;
    self.menuContext = nil;
    if not m or m.group ~= group or m.button ~= button or m.owner ~= me.szName or GetTime() - m.time > 60 then return false; end
    local row = self.MENU[id];
    if not row then return false; end
    local ok, why = pcall(function()
        local act = row[2];
        if act == "open" then return self:Open(); end
        self:EnsureModules();
        self:Install();
        if act == "start" then return self:Start(self:LoadOptions()); end
        if act == "stop" then if self.job then self:Stop("Đã dừng Auto Vượt Ải."); end return; end
        if act == "assign" then return self:SendAssign(); end
        if act == "pton" then return self:SendRun(true); end
        if act == "ptoff" then return self:SendRun(false); end
        if act == "ptgo" then return self:SendGo(); end
        if act == "ptgather" then return self:SendGather(); end
        if act == "ptexit" then return self:SendExit(); end
    end);
    if not ok then self:Message(tostring(why)); end
end

-- ---------------------------------------------------------------- nhận lệnh đội [WJXKG:...] (kênh Đội)
-- Bọc Ui(UI_MSGPAD).OnSendMsgToChannel đúng 1 lớp: hàm cũ luôn chạy trước; tin của mình xử lý ở nhịp hẹn giờ kế tiếp.
local C = Ui.WJXVuotAiChat or {};
Ui.WJXVuotAiChat = C;
function C:Install()
    if not Ui.UI_MSGPAD then return false; end
    local okPad, pad = pcall(Ui, Ui.UI_MSGPAD);
    if not okPad or type(pad) ~= "table" or type(pad.OnSendMsgToChannel) ~= "function" then return false; end
    if pad == self.pad then return true; end
    local old = pad.OnSendMsgToChannel;
    pad.OnSendMsgToChannel = function(w, channel, sender, msg, gateway)
        local result = old(w, channel, sender, msg, gateway);
        if channel == "Team" and type(msg) == "string" and string.sub(msg, 1, string.len(M.PREFIX)) == M.PREFIX then
            Ui.tbLogic.tbTimer:Register(1, function()
                local ok, err = pcall(function()
                    M:EnsureModules();
                    M:Install();
                    M:Receive(sender, msg);
                end);
                if not ok then M:Message("Lỗi nhận lệnh đội (" .. string.len(msg) .. " byte): " .. tostring(err)); end
                return 0;
            end);
        end
        return result;
    end;
    self.pad = pad;
    return true;
end
if not C.watch and Ui.tbLogic and Ui.tbLogic.tbTimer then
    C.watch = Ui.tbLogic.tbTimer:Register(Env.GAME_FPS * 5, function()
        pcall(C.Install, C);
        return Env.GAME_FPS * 5;
    end);
end
pcall(C.Install, C);
