-- Auto Vượt Ải Gia Tộc — CONTROLLER: mỗi nhịp (~0,5 giây) cập nhật "phòng nào đã mở", rồi chọn 1 việc theo ưu tiên:
--   bảng hội thoại do mình mở → thanh tiến trình → phòng Tâm Ma → đánh quái quanh mình / trong phòng →
--   cơ quan của phòng (trụ, bia, rương tiền, bí dược, Mã Xuyên Sơn) → đi tới phòng theo kế hoạch (tuyến / chuỗi được gán).
-- Nguyên tắc: auto khác đang điều khiển (Tiêu Dao, Điều Phối, CheckBOSS, Auto6 của người khác...) thì CHỈ QUAN SÁT.
if not Ui.WJXVuotAi or not Ui.WJXVuotAi.loading then return; end
local M = Ui.WJXVuotAi;

M.TICK = 9;                 -- ~0,5 giây
M.FIGHT_NEAR = 16;          -- quái trong bán kính này (ô) quanh mình luôn đánh trước
M.CLICK_GUARD = 12;         -- dọn quái quanh cơ quan trước khi bấm (bị đánh là đứt thanh tiến trình)
M.CLICK_TRIES = 3;
M.DOOR_SEE = 12;            -- đứng cách cửa ngần này ô mới tin vào việc có / không thấy bia chặn
M.DOOR_TRUST = 2;           -- giây đứng gần cửa không thấy bia chặn thì coi phòng đã mở
M.CLOSED_WAIT = 15;         -- vừa thấy phòng đóng / bị trap đẩy lùi: không đi lại cửa đó trong ngần này giây
M.DONE_QUIET = 25;          -- phòng song song: đã bật bia và yên quái ngần này giây thì coi là xong
M.GATHER_TIME = 180;        -- giây: lệnh PT Tập Trung hết hạn
M.GATHER_NEAR = 5;          -- ô: tới gần chỗ đội trưởng ngần này là xong

local function visible(group) return group and UiManager:WindowVisible(group) == 1; end
local function now() return GetTime(); end

-- ---------------------------------------------------------------- móc client (1 lần): bảng hội thoại + chữ giữa màn hình
function M:Install()
    if self.installed then return; end
    self.installed = true;
    local say = Ui(Ui.UI_SAYPANEL);
    local onSay = say.OnOpen;
    say.OnOpen = function(window, param, a, b)
        local result = onSay(window, param, a, b);     -- luôn để chuỗi hook cũ chạy trước
        local j = M.job;
        if j and ((j.sayUntil and now() <= j.sayUntil) or M:CoinGate(param)) then j.say = param; end
        return result;
    end;
    -- Dialog:SendBlackBoardMsg của máy chủ = Ui:ServerCall("UI_TASKTIPS", "Begin", chữ)
    local ok, tips = pcall(Ui, Ui.UI_TASKTIPS or "UI_TASKTIPS");
    if ok and type(tips) == "table" and type(tips.Begin) == "function" then
        local begin = tips.Begin;
        tips.Begin = function(window, text, t)
            local result = begin(window, text, t);
            if M.job then
                M.tips = M.tips or {};
                if #M.tips < 20 then M.tips[#M.tips + 1] = tostring(text or ""); end
            end
            return result;
        end;
    end
end

-- ---------------------------------------------------------------- mượn Auto6 (như Auto Tiêu Dao / CheckBOSS)
function M:OwnsAuto6(job)
    local j, a = job or self.job, Ui.WJXAuto6;
    return j and j.auto6 and a and a.session and a.active == j.auto6 and true or false;
end

function M:Auto6Config(options, points)
    local a = Ui.WJXAuto6;
    if not a or type(a.Normalize) ~= "function" or type(a.Copy) ~= "function" or not AutoAi.UpdateCfg then return nil, "chưa nạp Auto6"; end
    local ok, c = pcall(function()
        local c = a:Normalize(a:Copy(Ui(Ui.UI_AUTOFIGHT):Load("AutoFight") or {}));
        c.nAutoFight, c.nCombatEnabled, c.nPvpMode = 1, 1, 0;
        c.nFollow, c.nFollowLeader, c.nTrain, c.nAssistLeader = 0, 0, 0, 0;
        c.nSupply, c.nRevive, c.nDead, c.nCreateTeam, c.nJoin = 0, 0, 0, 0, 0;
        c.nLockTarget, c.nSkipNormal = 0, 0;
        c.nScanRange = options.range or M.RANGE_DEFAULT;
        c.nDismount = options.dismount == 0 and 0 or 1;
        c.nTrain, c.tbTrainPoints = 0, {};
        if points then
            -- Luyện Công trong phòng: Auto6 tự đi vòng các điểm của phòng và đánh, không neo ở cửa
            c.nTrain, c.nTrainCircle, c.nTrainSkipFew, c.nTrainMin = 1, 0, 0, 0;
            c.nTrainRadius = math.max(300, math.min(1200, options.range or M.RANGE_DEFAULT));
            c.tbTrainPoints = points;
        end
        return c;
    end);
    if not ok or type(c) ~= "table" then return nil, "không đọc được cài đặt Auto6"; end
    if type(a.SkillPreflight) == "function" then
        local okPre, valid, why = pcall(a.SkillPreflight, a, c, true);
        if not okPre or not valid then return nil, tostring(why or "Auto6 báo chưa có kỹ năng hợp lệ"); end
    end
    return c;
end

function M:UseAuto6(j, foe)
    if j.options.auto6 ~= 1 then return false; end
    local a = Ui.WJXAuto6;
    if j.auto6 and not self:OwnsAuto6(j) then j.auto6, j.auto6Off = nil, now(); end
    if not j.auto6 then
        if j.auto6Off and now() - j.auto6Off < 60 then return false; end
        if me.nFightState ~= 1 or (a and a.session) or me.nAutoFightState == 1 then return false; end
        local config, why = self:Auto6Config(j.options);
        if not config then
            if not j.auto6Said then j.auto6Said = true; self:Message("Không bật được Auto6 (" .. tostring(why) .. "); tự đánh bằng kỹ năng tay trái."); end
            j.auto6Off = now();
            return false;
        end
        self:StopAttack(j);
        local ok = pcall(AutoAi.UpdateCfg, AutoAi, config);
        if not ok or not a.session then j.auto6Off = now(); return false; end
        j.auto6 = a.active;
    end
    local id = self.Field(foe, "dwId");
    if id and a.targetId ~= id and not a.targetId then a.targetId = id; end
    return true;
end

-- Bật Auto6 Luyện Công với các điểm của phòng r (đứng trong phòng). Trả true nếu Auto6 đang lo phòng này.
function M:TrainRoom(j, r)
    if j.options.auto6 ~= 1 then return false; end
    local a = Ui.WJXAuto6;
    if j.auto6 and self:OwnsAuto6(j) and j.auto6Room == r then return true; end
    if j.auto6 then self:ReleaseAuto6(j); end
    if j.trainOff and now() - j.trainOff < 8 then return false; end
    if me.nFightState ~= 1 or (a and a.session) or me.nAutoFightState == 1 then return false; end
    local points = self:TrainPoints(r);
    if not points then return false; end
    local config, why = self:Auto6Config(j.options, points);
    if not config then
        if not j.auto6Said then j.auto6Said = true; self:Message("Không bật được Auto6 (" .. tostring(why) .. "); tự chạy vòng và đánh."); end
        j.trainOff = now();
        return false;
    end
    self:StopAttack(j);
    local ok = pcall(AutoAi.UpdateCfg, AutoAi, config);
    if not ok or not a.session then j.trainOff = now(); return false; end
    j.auto6, j.auto6Room = a.active, r;
    return true;
end

function M:ReleaseAuto6(j)
    local a = Ui.WJXAuto6;
    local mine = self:OwnsAuto6(j);
    j.auto6, j.auto6Room = nil, nil;
    if mine then pcall(a.Stop, a, "WJXKG_RELEASE"); end
end

-- ---------------------------------------------------------------- di chuyển / đánh
function M:Step(x, y)
    local j = self.job;
    if j.stepAt and now() - j.stepAt < 1 and j.stepX == x and j.stepY == y then return; end
    j.stepAt, j.stepX, j.stepY, j.goal = now(), x, y, {x, y};
    pcall(me.StartAutoPath, math.floor(x), math.floor(y));
end

-- Đi tới phòng target theo đúng cửa (xem M:Waypoints), cuối cùng tới (fx, fy) nếu có.
-- Trả false, lý do nếu không có đường an toàn.
M.WAY_NEAR = 3;             -- tới gần điểm ngần này ô thì sang điểm kế
M.WAY_STUCK = 15;           -- giây kẹt ở 1 điểm thì bỏ qua điểm đó
function M:Go(j, target, fx, fy)
    local _, x, y = me.GetWorldPos();
    local here = j.room or j.lastRoom or self:NearestRoom(x, y);
    local key = tostring(here) .. ">" .. tostring(target) .. ">" .. tostring(fx) .. "," .. tostring(fy);
    local w = j.way;
    if not w or w.key ~= key then
        local pts, why = self:Path(here, target);
        if not pts then return false, why; end
        if fx then pts[#pts + 1] = {fx, fy}; end
        w = {key = key, pts = pts, i = 1, at = now()};
        -- điểm đầu có thể đã đi qua: bắt đầu từ điểm gần mình nhất trong 3 điểm đầu
        local best, bd = 1, nil;
        for n = 1, math.min(3, #pts) do
            local d = self:DistXY(pts[n][1], pts[n][2]);
            if not bd or d < bd then best, bd = n, d; end
        end
        w.i = best;
        j.way = w;
    end
    while w.pts[w.i] and (self:DistXY(w.pts[w.i][1], w.pts[w.i][2]) <= self.WAY_NEAR or now() - w.at > self.WAY_STUCK) do
        w.i, w.at = w.i + 1, now();
    end
    local p = w.pts[w.i];
    if p then self:Step(p[1], p[2]); return true, #w.pts - w.i + 1; end
    return true, 0;
end

-- Đã tới điểm đứng của phòng target chưa (đi hết các điểm).
function M:Arrived(j, target)
    local w = self.WALK[target];
    return w and self:DistXY(w[1], w[2]) <= 6;
end

local function riding()
    local ok, v = pcall(function() return me.GetNpc().nIsRideHorse; end);
    return ok and tonumber(v) == 1;
end

function M:Attack(npc)
    local j = self.job;
    local idx = npc.nIndex;
    if j.attackIdx ~= idx or not j.attackAt or now() - j.attackAt >= 2 then
        j.attackIdx, j.attackAt, j.attacking = idx, now(), true;
        if j.options.dismount == 1 and riding() and type(Switch) == "function" and
            (not j.dismountAt or now() - j.dismountAt >= 2) then
            j.dismountAt = now(); pcall(Switch, "horse");
        end
        local skill = tonumber(me.nLeftSkill) or 0;
        if skill > 0 and AutoAi.SetActiveSkill and me.CanCastSkill and me.CanCastSkill(skill) == 1 then
            pcall(AutoAi.SetActiveSkill, skill, 600);
        end
        AutoAi.SetTargetIndex(idx);
    end
end

function M:StopAttack(j)
    if j.attacking then j.attacking, j.attackIdx = nil, nil; pcall(AutoAi.SetTargetIndex, 0); end
end

function M:Calm(j)
    if j.auto6 then self:ReleaseAuto6(j); end
    self:StopAttack(j);
end

function M:Fight(j, foe)
    j.fought = now();
    local name = tostring(self.Field(foe, "szName") or "quái");
    if self:Dist(foe) * 32 > (j.options.range or self.RANGE_DEFAULT) then
        self:Calm(j);
        local x, y = self:Pos(foe);
        self:Step(x, y);
        self.work = "Tới gần " .. name .. ".";
        return;
    end
    if self:UseAuto6(j, foe) then self.work = "Auto6 đánh " .. name .. "."; return; end
    self:Attack(foe);
    self.work = "Đánh " .. name .. ".";
end

-- ---------------------------------------------------------------- nhận quyền điều khiển (lệnh đội trưởng)
-- Lệnh PT của đội trưởng (Vào Ải / Mã Xuyên Sơn / Tập Trung / Rời / Bật Auto) thay được Theo Sau của Điều Phối
-- Tổ Đội và phiên Auto6 đang theo sau (như CheckBOSS), nhưng KHÔNG tắt hoạt động khác (Tiêu Dao, CheckBOSS, Tống Kim…).
-- Trả lý do nếu không nhận được.
function M:TakeOver()
    local party = Ui.WJXParty;
    local dispatch = party and party.dispatch;
    if dispatch and dispatch.job and type(dispatch.StopJob) == "function" then pcall(dispatch.StopJob, dispatch, "WJXKG_TAKEOVER"); end
    local a = Ui.WJXAuto6;
    local busy = self:OtherOwner();
    if a and a.session and not self:OwnsAuto6() and (busy == "Auto6 / Theo Sau" or busy == "Điều Phối Tổ Đội") then
        pcall(a.Stop, a, "WJXKG_TAKEOVER");
    end
    if me.nAutoFightState == 1 and not self:OwnsAuto6() and Ui.tbLogic and Ui.tbLogic.tbAutoFightData then
        pcall(function()
            local d = Ui.tbLogic.tbAutoFightData;
            d:Load();
            d.LoadData.nAutoFight = 0;
            AutoAi:UpdateCfg(d.LoadData);
        end);
    end
    return self:OtherOwner();
end

-- Bắt đầu theo lệnh đội trưởng: nhận quyền điều khiển trước, báo rõ nếu bị hoạt động khác giữ.
function M:StartCommand(extra)
    local why = self:TakeOver();
    local ok = self:Start(self:LoadOptions(), extra);
    if ok and why then self:Message("Đang bị " .. why .. " giữ nhân vật: tắt " .. why .. " để làm theo lệnh đội trưởng."); end
    return ok;
end

-- ---------------------------------------------------------------- bắt đầu / dừng
function M:Start(raw, extra)
    local options = self:Options(raw);
    if me.IsDead and me.IsDead() == 1 then self:Message("Nhân vật đang bị hạ gục."); return false; end
    self:Stop();
    self:Install();
    self.job = {options = options, owner = me.szName, started = now(), clicked = {}, blocked = {}, doorSeen = {}};
    for key, v in pairs(extra or {}) do self.job[key] = v; end
    if self.job.enterOnly or self.job.goCity then options.enter = 1; end
    self.tips = {};
    self.status, self.work = "Đang chạy.", "—";
    self.timer = Ui.tbLogic.tbTimer:Register(self.TICK, function()
        local ok, result = pcall(M.Tick, M);
        if not ok then M:Stop("Lỗi: " .. tostring(result)); return 0; end
        if M.job and M.Report then pcall(M.Report, M); end
        return result;
    end);
    local owner = self:OtherOwner();
    local what = self.job.gatherOnly and "Tập trung về chỗ đội trưởng" or (self.job.toEntry and "Tới Mã Xuyên Sơn")
        or (self.job.enterOnly and "Vào ải" or "Auto Vượt Ải");
    self:Message(owner and ("Đã bật " .. what .. "; " .. owner .. " đang điều khiển nên tạm chỉ quan sát.") or ("Đã bật " .. what .. "."));
    return true;
end

function M:Stop(reason)
    local j = self.job;
    self.job = nil;
    if self.timer then Ui.tbLogic.tbTimer:Close(self.timer); self.timer = nil; end
    if j then
        self:Calm(j);
        if j.travelAt then pcall(self.StopTravel, self); end
        if self.Report then pcall(M.Report, M, 0, true); end
    end
    self.work = "—";
    if reason then self:Message(reason); end
end

-- Thành viên được gán tuyến / chuỗi (đội trưởng gửi hoặc tự chọn khi đi một mình).
function M:Mine() self.mine = self.mine or {route = 0}; return self.mine; end

-- Phòng vừa được biết là mở (do mình thấy): báo cả đội để người khác khỏi phải dò.
function M:OnRoomOpened(r, from)
    if self.receiving or not self.job then return; end
    self.openQueue = self.openQueue or {};
    self.openQueue[#self.openQueue + 1] = {r, from or 0};
end

-- ---------------------------------------------------------------- đọc chữ máy chủ
-- Chữ giữa màn hình (UI_TASKTIPS) và bảng hội thoại đều là chuỗi trong script máy chủ (tiếng Trung, có thể đã dịch):
-- so cả 2 thứ tiếng.
function M:ReadTips(j)
    local list = self.tips or {};
    self.tips = {};
    local k = self:Know();
    for _, text in ipairs(list) do
        local room = self:RoomInText(text);
        local last = j.lastClick;
        local from = last and last.room;
        if self:Has(text, "开启了", "đã mở", "mở ra") and room then
            self:MarkOpen(room, from);
        elseif self:Has(text, "被人按下", "被人开动过", "đã có người", "đã bị người") then
            if last then k.used[last.id] = true; if last.room then k.pressed = k.pressed or {}; k.pressed[last.room] = true; end end
            if room then self:MarkOpen(room, from);
            elseif from and from >= 7 and from <= 14 and last.role == "switch" then
                -- bia phòng ngẫu nhiên cuối chuỗi đã có người bấm: chuỗi đã tới phòng phụ trợ
                local c = from <= 10 and 1 or 2;
                self:MarkOpen(self.CHAIN[c].last, from);
            end
        elseif last and last.role == "pillar" and last.pillar and self:Has(text, "开动过", "咔", "đã được mở", "đã mở", "Cạch", "cạch", "rắc") then
            self:PillarDone(last.pillar);
        elseif self:Has(text, "人手还不够", "chưa đủ người") then
            j.keyWaitAt = now();
        elseif self:Has(text, "头晕", "chóng mặt") then
            j.heartAt = now();
        end
    end
end

-- Bảng hội thoại do mình vừa bấm NPC mở ra. Trả true nếu đã xử lý.
local function opts(say)
    local o = {};
    for i, v in ipairs((type(say) == "table" and say[2]) or {}) do
        o[i] = type(v) == "table" and tostring(v[1] or "") or tostring(v or "");
    end
    return o;
end

function M:Choose(j, index, waitMore)
    j.sayUntil = now() + (waitMore or 6);
    Ui(Ui.UI_SAYPANEL):OnListSel("LstSelectArray", index);
end

function M:CloseSay(j)
    j.sayUntil = nil;
    if visible(Ui.UI_SAYPANEL) then UiManager:CloseWindow(Ui.UI_SAYPANEL); end
end

-- Bia chọn tuyến tự hiện khi bước lại vào trap tuyến của mình: “phải trả 5 đồng tiền xu cổ…”
function M:CoinGate(say)
    local text = type(say) == "table" and tostring(say[1] or "") or "";
    return self:Has(text, "5个古铜钱", "5 đồng tiền", "5 tiền");
end

function M:SayTick(j)
    local say = j.say;
    if not say then return false; end
    j.say = nil;
    local text = type(say) == "table" and tostring(say[1] or "") or "";
    local o = opts(say);
    local last = j.lastClick or {};
    local k = self:Know();
    local function find(...)
        for i, s in ipairs(o) do if self:Has(s, ...) then return i; end end
    end
    -- Bia chọn tuyến khi quay lại: KHÔNG trả 5 cổ đồng tiền.
    if self:Has(text, "5个古铜钱", "5 đồng tiền", "5 tiền") then
        local i = find("不理", "Không", "không", "Kết thúc", "Mặc kệ");
        if i then self:Choose(j, i); else self:CloseSay(j); end
        self.work = "Không trả 5 tiền để quay lại tuyến.";
        return true;
    end
    -- Mã Xuyên Sơn ở thành
    if last.role == "entry" then
        -- “Có, cho ta qua.” (好的，送我过去吧) — luôn là dòng 1 khi được vào
        local i = find("送我过去", "cho ta qua", "Cho ta qua", "đưa ta", "đưa tôi", "Đưa");
        if i then self:Choose(j, i, 10); self.work = "Mã Xuyên Sơn: vào Thần Bí Bảo Khố."; return true; end
        -- Chưa có Túi tiền: Mã Xuyên Sơn đưa túi, chọn “Tốt!” (好！) là được đưa vào luôn
        if self:Has(text, "钱袋", "Túi tiền", "túi tiền") and #o >= 1 then
            local ok = find("好", "Tốt", "tốt") or 1;
            self:Choose(j, ok, 10);
            self.work = "Mã Xuyên Sơn: nhận Túi tiền, vào Thần Bí Bảo Khố.";
            return true;
        end
        for id, c in pairs(self.CITY) do
            if id ~= me.GetWorldPos() and (string.find(text, c.cn, 1, true) or string.find(text, c.vn, 1, true)) then
                j.enterFail, j.enterWhy = now(), "Tộc mở ải ở " .. c.vn .. "; hãy tới thành đó.";
                self:CloseSay(j); return true;
            end
        end
        j.enterFail, j.enterWhy = now(), "Mã Xuyên Sơn chưa cho vào (tộc chưa mở ải hôm nay, hoặc ải đã bắt đầu).";
        self:CloseSay(j);
        return true;
    end
    -- Mã Xuyên Sơn cuối ải: đổi 100 tiền lấy rương
    if last.role == "exchange" then
        if self:Has(text, "需要100", "chưa đủ", "不在身上", "Túi tiền") and #o <= 1 then
            j.exchangeDone = true; self:CloseSay(j); self.work = "Đổi rương: không đủ 100 tiền / thiếu Túi tiền."; return true;
        end
        local i = find("100");
        if i and j.options.exchange == 1 then
            self:Choose(j, i);
            j.exchangeN = (j.exchangeN or 0) + 1;
            if last.id then j.clicked[last.id] = nil; end      -- đổi được thì nói chuyện lại ngay, không tính là lần hỏng
            if j.exchangeN >= 50 then j.exchangeDone = true; end
            self.work = "Đổi 100 tiền lấy rương (lần " .. j.exchangeN .. ").";
            return true;
        end
        j.exchangeDone = true; self:CloseSay(j); return true;
    end
    -- Trụ ở Lối vào: cắm chìa
    -- Đồ Đằng Trụ ở Lối vào: dòng 1 “Mở khóa” (插钥匙进去试试) — chỉ khi bật “Người cầm chìa”
    if last.role == "pillar" and last.room == 1 then
        if j.options.key == 1 and #o >= 2 then
            self:Choose(j, 1); k.used[last.id] = true; self.work = "Cắm chìa vào Đồ Đằng Trụ.";
        else self:CloseSay(j); end
        return true;
    end
    -- Bia bật cơ quan: chữ trên bia báo phòng mở tiếp theo
    if last.role == "switch" then
        local room = self:RoomInText(text);
        k.pressed = k.pressed or {};
        if #o >= 2 then
            self:Choose(j, 1);
            k.used[last.id], k.pressed[last.room or 0] = true, true;
            if room and last.room then self:MarkOpen(room, last.room); end
            self.work = room and ("Bật bia: mở " .. (self.ROOMS[room] and self.ROOMS[room].vn or "?") .. ".") or "Bật bia.";
            return true;
        end
        -- Không có lựa chọn: bia cuối chuỗi (đã mở phòng phụ trợ) hoặc chỉ là lời nhắn
        k.used[last.id], k.pressed[last.room or 0] = true, true;
        if last.room and last.room >= 7 and last.room <= 14 then
            local c = last.room <= 10 and 1 or 2;
            self:MarkOpen(self.CHAIN[c].last, last.room);
        end
        self:CloseSay(j);
        return true;
    end
    self:CloseSay(j);
    return true;
end

-- ---------------------------------------------------------------- cập nhật bộ nhớ từ những gì nhìn thấy
function M:See(j, npcs)
    local k = self:Know();
    local _, mx, my = me.GetWorldPos();
    -- trap Phòng Thủ Vệ bật trạng thái chiến đấu khi phòng đã mở: đang chiến đấu trong ải = phòng 2 đã mở
    if me.nFightState == 1 and not k.open[2] then self:MarkOpen(2); end
    do
        local r = self:RoomStrict(mx, my);
        if r and r > 1 and not k.open[r] then self:MarkOpen(r); end
    end
    -- quái đang sống trong khung một phòng → phòng đó đã mở
    for _, n in ipairs(npcs) do
        if self:Attackable(n) then
            local x, y = self:Pos(n);
            local r = self:RoomAt(x, y);
            if r and r > 1 then self:MarkOpen(r); end
        end
    end
    -- bia chặn cửa: đứng gần cửa mà vẫn thấy → còn đóng; không thấy trong DOOR_TRUST giây → đã mở
    local gates = {};
    for _, n in ipairs(npcs) do
        if self.NPC_ROLE[self:Tpl(n)] == "gate" then local x, y = self:Pos(n); gates[#gates + 1] = {x, y}; end
    end
    for id, r in pairs(self.ROOMS) do
        if id ~= 2 and not k.open[id] and r.doors and #r.doors > 0 then
            for _, d in ipairs(r.doors) do
                if (d[1] - mx) ^ 2 + (d[2] - my) ^ 2 <= self.DOOR_SEE * self.DOOR_SEE then
                    local blocked = false;
                    for _, g in ipairs(gates) do if (g[1] - d[1]) ^ 2 + (g[2] - d[2]) ^ 2 <= 25 then blocked = true; end end
                    if blocked then
                        k.closed[id], j.doorSeen[id] = now(), nil;
                    else
                        j.doorSeen[id] = j.doorSeen[id] or now();
                        if now() - j.doorSeen[id] >= self.DOOR_TRUST then self:MarkOpen(id); end
                    end
                end
            end
        end
    end
    -- bị trap cửa đẩy lùi: vị trí nhảy xa khi đang đi về phía một phòng chưa mở
    if j.lastX and not (me.IsDead and me.IsDead() == 1) then
        local jump = (mx - j.lastX) ^ 2 + (my - j.lastY) ^ 2;
        if jump > 15 * 15 and j.target and not k.open[j.target] then k.closed[j.target] = now(); end
    end
    j.lastX, j.lastY = mx, my;
end

-- ---------------------------------------------------------------- kế hoạch: nên ở phòng nào
-- Trả: phòng đích, kiểu ("room" / "probe" / "wait"), ghi chú.
--   room  = tới phòng, chạy vòng đánh quái, bật bia;  probe = đi tới cửa phòng chưa biết mở (bị đẩy lùi = còn đóng);
--   wait  = đứng ở phòng đích chờ.
function M:Recently(r)
    local k = self:Know();
    return k.closed[r] and now() - k.closed[r] < self.CLOSED_WAIT;
end

-- Phòng đã xong phần của mình: tự đánh xong / đã bật bia / bia đã mở phòng kế.
function M:Finished(r)
    local k = self:Know();
    return k.done[r] or (k.pressed and k.pressed[r]) or (k.next[r] and k.open[k.next[r]]) or false;
end

local function vn(self, r) return (self.ROOMS[r] or {}).vn or ("phòng " .. tostring(r)); end

function M:Plan(j)
    local k, mine = self:Know(), self:Mine();
    local o = j.options;
    if not k.open[2] then return 2, "enter2", "Chờ ở cửa Phòng Thủ Vệ (người cầm chìa chọn Mở khóa, hoặc đủ 10 phút); thử bước vào mỗi 15 giây."; end
    if not (k.open[4] or k.open[5] or k.open[6]) then
        if k.open[3] then
            k.pillar = k.pillar or {};
            for i, p in ipairs(self.PILLARS) do
                if not k.pillar[i] then return 3, "pillar", "Phòng tuyển chọn: tới bật Đồ Đằng Trụ " .. i .. "/4.", p; end
            end
            return 3, "wait", "Đã bật đủ 4 trụ; chờ mở tuyến.";
        end
        if self:QuietFor(j, 2) >= self.ROOM_QUIET then return 3, "probe", "Phòng Thủ Vệ sạch quái: tới cửa Phòng tuyển chọn."; end
        return 2, "room", "Phòng Thủ Vệ: đánh quái.";
    end
    -- Sau Phòng nghỉ: cả 4 tuyến gặp nhau
    if k.open[26] then
        if not k.open[27] then return 27, "probe", "Phòng nghỉ: lên cửa Phòng bùa chú."; end
        if not k.open[28] then
            local has = self:CountItem(self.ITEM_MIYAO) > 0 or (me.GetSkillState and me.GetSkillState(self.STATE_MIYAO) > 0);
            j.herbTried = j.herbTried or {};
            if o.miyao == 1 and not has then
                for _, h in ipairs({31, 32}) do
                    if not j.herbTried[h] then return h, "room", "Hái Bí dược (" .. (h == 31 and "góc trái" or "góc phải") .. ")."; end
                end
            end
            if j.bossGone and now() - j.bossGone > 8 then return 28, "probe", "Lên cửa phòng bảo rương."; end
            return 27, "room", "Phòng bùa chú: boss Minh Phủ Oan Hồn.";
        end
        return 28, "room", "Phòng bảo rương — đã qua ải.";
    end
    local R = self.ROUTES[mine.route or 0];
    if not R then return 3, "wait", "Chưa được đội trưởng gán tuyến (4 tuyến: Trái / Giữa 1–4 / Giữa 5–8 / Phải)."; end
    local function waitAt(r, note) return r, "wait", note; end
    -- Phòng cuối của tuyến (Vực thẳm / Phục chế / Siêu Tốc) → Phòng nghỉ
    if k.open[R.final] then
        if not k.done[R.final] then return R.final, "room", vn(self, R.final) .. ": bật bia, đánh hết quái."; end
        return 26, "probe", "Đứng cửa Phòng nghỉ chờ mở.";
    end
    -- Chưa mở Bí văn 1 / 5: đánh phòng tuyến (bật bia ở phòng Phản Đòn / Choáng); giữa đánh xong thì ra đứng cửa Bí văn
    if not (k.open[15] or k.open[19]) then
        if R.mids and self:QuietFor(j, 5) >= self.ROOM_QUIET then
            return R.mids[1], "probe", "Cơ Quan sạch quái: đứng cửa " .. vn(self, R.mids[1]) .. " chờ mở.";
        end
        return R.room, "room", vn(self, R.room) .. ".";
    end
    if R.rand then
        -- Trái / Phải: đánh phòng ngẫu nhiên bên mình vừa được bia Bí văn mở
        local best, bd;
        for _, r in ipairs(R.rand) do
            if k.open[r] and not self:Finished(r) then
                local w = self.WALK[r];
                local d = self:DistXY(w[1], w[2]);
                if not bd or d < bd then best, bd = r, d; end
            end
        end
        if best then return best, "room", vn(self, best) .. ": đánh quái, bật bia mở Bí văn kế."; end
        local other = R.room == 4 and 29 or 30;
        if k.open[other] then return R.final, "probe", "Đứng cửa " .. vn(self, R.final) .. " chờ mở."; end
        return waitAt(R.room, "Chờ bia Bí văn mở phòng " .. (R.room == 4 and "Thiên / Địa / Nhật / Nguyệt Tự" or "Thanh Long / Bạch Hổ / Chu Tước / Huyền Vũ") .. ".");
    end
    -- Giữa: bật bia Bí văn theo thứ tự
    local last = 5;
    for i, m in ipairs(R.mids) do
        if not k.open[m] then
            return m, "probe", "Đứng cửa " .. vn(self, m) .. " chờ phe " .. (R.mids[1] == 15 and "Trái" or "Phải") .. " bật bia phòng ngẫu nhiên mở.";
        end
        if not self:Finished(m) then return m, "room", vn(self, m) .. ": đánh quái, bật bia."; end
        last = m;
    end
    if k.open[29] or k.open[30] then return R.final, "probe", "Đứng cửa " .. vn(self, R.final) .. " chờ mở."; end
    return waitAt(5, "Nhánh xong; chờ phụ trợ " .. (k.open[29] and "B" or "A") .. " mở rồi vào " .. vn(self, R.final) .. ".");
end

-- ---------------------------------------------------------------- việc trong phòng
function M:Foe(j, npcs, room, target)
    local _, mx, my = me.GetWorldPos();
    local box = room and self.ROOMS[room] and self.ROOMS[room].box;
    local tbox = target and target ~= room and target <= 28 and self.ROOMS[target] and self.ROOMS[target].box;
    local foe, fd;
    for _, n in ipairs(npcs) do
        if self:Attackable(n) then
            local x, y = self:Pos(n);
            local d = math.sqrt((x - mx) ^ 2 + (y - my) ^ 2);
            local inside = (box and x >= box[1] - 6 and x <= box[3] + 6 and y >= box[2] - 6 and y <= box[4] + 6)
                or (tbox and self:Know().open[target] and x >= tbox[1] and x <= tbox[3] and y >= tbox[2] and y <= tbox[4]);
            if (d <= self.FIGHT_NEAR or inside) and (not fd or d < fd) then foe, fd = n, d; end
        end
    end
    return foe, fd;
end

-- Cơ quan cần bấm ở phòng r: trả npc, vai trò.
function M:Clickable(j, npcs, r)
    local k = self:Know();
    local o = j.options;
    local hasMiyao = self:CountItem(self.ITEM_MIYAO) > 0 or (me.GetSkillState and me.GetSkillState(self.STATE_MIYAO) > 0);
    local best, bd, brole;
    for _, n in ipairs(npcs) do
        local tid = self:Tpl(n);
        local role = self.NPC_ROLE[tid];
        local id = self.Field(n, "dwId") or n.nIndex;
        local ok = false;
        if role and not k.used[id] and not (j.blocked[id] and now() < j.blocked[id]) then
            local x, y = self:Pos(n);
            local at = self:RoomAt(x, y);
            if role == "pillar" then
                local pi = at == 3 and self:PillarIndex(x, y);
                ok = (r == 3 and at == 3 and not (pi and k.pillar and k.pillar[pi])) or (r == 1 and at == 1 and o.key == 1 and not k.open[2]);
            elseif role == "switch" then ok = at == r;
            elseif role == "coinbox" then ok = o.coinbox == 1 and self:DistXY(x, y) <= 30;
            elseif role == "miyao" then ok = o.miyao == 1 and k.open[26] and not k.open[28] and not hasMiyao;
            elseif role == "exchange" then ok = o.exchange == 1 and r == 28 and not j.exchangeDone;
            end
            if ok then
                local d = self:Dist(n);
                if not bd or d < bd then best, bd, brole = n, d, role; end
            end
        end
    end
    return best, brole, bd;
end

function M:Click(j, npc, role, r)
    local k = self:Know();
    local id = self.Field(npc, "dwId") or npc.nIndex;
    local c = j.clicked[id] or {tries = 0};
    j.clicked[id] = c;
    local d = self:Dist(npc);
    if c.at and now() - c.at < c.wait then self.work = "Đang tương tác " .. tostring(self.Field(npc, "szName") or "") .. "."; return; end
    if c.tries >= self.CLICK_TRIES then
        if role == "switch" or role == "pillar" then k.used[id] = true; else j.blocked[id] = now() + 30; end
        if role == "pillar" and r == 3 then local x, y = self:Pos(npc); local pi = self:PillarIndex(x, y); if pi then self:PillarDone(pi); end end
        j.clicked[id] = nil;
        return;
    end
    c.at, c.tries = now(), c.tries + 1;
    c.wait = 4 + math.min(20, d / 5);
    j.lastClick = {id = id, role = role, room = r, at = now()};
    if role == "pillar" and r == 3 then
        local x, y = self:Pos(npc);
        j.lastClick.pillar = self:PillarIndex(x, y);
        if j.lastClick.pillar then j.pillarWork = {i = j.lastClick.pillar, at = now()}; end
    end
    j.sayUntil = now() + c.wait + 4;
    self:Calm(j);
    AutoAi.SetTargetIndex(npc.nIndex);
    self.work = "Bấm " .. tostring(self.Field(npc, "szName") or role) .. " (lần " .. c.tries .. ").";
end

-- Lối vào trước khi ải bắt đầu: người cầm chìa đủ người thì cắm chìa (nếu bật).
function M:EntryTick(j, npcs, players)
    if j.options.key ~= 1 or self:CountItem(self.ITEM_KEY) == 0 then return false; end
    if players < j.options.keyCount or (j.keyWaitAt and now() - j.keyWaitAt < 10) then
        self.work = "Cầm chìa: chờ đủ " .. j.options.keyCount .. " người (thấy " .. players .. ").";
        return true;
    end
    local npc, role = self:Clickable(j, npcs, 1);
    if npc and role == "pillar" then self:Click(j, npc, role, 1); return true; end
    return false;
end

-- Ngoài ải, đang ở 1 trong 7 thành: tới Mã Xuyên Sơn → “đưa tôi qua”.
function M:AutoPath()
    local ap = Ui.tbLogic and Ui.tbLogic.tbAutoPath;
    if type(ap) == "table" and type(ap.GotoPos) == "function" then return ap; end
end

function M:StopTravel()
    local ap = self:AutoPath();
    if ap and ap.tbGotoPos and self.travelMap and ap.tbGotoPos.nMapId == self.travelMap then pcall(ap.StopGoto, ap, "WJXKG"); end
    self.travelMap = nil;
end

-- Tự tìm đường liên bản đồ của client (như bấm toạ độ / theo chân đội) tới Mã Xuyên Sơn ở thành city.
function M:TravelTick(j, city)
    local c = self.CITY[city];
    local ap = self:AutoPath();
    if not ap then j.enterFail, j.enterWhy = now(), "Client không có tự tìm đường liên bản đồ; hãy tự tới " .. c.vn .. "."; self.work = j.enterWhy; return true; end
    if ap.tbGotoPos then self.work = "Đang tự tìm đường tới Mã Xuyên Sơn (" .. c.vn .. ")."; j.travelAt = now(); return true; end
    if j.travelAt and now() - j.travelAt < 6 then self.work = "Chờ tới " .. c.vn .. "."; return true; end
    j.travelN = (j.travelN or 0) + 1;
    if j.travelN > 4 then j.enterFail, j.enterWhy, j.travelN = now(), "Không tự tìm được đường tới " .. c.vn .. "; hãy tự tới thành đó.", 0; self.work = j.enterWhy; return true; end
    j.travelAt, self.travelMap = now(), city;
    self:Calm(j);
    local ok, why = pcall(ap.GotoPos, ap, {nMapId = city, nX = c.x, nY = c.y});
    self.work = "Tự tìm đường tới Mã Xuyên Sơn (" .. c.vn .. ").";
    if not ok then self:Message("Tự tìm đường lỗi: " .. tostring(why));
    elseif j.travelN == 1 then self:Message(self.work); end
    return true;
end

function M:EnterTick(j, npcs)
    local map, x, y = me.GetWorldPos();
    local c = self.CITY[map];
    if c then self.lastCity = map; end
    if j.options.enter ~= 1 then return false; end
    if j.enterFail and now() - j.enterFail < 60 then self.work = j.enterWhy or "Chờ."; return true; end
    local want = (j.goCity and self.CITY[j.goCity] and j.goCity) or (not c and self.lastCity) or nil;
    if want and want ~= map then return self:TravelTick(j, want); end
    if not c then return false; end
    local npc;
    for _, n in ipairs(npcs) do if self.NPC_ROLE[self:Tpl(n)] == "entry" then npc = n; end end
    if not npc or self:Dist(npc) > 4 then
        local tx, ty = c.x, c.y;
        if npc then tx, ty = self:Pos(npc); end
        if j.toEntry and not npc and self:DistXY(tx, ty) <= 3 then
            self:Stop("Đã tới Mã Xuyên Sơn (" .. c.vn .. "). Đứng chờ.");
            return true;
        end
        self:Step(tx, ty);
        self.work = "Tới Mã Xuyên Sơn (" .. c.vn .. ").";
        return true;
    end
    -- PT Mã Xuyên Sơn: chỉ tới đứng cạnh, không vào ải
    if j.toEntry then self:Stop("Đã tới Mã Xuyên Sơn (" .. c.vn .. "). Đứng chờ."); return true; end
    if not j.talkAt or now() - j.talkAt >= 8 then
        j.talkAt = now();
        j.lastClick = {id = self.Field(npc, "dwId") or npc.nIndex, role = "entry", at = now()};
        j.sayUntil = now() + 8;
        AutoAi.SetTargetIndex(npc.nIndex);
        self.work = "Nói chuyện Mã Xuyên Sơn.";
    end
    return true;
end

-- Phòng Tâm Ma (sau khi hái bí dược): đánh Tâm Ma nếu bật “Đánh Tâm Ma”.
function M:HeartTick(j, npcs)
    if j.options.heart ~= 1 then self:Calm(j); self.work = "Phòng Tâm Ma: bạn tự đánh (chưa bật “Đánh Tâm Ma”)."; return; end
    for _, n in ipairs(npcs) do
        if self.NPC_ROLE[self:Tpl(n)] == "heart" and self:Alive(n) then self:Fight(j, n); return; end
    end
    self:Calm(j);
    self.work = "Phòng Tâm Ma: chờ.";
end

-- Phòng bùa chú: dùng bí dược trước khi đánh boss (nếu có).
function M:MiyaoUse(j, npcs)
    if not me.GetSkillState or me.GetSkillState(self.STATE_MIYAO) > 0 then return false; end
    local seen = false;
    for _, n in ipairs(npcs) do if self.BOSS27[self:Tpl(n)] and self:Alive(n) and self:Dist(n) <= 30 then seen = true; end end
    if not seen or (j.miyaoAt and now() - j.miyaoAt < 5) then return false; end
    local n, list = self:CountItem(self.ITEM_MIYAO);
    if n == 0 then return false; end
    j.miyaoAt = now();
    pcall(me.UseItem, list[1].pItem);
    self.work = "Dùng Bí dược trước khi đánh boss.";
    return true;
end

-- ---------------------------------------------------------------- nhịp chính
function M:Tick()
    local j = self.job;
    if not j then return 0; end
    local name = me.szName;
    if name and name ~= "" and name ~= j.owner then
        j.otherSince = j.otherSince or now();
        if now() - j.otherSince >= 5 then self:Stop("Đã đổi nhân vật."); return 0; end
        return self.TICK;
    end
    j.otherSince = nil;
    if self.FlushOpen then pcall(self.FlushOpen, self); end
    if me.IsDead and me.IsDead() == 1 then
        self:Calm(j);
        j.way, j.lastRoom = nil, 1;
        self.status, self.work = "Bị hạ gục; hồi sinh ở Lối vào rồi đi lại theo đúng cửa.", "—";
        return self.TICK;
    end
    local owner = self:OtherOwner();
    if owner then
        self:Calm(j);
        self.status, self.work = "Quan sát: " .. owner .. " đang điều khiển.", "—";
        return self.TICK;
    end
    local npcs, players = self:Around();
    if self:SayTick(j) then self.status = "Đang chạy."; return self.TICK; end
    if visible(Ui.UI_SAYPANEL) and j.sayUntil and now() <= j.sayUntil then return self.TICK; end
    if not self:InGame() then
        self:Calm(j);
        j.room, j.way, j.lastRoom = nil, nil, nil;
        if j.gatherOnly then self:Stop("Không ở trong ải; bỏ lệnh tập trung."); return 0; end
        if j.exitOnly then self:Stop("Đã ra khỏi ải."); return 0; end
        if self:EnterTick(j, npcs) then self.status = "Ngoài ải."; return self.TICK; end
        self.status, self.work = "Chưa ở trong Thần Bí Bảo Khố; chờ vào ải.", "—";
        return self.TICK;
    end
    if j.toEntry then self:Stop("Đang ở trong ải; bỏ lệnh tới Mã Xuyên Sơn."); return 0; end
    if j.enterOnly then self:Stop("Đã vào Thần Bí Bảo Khố. Chờ đội trưởng gọi PT Bật Auto (hoặc tự bật)."); return 0; end
    self.status = "Đang chạy.";
    self:ReadTips(j);
    self:PillarTick(j);
    if visible(Ui.UI_SKILLPROGRESS) then self.work = "Đang thao tác (thanh tiến trình)."; return self.TICK; end
    local _, x, y = me.GetWorldPos();
    if self:InHeart(x, y) then j.room = nil; self:HeartTick(j, npcs); return self.TICK; end
    self:See(j, npcs);
    local k = self:Know();
    j.room = self:RoomAt(x, y);
    if j.room then j.lastRoom = j.room; end
    local mine = self:Mine();
    if j.gather then
        local res = self:GatherTick(j, k);
        if res then return res; end
    end
    if j.exitOnly then return self:ExitTick(j, k); end
    if j.room == 1 and not k.open[2] and self:EntryTick(j, npcs, players) then return self.TICK; end
    local target, kind, note, point = self:Plan(j);
    j.target = target;
    self.planNote = note;
    local here = j.room;
    self:TrackQuiet(j, npcs, here);
    -- Auto6 Luyện Công đang lo phòng khác → trả lại
    local training = j.auto6Room and self:OwnsAuto6(j);
    if j.auto6Room and (not training or j.auto6Room ~= target or kind ~= "room") then self:ReleaseAuto6(j); training = false; end
    -- Quái quanh mình / trong phòng đang đứng / trong phòng đích đã mở: đánh trước (khi Auto6 chưa lo)
    local foe = self:Foe(j, npcs, here, target);
    if foe then
        if here then j.foughtIn = j.foughtIn or {}; j.foughtIn[here] = now(); end
        if self.BOSS27[self:Tpl(foe)] then j.bossSeen = now(); end
        if here == 27 and self:MiyaoUse(j, npcs) then return self.TICK; end
    end
    if foe and not training then
        if kind == "room" and target == here and self:TrainRoom(j, here) then self.work = note .. " Auto6 Luyện Công trong phòng."; return self.TICK; end
        self:Fight(j, foe);
        return self.TICK;
    end
    if here == 27 and j.bossSeen and not j.bossGone and now() - j.bossSeen > 5 then j.bossGone = now(); end
    -- cơ quan / cỏ bí dược / rương tiền (không bấm khi quái đang sát bên)
    if not foe or self:Dist(foe) > self.CLICK_GUARD then
        local npc, role = self:Clickable(j, npcs, here or 0);
        if npc then self:Click(j, npc, role, here); return self.TICK; end
    end
    -- Phòng cuối tuyến: đã bật bia, yên quái đủ lâu → xong
    if here and (here == 23 or here == 24 or here == 25) and k.pressed and k.pressed[here] and self:QuietFor(j, here) >= self.DONE_QUIET then
        k.done[here] = true;
    end
    -- Góc bí dược: tới nơi mà không còn cỏ để hái → thử góc kia
    if (target == 31 or target == 32) and self:Arrived(j, target) then
        j.herbTried = j.herbTried or {};
        j.herbAt = j.herbAt or now();
        if now() - j.herbAt > 4 then j.herbTried[target], j.herbAt = true, nil; end
    end
    if training then self.work = note .. " Auto6 Luyện Công trong phòng."; return self.TICK; end
    self:Calm(j);
    if not target then self.work = note or "Chờ."; return self.TICK; end
    -- Bia chọn tuyến: chạm trap rồi bị đẩy ra điểm ngoài → tuyến đã đủ người
    for r in pairs(self.ROUTE_TRAP_ROOM) do
        local t, out = self.ROUTE_TRAP[r], self.ROUTE_OUT[r];
        if (x - t[1]) ^ 2 + (y - t[2]) ^ 2 <= 9 then j.routeNear = now(); end
        if (x - out[1]) ^ 2 + (y - out[2]) ^ 2 <= 4 and j.routeNear and now() - j.routeNear < 6 then
            self.work = "Tuyến " .. self.ROOMS[r].vn .. " đã đủ người; báo đội trưởng gán lại.";
            return self.TICK;
        end
    end
    -- Phòng Thủ Vệ chưa mở: đứng cạnh cửa, thỉnh thoảng bước vào trap (mở rồi thì được đưa vào)
    if kind == "enter2" then
        local px, py = self:ProbePoint(2);
        if self:DistXY(px, py) <= self.WAY_NEAR + 1 and (not j.try2At or now() - j.try2At >= 15) then
            j.try2At = now();
            local t = self.TRAPS[2][1];
            self:Step(t[3], t[4]);
        elseif not j.try2At or now() - j.try2At >= 3 then
            self:Go(j, 1, px, py);
        end
        self.work = note;
        return self.TICK;
    end
    local ok, why;
    if kind == "probe" then
        local px, py = self:ProbePoint(target);
        ok, why = self:Go(j, self:NearestRoom(px, py), px, py);
    elseif kind == "pillar" then
        ok, why = self:Go(j, 3, point[1], point[2]);
        if ok and self:DistXY(point[1], point[2]) <= 4 then
            -- tới chỗ trụ mà không thấy trụ nào để bấm → coi như trụ này đã bật (đã có người mở)
            j.pillarSeen = j.pillarSeen or {};
            local idx = self:PillarIndex(point[1], point[2]);
            j.pillarSeen[idx] = j.pillarSeen[idx] or now();
            if now() - j.pillarSeen[idx] > 6 then self:PillarDone(idx); end
        end
        self.work = note;
        return self.TICK;
    else
        ok, why = self:Go(j, target);
    end
    if not ok then
        if why and j.wayWhy ~= why then j.wayWhy = why; self:Message(why); end
        self.work = why or note;
        return self.TICK;
    end
    if kind == "probe" then self.work = note; return self.TICK; end
    if not self:Arrived(j, target) and not (j.way and not j.way.pts[j.way.i]) then
        self.work = "Tới " .. ((self.ROOMS[target] or {}).vn or "góc bí dược") .. ".";
        j.patrol = nil;
        return self.TICK;
    end
    if kind == "room" and target <= 28 and target ~= 26 and target ~= 28 and self:TrainRoom(j, target) then
        self.work = note .. " Auto6 Luyện Công trong phòng.";
        return self.TICK;
    end
    if kind == "room" and self:Patrol(j, target) then self.work = note .. " Chạy vòng tìm quái."; return self.TICK; end
    self.work = note .. (kind == "room" and " Chờ quái / sự kiện." or "");
    return self.TICK;
end

-- Yên quái trong phòng r bao lâu rồi (giây). Chỉ tính khi đang đứng trong phòng.
M.ROOM_QUIET = 8;
function M:TrackQuiet(j, npcs, r)
    j.quiet = j.quiet or {};
    if not r then return; end
    local box = self.ROOMS[r] and self.ROOMS[r].box;
    local busy = false;
    for _, n in ipairs(npcs) do
        if self:Attackable(n) then
            local x, y = self:Pos(n);
            if (box and x >= box[1] - 6 and x <= box[3] + 6 and y >= box[2] - 6 and y <= box[4] + 6) or self:Dist(n) <= self.FIGHT_NEAR then busy = true; end
        end
    end
    if busy then j.quiet[r] = nil; else j.quiet[r] = j.quiet[r] or now(); end
end

function M:QuietFor(j, r)
    local t = j.quiet and j.quiet[r];
    return t and (now() - t) or 0;
end

-- Trụ phòng tuyển chọn: đã bấm và thanh tiến trình chạy hết (không bị ngắt) → trụ đã bật
function M:PillarTick(j)
    local w = j.pillarWork;
    if not w then return; end
    if visible(Ui.UI_SKILLPROGRESS) then w.progress = now(); return; end
    if w.progress and now() - w.progress >= 1 then self:PillarDone(w.i); j.pillarWork = nil; return; end
    if now() - w.at > 45 then j.pillarWork = nil; end
end

function M:PillarDone(i)
    local k = self:Know();
    k.pillar = k.pillar or {};
    if not i or k.pillar[i] then return; end
    k.pillar[i] = true;
    local n = 0;
    for idx = 1, #self.PILLARS do if k.pillar[idx] then n = n + 1; end end
    if n >= #self.PILLARS then for _, r in ipairs({4, 5, 6}) do self:MarkOpen(r, 3); end end
end

-- Điểm đứng trước cửa phòng r (phía đi tới, cách tâm trap ~1,5 lần khoảng bị đẩy lùi)
function M:ProbePoint(r)
    local best, bd;
    for _, t in ipairs(self.TRAPS[r] or {}) do
        local d = self:DistXY(t[1], t[2]);
        if not bd or d < bd then best, bd = t, d; end
    end
    if not best then local w = self.WALK[r]; return w[1], w[2]; end
    return math.floor(best[1] + 1.5 * (best[1] - best[3]) + 0.5), math.floor(best[2] + 1.5 * (best[2] - best[4]) + 0.5);
end

-- Chạy vòng quanh các điểm của phòng để kéo quái; 1 vòng không gặp quái thì đứng giữa phòng (đến khi phòng có quái lại).
function M:Patrol(j, r)
    local list = self.PATROL[r];
    if not list then return false; end
    local p = j.patrol;
    if not p or p.room ~= r then
        p = {room = r, i = 1, quiet = 0};
        j.patrol = p;
    end
    local fought = j.foughtIn and j.foughtIn[r];
    if fought and fought > (p.lastFight or 0) then p.lastFight, p.quiet = fought, 0; end
    if p.quiet >= #list then
        if self:DistXY(self.WALK[r][1], self.WALK[r][2]) > 3 then self:Step(self.WALK[r][1], self.WALK[r][2]); end
        return false;
    end
    local pt = list[p.i];
    if self:DistXY(pt[1], pt[2]) <= self.WAY_NEAR then
        p.i, p.quiet = p.i % #list + 1, p.quiet + 1;
        pt = list[p.i];
    end
    self:Step(pt[1], pt[2]);
    return true;
end

-- PT Rời VAGT: tới Phòng bảo rương rồi bước vào trap ra (cạnh Điểm Rời Bản Đồ).
function M:ExitTick(j, k)
    self:Calm(j);
    local ok, why = self:Go(j, 28, self.EXIT_POS[1], self.EXIT_POS[2]);
    if not ok then self:Stop("Không tới được lối ra: " .. tostring(why)); return 0; end
    self.status, self.work = "Rời ải.", "Tới Điểm Rời Bản Đồ.";
    return self.TICK;
end

-- PT Tập Trung (đội trưởng gửi phòng + toạ độ): đi theo đúng cửa về chỗ đội trưởng. Trả nhịp kế, hoặc nil để chạy tiếp.
function M:GatherTick(j, k)
    local g = j.gather;
    local function finish(text)
        j.gather, j.way = nil, nil;
        if j.gatherOnly then self:Stop(text); return 0; end
        self:Message(text);
    end
    if k.map ~= g.map then return finish("Đội trưởng không ở cùng lượt ải với bạn; bỏ lệnh tập trung."); end
    if now() - g.at > self.GATHER_TIME then return finish("Hết thời gian tập trung."); end
    if self:DistXY(g.x, g.y) <= self.GATHER_NEAR then return finish("Đã tới chỗ đội trưởng."); end
    local room = g.room > 0 and g.room or self:NearestRoom(g.x, g.y);
    local ok, why = self:Go(j, room, g.x, g.y);
    if not ok then return finish("Không tập trung được: " .. tostring(why)); end
    self:Calm(j);
    self.status = "Tập trung.";
    self.work = "Về chỗ đội trưởng (" .. ((self.ROOMS[room] or {}).vn or "?") .. ") theo đúng cửa.";
    return self.TICK;
end

-- Ảnh chụp cho cửa sổ.
function M:ViewState()
    local k = self.know;
    local j = self.job;
    local opened = {};
    if k then for r = 1, 30 do if k.open[r] then opened[#opened + 1] = r; end end end
    return j and j.room, self.planNote, opened;
end
