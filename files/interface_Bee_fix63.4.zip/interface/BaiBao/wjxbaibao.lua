-- Auto Bách Bảo Rương (by HUKT). Cửa sổ cài đặt mở từ nút Bảo Rương ở thanh Home.
-- Gửi đúng lệnh như các nút của giao diện Bách Bảo Rương gốc:
--   quay / tiếp : me.CallServerScript({"ApplyBaibaoxiangGetResult", tiền cược})
--   nhận thưởng : me.CallServerScript({"ApplyBaibaoxiangGetAward", 1 = vật phẩm | 2 = vỏ sò})
-- Đọc trạng thái từ biến nhiệm vụ nhóm 2086 (1 cấp tổng, 2 số lần quay, 3 loại thưởng, 4 tiền cược,
-- 6 vượt cấp, 7 được quay tiếp). Server bắt mỗi thao tác cách nhau >= 3 giây.
-- Không ghi log tên nhân vật / tài khoản.
Ui.WJXBaiBao = Ui.WJXBaiBao or {};
local M = Ui.WJXBaiBao;
M.VERSION = "1.3.2";
M.CFG_VER = 3;   -- đổi mặc định: bỏ cấu hình cũ trước bản này
M.GROUP = "UI_WJXBAIBAO";
M.CLASS = "wjxbaibao";
M.INI = "wjxbaibao.ini";
M.INI_PATH = "\\interface\\BaiBao\\wjxbaibao.ini";
M.TASK = 2086;
M.COIN = {18, 1, 325, 1};
M.BETS = {2, 10, 50};
M.BET_BTN = {[2] = "BtnBet2", [10] = "BtnBet10", [50] = "BtnBet50"};
M.TYPES = {"Huyền Tinh", "Tinh hoạt", "Bạc thường", "Đồng khóa"};   -- loại 1..4 (5 = Bảo rương)
M.VALUES = {
    {4, 5, 6, 7, 8, 9},
    {300, 900, 3000, 10500, 36000, 120000},
    {10000, 30000, 100000, 350000, 1200000, 4000000},
    {60, 180, 600, 2100, 7200, 24000},
};
M.SHELL = {1, 3, 10, 35, 120, 400};
M.WAIT = 8;   -- giây chờ server trả kết quả mỗi lệnh

local function msg(s) if me and me.Msg then me.Msg("<color=yellow>[Bảo Rương]<color> " .. s) end end
local function T(i) return me.GetTask(M.TASK, i) or 0 end
local function coins() return me.GetItemCountInBags(unpack(M.COIN)) or 0 end
-- 4000000 -> "4tr", 1200000 -> "1,2tr", 10500 -> "10,5k", 300 -> "300"
local function short(v)
    local function f(x, u)
        local s = string.format("%.1f", x);
        s = string.gsub(s, "%.0$", ""); s = string.gsub(s, "%.", ",");
        return s .. u;
    end
    if v >= 1000000 then return f(v / 1000000, "tr") end
    if v >= 10000 then return f(v / 1000, "k") end
    return tostring(v);
end
local function clamp(v, lo, hi) v = tonumber(v) or lo; if v < lo then v = lo end; if v > hi then v = hi end; return math.floor(v) end

-- ---------------------------------------------------------------- cấu hình
function M:Defaults()
    -- Huyền Tinh: Cấp 1, Vật phẩm | Tinh hoạt / Bạc / Đồng khóa: Cấp 1, Vỏ sò | tất cả KHÔNG tick Tiếp | 3 giây
    return {ver = self.CFG_VER, bet = 2, speed = 3, lv = {1, 1, 1, 1}, nxt = {0, 0, 0, 0}, pick = {1, 2, 2, 2}};
end
function M:File() return "\\user\\TuDongDanh\\" .. tostring(me.szName) .. "_BaiBao.dat" end
function M:Load()
    local c = self:Defaults();
    local ok, s = pcall(KIo.ReadTxtFile, self:File());
    if ok and type(s) == "string" and s ~= "" then
        local ok2, t = pcall(Lib.Str2Val, Lib, s);
        if ok2 and type(t) == "table" and t.ver == self.CFG_VER then
            if t.bet == 2 or t.bet == 10 or t.bet == 50 then c.bet = t.bet end
            c.speed = clamp(t.speed or c.speed, 3, 10);
            for i = 1, 4 do
                if type(t.lv) == "table" then c.lv[i] = clamp(t.lv[i] or c.lv[i], 1, 6) end
                if type(t.pick) == "table" and (t.pick[i] == 1 or t.pick[i] == 2) then c.pick[i] = t.pick[i] end
                if type(t.nxt) == "table" and (t.nxt[i] == 0 or t.nxt[i] == 1) then c.nxt[i] = t.nxt[i] end
            end
        end
    end
    return c;
end
function M:Save(c)
    local s = Lib:Val2Str(c);
    local ok = pcall(KIo.WriteFile, self:File(), s);
    return ok;
end

-- ---------------------------------------------------------------- lịch sử
-- Mỗi bản ghi: {t = ngày giờ, k = start|spin|next|lose|award|stop, ty, lv, bet, pick, amt, unit, txt}
-- Lưu dạng bảng (Lib:Val2Str) theo nhân vật, giữ 500 bản ghi gần nhất; hiển thị mới nhất trước.
M.LOG_MAX = 500;
M.FILTERS = {
    {name = "Tất cả"},
    {name = "Nhận thưởng", k = "award"},
    {name = "Huyền Tinh", k = "award", unit = "ht"},
    {name = "Tinh hoạt", k = "award", unit = "tinhhoat"},
    {name = "Bạc", k = "award", unit = "bac"},
    {name = "Đồng khóa", k = "award", unit = "dong"},
    {name = "Bảo rương", k = "award", unit = "box"},
    {name = "Vỏ sò", k = "award", unit = "shell"},
    {name = "Thua", k = "lose"},
    {name = "Quay / Tiếp", k = "spin"},
};
M.UNIT_NAME = {ht = "Huyền Tinh", tinhhoat = "Tinh hoạt", bac = "Bạc", dong = "Đồng khóa", box = "Bảo rương", shell = "Vỏ sò"};
function M:LogFile() return "\\user\\TuDongDanh\\" .. tostring(me.szName) .. "_BaiBao_log.dat" end
local function stamp()
    local ok, s = pcall(GetLocalDate, "%d/%m/%Y %H:%M:%S");
    if ok and type(s) == "string" and s ~= "" then return s end
    local ok2, s2 = pcall(os.date, "%d/%m/%Y %H:%M:%S");
    return ok2 and s2 or "?";
end
-- Mỗi lần vào game (đăng nhập / đổi nhân vật) xóa log cũ để file không phình to.
if M.logResetPending == nil then M.logResetPending = true end
if Ui.EnterGame ~= M.fnEnterGame then
    local old = Ui.EnterGame;
    M.fnEnterGame = function(ui, ...)
        M.logResetPending = true; M.logRecs, M.logOwner = nil, nil;
        if old then return old(ui, unpack(arg)) end
    end;
    Ui.EnterGame = M.fnEnterGame;
end
function M:LogLoad()
    if self.logResetPending then
        self.logResetPending = false;
        self.logRecs, self.logOwner = {}, me.szName;
        pcall(KIo.WriteFile, self:LogFile(), Lib:Val2Str({}));
        return self.logRecs;
    end
    if self.logOwner == me.szName and self.logRecs then return self.logRecs end
    self.logRecs, self.logOwner = {}, me.szName;
    local ok, s = pcall(KIo.ReadTxtFile, self:LogFile());
    if ok and type(s) == "string" and s ~= "" then
        local ok2, t = pcall(Lib.Str2Val, Lib, s);
        if ok2 and type(t) == "table" then
            for _, r in ipairs(t) do if type(r) == "table" and r.txt then table.insert(self.logRecs, r) end end
        end
    end
    return self.logRecs;
end
function M:Log(k, txt, extra)
    local recs = self:LogLoad();
    local r = {t = stamp(), k = k, txt = txt};
    for key, v in pairs(extra or {}) do r[key] = v end
    table.insert(recs, r);
    while table.getn(recs) > self.LOG_MAX do table.remove(recs, 1) end
    pcall(KIo.WriteFile, self:LogFile(), Lib:Val2Str(recs));
    if self.ready and UiManager:WindowVisible(self.GROUP) == 1 then
        local w = Ui(self.GROUP);
        if w and w.logOpen then pcall(w.RefreshLog, w, true) end
    end
end
function M:LogClear()
    self.logRecs, self.logOwner = {}, me.szName;
    pcall(KIo.WriteFile, self:LogFile(), Lib:Val2Str({}));
end
-- Số lượng + đơn vị của phần thưởng (để tổng hợp)
function M:AwardAmount(typ, level, bet, pick)
    local mul = math.floor((bet or 2) / 2);
    if typ == 5 then return mul, "box" end
    if pick == 2 then return (self.SHELL[level] or 0) * mul, "shell" end
    local v = self.VALUES[typ] and self.VALUES[typ][level] or 0;
    if typ == 1 then return mul, "ht", v end            -- mul viên Huyền Tinh cấp v
    return v * mul, (typ == 2 and "tinhhoat" or typ == 3 and "bac" or "dong");
end
-- Mô tả phần thưởng theo loại / cấp / mức cược / cách nhận (1 vật phẩm, 2 vỏ sò)
function M:AwardText(typ, level, bet, pick)
    local mul = math.floor((bet or 2) / 2);
    if typ == 5 then return mul .. " Bảo rương" end
    if pick == 2 then return (self.SHELL[level] or 0) * mul .. " Vỏ sò" end
    local v = self.VALUES[typ] and self.VALUES[typ][level];
    if not v then return "?" end
    if typ == 1 then return mul .. " Huyền Tinh cấp " .. v end
    return v * mul .. " " .. (typ == 2 and "Tinh hoạt" or typ == 3 and "Bạc" or "Đồng khóa");
end
function M:TypeText(typ, level)
    if typ == 5 then return "Bảo rương" end
    return (self.TYPES[typ] or ("loại " .. tostring(typ))) .. " cấp " .. tostring(level);
end

-- ---------------------------------------------------------------- chạy
function M:IsRunning() return self.run ~= nil end

function M:Locked()
    return me and me.IsAccountLock and me.IsAccountLock() ~= 0;
end

function M:Start(c, limit)
    if self.run then return end
    if not me or me.IsDead() == 1 then msg("Nhân vật đang bị hạ gục."); return end
    if self:Locked() then msg("Tài khoản đang khóa, không thể dùng Bảo Rương."); return end
    local have = coins();
    local times = T(2);
    if times <= 0 and have < c.bet then msg("Không đủ vỏ sò để cược " .. c.bet .. "."); return end
    self.run = {cfg = c, limit = limit, spent = 0, spins = 0, wins = 0, losses = 0, next = GetTime(), pending = nil};
    if not self.timer then self.timer = Ui.tbLogic.tbTimer:Register(4, self.OnTimer, self) end
    msg(string.format("Bắt đầu: cược %d vỏ sò%s.", c.bet, limit and (", dùng tối đa " .. limit) or ""));
    self:Log("start", string.format("BẮT ĐẦU  cược %d | %s | có %d vỏ sò", c.bet,
        limit and ("giới hạn " .. limit) or "không giới hạn", have), {bet = c.bet});
    self:Refresh();
end

function M:Stop(why)
    local r = self.run; self.run = nil;
    if r then
        local s = string.format("Quay %d lần, nhận thưởng %d, thua %d, đã dùng %d vỏ sò.", r.spins, r.wins, r.losses, r.spent);
        msg("Dừng" .. (why and (": " .. why) or "") .. ". " .. s);
        self:Log("stop", "DỪNG  " .. (why or "") .. string.format(" | quay %d, nhận %d, thua %d, dùng %d, còn %d",
            r.spins, r.wins, r.losses, r.spent, coins()));
    end
    self:Refresh(why);
end

function M:Snapshot() return {T(1), T(2), T(3), T(4), T(6), T(7)} end
local function same(a, b) for i = 1, 6 do if a[i] ~= b[i] then return false end end return true end

function M:Send(kind, arg1, tries)
    local r = self.run;
    r.pending = {kind = kind, arg = arg1, tries = tries or 0, at = GetTime(), snap = self:Snapshot()};
    r.action = kind == "award" and "nhận thưởng" or (self:Snapshot()[2] > 0 and "Tiếp" or "quay");
    r.next = GetTime() + r.cfg.speed;
    if kind == "award" then
        me.CallServerScript({"ApplyBaibaoxiangGetAward", arg1});
    else
        me.CallServerScript({"ApplyBaibaoxiangGetResult", arg1});
    end
end

function M:Step()
    local r = self.run; if not r then return end
    local now = GetTime();
    if me.IsDead() == 1 then return self:Stop("nhân vật bị hạ gục") end
    -- chờ server trả kết quả lệnh trước
    if r.pending then
        local p = r.pending;
        if same(p.snap, self:Snapshot()) then
            if now - p.at > self.WAIT then
                -- server bỏ qua lệnh gửi sát nhau < 3 giây (không báo gì): thử lại tối đa 2 lần, cả quay lẫn nhận
                if p.tries < 2 then
                    r.pending = nil; r.next = now + 2;
                    r.retry = {kind = p.kind, arg = p.arg, tries = p.tries + 1};
                    return;
                end
                if p.kind == "award" then return self:Stop("nhận thưởng không thành công sau 3 lần (xem thông báo của hệ thống: túi đầy / bạc vượt giới hạn...)") end
                return self:Stop("server không trả kết quả quay");
            end
            return;
        end
        -- có thay đổi
        if p.kind == "spin" then
            r.spins = r.spins + 1;
            if p.snap[2] <= 0 and T(2) > 0 then
                local bet = T(4) > 0 and T(4) or r.cfg.bet;
                r.spent = r.spent + bet;
                self:Log("spin", string.format("QUAY  cược %d -> %s | đã dùng %d", bet, self:TypeText(T(3), T(1)), r.spent),
                    {ty = T(3), lv = T(1), bet = bet, amt = bet, unit = "spent"});
            elseif p.snap[2] > 0 and T(2) <= 0 then
                r.losses = r.losses + 1;   -- ra khác loại: mất lượt
                self:Log("lose", string.format("THUA  đang %s, ra loại khác (mất cược %d)", self:TypeText(p.snap[3], p.snap[1]), p.snap[4]),
                    {ty = p.snap[3], lv = p.snap[1], bet = p.snap[4], amt = p.snap[4]});
            else
                self:Log("next", string.format("TIẾP  lên %s", self:TypeText(T(3), T(1))), {ty = T(3), lv = T(1), bet = T(4)});
            end
        elseif p.kind == "award" then
            if T(2) <= 0 then
                r.wins = r.wins + 1;
                local amt, unit, htlv = self:AwardAmount(p.snap[3], p.snap[1], p.snap[4], p.arg);
                self:Log("award", string.format("NHẬN  %s <- %s (cược %d)", self:AwardText(p.snap[3], p.snap[1], p.snap[4], p.arg),
                    self:TypeText(p.snap[3], p.snap[1]), p.snap[4]),
                    {ty = p.snap[3], lv = p.snap[1], bet = p.snap[4], pick = p.arg, amt = amt, unit = unit, htlv = htlv});
            end
        end
        r.pending = nil;
        self:Refresh();
    end
    if now < r.next then return end
    if r.retry then local x = r.retry; r.retry = nil; return self:Send(x.kind or "spin", x.arg, x.tries) end
    local level, times, typ, bet, over, cont = T(1), T(2), T(3), T(4), T(6), T(7);
    local c = r.cfg;
    if times <= 0 then
        -- lượt mới
        if r.limit and r.spent + c.bet > r.limit then return self:Stop("đã dùng hết giới hạn " .. r.limit .. " vỏ sò") end
        if coins() < c.bet then return self:Stop("không đủ vỏ sò") end
        return self:Send("spin", c.bet);
    end
    -- đang có kết quả
    if typ == 5 then return self:Send("award", 1) end                 -- Bảo rương: chỉ nhận vật phẩm
    if typ < 1 or typ > 4 then return self:Stop("trạng thái Bách Bảo Rương không rõ (loại " .. tostring(typ) .. ")") end
    local pick = c.pick[typ] == 2 and 2 or 1;
    if level >= 6 or over == 1 or cont ~= 1 then return self:Send("award", pick) end   -- không quay tiếp được nữa
    if level >= (c.lv[typ] or 6) and c.nxt[typ] ~= 1 then return self:Send("award", pick) end -- đạt cấp, không tick Tiếp
    return self:Send("spin", bet > 0 and bet or c.bet);                -- chưa đạt cấp, hoặc tick Tiếp
end

function M:OnTimer()
    if self.run then
        local ok, why = pcall(self.Step, self);
        if not ok then self:Stop("lỗi: " .. tostring(why)) end
    end
    if self.ready and UiManager:WindowVisible(self.GROUP) == 1 then
        pcall(self.RefreshCoin, self);
        local w = Ui(self.GROUP);
        if w and w.logOpen then pcall(w.RefreshLog, w, false) end
    end
    if not self.run and not (self.ready and UiManager:WindowVisible(self.GROUP) == 1) then
        self.timer = nil;
        return 0;
    end
    return 4;
end

-- ---------------------------------------------------------------- cửa sổ
function M:Register()
    if self.ready then return true end
    local native = LoadUiGroup;
    local buffer = self.INI .. string.rep("\0", 256 - string.len(self.INI));
    LoadUiGroup = function(group, name, a, b)
        if group == M.GROUP then name = buffer end
        return native(group, name, a, b);
    end;
    local ok, why = pcall(Ui.RegisterNewUiWindow, Ui, self.GROUP, self.CLASS, {"a", 200, 120}, {"b", 300, 180}, {"c", 420, 200});
    LoadUiGroup = native;
    if not ok then error(why) end
    local w, h = Wnd_GetSize(self.GROUP, "Main");
    if not w or w <= 0 or not h or h <= 0 then
        LoadUiGroup(self.GROUP, self.INI_PATH);
        w, h = Wnd_GetSize(self.GROUP, "Main");
    end
    assert(w and w > 0 and h and h > 0, "Chưa nạp " .. self.INI .. "; hãy thoát hẳn game rồi vào lại.");
    self.ready = true;
    return true;
end

function M:Open()
    if UiManager:WindowVisible(self.GROUP) ~= 1 and self:Locked() then
        msg("Tài khoản đang khóa, không thể mở Bảo Rương."); return;
    end
    local ok, why = pcall(self.Register, self);
    if not ok then msg("Không mở được cửa sổ: " .. tostring(why)); return end
    if UiManager:WindowVisible(self.GROUP) == 1 then UiManager:CloseWindow(self.GROUP); return end
    UiManager:OpenWindow(self.GROUP);
end

local V = Ui:GetClass(M.CLASS);

function M:RefreshCoin()
    local g = self.GROUP;
    Txt_SetTxt(g, "TxtCoin", "Số Vỏ Sò hiện có: " .. coins());
    local r = self.run;
    if r then
        local lv, typ = T(1), T(3);
        local now = "chờ quay";
        if T(2) > 0 then
            if typ == 5 then now = "ra Bảo rương"
            elseif self.TYPES[typ] then now = self.TYPES[typ] .. " cấp " .. lv end
        end
        Txt_SetTxt(g, "TxtState", string.format("ĐANG CHẠY | %s | quay %d, nhận %d, thua %d, dùng %d",
            now, r.spins, r.wins, r.losses, r.spent));
    end
end

function M:Refresh(note)
    if not (self.ready and UiManager:WindowVisible(self.GROUP) == 1) then return end
    local g, running = self.GROUP, self.run ~= nil;
    if not running then Txt_SetTxt(g, "TxtState", "ĐÃ DỪNG") end
    pcall(self.RefreshCoin, self);
    Btn_SetTxt(g, "BtnStart", running and "Dừng" or "Bắt Đầu");
    for _, name in ipairs({"BtnLimit", "EdtLimit", "BtnBet2", "BtnBet10", "BtnBet50", "BtnSave", "ScrSpeed",
        "CmbLv1", "CmbLv2", "CmbLv3", "CmbLv4", "CmbPick1", "CmbPick2", "CmbPick3", "CmbPick4",
        "BtnNext1", "BtnNext2", "BtnNext3", "BtnNext4"}) do
        Wnd_SetEnable(g, name, running and 0 or 1);
    end
    if note then Txt_SetTxt(g, "TxtMessage", note) end
end

-- Ô Cấp Sao ghi giá trị gốc * hệ số cược (2 -> *1, 10 -> *5, 50 -> *25), như giao diện gốc.
function V:FillLevels()
    local c = self.draft; local g = self.UIGROUP;
    local mul = c.bet / 2;
    local old = self.binding; self.binding = true;
    for i = 1, 4 do
        ClearComboBoxItem(g, "CmbLv" .. i);
        for lv = 1, 6 do
            ComboBoxAddItem(g, "CmbLv" .. i, lv, "Cấp " .. lv .. " (" .. short(M.VALUES[i][lv]) .. "*" .. mul .. ")");
        end
        ComboBoxSelectItem(g, "CmbLv" .. i, c.lv[i] - 1);
    end
    self.binding = old;
end

function V:Bind()
    local c = self.draft; local g = self.UIGROUP;
    self.binding = true;
    for _, b in ipairs(M.BETS) do Btn_Check(g, M.BET_BTN[b], c.bet == b and 1 or 0) end
    self:FillLevels();
    for i = 1, 4 do
        ClearComboBoxItem(g, "CmbPick" .. i);
        ComboBoxAddItem(g, "CmbPick" .. i, 1, "Vật phẩm");
        ComboBoxAddItem(g, "CmbPick" .. i, 2, "Vỏ sò");
        ComboBoxSelectItem(g, "CmbPick" .. i, c.pick[i] - 1);
        Btn_Check(g, "BtnNext" .. i, c.nxt[i] == 1 and 1 or 0);
    end
    ScrBar_SetCurValue(g, "ScrSpeed", c.speed - 3);
    Txt_SetTxt(g, "TxtSpeed", "Tốc độ: " .. c.speed .. " giây");
    self.binding = false;
end

-- ---------- Lịch Sử ----------
M.HIDE_ON_LOG = {"TxtCoin", "BtnLimit", "LimitBg", "EdtLimit", "TxtBet", "BtnBet2", "BtnBet10", "BtnBet50",
    "TxtHead1", "TxtHead2", "TxtHead3", "TxtHead4", "TxtBox", "TxtSpeed", "ScrSpeed", "TxtMessage",
    "TxtAward1", "TxtAward2", "TxtAward3", "TxtAward4", "CmbLv1", "CmbLv2", "CmbLv3", "CmbLv4",
    "BtnNext1", "BtnNext2", "BtnNext3", "BtnNext4", "CmbPick1", "CmbPick2", "CmbPick3", "CmbPick4"};

function V:ShowLog(on)
    local g = self.UIGROUP;
    self.logOpen = on and true or nil;
    for _, n in ipairs(M.HIDE_ON_LOG) do if on then Wnd_Hide(g, n) else Wnd_Show(g, n) end end
    if on then
        Wnd_Show(g, "LogPanel");
        self.binding = true;
        ClearComboBoxItem(g, "CmbLogFilter");
        for k, f in ipairs(M.FILTERS) do ComboBoxAddItem(g, "CmbLogFilter", k, f.name) end
        ComboBoxSelectItem(g, "CmbLogFilter", (self.logFilter or 1) - 1);
        self.binding = false;
        self:RefreshLog(true);
    else
        Wnd_Hide(g, "LogPanel");
    end
    Btn_SetTxt(g, "BtnHistory", on and "Cài Đặt" or "Lịch Sử");
end

local function match(f, r)
    if f.k == "spin" then return r.k == "spin" or r.k == "next" end
    if f.k and r.k ~= f.k then return false end
    if f.unit and r.unit ~= f.unit then return false end
    return true;
end

-- Tổng hợp theo bộ lọc đang chọn
function V:LogSummary(f, rows)
    local n = table.getn(rows);
    if not f.k then
        local spent, shell, wins, lose = 0, 0, 0, 0;
        for _, r in ipairs(rows) do
            if r.k == "spin" and r.unit == "spent" then spent = spent + (r.amt or 0) end
            if r.k == "award" then wins = wins + 1; if r.unit == "shell" then shell = shell + (r.amt or 0) end end
            if r.k == "lose" then lose = lose + 1 end
        end
        return string.format("Tổng: dùng %d vỏ sò | nhận thưởng %d lần (đổi được %d vỏ sò) | thua %d lần", spent, wins, shell, lose);
    end
    if f.k == "lose" then
        local lost = 0; for _, r in ipairs(rows) do lost = lost + (r.amt or 0) end
        return string.format("Thua %d lần, mất %d vỏ sò tiền cược", n, lost);
    end
    if f.k == "spin" then
        local spent = 0; for _, r in ipairs(rows) do if r.unit == "spent" then spent = spent + (r.amt or 0) end end
        return string.format("%d lượt quay/tiếp, dùng %d vỏ sò", n, spent);
    end
    -- nhận thưởng: cộng theo đơn vị (Huyền Tinh cộng theo cấp HT)
    local sum, ht, order = {}, {}, {"tinhhoat", "bac", "dong", "box", "shell"};
    for _, r in ipairs(rows) do
        if r.unit == "ht" then ht[r.htlv or 0] = (ht[r.htlv or 0] or 0) + (r.amt or 0)
        elseif r.unit then sum[r.unit] = (sum[r.unit] or 0) + (r.amt or 0) end
    end
    local parts = {};
    for lv = 1, 12 do if ht[lv] then table.insert(parts, ht[lv] .. " HT cấp " .. lv) end end
    for _, u in ipairs(order) do if sum[u] then table.insert(parts, sum[u] .. " " .. M.UNIT_NAME[u]) end end
    return string.format("%d lần nhận | tổng: %s", n, table.getn(parts) > 0 and table.concat(parts, ", ") or "0");
end

-- rebuild=true: dựng lại danh sách (có bản ghi mới / đổi lọc); false: chỉ cập nhật dòng trạng thái
function V:RefreshLog(rebuild)
    local g = self.UIGROUP;
    if rebuild then
        local f = M.FILTERS[self.logFilter or 1] or M.FILTERS[1];
        local recs, rows = M:LogLoad(), {};
        for k = table.getn(recs), 1, -1 do if match(f, recs[k]) then table.insert(rows, recs[k]) end end   -- mới nhất trước
        Lst_Clear(g, "LstLog");
        for k, r in ipairs(rows) do Lst_SetCell(g, "LstLog", k, 0, r.t .. "  " .. r.txt) end
        if table.getn(rows) == 0 then Lst_SetCell(g, "LstLog", 1, 0, "Chưa có lịch sử.") end
        Txt_SetTxt(g, "TxtLogSum", self:LogSummary(f, rows));
    end
    local r = M.run;
    local s;
    if r then
        local now = "chờ thao tác";
        if r.pending then now = "đang " .. (r.action or "chờ") .. "..."
        elseif T(2) > 0 then now = "đang giữ " .. M:TypeText(T(3), T(1)) end
        s = string.format("ĐANG CHẠY | %s<enter>Cược %d | đã dùng %d%s vỏ sò | quay %d, nhận %d, thua %d",
            now, r.cfg.bet, r.spent, r.limit and ("/" .. r.limit) or "", r.spins, r.wins, r.losses);
    else
        s = "ĐÃ DỪNG" .. (T(2) > 0 and (" | còn lượt dở: " .. M:TypeText(T(3), T(1))) or "") ..
            "<enter>Vỏ sò hiện có: " .. coins();
    end
    Txt_SetTxt(g, "TxtLogState", s);
end

function V:OnOpen()
    self.draft = M:Load();
    local have = coins();
    Btn_Check(self.UIGROUP, "BtnLimit", 1);                 -- mặc định: giới hạn = số vỏ sò đang có
    Edt_SetInt(self.UIGROUP, "EdtLimit", have);
    self:Bind();
    Txt_SetTxt(self.UIGROUP, "TxtMessage", "");
    self:ShowLog(false);
    if not M.timer then M.timer = Ui.tbLogic.tbTimer:Register(4, M.OnTimer, M) end
    M:Refresh();
    return 1;
end

function V:OnClose() end   -- đóng cửa sổ không dừng auto

function V:OnComboBoxIndexChange(name, index)
    if self.binding then return end
    if name == "CmbLogFilter" then
        self.logFilter = math.max(1, math.min(table.getn(M.FILTERS), (tonumber(index) or 0) + 1));
        self:RefreshLog(true); return;
    end
    if not self.draft then return end
    local i = tonumber(string.match(name, "^CmbLv(%d)$"));
    if i then self.draft.lv[i] = clamp((tonumber(index) or 0) + 1, 1, 6); return end
    i = tonumber(string.match(name, "^CmbPick(%d)$"));
    if i then self.draft.pick[i] = (tonumber(index) or 0) == 1 and 2 or 1 end
end

function V:OnScorllbarPosChanged(name, value)
    if name ~= "ScrSpeed" or not self.draft then return end
    self.draft.speed = clamp((tonumber(value) or 1) + 3, 3, 10);
    Txt_SetTxt(self.UIGROUP, "TxtSpeed", "Tốc độ: " .. self.draft.speed .. " giây");
end

function V:OnEditChange(name)
    if self.binding or name ~= "EdtLimit" then return end
    local n = Edt_GetInt(self.UIGROUP, name) or 0;
    local c = clamp(n, 0, 9999999);
    if c ~= n then self.binding = true; Edt_SetInt(self.UIGROUP, name, c); self.binding = false end
end

function V:Limit()
    if Btn_GetCheck(self.UIGROUP, "BtnLimit") ~= 1 then return nil end
    return clamp(Edt_GetInt(self.UIGROUP, "EdtLimit"), 0, 9999999);
end

function V:OnButtonClick(name, value)
    local g = self.UIGROUP;
    if name == "BtnClose" then UiManager:CloseWindow(g); return end
    if name == "BtnHistory" then self:ShowLog(not self.logOpen); return end
    if name == "BtnLogBack" then self:ShowLog(false); return end
    if name == "BtnLogClear" then M:LogClear(); self:RefreshLog(true); return end
    local n = tonumber(string.match(name, "^BtnNext(%d)$"));
    if n then self.draft.nxt[n] = value == 1 and 1 or 0; return end
    for _, b in ipairs(M.BETS) do
        if name == M.BET_BTN[b] then
            self.draft.bet = b;
            for _, b2 in ipairs(M.BETS) do Btn_Check(g, M.BET_BTN[b2], b2 == b and 1 or 0) end
            self:FillLevels();
            return;
        end
    end
    if name == "BtnSave" then
        if M:Save(self.draft) then Txt_SetTxt(g, "TxtMessage", "Đã lưu cài đặt.") else Txt_SetTxt(g, "TxtMessage", "Không ghi được cài đặt.") end
        return;
    end
    if name == "BtnStart" then
        if M:IsRunning() then M:Stop("bấm Dừng"); return end
        M:Save(self.draft);
        local limit = self:Limit();
        if limit and limit < self.draft.bet and T(2) <= 0 then
            Txt_SetTxt(g, "TxtMessage", "Giới hạn sử dụng (" .. limit .. ") nhỏ hơn tiền cược (" .. self.draft.bet .. ")."); return;
        end
        M:Start(M:Load(), limit);
        return;
    end
    if name == "BtnManual" then
        if M:Locked() then Txt_SetTxt(g, "TxtMessage", "Tài khoản đang khóa, không thể mở Bảo Rương."); return end
        if M:IsRunning() then M:Stop("chuyển sang quay thủ công") end
        UiManager:OpenWindow(Ui.UI_BAIBAOXIANG, 1);
        return;
    end
end
