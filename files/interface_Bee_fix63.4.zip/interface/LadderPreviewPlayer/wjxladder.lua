-- Bảng Xếp Hạng mới (by HUKT) — plugin LadderPreviewPlayer.
-- Ctrl+C mở cửa sổ này (thay cho BXH cũ). 5 tab: Uy Danh / Đẳng Cấp / Võ Lâm / Thủ Lĩnh / Tài Phú (mở sẵn tab Đẳng Cấp).
-- Mỗi tab hiện 5 người đứng đầu, 5 ô từ trái sang phải ứng với hạng 5 2 1 3 4 (hạng 1 ở giữa).
-- Mỗi ô (từ dưới lên): khung model → vòng sáng dưới chân (StateEffect) → ngựa → nhân vật → viền model → danh hiệu (Title);
-- phía dưới: khung hạng + chữ với Hạng, Tên, Điểm, Phái - Cấp, Gia Tộc (Bang).
-- Các .spr động khai báo theo tab + hạng trong ladder_spr.txt; không khai thì dùng mặc định ở \image\ui\001a\ladder\preview\:
--   rank<N>_model_bg / _model_border / _info / _title / _stateeffect .spr   (thiếu file nào thì lớp đó để trống)
-- Ngoại hình: đọc ladder_model.txt theo mốc mở cấp (suy từ cấp Top 1 Xếp Hạng Đẳng Cấp) + Phái/Hệ + Giới tính.
-- Nút "Xem Chi Tiết": đóng cửa sổ này rồi mở BXH cũ (UI_LADDER) đúng mục đang xem.
-- Không sửa file gốc: chỉ trỏ alias "UI_LADDER" (Ctrl+C) sang cửa sổ mới; BXH cũ giữ nguyên.

Ui.WJXLadderPreview = Ui.WJXLadderPreview or {};
local L = Ui.WJXLadderPreview;
L.GROUP    = "UI_WJXLADDERPREVIEW";
L.CLASS    = "wjxladder_main";
L.INI      = "wjxladder_main.ini";
L.INI_PATH = "\\interface\\LadderPreviewPlayer\\wjxladder_main.ini";
L.MODEL_TXT = "\\interface\\LadderPreviewPlayer\\ladder_model.txt";
L.VERSION  = "1.3.5";
L.CMD      = "Ui.WJXLadderPreview:Open()";

-- Mã BXH theo setting\player\ladderid.txt (HUGE_ID, MID_ID, SMALL_ID). Thứ tự = thứ tự nút trên cửa sổ.
L.TABS = {
    {btn = "BtnTab1", page = 2, gen = 2, sub = 4, name = "Xếp Hạng Uy Danh",   point = "Điểm Uy Danh"},
    {btn = "BtnTab2", page = 2, gen = 1, sub = 0, name = "Xếp Hạng Đẳng Cấp",  point = "Cấp"},
    {btn = "BtnTab3", page = 4, gen = 1, sub = 0, name = "Xếp Hạng Võ Lâm",    point = "Điểm Võ Lâm"},
    {btn = "BtnTab4", page = 5, gen = 1, sub = 0, name = "Xếp Hạng Thủ Lĩnh",  point = "Điểm Thủ Lĩnh"},
    {btn = "BtnTab5", page = 6, gen = 1, sub = 0, name = "Xếp Hạng Tài Phú",   point = "Điểm Tài Phú"},
};
L.DEFAULT_TAB = 2;           -- mở cửa sổ là chọn sẵn Xếp Hạng Đẳng Cấp
L.LEVEL_TAB   = 2;           -- tab dùng để suy mốc mở cấp (cấp của Top 1)
L.ORDER = {5, 2, 1, 3, 4};   -- ô 1..5 (trái → phải) ứng với hạng
L.SLOTS = 5;
L.RES_DEFAULT = 1;           -- dùng khi ladder_model.txt không có dòng nào khớp

-- ================================================================ CẤU HÌNH VỊ TRÍ (chỉnh ở đây)
-- Vị trí gốc của ô nhân vật k (giống ObjPreview trong wjxladder_main.ini).
local SLOT_LEFT = function(k) return 11 + (k - 1) * 137; end
local SLOT_DY   = {24, 6, -12, 6, 24};
-- MODEL_DY: dời cả cụm nhân vật + ngựa + vòng sáng + danh hiệu lên (số âm) / xuống (số dương).
-- L.MODEL_DY = -36;
L.MODEL_DY = -1;
function L:CharBase(k) return SLOT_LEFT(k) + 8, 158 + SLOT_DY[k] + self.MODEL_DY; end

-- Khi có ngựa: nhân vật dịch phải CHAR_DX, ngựa đứng bên trái (lệch HORSE_DX, HORSE_DY so với vị trí gốc), hướng HORSE_DIR.
L.CHAR_DX   = 16;
L.HORSE_DX  = -16;
L.HORSE_DY  = -4;
L.HORSE_DIR = 1;

-- Điểm chân / điểm trên đầu của nhân vật, tính từ góc ô nhân vật (ObjPreview).
L.FOOT = {58, 37}; -- X tăng sang phải, Y tăng sẽ đi xuống
L.HEAD = {58, -36}; -- X tăng sang phải, Y tăng sẽ đi xuống
-- Chữ "Hạng N" (khi không có spr danh hiệu) đặt giữa điểm HEAD; kích thước ô chữ trong .ini.
L.RANK_TXT_SIZE = {131, 18};
-- Tâm của file .spr (centerX, centerY trong header SPR) theo hạng 1..5.
-- Ô ảnh vẽ từ góc trên-trái nên trừ tâm để tâm spr rơi đúng chân / đầu. Đổi spr thì sửa lại số ở đây.
L.STATE_CENTER = {{76, 55}, {76, 55}, {76, 55}, {76, 55}, {76, 55}};   -- vòng sáng (giống halo Partner)
L.TITLE_CENTER = {{65, 20}, {65, 20}, {65, 20}, {65, 20}, {65, 20}};   -- danh hiệu (khung 131x40)

-- Khung .spr động (dùng chung cho mọi tab). Tên ô trong .ini → hậu tố file.
L.SPR_DIR = "\\image\\ui\\001a\\ladder\\preview\\";
-- key = tên cột trong ladder_spr.txt; file = tên mặc định khi txt không khai (rank<N> + file).
L.FRAMES = {
    {wnd = "ImgModelBg",     key = "ModelBg",     file = "_model_bg.spr"},       -- sau lưng nhân vật
    {wnd = "ImgModelBorder", key = "ModelBorder", file = "_model_border.spr"},   -- viền, đè lên nhân vật
    {wnd = "ImgInfoBg",      key = "Info",        file = "_info.spr"},           -- sau hạng + chữ
};
-- Hai lớp chỉ hiện khi ô có người chơi, bám theo vị trí nhân vật. cx/cy = cột tâm spr trong txt.
L.FX = {
    {wnd = "ImgStateEffect", key = "StateEffect", file = "_stateeffect.spr", point = "FOOT", center = "STATE_CENTER", cx = "StateCX", cy = "StateCY"},
    {wnd = "ImgTitle",       key = "Title",       file = "_title.spr",       point = "HEAD", center = "TITLE_CENTER", cx = "TitleCX", cy = "TitleCY", nodefault = true},
};
L.SPR_TXT = "\\interface\\LadderPreviewPlayer\\ladder_spr.txt";

local function say(why) if me and me.Msg then me.Msg("[Bảng Xếp Hạng] " .. tostring(why)); end end

-- ---------------------------------------------------------------- tiện ích dữ liệu
function L:TypeOf(nTab)
    local t = self.TABS[nTab];
    local n = 0;
    n = KLib.SetByte(n, 3, t.page);
    n = KLib.SetByte(n, 2, t.gen);
    n = KLib.SetByte(n, 1, t.sub);
    return n;
end

-- Bỏ phần nhãn "xxx:" / "xxx：" ở đầu chuỗi (szTxt4 / szTxt5 có dạng "Gia tộc: Tên").
local function value(s)
    s = tostring(s or "");
    local p = string.find(s, "：", 1, true);
    local w = 3;
    if not p then p = string.find(s, ":", 1, true); w = 1; end
    if p then s = string.sub(s, p + w); end
    s = string.gsub(s, "^%s+", "");
    s = string.gsub(s, "%s+$", "");
    return s;
end

local function trim(s)
    s = tostring(s or "");
    s = string.gsub(s, "^%s+", "");
    s = string.gsub(s, "%s+$", "");
    return s;
end

-- Số đầu tiên trong chuỗi (szTxt1 "12345 điểm…", szTxt3 "150 cấp"…). nil nếu không có.
local function firstNumber(s)
    s = tostring(s or "");
    local a, b = string.find(s, "%d+");
    if not a then return nil; end
    return string.sub(s, a, b);
end

-- 1234567 → "1.234.567"
local function group(sz)
    local out = sz;
    while true do
        local n;
        out, n = string.gsub(out, "^(%d+)(%d%d%d)", "%1.%2");
        if n == 0 then break; end
    end
    return out;
end

function L:KinText(p)
    local szKin, szTong = value(p.szTxt4), value(p.szTxt5);
    if szKin == "" then return szTong; end
    if szTong == "" then return szKin; end
    return szKin .. " (" .. szTong .. ")";
end

function L:PointText(p)
    local t = self.TABS[self.nTab or 1];
    local n = firstNumber(p.szTxt1);
    if n then return t.point .. ": " .. group(n); end
    return tostring(p.szTxt1 or "");
end

-- "Phái - Cấp N" trên cùng 1 dòng.
function L:FactionLevelText(p)
    local szFaction = tostring(p.szTxt2 or "");
    local n = firstNumber(p.szTxt3);
    local szLevel = n and ("Cấp " .. n) or tostring(p.szTxt3 or "");
    if szFaction == "" then return szLevel; end
    if szLevel == "" then return szFaction; end
    return szFaction .. " - " .. szLevel;
end

-- ---------------------------------------------------------------- ladder_model.txt
-- Cột: TimeFrame  Faction  Route  Sex  Helm  Armor  Weapon  Mantle  Horse  Note
-- Bỏ qua dòng mô tả / dòng có TimeFrame bắt đầu bằng "#" / TimeFrame không chứa số cấp.
function L:LoadModels()
    self.tbModel = {};
    self.tbFrameLevel = {};          -- danh sách cấp mốc đã khai báo, tăng dần (69, 79, 89...)
    local ok, tbRows = pcall(Lib.LoadTabFile, Lib, self.MODEL_TXT);
    if not ok or type(tbRows) ~= "table" then
        say("Không đọc được ladder_model.txt, dùng ngoại hình mặc định.");
        return;
    end
    local tbSeen = {};
    for _, r in pairs(tbRows) do
        local szFrame = trim(r.TimeFrame);
        local nCap = tonumber(firstNumber(szFrame));
        if szFrame ~= "" and string.sub(szFrame, 1, 1) ~= "#" and nCap and tonumber(r.Sex) then
            local m = {
                nCap     = nCap,
                nFaction = tonumber(r.Faction) or 0,
                nRoute   = tonumber(r.Route) or 0,
                nSex     = tonumber(r.Sex) or -1,
                nHelm    = tonumber(r.Helm) or 0,
                nArmor   = tonumber(r.Armor) or 0,
                nWeapon  = tonumber(r.Weapon) or 0,
                nMantle  = tonumber(r.Mantle) or 0,
                nHorse   = tonumber(r.Horse) or 0,
            };
            table.insert(self.tbModel, m);
            if not tbSeen[nCap] then
                tbSeen[nCap] = 1;
                table.insert(self.tbFrameLevel, nCap);
            end
        end
    end
    table.sort(self.tbFrameLevel);
end

-- Tên hệ / tên phái (như szTxt2 trên BXH) → {phái, hệ}. Lập 1 lần từ Player:GetFactionRouteName của client.
-- function L:BuildRouteMap()
    -- if self.tbRouteMap then return; end
    -- self.tbRouteMap = {};
    -- if not (Player and Player.GetFactionRouteName) then return; end
    -- local nNum = tonumber(Player.FACTION_NUM) or 12;
    -- for f = 1, nNum do
        -- local ok, szF = pcall(Player.GetFactionRouteName, Player, f);
        -- if ok and szF and szF ~= "" and not self.tbRouteMap[szF] then
            -- self.tbRouteMap[szF] = {f, 0};
        -- end
        -- for r = 1, 2 do
            -- local ok2, szR = pcall(Player.GetFactionRouteName, Player, f, r);
            -- if ok2 and szR and szR ~= "" then self.tbRouteMap[szR] = {f, r}; end
        -- end
    -- end
-- end

function L:BuildRouteMap()
    if self.tbRouteMap then return; end
    self.tbRouteMap = {};
    self.tbRouteList = {};
    local nNum = tonumber(Player and Player.FACTION_NUM) or 14;
    for f = 1, nNum do
        -- 1. Lấy tên Môn Phái chuẩn từ bảng tbFactions của client (fallback sang GetFactionRouteName)
        local szF = Player and Player.tbFactions and Player.tbFactions[f] and Player.tbFactions[f].szName;
        if not szF or szF == "" then
            local ok, res = pcall(Player.GetFactionRouteName, Player, f);
            if ok then szF = res; end
        end
        if szF and szF ~= "" then
            szF = trim(szF);
            self.tbRouteMap[szF] = {f, 0};
            table.insert(self.tbRouteList, {name = szF, f = f, r = 0});
        end

        -- 2. Lấy tên Hệ/Nhánh (Route 1, 2)
        for r = 1, 2 do
            local ok2, szR = pcall(Player.GetFactionRouteName, Player, f, r);
            if ok2 and szR and szR ~= "" then
                szR = trim(szR);
                self.tbRouteMap[szR] = {f, r};
                table.insert(self.tbRouteList, {name = szR, f = f, r = r});
            end
        end
    end
    -- Ưu tiên khớp tên dài (tên Hệ) trước tên ngắn (tên Phái)
    table.sort(self.tbRouteList, function(a, b) return string.len(a.name) > string.len(b.name); end);
end

-- function L:FactionRouteOf(p)
    -- self:BuildRouteMap();
    -- local t = self.tbRouteMap[trim(p.szTxt2)];
    -- if t then return t[1], t[2]; end
    -- return 0, 0;
-- end

function L:FactionRouteOf(p)
    self:BuildRouteMap();
    local szRaw = trim(value(p.szTxt2));
    if szRaw == "" then return 0, 0; end

    local t = self.tbRouteMap[szRaw];
    if t then return t[1], t[2]; end

    for _, item in ipairs(self.tbRouteList or {}) do
        if string.find(szRaw, item.name, 1, true) then
            return item.f, item.r;
        end
    end
    return 0, 0;
end

-- Mốc mở cấp: cấp Top 1 của Xếp Hạng Đẳng Cấp → mốc nhỏ nhất có cấp ≥ cấp đó (vượt hết thì lấy mốc cao nhất).
function L:UpdateTopLevel()
    local tb = self.tbSnap and self.tbSnap[self.LEVEL_TAB];
    local p = tb and type(tb.tbLadder) == "table" and tb.tbLadder[1];
    if p then
        local n = tonumber(firstNumber(p.szTxt3)) or tonumber(firstNumber(p.szTxt1));
        if n and n > 0 then self.nTopLevel = n; end
    end
    return self.nTopLevel;
end

-- function L:CurrentCap()
    -- local tbCap = self.tbFrameLevel or {};
    -- if #tbCap == 0 then return nil; end
    -- local nTop = self:UpdateTopLevel();
    -- if not nTop then return tbCap[1]; end
    -- for _, nCap in ipairs(tbCap) do
        -- if nTop <= nCap then return nCap; end
    -- end
    -- return tbCap[#tbCap];
-- end

function L:CurrentCap()
    local tbCap = self.tbFrameLevel or {};
    if #tbCap == 0 then return nil; end
    local nTop = self:UpdateTopLevel();
    if not nTop then return tbCap[1]; end

    -- Duyệt từ mốc cao nhất xuống thấp nhất: đạt đủ cấp mốc nào (nTop >= nCap) thì lấy mốc đó
    for i = #tbCap, 1, -1 do
        if nTop >= tbCap[i] then
            return tbCap[i];
        end
    end

    -- Nếu cấp Top 1 thấp hơn cả mốc nhỏ nhất trong file txt thì trả về mốc nhỏ nhất
    return tbCap[1];
end

-- Chọn dòng khớp nhất trong 1 mốc: đúng phái+hệ (3) > đúng phái, hệ 0 (2) > 0/0 (1); giới tính đúng > -1.
-- function L:PickInCap(nCap, nFaction, nRoute, nSex)
    -- local best, nBest = nil, 0;
    -- for _, m in ipairs(self.tbModel or {}) do
        -- if m.nCap == nCap and (m.nSex == nSex or m.nSex == -1) then
            -- local s = 0;
            -- if m.nFaction == nFaction and nFaction ~= 0 and m.nRoute == nRoute and nRoute ~= 0 then s = 3;
            -- elseif m.nFaction == nFaction and nFaction ~= 0 and m.nRoute == 0 then s = 2;
            -- elseif m.nFaction == 0 and m.nRoute == 0 then s = 1; end
            -- if s > 0 then
                -- s = s * 2 + ((m.nSex == nSex) and 1 or 0);
                -- if s > nBest then best, nBest = m, s; end
            -- end
        -- end
    -- end
    -- return best;
-- end

function L:PickInCap(nCap, nFaction, nRoute, nSex)
    local best, nBest = nil, 0;
    for _, m in ipairs(self.tbModel or {}) do
        if m.nCap == nCap and (m.nSex == nSex or m.nSex == -1) then
            local s = 0;
            if m.nFaction == nFaction and nFaction ~= 0 then
                if m.nRoute == nRoute and nRoute ~= 0 then
                    s = 4;      -- Khớp cả Phái + Hệ
                elseif m.nRoute == 0 then
                    s = 3;      -- Khớp Phái, dòng mặc định Route = 0
                elseif nRoute == 0 then
                    s = 2;      -- BXH chỉ trả về Phái (nRoute = 0) -> lấy tạm Route 1/2 của Phái đó
                end
            elseif m.nFaction == 0 and m.nRoute == 0 then
                s = 1;          -- Mặc định chung toàn server
            end
            if s > 0 then
                s = s * 2 + ((m.nSex == nSex) and 1 or 0);
                if s > nBest then best, nBest = m, s; end
            end
        end
    end
    return best;
end

-- Mốc hiện tại không có dòng khớp → lùi về các mốc thấp hơn.
function L:PickModel(p)
    local nSex = (tonumber(p.dwImgType) == 1) and 1 or 0;
    local nFaction, nRoute = self:FactionRouteOf(p);
    local nCap = self:CurrentCap();
    if not nCap then return nil, nSex; end
    local tbCap = self.tbFrameLevel;
    for i = #tbCap, 1, -1 do
        if tbCap[i] <= nCap then
            local m = self:PickInCap(tbCap[i], nFaction, nRoute, nSex);
            if m then return m, nSex; end
        end
    end
    return nil, nSex;
end

local function part(tb, szKey, nRes)
    local nPart = Npc[szKey];
    if nPart then tb[nPart] = {nResId = nRes or 0, nChangeColorScheme = 0}; end
end

-- Trả về: obj nhân vật, obj ngựa (nil nếu không có ngựa).
function L:BuildObj(p)
    local m, nSex = self:PickModel(p);
    local tbPart = {};
    if m then
        part(tbPart, "NPCRES_PART_HELM",   m.nHelm);
        part(tbPart, "NPCRES_PART_ARMOR",  m.nArmor);
        part(tbPart, "NPCRES_PART_WEAPON", m.nWeapon);
        part(tbPart, "NPCRES_PART_MANTLE", m.nMantle);
    else
        part(tbPart, "NPCRES_PART_HELM",   self.RES_DEFAULT);
        part(tbPart, "NPCRES_PART_ARMOR",  self.RES_DEFAULT);
        part(tbPart, "NPCRES_PART_WEAPON", self.RES_DEFAULT);
        part(tbPart, "NPCRES_PART_MANTLE", self.RES_DEFAULT);
    end
    part(tbPart, "NPCRES_PART_HORSE", 0);   -- nhân vật đứng, không cưỡi
    local tbObj = {};
    tbObj.nType       = Ui.OBJ_NPCRES;
    tbObj.nTemplateId = (nSex == 1) and -2 or -1;   -- -1 nam, -2 nữ
    tbObj.nAction     = Npc.ACT_STAND1;
    tbObj.tbPart      = tbPart;
    tbObj.nDir        = 0;
    tbObj.bRideHorse  = 0;

    local tbHorse = nil;
    -- if m and m.nHorse > 0 then -- Ngựa đứng riêng: vẽ NPC ngựa theo Id trong setting\npc\npc.txt (như cách game vẽ đồng hành).
        -- tbHorse = {};
        -- tbHorse.nType       = Ui.OBJ_NPCRES;
        -- tbHorse.nTemplateId = m.nHorse;
        -- tbHorse.nAction     = Npc.ACT_STAND1;
        -- tbHorse.tbPart      = {};
        -- tbHorse.nDir        = self.HORSE_DIR;
        -- tbHorse.bRideHorse  = 0;
    -- end
    return tbObj, tbHorse;
end

-- function L:BuildObj(p) -- Vẽ 2 Player đứng cạnh nhau
    -- local m, nSex = self:PickModel(p);

    -- local tbPart = {}; -- 1. NHÂN VẬT CHÍNH
    -- if m then
        -- part(tbPart, "NPCRES_PART_HELM",   m.nHelm);
        -- part(tbPart, "NPCRES_PART_ARMOR",  m.nArmor);
        -- part(tbPart, "NPCRES_PART_WEAPON", m.nWeapon);
        -- part(tbPart, "NPCRES_PART_MANTLE", m.nMantle);
    -- else
        -- part(tbPart, "NPCRES_PART_HELM",   self.RES_DEFAULT);
        -- part(tbPart, "NPCRES_PART_ARMOR",  self.RES_DEFAULT);
        -- part(tbPart, "NPCRES_PART_WEAPON", self.RES_DEFAULT);
        -- part(tbPart, "NPCRES_PART_MANTLE", self.RES_DEFAULT);
    -- end
    -- part(tbPart, "NPCRES_PART_HORSE", 0);

    -- local tbObj = {};
    -- tbObj.nType       = Ui.OBJ_NPCRES;
    -- tbObj.nTemplateId = (nSex == 1) and -2 or -1;   -- -1 nam, -2 nữ
    -- tbObj.nAction     = Npc.ACT_STAND1;
    -- tbObj.tbPart      = tbPart;
    -- tbObj.nDir        = 0;
    -- tbObj.bRideHorse  = 0;
   
    -- local tbPart2 = {}; -- 2. NHÂN VẬT THỨ 2 (Luôn tạo để kiểm tra hiển thị)
    -- part(tbPart2, "NPCRES_PART_HELM",   0);     -- Lưu ý: Để 1 (đồ tân thủ cơ bản) thay vì 0 để chắc chắn thấy hình hài nhân vật trước, sau khi thấy nhân vật hiện rồi bạn có thể đổi lại thành 0 nếu muốn ẩn giáp/mũ.
    -- part(tbPart2, "NPCRES_PART_ARMOR",  0);
    -- part(tbPart2, "NPCRES_PART_WEAPON", 0);
    -- part(tbPart2, "NPCRES_PART_MANTLE", 0);

    -- local bRide2 = (m and m.nHorse > 0 and m.nHorse < 1000) and 1 or 0; -- Chỉ cưỡi ngựa nếu nHorse là ResId hợp lệ (thường < 1000, tránh nhầm NPC ID > 1000)
    -- part(tbPart2, "NPCRES_PART_HORSE", bRide2 == 1 and m.nHorse or 0);

    -- local tbSecondChar = {};
    -- tbSecondChar.nType       = Ui.OBJ_NPCRES;
    -- tbSecondChar.nTemplateId = (nSex == 1) and -2 or -1;
    -- tbSecondChar.nAction     = (bRide2 == 1) and Npc.ACT_RIDE_STAND1 or Npc.ACT_STAND1;
    -- tbSecondChar.tbPart      = tbPart2;
    -- tbSecondChar.nDir        = self.HORSE_DIR;
    -- tbSecondChar.bRideHorse  = bRide2;

    -- return tbObj, tbSecondChar;
-- end

-- ---------------------------------------------------------------- cửa sổ
function L:Register()
    if self.ready then return true; end
    local native = LoadUiGroup;
    local buffer = self.INI .. string.rep("\0", 256 - string.len(self.INI));
    LoadUiGroup = function(group, name, a, b)
        if group == L.GROUP then name = buffer; end
        return native(group, name, a, b);
    end;
    -- Cùng vị trí với BXH cũ (ui\001a\window\ladder.ini + ui\001b/c/d\wndconfig.ini).
    local ok, why = pcall(Ui.RegisterNewUiWindow, Ui, self.GROUP, self.CLASS, {"a", 150, 120}, {"b", 150, 120}, {"c", 280, 135});
    LoadUiGroup = native;
    if not ok then error(why); end
    local w, h = Wnd_GetSize(self.GROUP, "Main");
    if not w or w <= 0 or not h or h <= 0 then
        LoadUiGroup(self.GROUP, self.INI_PATH);
        w, h = Wnd_GetSize(self.GROUP, "Main");
    end
    assert(w and w > 0 and h and h > 0, "Chưa nạp " .. self.INI .. "; hãy thoát hẳn game rồi vào lại.");
    if GetUiMode() == "d" then
        Ui:AddExWndConfig(self.GROUP, {"d", 600, 275});
        Ui:LoadExWndConfig(self.GROUP);
    end
    self.ready = true;
    return true;
end

-- Ctrl+C: chỉ mở (tắt bằng ESC hoặc nút X).
function L:Open()
    local ok, why = pcall(self.Register, self);
    if not ok then say("Không mở được cửa sổ: " .. tostring(why)); return; end
    if UiManager:WindowVisible(self.GROUP) ~= 1 then UiManager:OpenWindow(self.GROUP); end
end

-- Đóng cửa sổ này, mở BXH cũ đúng mục đang xem (đi đúng chuỗi như khi bấm nút trong BXH cũ).
function L:OpenDetail()
    local t = self.TABS[self.nTab or 1];
    UiManager:CloseWindow(self.GROUP);
    UiManager:OpenWindow(Ui.UI_LADDER);
    local ok, why = pcall(function()
        local w = Ui(Ui.UI_LADDER);
        if not (w and w.UpdatePage) then return; end
        w.nCurListMode   = 0;
        w.nCurPageIndex  = t.page;
        w:UpdatePage();                       -- genre = 1, subject = 0
        if t.gen ~= 1 then
            w.nCurGenreIndex = t.gen;
            w:UpdateGenre();                  -- subject = 0
        end
        if t.sub ~= 0 then
            w.nCurSubjectIndex = t.sub;
            w:UpdateSubject();
            w:OnRefresh();
        end
    end);
    if not ok then say(why); end
end

-- Khung model + ngựa: plugin không được game tự gọi OnCreate → tạo ở đây (gọi lại không tạo trùng).
function L:EnsureGrids(w)
    if w.tbGrid then return; end
    local tbObject = Ui.tbLogic.tbObject;
    w.tbGrid, w.tbHorse = {}, {};
    for k = 1, self.SLOTS do
        w.tbGrid[k]  = tbObject:RegisterContainer(w.UIGROUP, "ObjPreview" .. k);
        w.tbHorse[k] = tbObject:RegisterContainer(w.UIGROUP, "ObjHorse" .. k);
    end
end

local function playSpr(g, szWnd, szSpr)
    local ok = pcall(function()
        Wnd_SetVisible(g, szWnd, 1);
        Img_SetImage(g, szWnd, 1, szSpr);
        Img_PlayAnimation(g, szWnd, 1);
    end);
    if not ok then pcall(Wnd_SetVisible, g, szWnd, 0); end
end

-- ---------------------------------------------------------------- ladder_spr.txt
-- Cột: Tab  Rank  ModelBg  ModelBorder  Info  Title  StateEffect  TitleCX  TitleCY  StateCX  StateCY  Background  Note
-- Rank 0 = dòng của cả cửa sổ (chỉ dùng cột Background: nền 705x461).
-- Tab 0 = dùng chung mọi tab; Tab 1..5 = theo thứ tự nút (1 Uy Danh, 2 Đẳng Cấp, 3 Võ Lâm, 4 Thủ Lĩnh, 5 Tài Phú).
-- Ô trống → lấy dòng Tab 0 cùng hạng → không có nữa thì dùng file mặc định rank<N>_xxx.spr.
-- "-" = không dùng lớp đó. Chỉ ghi tên file → tìm trong \image\ui\001a\ladder\preview\; ghi đường dẫn bắt đầu bằng "\" → dùng nguyên.
function L:LoadSpr()
    self.tbSpr = {};
    local ok, tbRows = pcall(Lib.LoadTabFile, Lib, self.SPR_TXT);
    if not ok or type(tbRows) ~= "table" then return; end
    for _, r in pairs(tbRows) do
        local nTab, nRank = tonumber(trim(r.Tab)), tonumber(trim(r.Rank));
        if nTab and nRank then
            self.tbSpr[nTab] = self.tbSpr[nTab] or {};
            local tb = {};
            for k, v in pairs(r) do
                v = trim(v);
                if v ~= "" then tb[k] = v; end
            end
            self.tbSpr[nTab][nRank] = tb;
        end
    end
end

-- Giá trị 1 cột cho (tab, hạng): tab đang xem → Tab 0 → nil.
function L:SprCell(nTab, nRank, szKey)
    local tbSpr = self.tbSpr or {};
    for _, t in ipairs({nTab, 0}) do
        local v = tbSpr[t] and tbSpr[t][nRank] and tbSpr[t][nRank][szKey];
        if v then return v; end
    end
    return nil;
end

-- Đường dẫn spr của 1 lớp; nil nếu khai "-".
function L:SprPath(nRank, f)
    local v = self:SprCell(self.nTab or 1, nRank, f.key);
    if v == "-" then return nil; end
    if not v then
        if f.nodefault then return nil; end      -- danh hiệu: không khai → hiện chữ "Hạng N"
        return self.SPR_DIR .. "rank" .. nRank .. f.file;
    end
    if string.sub(v, 1, 1) == "\\" then return v; end
    return self.SPR_DIR .. v;
end

function L:SprCenter(nRank, f)
    local tbC = self[f.center][nRank] or {0, 0};
    local x = tonumber(self:SprCell(self.nTab or 1, nRank, f.cx) or "") or tbC[1];
    local y = tonumber(self:SprCell(self.nTab or 1, nRank, f.cy) or "") or tbC[2];
    return x, y;
end

local function showSpr(g, szWnd, szSpr)
    if szSpr then
        playSpr(g, szWnd, szSpr);
    else
        pcall(Img_StopAnimation, g, szWnd);
        pcall(Wnd_SetVisible, g, szWnd, 0);
    end
end

-- Nền cửa sổ = ảnh của chính khung Main (WndShowAnimate như partner.ini / viewplayer.ini), nên luôn nằm dưới
-- mọi nút và chữ. Cột Background ở dòng Rank 0 (tab đang xem → Tab 0). Không khai / "-" → nền mặc định BG_DEFAULT
-- (trùng dòng Image= của [Main] trong wjxladder_main.ini; đổi nền mặc định thì sửa cả 2 chỗ).
L.BG_WND = "Main";
L.BG_DEFAULT = "\\image\\ui\\001a\\LadderPreviewPlayer\\bg_ladder.spr";
function L:BackgroundPath()
    local v = self:SprCell(self.nTab or 1, 0, "Background");
    if not v or v == "-" then return self.BG_DEFAULT; end
    if string.sub(v, 1, 1) == "\\" then return v; end
    return self.SPR_DIR .. v;
end

-- Khung .spr động theo tab đang xem (như vòng sáng Partner: Img_SetImage + Img_PlayAnimation).
-- Chỉ đặt lại khi file khác lúc trước, để đổi tab mà khung giống nhau thì không bị chạy lại từ đầu.
function L:ApplyFrames(w)
    w.tbSprNow = w.tbSprNow or {};
    local szBg = self:BackgroundPath();
    if w.tbSprNow[self.BG_WND] ~= szBg then
        -- Không ẩn/hiện khung Main (lỗi đặt ảnh thì giữ nền đang có).
        pcall(Img_SetImage, w.UIGROUP, self.BG_WND, 1, szBg);
        pcall(Img_PlayAnimation, w.UIGROUP, self.BG_WND, 1);
        w.tbSprNow[self.BG_WND] = szBg;
    end
    for k = 1, self.SLOTS do
        local nRank = self.ORDER[k];
        for _, f in ipairs(self.FRAMES) do
            local szWnd = f.wnd .. k;
            local szSpr = self:SprPath(nRank, f);
            if w.tbSprNow[szWnd] ~= (szSpr or "-") then
                showSpr(w.UIGROUP, szWnd, szSpr);
                w.tbSprNow[szWnd] = szSpr or "-";
            end
        end
    end
end

function L:StopFrames(w)
    w.tbSprNow = nil;
    pcall(Img_StopAnimation, w.UIGROUP, L.BG_WND);
    for k = 1, self.SLOTS do
        for _, f in ipairs(self.FRAMES) do pcall(Img_StopAnimation, w.UIGROUP, f.wnd .. k); end
        for _, f in ipairs(self.FX) do pcall(Img_StopAnimation, w.UIGROUP, f.wnd .. k); end
    end
end

-- Đặt nhân vật / ngựa / vòng sáng / danh hiệu của ô k. bShow = 0 → ẩn ngựa + vòng sáng + danh hiệu.
function L:PlaceSlot(w, k, bShow, bHorse)
    local g = w.UIGROUP;
    local nX, nY = self:CharBase(k);
    if bHorse then
        pcall(Wnd_SetPos, g, "ObjHorse" .. k, nX + self.HORSE_DX, nY + self.HORSE_DY);
        nX = nX + self.CHAR_DX;
    end
    pcall(Wnd_SetPos, g, "ObjPreview" .. k, nX, nY);
    local nRank = self.ORDER[k];
    local bTitleSpr = false;
    for _, f in ipairs(self.FX) do
        local szWnd = f.wnd .. k;
        local szSpr = bShow and self:SprPath(nRank, f);
        if szSpr and f.key == "Title" then bTitleSpr = true; end
        if szSpr then
            local tbP = self[f.point];
            local cx, cy = self:SprCenter(nRank, f);
            pcall(Wnd_SetPos, g, szWnd, nX + tbP[1] - cx, nY + tbP[2] - cy);
            playSpr(g, szWnd, szSpr);
        else
            pcall(Img_StopAnimation, g, szWnd);
            pcall(Wnd_SetVisible, g, szWnd, 0);
        end
    end
    -- Chữ "Hạng N" làm danh hiệu trên đầu: có spr danh hiệu thì ẩn chữ.
    local szTxt = "TxtRank" .. k;
    pcall(Wnd_SetPos, g, szTxt, nX + self.HEAD[1] - math.floor(self.RANK_TXT_SIZE[1] / 2),
        nY + self.HEAD[2] - math.floor(self.RANK_TXT_SIZE[2] / 2));
    pcall(Wnd_SetVisible, g, szTxt, bTitleSpr and 0 or 1);
end

-- ---------------------------------------------------------------- tải dữ liệu: 1 lần mỗi lần mở (Ctrl+C)
-- L.tbSnap[nTab] giữ bảng BXH đã nhận (Ladder.tbSaveLadder[type] — mỗi lần đồng bộ game tạo bảng mới,
-- nên giữ tham chiếu là giữ nguyên bản đã tải). Đổi tab chỉ đọc lại bản này, không xin server nữa.
L.WAIT_TICKS  = 10;     -- chờ tối đa ~10 giây
L.RETRY_TICKS = {[3] = 1, [6] = 1};   -- giây thứ 3 và 6 hỏi lại các tab còn thiếu

function L:Snapshot(nTab)
    if self.tbSnap[nTab] then return false; end
    local tb = Ladder.tbSaveLadder and Ladder.tbSaveLadder[self:TypeOf(nTab)];
    if tb and type(tb.tbLadder) == "table" and #tb.tbLadder > 0 then
        self.tbSnap[nTab] = tb;
        return true;
    end
    return false;
end

function L:Missing()
    local n = 0;
    for i = 1, #self.TABS do
        if not self.tbSnap[i] then n = n + 1; end
    end
    return n;
end

-- Hỏi server các tab còn thiếu (GetLadderByType trả luôn nếu game còn giữ bản trong 10 giây).
function L:RequestMissing()
    for i = 1, #self.TABS do
        if not self.tbSnap[i] then
            pcall(Ladder.GetLadderByType, Ladder, self:TypeOf(i));
            self:Snapshot(i);
        end
    end
end

-- Nhận các tab vừa có dữ liệu. Chỉ vẽ khi tab đang xem vừa có, hoặc mốc mở cấp vừa đổi (Đẳng Cấp về sau).
function L:Collect(w)
    local nCapOld = self:CurrentCap();
    local bCur = false;
    for i = 1, #self.TABS do
        if self:Snapshot(i) and i == self.nTab then bCur = true; end
    end
    if self:Missing() == 0 then self.bLoading = false; end   -- bộ đếm tự dừng ở lượt kế
    if bCur then
        self:Render(w);
    elseif self.tbSnap[self.nTab] and self:CurrentCap() ~= nCapOld then
        self:Render(w);
    end
end

function L:StopWatch()
    self.bLoading = false;
    self.nWatchSeq = (self.nWatchSeq or 0) + 1;      -- vô hiệu bộ đếm cũ
    if self.nWatch and Ui.tbLogic.tbTimer then pcall(Ui.tbLogic.tbTimer.Close, Ui.tbLogic.tbTimer, self.nWatch); end
    self.nWatch = nil;
end

-- Bắt đầu 1 lượt tải: xoá bản cũ, hỏi cả 5 tab, chạy bộ đếm 1 giây đề phòng lỡ thông báo dữ liệu về.
function L:BeginLoad(w)
    self:StopWatch();
    self.tbSnap = {};
    self.bLoading = true;
    self.nPlanRetry = 0;
    self:RequestMissing();
    if self:Missing() == 0 then self.bLoading = false; return; end
    if not (Ui.tbLogic and Ui.tbLogic.tbTimer and Env and Env.GAME_FPS) then return; end
    local nSeq = self.nWatchSeq;
    local nTick = 0;
    self.nWatch = Ui.tbLogic.tbTimer:Register(Env.GAME_FPS, function()
        if nSeq ~= L.nWatchSeq or UiManager:WindowVisible(L.GROUP) ~= 1 then return 0; end
        nTick = nTick + 1;
        local ok, why = pcall(function()
            L:Collect(w);
            if not L.bLoading then return; end
            if L.RETRY_TICKS[nTick] then L:RequestMissing(); L:Collect(w); end
            if nTick >= L.WAIT_TICKS and L.bLoading then
                L.bLoading = false;
                if not L.tbSnap[L.nTab] then L:Render(w); end
            end
        end);
        if not ok then say(why); L.bLoading = false; end
        if not L.bLoading or nSeq ~= L.nWatchSeq then L.nWatch = nil; return 0; end
        return Env.GAME_FPS;
    end);
end

function L:SelectTab(w, nTab)
    self.nTab = nTab;
    for i, t in ipairs(self.TABS) do
        Btn_Check(w.UIGROUP, t.btn, (i == nTab) and 1 or 0);
    end
    self:ApplyFrames(w);
    self.tbSnap = self.tbSnap or {};
    self:Snapshot(nTab);
    if self.tbSnap[nTab] or not self.bLoading then
        self:Render(w);
    else
        self:Clear(w);
        Txt_SetTxt(w.UIGROUP, "TxtSubTitle", self.TABS[nTab].name .. " — đang tải dữ liệu...");
    end
end

function L:ClearSlot(w, k)
    if w.tbGrid and w.tbGrid[k] then w.tbGrid[k]:ClearObj(); end
    if w.tbHorse and w.tbHorse[k] then w.tbHorse[k]:ClearObj(); end
    self:PlaceSlot(w, k, false, false);
    Txt_SetTxt(w.UIGROUP, "TxtRank" .. k, "Hạng " .. self.ORDER[k]);
    Txt_SetTxt(w.UIGROUP, "TxtName" .. k, "—");
    Txt_SetTxt(w.UIGROUP, "TxtPoint" .. k, "");
    Txt_SetTxt(w.UIGROUP, "TxtFaction" .. k, "");
    Txt_SetTxt(w.UIGROUP, "TxtKin" .. k, "");
end

function L:Clear(w)
    for k = 1, self.SLOTS do self:ClearSlot(w, k); end
end

-- Vẽ tab đang xem từ bản đã tải (không xin server).
function L:Render(w)
    self:EnsureGrids(w);
    local t = self.TABS[self.nTab or 1];
    local tb = self.tbSnap and self.tbSnap[self.nTab or 1];
    if not tb then
        self:Clear(w);
        Txt_SetTxt(w.UIGROUP, "TxtSubTitle", t.name .. " — chưa có dữ liệu (đóng rồi Ctrl+C để tải lại)");
        return;
    end
    local szContext = tb.szContext;
    if not szContext or szContext == "" or szContext == "_ " then szContext = t.name; end
    Txt_SetTxt(w.UIGROUP, "TxtSubTitle", szContext);
    for k = 1, self.SLOTS do
        local nRank = self.ORDER[k];
        local p = tb.tbLadder[nRank];
        if p then
            Txt_SetTxt(w.UIGROUP, "TxtRank" .. k, "Hạng " .. nRank);
            Txt_SetTxt(w.UIGROUP, "TxtName" .. k, tostring(p.szName or ""));
            Txt_SetTxt(w.UIGROUP, "TxtPoint" .. k, self:PointText(p));
            Txt_SetTxt(w.UIGROUP, "TxtFaction" .. k, self:FactionLevelText(p));
            Txt_SetTxt(w.UIGROUP, "TxtKin" .. k, self:KinText(p));
            local tbObj, tbHorse = self:BuildObj(p);
            self:PlaceSlot(w, k, true, tbHorse ~= nil);
            if w.tbHorse and w.tbHorse[k] then
                w.tbHorse[k]:ClearObj();
                if tbHorse then w.tbHorse[k]:SetObj(tbHorse); end
            end
            if w.tbGrid and w.tbGrid[k] then
                w.tbGrid[k]:ClearObj();
                w.tbGrid[k]:SetObj(tbObj);
            end
        else
            self:ClearSlot(w, k);
        end
    end
end

local V = Ui:GetClass(L.CLASS);

function V:OnCreate()
    L:EnsureGrids(self);
end

local function eachGrid(w, fn)
    for _, tb in ipairs({w.tbGrid or {}, w.tbHorse or {}}) do
        for k = 1, L.SLOTS do
            if tb[k] then fn(tb[k]); end
        end
    end
end

function V:OnDestroy()
    local tbObject = Ui.tbLogic.tbObject;
    eachGrid(self, function(c) tbObject:UnregContainer(c); end);
    self.tbGrid, self.tbHorse = nil, nil;
end

-- function V:OnOpen()
    -- Txt_SetTxt(self.UIGROUP, "TxtTitle", "Bảng Xếp Hạng");
    -- local ok, why = pcall(function()
        -- L:LoadModels();                 -- đọc lại mỗi lần mở: sửa txt xong chỉ cần đóng/mở cửa sổ
        -- L:LoadSpr();
        -- L:EnsureGrids(self);
        -- L:BeginLoad(self);              -- Ctrl+C: tải 1 lần cho cả 5 tab
        -- L:SelectTab(self, L.DEFAULT_TAB);
    -- end);
    -- if not ok then say(why); end
-- end

function V:OnOpen()
    Txt_SetTxt(self.UIGROUP, "TxtTitle", "Bảng Xếp Hạng");

    -- Dịch chuyển tọa độ lần đầu khi mở cửa sổ (tránh cộng dồn nhiều lần)
    if not self.bAdjustedPos then
        self.bAdjustedPos = true;

        -- 2. Dời cụm thông tin phía dưới của cả 5 ô (ví dụ: dịch xuống dưới +10px)
        local nInfoDy = 40; 
        local tbInfoControls = {"TxtName", "TxtPoint", "TxtFaction", "TxtKin"};
        for k = 1, L.SLOTS do
            for _, szPrefix in ipairs(tbInfoControls) do
                local szWnd = szPrefix .. k;
                local x, y = Wnd_GetPos(self.UIGROUP, szWnd);
                if x and y then
                    Wnd_SetPos(self.UIGROUP, szWnd, x, y + nInfoDy);
                end
            end
        end
    end

    local ok, why = pcall(function()
        L:LoadModels();                 -- đọc lại mỗi lần mở: sửa txt xong chỉ cần đóng/mở cửa sổ
        L:LoadSpr();
        L:EnsureGrids(self);
        L:BeginLoad(self);              -- Ctrl+C: tải 1 lần cho cả 5 tab
        L:SelectTab(self, L.DEFAULT_TAB);
    end);
    if not ok then say(why); end
end

function V:OnClose()
    L:StopWatch();
    eachGrid(self, function(c) c:ClearObj(); end);
    L:StopFrames(self);
end

function V:OnButtonClick(szWnd, nParam)
    if szWnd == "BtnClose" then
        UiManager:CloseWindow(self.UIGROUP);
    elseif szWnd == "BtnDetail" then
        L:OpenDetail();
    else
        for i, t in ipairs(L.TABS) do
            if szWnd == t.btn then
                local ok, why = pcall(L.SelectTab, L, self, i);
                if not ok then say(why); end
                return;
            end
        end
    end
end

-- Có dữ liệu BXH về: chỉ nhận cho tab còn thiếu; tab đã có thì bỏ qua (không vẽ lại).
function V:OnLadderRefresh()
    if UiManager:WindowVisible(L.GROUP) ~= 1 or not L.bLoading then return; end
    local ok, why = pcall(L.Collect, L, self);
    if not ok then say(why); end
end

-- Server đồng bộ lại danh mục BXH (nSaveTime mới) → hỏi lại các tab còn thiếu (tối đa vài lần mỗi lần mở).
function V:OnLadderPlanRefresh()
    if UiManager:WindowVisible(L.GROUP) ~= 1 or not L.bLoading then return; end
    if (L.nPlanRetry or 0) >= 3 then return; end
    L.nPlanRetry = (L.nPlanRetry or 0) + 1;
    local ok, why = pcall(L.RequestMissing, L);
    if not ok then say(why); end
end

function V:RegisterEvent()
    local tb = {
        {UiNotify.emCOREEVENT_LADDERREFRESH,     self.OnLadderRefresh},
        {UiNotify.emCOREEVENT_LADDERPLANREFRESH, self.OnLadderPlanRefresh},
    };
    eachGrid(self, function(c) tb = Lib:MergeTable(tb, c:RegisterEvent()); end);
    return tb;
end

function V:RegisterMessage()
    local tb = {};
    eachGrid(self, function(c) tb = Lib:MergeTable(tb, c:RegisterMessage()); end);
    return tb;
end

-- ---------------------------------------------------------------- phím tắt Ctrl+C
-- Gốc: shortcutalias.lua gán Ctrl+C → alias "UI_LADDER". Ở đây chỉ đổi lệnh của alias đó (cả dòng trong
-- m_tKeyList) nên không đăng ký phím mới. Bọc RegisterAlias để game nạp lại phím tắt cũng không trả về như cũ.
local function patchLadderKey(alias)
    if type(alias) ~= "table" then return; end
    local rows = alias.m_tKeyList;
    if type(rows) == "table" then
        for _, row in ipairs(rows) do
            if row[2] == "UI_LADDER" then row[1] = L.CMD; end
        end
    end
    if type(alias.AddAlias) == "function" then alias:AddAlias("UI_LADDER", L.CMD); end
end

if UiShortcutAlias and type(UiShortcutAlias.RegisterAlias) == "function" and UiShortcutAlias.RegisterAlias ~= L.aliasWrapper then
    local prior = UiShortcutAlias.RegisterAlias;
    L.aliasWrapper = function(alias, ...)
        patchLadderKey(alias);
        local r = prior(alias, unpack(arg));
        patchLadderKey(alias);
        return r;
    end;
    UiShortcutAlias.RegisterAlias = L.aliasWrapper;
end
patchLadderKey(UiShortcutAlias);
