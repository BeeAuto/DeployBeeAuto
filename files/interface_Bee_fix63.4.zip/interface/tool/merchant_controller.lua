if not Ui.WJXMerchant or not Ui.WJXMerchant.loading then return; end
local M = Ui.WJXMerchant;
local function visible(group)
    return group and UiManager:WindowVisible(group) == 1;
end

function M:Message(text)
    self.status = tostring(text);
    me.Msg("[Thương Hội] " .. self.status);
end

function M:Phase(name, message)
    local j = self.job;
    j.phase, j.at = name, GetTime();
    j.say, j.ownedSay, j.input = nil, nil, nil;
    if message then self.status = message; end
end

function M:StopPath(j)
    local path = Ui.tbLogic.tbAutoPath;
    if j.path and path.tbGotoPos == j.path then path:StopGoto("MerchantStop"); end
    j.path = nil;
end

function M:Stop(reason)
    local j = self.job;
    self.job = nil;
    if self.timer then Ui.tbLogic.tbTimer:Close(self.timer); self.timer = nil; end
    if j then
        if j.transfer then Ui.WJXTransfer:Cancel(j.transfer); end
        self:StopPath(j);
        if j.ownedSay and visible(Ui.UI_SAYPANEL) then UiManager:CloseWindow(Ui.UI_SAYPANEL); end
        if j.gift and visible(Ui.UI_ITEMGIFT) and Ui(Ui.UI_ITEMGIFT).tbGiftCont.tbGift == j.gift then
            Ui(Ui.UI_ITEMGIFT):OnButtonClick("BtnClose"); -- return staged items, never submit on stop
        end
    end
    if reason then self:Message(reason); end
end

function M:Conflict()
    local a, t, p, b = Ui.WJXAuto6, Ui.WJXTongKim, Ui.WJXParty, Ui.WJXCheckBoss;
    if a and a.session then return "Dừng Auto6 / Theo Sau trước khi chạy Thương Hội."; end
    if t and (t.job or t.patrol) then return "Dừng Tống Kim trước khi chạy Thương Hội."; end
    if p and p.dispatch and p.dispatch.job then return "Dừng Điều Phối Tổ Đội trước khi chạy Thương Hội."; end
    if b and b.job then return "Dừng CheckBOSS trước khi chạy Thương Hội."; end
    if Ui.WJXThief and Ui.WJXThief.job then return "Dừng Hải Tặc trước khi chạy Thương Hội."; end
    if a and a.LegacyTrainRunning and a:LegacyTrainRunning() then return "Dừng Luyện Công cũ trước khi chạy Thương Hội."; end
    if Map.tbAutoEgg and Map.tbAutoEgg.nPickState == 1 then return "Dừng Thu Thập NPC trước khi chạy Thương Hội."; end
    if Map.tbAutoAim and Map.tbAutoAim.nFollowState == 1 then return "Dừng Hộ Tống trước khi chạy Thương Hội."; end
    if me.nAutoFightState == 1 or (AutoAi.GetAutoFightState and AutoAi.GetAutoFightState() == 1) then
        return "Tắt Tự Đánh trước khi chạy Thương Hội.";
    end
end

function M:Install()
    if self.installed then return; end
    self.installed = true;
    local say = Ui(Ui.UI_SAYPANEL);
    local onSay = say.OnOpen;
    say.OnOpen = function(window, param, ...)
        local result = onSay(window, param, unpack(arg));
        local j = M.job;
        if j and j.owner == me.szName then
            if j.transfer then Ui.WJXTransfer:Capture(j.transfer, param);
            elseif j.phase == "dialog" or j.phase == "withdraw" or j.phase == "wait" or j.phase == "buywait" then
                j.say = param;
                j.ownedSay = true;
                j.saySerial = (j.saySerial or 0) + 1;
            end
        end
        return result;
    end;
    local input = Ui(Ui.UI_TEXTINPUT);
    local onInput = input.OnOpen;
    input.OnOpen = function(window, ...)
        local result = onInput(window, unpack(arg));
        local j = M.job;
        if j and j.phase == "withdraw" and j.tokenChosen then
            j.input = {window = window, range = window.tbRange};
        end
        return result;
    end;
    local gift = Ui(Ui.UI_ITEMGIFT);
    local onGift = gift.OnOpen;
    gift.OnOpen = function(window, form, ...)
        local result = onGift(window, form, unpack(arg));
        local j = M.job;
        if j and j.phase == "dialog" and j.action == "task" and j.taskChosen then
            j.gift = form;
        end
        return result;
    end;
    local talk = Ui(Ui.UI_GUTTALK);
    local onTalk = talk.OnOpen;
    talk.OnOpen = function(window, ...)
        local result = onTalk(window, unpack(arg));
        local j = M.job;
        if j and j.phase == "dialog" and j.taskChosen then j.talk = true; end
        return result;
    end;
end

function M:Start(raw)
    local conflict = self:Conflict();
    if conflict then self:Message(conflict); return false; end
    for _, group in ipairs({Ui.UI_SAYPANEL, Ui.UI_ITEMGIFT, Ui.UI_SHOP, Ui.UI_TEXTINPUT,
        Ui.UI_GUTAWARD, Ui.UI_GUTTALK, Ui.UI_SKILLPROGRESS}) do
        if visible(group) then self:Message("Đóng hội thoại/cửa hàng hoặc chờ tiến trình xong rồi Bắt Đầu."); return false; end
    end
    local options = self:Options(raw);
    local catalog, why;
    if options.buy == 1 then
        catalog, why = self:ReadBuyCatalog();
        if not catalog then self:Message(why); return false; end
    end
    local deliveryRoutes, deliveryError = self:ReadDeliveryRoutes();
    self:Stop();
    self:Install();
    -- Freeze purchase definitions for this run; never reload during a confirmation.
    self.job = {options = options, buyCatalog = catalog,
        deliveryRoutes = deliveryRoutes, deliveryError = deliveryError,
        owner = me.szName, faction = me.nFaction, started = GetTime()};
    self:Phase("evaluate", "Đang kiểm tra nhiệm vụ và hành trang.");
    self.timer = Ui.tbLogic.tbTimer:Register(Env.GAME_FPS, function()
        local ok, result = pcall(M.Tick, M);
        if not ok then M:Stop("Lỗi: " .. tostring(result)); return 0; end
        return result;
    end);
    return true;
end

function M:Choose(choices, prefix)
    local j = self.job;
    if not j.say or not visible(Ui.UI_SAYPANEL) then return false; end
    local index;
    for i, answer in ipairs(j.say[2] or {}) do
        local clean = self:Clean(answer);
        for _, choice in ipairs(choices) do
            local match = self:Clean(choice);
            if clean == match or (prefix and clean:sub(1, #match) == match and clean:sub(#match + 1, #match + 1) == "(") then
                if index and index ~= i then self:Stop("Có nhiều lựa chọn cùng tên; hãy đối thoại thủ công."); return false; end
                index = i;
            end
        end
    end
    if not index then return false; end
    j.answers = (j.answers or 0) + 1;
    if j.answers > 12 then self:Stop("Đối thoại lặp; đã dừng để kiểm tra."); return false; end
    j.say, j.ownedSay = nil, nil;
    Ui(Ui.UI_SAYPANEL):OnListSel("LstSelectArray", index);
    return true;
end

function M:BeginTransfer(destination, after)
    local j = self.job;
    local transfer = Ui.WJXTransfer;
    local ok, why = transfer:Check(destination);
    if ok ~= true then self:Stop(why or "Không thể dùng Vô Hạn Phù tại đây."); return; end
    local item = transfer:Item();
    if not item then self:Stop("Không có Vô Hạn Phù trong hành trang."); return; end
    self:Phase("transfer", "Đang dùng Vô Hạn Phù tới " .. (destination.label or tostring(destination.map)) .. ".");
    j.afterTransfer = after;
    local _, x, y = me.GetWorldPos();
    j.transferStartX, j.transferStartY = x, y;
    j.transfer = transfer:Begin(destination, item);
    local result = me.UseItem(item);
    if result == 0 then self:Stop("Không dùng được Vô Hạn Phù."); end
end

function M:NativePath(point, after)
    local j = self.job;
    local map, x, y = me.GetWorldPos();
    local path = Ui.tbLogic.tbAutoPath;
    local destination = {nMapId = point.map, nX = point.x, nY = point.y};
    self:Phase("travel", "Đang di chuyển tới " .. (point.name or "điểm nhiệm vụ") .. ".");
    j.point, j.afterPath = point, after;
    j.lastMap, j.lastX, j.lastY, j.progress = map, x, y, GetTime();
    path:GotoPos(destination);
    j.path = path.tbGotoPos;
    if not j.path and (map ~= point.map or (x - point.x)^2 + (y - point.y)^2 > 9) then
        self:Stop("Không tìm được đường đến điểm nhiệm vụ. Kiểm tra bản đồ hoặc đến gần rồi chạy lại.");
    end
end

function M:Travel(point, after)
    if me.GetWorldPos() ~= point.map then
        local dest, item = Ui.WJXTransfer:Plan(point.map);
        if dest then
            self.job.resumePoint, self.job.resumeAfter = point, after;
            self:BeginTransfer(dest, "resume");
            return;
        end
    end
    self:NativePath(point, after);
end

function M:GoNpc(id, map, action, snapshot)
    local j = self.job;
    j.npc, j.action, j.request = id, action, snapshot;
    j.answers, j.taskChosen, j.talk, j.gift, j.awardSent, j.npcSearched = 0, nil, nil, nil, nil, nil;
    local npc = self:FindNpc(id);
    if npc and (map == 0 or map == me.GetWorldPos()) then self:Phase("npc"); return; end
    if snapshot.kind == 5 and snapshot.delivery and action == "task" and id ~= 2965 then
        self:BeginDelivery(j, snapshot);
        return;
    end
    local city = self.cities[j.options.city];
    if id == 2965 then
        if j.options.route == 1 then
            self:BeginTransfer({map = city.map, label = "Chủ Thương Hội " .. city.name,
                route = {self:Clean("Thương Hội Cấp 60"), self:Clean("Báo danh " .. city.name)}}, "npc");
            return;
        end
        map = city.map;
        if me.GetWorldPos() ~= map then
            local destination = Ui.WJXTransfer:Destinations()[map];
            if destination then self:BeginTransfer(destination, "npc"); return; end
        end
    elseif map == 0 then
        -- Activity NPCs have map=0 in the table. Never guess a battle instance.
        self:Stop("Chưa thấy NPC " .. id .. ". Hãy vào đúng bản đồ hoạt động rồi chạy lại. " .. (snapshot.hint or snapshot.title));
        return;
    end
    local point = self:NpcPoint(map, id);
    if not point then self:Stop("Chưa có tọa độ NPC " .. id .. " ở map " .. map .. ". Chọn cách Thương Hội Cấp 60 hoặc đến gần NPC."); return; end
    self:Travel(point, "npc");
end

function M:Evaluate(s)
    local j = self.job;
    if s.error then self:Stop(s.error); return; end
    if j.options.box == 1 and not s.boxItem then
        if s.boxRepository then self:Stop("Hộp lệnh bài đang ở rương chứa đồ. Lấy hộp vào hành trang rồi Bắt Đầu lại."); return; end
        if me.CountFreeBagCell() < 1 then self:Stop("Hành trang đầy; cần một ô trống để nhận hộp."); return; end
        self:GoNpc(2965, 0, "box", s);
        return;
    end
    if not s.active then
        if s.closed then self:Stop("Không còn lượt Thương Hội / đã hoàn thành. Máy chủ không mở nhiệm vụ mới."); return; end
        self:GoNpc(2965, 0, "task", s);
        return;
    end
    if s.bag >= s.need then self:GoNpc(s.npc, s.map, "task", s); return; end
    if j.options.withdraw == 1 and (s.stored or 0) > 0 then
        if not s.boxItem then self:Stop("Có lệnh bài lưu trong hộp nhưng hộp chưa ở hành trang."); return; end
        local count = math.min(s.need - s.bag, s.stored);
        if me.CountFreeBagCell() < count then self:Stop("Cần " .. count .. " ô trống để rút đủ lệnh bài."); return; end
        self:Phase("withdraw", "Đang rút " .. count .. " " .. s.itemName .. " từ hộp.");
        j.request, j.take, j.tokenChosen, j.answers = s, count, nil, 0;
        j.withdrawMenu, j.pages = nil, {};
        me.UseItem(s.boxItem);
        return;
    end
    if s.delivery then
        local repository = me.FindItemInRepository(s.g, s.d, s.p, s.l) or {};
        if #repository > 0 then self:Stop("Thư Thương Hội nằm trong rương; lấy vào hành trang rồi chạy lại."); return; end
        self:GoNpc(2965, 0, "letter", s);
        return;
    end
    if j.options.buy == 1 then
        self:BeginBuy(s);
        return;
    end
    if s.collect and s.point and s.collectNpc then
        j.request, j.collectStarted, j.collectCount, j.collectProgress = s, GetTime(), s.bag, GetTime();
        self:Travel(s.point, "collect");
        return;
    end
    self:Stop("Còn thiếu " .. math.max(0, s.need - s.bag) .. " " .. s.itemName ..
        ". " .. (s.hint ~= "" and s.hint or "Kiếm đủ vật phẩm rồi bấm Lưu và Bắt Đầu để tiếp tục."));
end

function M:NpcTick(j)
    local npc, distance = self:FindNpc(j.npc);
    if not npc then
        if not j.npcSearched then
            j.npcSearched = true;
            local point = self:NpcPoint(me.GetWorldPos(), j.npc);
            if point then self:NativePath(point, "npc"); return; end
        end
        if GetTime() - j.at > 12 then self:Stop("Đã đến nơi nhưng chưa thấy NPC " .. j.npc .. " trong tầm nhìn."); end
        return;
    end
    if distance > 150 then
        local x, y = npc.GetMpsPos();
        self:NativePath({map = me.GetWorldPos(), x = math.floor(x / 32), y = math.floor(y / 32)}, "npc");
        return;
    end
    self:StopPath(j);
    self:Phase("dialog", "Đang đối thoại với " .. npc.szName .. ".");
    j.npcIndex = npc.nIndex;
    AutoAi.SetTargetIndex(npc.nIndex);
end

function M:GiftTick(j)
    local window = Ui(Ui.UI_ITEMGIFT);
    if window.tbGiftCont.tbGift ~= j.gift then self:Stop("Cửa sổ giao đồ đã thay đổi; không tự giao."); return; end
    local s = j.request;
    local valid, reason = self:GiftRequestMatches(j);
    if not valid then self:Stop(reason); return; end
    if not j.bagsOpened then
        j.bagsOpened = true;
        if not visible(Ui.UI_ITEMBOX) then UiManager:OpenWindow(Ui.UI_ITEMBOX); end
        if Ui.tbLogic.tbExtBagLayout then Ui.tbLogic.tbExtBagLayout:Show(); end
        return;
    end
    local offered, seen = 0, {};
    for y = 0, 3 do
        for x = 0, 4 do
            local item = me.GetItem(Item.ROOM_GIFT, x, y);
            if item then
                if not self:Matches(item, s) then self:Stop("Có vật phẩm khác trong khung giao; đã hủy giao tự động."); return; end
                local key = item.dwId or item.nIndex or item;
                if not seen[key] then
                    seen[key] = true;
                    offered = offered + item.nCount;
                end
            end
        end
    end
    if offered > s.need then self:Stop("Số lượng trong khung giao vượt yêu cầu; đã hủy giao."); return; end
    if offered == s.need then
        j.gift = nil;
        self:Phase("wait", "Đã giao đủ; đang chờ máy chủ xác nhận.");
        j.waitFor, j.beforeKey = "task", s.key;
        window:OnButtonClick("BtnOk");
        return;
    end
    if j.offerAt and GetTime() - j.offerAt < 2 then return; end
    if j.offeredBefore == offered and j.offerAt then
        if GetTime() - j.offerAt > 8 then self:Stop("Vật phẩm chưa chuyển vào khung giao; đã dừng."); end
        return;
    end
    local remaining = s.need - offered;
    local cells = self:BagCells();
    table.sort(cells, function(a, b) return a.item.nCount < b.item.nCount; end);
    for _, cell in ipairs(cells) do
        if self:Matches(cell.item, s) then
            if cell.item.nCount > remaining then
                if j.splitAt then
                    if GetTime() - j.splitAt > 8 then self:Stop("Chưa tách được số lượng cần giao."); end
                    return;
                end
                if me.CountFreeBagCell() < 1 then self:Stop("Cần một ô trống để tách vật phẩm giao nhiệm vụ."); return; end
                j.splitAt = GetTime();
                UiManager:SetUiState(UiManager.UIS_ITEM_SPLIT);
                local ok, why = pcall(me.SplitItem, cell.item, remaining);
                UiManager:ReleaseUiState(UiManager.UIS_ITEM_SPLIT);
                if not ok then error(why); end
                return;
            end
            if not visible(cell.group) then UiManager:OpenWindow(cell.group); return; end
            local object = cell.container:GetObj(cell.x, cell.y);
            local current = object and me.GetItem(object.nRoom, object.nX, object.nY);
            if object ~= cell.object or not current or not self:Matches(current, s) or
                (current.dwId or current.nIndex or current) ~= (cell.item.dwId or cell.item.nIndex or cell.item) or
                current.nCount > remaining then
                self:WaitGiftBag(j, offered);
                return;
            end
            j.giftReadAt, j.giftReadCount = nil, nil;
            j.offerAt, j.offeredBefore, j.splitAt = GetTime(), offered, nil;
            cell.container:UseObj(object, cell.x, cell.y);
            return;
        end
    end
    local available = 0;
    for _, item in ipairs(self:BagItems(s)) do available = available + item.nCount; end
    if available >= remaining then
        self:WaitGiftBag(j, offered);
    else
        self:Stop("Không còn đủ vật phẩm phù hợp để đưa vào khung giao.");
    end
end

function M:DialogTick(j, s)
    if j.action == "buy" then self:BuyDialogTick(j, s); return; end
    if j.action == "task" and j.taskChosen and visible(Ui.UI_GUTAWARD) then
        local window = Ui(Ui.UI_GUTAWARD);
        if window.nTaskId ~= 50000 then self:Stop("Giao diện nhiệm vụ khác đang mở."); return; end
        if window.tbAwards and window.tbAwards.tbOpt and #window.tbAwards.tbOpt > 0 then
            self:Stop("Có phần thưởng tùy chọn; hãy chọn thủ công rồi chạy lại."); return;
        end
        self:Phase("wait", "Đang nhận / trả nhiệm vụ Thương Hội.");
        j.waitFor, j.beforeKey = "task", j.request.key;
        window:OnButtonClick("zBtnAccept");
        return;
    end
    if j.talk and visible(Ui.UI_GUTTALK) then
        Ui(Ui.UI_GUTTALK):OnButtonClick("Main");
        return;
    end
    if j.gift and visible(Ui.UI_ITEMGIFT) then self:GiftTick(j); return; end
    if GetTime() - j.at > 60 then self:Stop("Chưa nhận được đối thoại/giao vật phẩm phù hợp từ máy chủ."); return; end
    if not j.say then return; end
    if j.action == "task" then
        j.taskChosen = true;
        if self:Choose({"Nhiệm vụ thương hội"}) then return; end
        if not self.job then return; end
        j.ownedSay = nil;
        self:Stop("NPC không có dòng Nhiệm vụ thương hội. Kiểm tra cấp, uy danh, chính tuyến và lượt tuần; đã giữ nguyên hội thoại.");
    else
        local expected = j.action == "box" and "Nhận hộp thu thập lệnh bài thương hội" or "Nhận thư thương hội";
        if self:Choose({expected}) then
            if self.job then
                self:Phase("wait", "Đang chờ nhận " .. (j.action == "box" and "hộp lệnh bài." or "Thư Thương Hội."));
                j.waitFor = j.action;
            end
            return;
        end
        if not self.job then return; end
        if self:Choose({"Ta muốn hỏi chuyện khác"}) then return; end
        if self.job then self:Stop("Không có lựa chọn " .. expected .. "."); end
    end
end

function M:WithdrawTick(j, s)
    if GetTime() - j.at > 30 then self:Stop("Quá thời gian rút lệnh bài từ hộp."); return; end
    if j.input then
        local input, window = j.input, j.input.window;
        if not visible(Ui.UI_TEXTINPUT) or window.tbRange ~= input.range then self:Stop("Hộp nhập đã thay đổi."); return; end
        local maximum = input.range and tonumber(input.range[2]);
        if not maximum or maximum < j.take or me.CountFreeBagCell() < j.take then
            self:Stop("Không đủ ô trống hoặc giới hạn rút đã thay đổi."); return;
        end
        self:Phase("wait", "Đang chờ lệnh bài vào hành trang.");
        j.waitFor, j.beforeBag = "withdraw", j.request.bag;
        Edt_SetInt(Ui.UI_TEXTINPUT, window.EDT_TEXT or "EdtText", j.take);
        window:OnButtonClick(window.BTN_ACCEPT or "BtnAccept", 0);
        return;
    end
    if not j.say then return; end
    if not j.withdrawMenu then
        j.withdrawMenu = true;
        if not self:Choose({"Rút vật phẩm"}) and self.job then self:Stop("Hộp không có mục Rút vật phẩm."); end
        return;
    end
    local signature = table.concat(j.say[2] or {}, "|");
    if j.pages[signature] then self:Stop("Danh sách lệnh bài bị lặp; đã dừng."); return; end
    j.pages[signature] = true;
    j.tokenChosen = true;
    if self:Choose({j.request.token.szName}, true) then return; end
    j.tokenChosen = nil;
    if self.job and self:Choose({"Sau"}) then return; end
    if self.job then self:Stop("Không tìm thấy đúng lệnh bài cần rút trong hộp."); end
end

function M:Tick()
    local j = self.job;
    if not j then return 0; end
    if me.szName ~= j.owner or me.nFaction ~= j.faction or me.IsDead() == 1 then self:Stop("Đã đổi nhân vật hoặc bị hạ gục."); return 0; end
    local conflict = self:Conflict();
    if conflict then self:Stop(conflict); return 0; end
    local s = self:Snapshot();
    if j.phase ~= "evaluate" and j.phase ~= "wait" and j.phase ~= "buywait" and j.request and s.key ~= j.request.key then
        self:Stop("Nhiệm vụ đã thay đổi trong lúc thao tác. Bấm Bắt Đầu để đọc lại yêu cầu mới.");
        return 0;
    end
    if j.phase == "evaluate" then self:Evaluate(s);
    elseif j.phase == "transfer" then
        local transfer = j.transfer;
        local map, x, y = me.GetWorldPos();
        local sameMapArrived = transfer.phase == "transfer" and transfer.from == transfer.dest.map and map == transfer.dest.map and
            (x - j.transferStartX)^2 + (y - j.transferStartY)^2 > 25;
        local state, why;
        if sameMapArrived and not visible(Ui.UI_SKILLPROGRESS) then state = "done";
        else state, why = Ui.WJXTransfer:Tick(transfer); end
        if state == "done" then
            Ui.WJXTransfer:Cancel(transfer);
            j.transfer = nil;
            self:Phase("settle", "Đã truyền tống; chờ tải cảnh.");
        elseif state ~= "wait" then self:Stop(why); end
    elseif j.phase == "settle" then
        local map, x, y = me.GetWorldPos();
        if visible(Ui.UI_SKILLPROGRESS) or not map or map <= 0 or x <= 0 or y <= 0 then j.quietAt = nil;
        else j.quietAt = j.quietAt or GetTime(); end
        if j.quietAt and GetTime() - j.quietAt >= 2 then
            j.quietAt = nil;
            if j.afterTransfer == "resume" then self:NativePath(j.resumePoint, j.resumeAfter);
            else self:Phase(j.afterTransfer); end
        elseif GetTime() - j.at > 30 then self:Stop("Quá thời gian tải cảnh sau truyền tống."); end
    elseif j.phase == "delivery" then self:DeliveryArrived(j);
    elseif j.phase == "travel" then
        local map, x, y = me.GetWorldPos();
        local path = Ui.tbLogic.tbAutoPath;
        if path.tbGotoPos and path.tbGotoPos ~= j.path then self:Stop("Đã nhường quyền cho lệnh di chuyển khác."); return 0; end
        if map == j.point.map and (x - j.point.x)^2 + (y - j.point.y)^2 <= 9 then
            self:StopPath(j);
            self:Phase(j.afterPath);
        else
            if map ~= j.lastMap or (x - j.lastX)^2 + (y - j.lastY)^2 > 1 then
                j.lastMap, j.lastX, j.lastY, j.progress = map, x, y, GetTime();
            end
            if GetTime() - j.progress > 30 or GetTime() - j.at > 300 then self:Stop("Không đến được điểm nhiệm vụ hoặc bị kẹt đường."); end
        end
    elseif j.phase == "npc" then self:NpcTick(j);
    elseif j.phase == "dialog" then self:DialogTick(j, s);
    elseif j.phase == "withdraw" then self:WithdrawTick(j, s);
    elseif j.phase == "buywait" then self:BuyWaitTick(j, s);
    elseif j.phase == "wait" then
        local done = (j.waitFor == "box" and s.boxItem) or
            (j.waitFor == "letter" and s.bag and s.bag >= s.need) or
            (j.waitFor == "withdraw" and s.key == j.request.key and s.bag >= j.beforeBag + j.take) or
            (j.waitFor == "task" and (s.key ~= j.beforeKey or s.closed));
        if done then
            if j.ownedSay and visible(Ui.UI_SAYPANEL) then UiManager:CloseWindow(Ui.UI_SAYPANEL); end
            j.offerAt, j.offeredBefore, j.splitAt, j.gift, j.bagsOpened = nil, nil, nil, nil, nil;
            self:Phase("evaluate", "Đã xác nhận thay đổi; đang đọc yêu cầu tiếp theo.");
        elseif j.waitFor == "task" and visible(Ui.UI_GUTAWARD) and not j.awardSent then
            local window = Ui(Ui.UI_GUTAWARD);
            if window.nTaskId ~= 50000 then self:Stop("Đang mở phần thưởng của nhiệm vụ khác."); return 0; end
            if window.tbAwards and window.tbAwards.tbOpt and #window.tbAwards.tbOpt > 0 then
                self:Stop("Hãy chọn phần thưởng nhiệm vụ thủ công rồi chạy lại."); return 0;
            end
            j.awardSent, j.at = true, GetTime();
            window:OnButtonClick("zBtnAccept");
        elseif GetTime() - j.at > 12 then self:Stop("Máy chủ chưa xác nhận thay đổi nhiệm vụ/vật phẩm; không gửi lặp."); end
    elseif j.phase == "collect" then
        if s.key ~= j.request.key then self:Phase("evaluate");
        elseif s.bag >= s.need then self:Phase("evaluate", "Đã thu thập đủ; chuẩn bị giao nhiệm vụ.");
        else
            if s.bag > j.collectCount then j.collectCount, j.collectProgress = s.bag, GetTime(); end
            if GetTime() - j.collectProgress > 240 then self:Stop("Thu thập chưa tiến triển. Có thể bị quái ngắt hoặc đối tượng chưa hồi; hãy kiểm tra bãi."); return 0; end
            if me.CountFreeBagCell() < 1 then self:Stop("Hành trang đầy; không thể thu thập tiếp."); return 0; end
            if not visible(Ui.UI_SKILLPROGRESS) and (not j.collectClick or GetTime() - j.collectClick >= 12) then
                local npc = self:FindNpc(s.collectNpc);
                if npc then
                    j.collectClick = GetTime();
                    AutoAi.SetTargetIndex(npc.nIndex);
                    self.status = "Đang thu thập " .. s.itemName .. " (" .. s.bag .. "/" .. s.need .. ").";
                else self.status = "Đang chờ đối tượng " .. s.itemName .. " xuất hiện."; end
            end
        end
    end
    return self.job and Env.GAME_FPS or 0;
end
