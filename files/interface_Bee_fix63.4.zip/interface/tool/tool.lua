Ui.UI_TOOL				= "UI_TOOL";
local uiTool			= Ui.tbWnd[Ui.UI_TOOL] or {};
uiTool.UIGROUP			= Ui.UI_TOOL;
Ui.tbWnd[Ui.UI_TOOL]	= uiTool
Map.tbTool		= uiTool;
-----------------------------------------------------------------------
local BTNDuLong							= "BtnDuLong"
local BTNMerchant						= "BtnMerchant"
local BTNTDLT						= "BtnTDLT"

local BTNVuotAi							= "BtnVuotAi"
local BTNHoaDang							= "BtnHoaDang"
local BTNBaoRuong						= "BtnBaoRuong"
local BTNChinhTuyen							= "BtnChinhTuyen"
local BTNChucPhuc							= "BtnChucPhuc"

local BTNGhepHT								= "BtnGhepHT"
local BTNStartBao							= "BtnStartBao"
local BTNStopBao							= "BtnStopBao"
local BTNTrain								= "BtnTrain"
local BTNBvd								= "BtnBvd"
local self									= uiTool 
local tbTimer = Ui.tbLogic.tbTimer;
Ui:RegisterNewUiWindow("UI_TOOL", "tool", {"a", 730, 0}, {"b", 954, 100}, {"c", 1210, 100});

function uiTool:VuotAiMenu(id)
	local ok, why = pcall(function()
		if not (Ui.WJXVuotAi and Ui.WJXVuotAi.ShowMenu) then
			Require("\\interface\\AutoVuotAi\\wjxkg.lua");
		end
		local v = assert(Ui.WJXVuotAi and Ui.WJXVuotAi.ShowMenu and Ui.WJXVuotAi, "Chưa nạp Auto Vượt Ải Gia Tộc (khởi động lại game).");
		if id == nil then
			-- Trễ 1 nhịp trước khi hiện sub-menu để click không đóng menu ngay.
			Ui.tbLogic.tbTimer:Register(2, function()
				local done, err = pcall(function() v:ShowMenu(uiTool.UIGROUP, BTNVuotAi); end);
				if not done then me.Msg("[Vượt Ải GT] " .. tostring(err)); end
				return 0;
			end);
		else
			v:SelectMenu(self.UIGROUP, BTNVuotAi, id);
		end
	end);
	if not ok then me.Msg("[Vượt Ải GT] " .. tostring(why)); end
end

function uiTool:OnMenuItemSelected(wnd, id, param)
	if wnd == BTNVuotAi then self:VuotAiMenu(id); end
end

function uiTool:OnButtonClick(szWnd)
--------------------------------------
	if (szWnd == BTNDuLong) then
		local ok, err = pcall(function()
			assert(Ui.WJXDuLongBoot and Ui.WJXDuLongBoot.Open, "Chưa nạp giao diện Du Long (Ctrl+Y).");
			Ui.WJXDuLongBoot:Open();
		end);
		if not ok then me.Msg("[Menu End] " .. tostring(err)); end
	elseif (szWnd == BTNMerchant) then
		local ok, why = pcall(function()
			if not Ui.WJXMerchant or not Ui.WJXMerchant.Open then
				Require("\\interface\\tool\\merchant.lua");
			end
			Ui.WJXMerchant:Open();
		end);
		if not ok then me.Msg("[Thương Hội] " .. tostring(why)); end
	elseif (szWnd == BTNTDLT) then
		local ok, why = pcall(function() Ui.WJXTDLT:Open(); end);
		if not ok and me and me.Msg then me.Msg("[Auto TDLT] " .. tostring(why)); end
--------------------------------------
	elseif (szWnd == BTNVuotAi) then
		self:VuotAiMenu();
	elseif (szWnd == BTNHoaDang) then
		local ok, why = pcall(function()
			local hd = Ui.WJXHoaDang;
			if hd and hd.Toggle then hd:Toggle(); return; end
			assert(type(UiManager.AutoAnswerSwitch) == "function", "Chưa nạp plugin Auto Hoa Đăng (AutoHoaDang, phím Ctrl+M).");
			UiManager:AutoAnswerSwitch();
		end);
		if not ok then me.Msg("[Hoa Đăng] " .. tostring(why)); end
	elseif (szWnd == BTNBaoRuong) then
		local ok, why = pcall(function()
			if Ui.WJXBaiBao and Ui.WJXBaiBao.Open then Ui.WJXBaiBao:Open(); else UiManager:OpenWindow(Ui.UI_BAIBAOXIANG, 1); end
		end);
		if not ok then me.Msg("[Bảo Rương] " .. tostring(why)); end
	elseif (szWnd == BTNChinhTuyen) then
		local ok, why = pcall(function() Ui.WJXMainQuest:Open(); end);
		if not ok and me and me.Msg then me.Msg("[Chinh Tuyen] " .. tostring(why)); end
	elseif (szWnd == BTNChucPhuc) then
		UiManager:SwitchWindow(Ui.UI_PLAYERPRAY);
--------------------------------------
	elseif szWnd == BTNGhepHT then		    
		local ok, why = pcall(function() Ui.WJXGhepHT:Toggle(); end);
		if not ok and me and me.Msg then me.Msg("[Ghep HT] " .. tostring(why)); end
	elseif szWnd == BTNStartBao then	
		UiManager:StartBao();
	elseif szWnd == BTNStopBao then	
		UiManager:StopBao();
	elseif szWnd == BTNTrain then
		UiManager:StartGua();	
	elseif szWnd == BTNBvd then	
		UiManager:SwitchWindow(Ui.UI_SPRBAO_SETTING);

	end
end

uiTool.DaoJu=function(self)
	if me.GetMapTemplateId() > 65500 then
		local nCount=me.GetItemCountInBags(20,1,603,1)
		SendChannelMsg("Team", string.format("Công cụ %d", nCount));
	else
		UiManager:OpenWindow("UI_INFOBOARD", "<bclr=Black><color=white>Chức năng này chỉ hoạt động trong Hậu Phục Ngưu Sơn<color>");
	end
end

uiTool.FishHook_Two=function(self)
	local nCurMapId, nWorldPosX, nWorldPosY = me.GetWorldPos();
	if nWorldPosX==13216/8 and nWorldPosY==62048/16 then
		me.RemoveSkillEffect(Player.HEAD_STATE_AUTOPATH)
		if UiManager:WindowVisible(Ui.UI_SKILLPROGRESS) ~= 1 then 
			local tbFind = me.FindItemInBags(20,1,253,1);
			for j, tbItem in pairs(tbFind) do
				me.UseItem(tbItem.pItem);
			end
		end
		if me.GetItemCountInBags(20,1,617,1)>=10 then
			me.Msg("Cá")
			Ui.tbLogic.tbTimer:Close(self.FishHookId)
		end
	else
		me.AutoPath(13216/8,62048/16)
		me.AddSkillEffect(Player.HEAD_STATE_AUTOPATH)
	end
end
uiTool.FishHook=function(self)
	Ui.tbLogic.tbTimer:Close(self.FishHookId)
	if me.GetMapTemplateId() > 65500 then
		me.Msg("<color=yellow>Bắt đầu tự động Câu cá<color>")
		if me.GetItemCountInBags(20,1,253,1)>=1 or me.GetItemCountInBags(20,1,254,1)>=1 then
			self.FishHookId=tbTimer:Register(Env.GAME_FPS, self.FishHook_Two, self);
		end
	else
UiManager:OpenWindow("UI_INFOBOARD", "<bclr=Black><color=white>Chức năng này chỉ hoạt động trong Hậu Phục Ngưu Sơn<color>");
	end
end
