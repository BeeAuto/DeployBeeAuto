-- Optional movement overrides for newtype_deliveritem.txt. Never changes task data.
if not Ui.WJXMerchant or not Ui.WJXMerchant.loading then return; end
local M = Ui.WJXMerchant;
M.DELIVERY_FILE = "\\interface\\tool\\merchant_delivery.txt";

local function trim(text)
    return (text:gsub("^%s+", ""):gsub("%s+$", ""));
end

local function split(text, separator)
    local parts, start = {}, 1;
    while true do
        local at = text:find(separator, start, true);
        if not at then
            parts[#parts + 1] = trim(text:sub(start));
            return parts;
        end
        parts[#parts + 1] = trim(text:sub(start, at - 1));
        start = at + #separator;
    end
end

local function integer(text, minimum)
    if not text:match("^%d+$") then return; end
    local number = tonumber(text);
    if number and number >= minimum and number <= 2147483647 then return number; end
end

function M:ParseDeliveryRoutes(source)
    local function bad(line, why)
        return nil, "merchant_delivery.txt dòng " .. line .. ": " .. why;
    end
    if type(source) ~= "string" or source == "" then return bad(1, "file trống hoặc chưa đọc được."); end
    if #source > 262144 then return bad(1, "file vượt 256 KB."); end
    source = source:gsub("^\239\187\191", "");
    if source:find("\0", 1, true) then return bad(1, "hãy lưu bằng UTF-8."); end
    local result, seen, header, rows, line = {}, {}, false, 0, 0;
    for raw in (source .. "\n"):gmatch("([^\n]*)\n") do
        line = line + 1;
        raw = raw:gsub("\r$", "");
        local clean = trim(raw);
        if clean ~= "" and clean:sub(1, 1) ~= "#" then
            local cells = split(raw, "\t");
            if #cells ~= 9 then return bad(line, "cần đủ 9 cột, cách nhau bằng TAB."); end
            if not header then
                for index, name in ipairs({"TaskId", "TaskName", "NpcName", "NpcId", "nMapId",
                    "nPosX", "nPosY", "MenuPath", "Enabled"}) do
                    if cells[index] ~= name then return bad(line, "sai tiêu đề cột " .. name .. "."); end
                end
                header = true;
            else
                rows = rows + 1;
                if rows > 512 then return bad(line, "tối đa 512 tuyến."); end
                local id, npc = integer(cells[1], 1), integer(cells[4], 1);
                local map, x, y = integer(cells[5], 1), integer(cells[6], 1), integer(cells[7], 1);
                if not id or not npc or not map or not x or not y then
                    return bad(line, "TaskId, NpcId, nMapId, nPosX, nPosY phải là số nguyên dương.");
                end
                if cells[9] ~= "0" and cells[9] ~= "1" then return bad(line, "Enabled chỉ nhận 0 hoặc 1."); end
                local key = id .. ":" .. map;
                if seen[key] then return bad(line, "TaskId/bản đồ trùng dòng " .. seen[key] .. "."); end
                seen[key] = line;
                local route = {};
                if cells[8] ~= "" then
                    route = split(cells[8], "\\");
                    if #route > 8 then return bad(line, "MenuPath vượt 8 tầng."); end
                    for index, label in ipairs(route) do
                        route[index] = self:Clean(label);
                        if route[index] == "" or route[index] == self:Clean("Kết thúc đối thoại") then
                            return bad(line, "MenuPath có tầng trống hoặc Kết thúc đối thoại.");
                        end
                    end
                end
                if cells[9] == "1" then
                    result[#result + 1] = {id = id, npc = npc, map = map, x = x, y = y,
                        route = route, title = cells[2], name = cells[3], line = line};
                end
            end
        end
    end
    if not header or rows == 0 then return bad(line, "chưa có tuyến đưa thư."); end
    return result;
end

function M:ReadDeliveryRoutes()
    local ok, source = pcall(KFile.ReadTxtFile, self.DELIVERY_FILE);
    if not ok or type(source) ~= "string" then
        return nil, "Không đọc được " .. self.DELIVERY_FILE .. ".";
    end
    return self:ParseDeliveryRoutes(source);
end

function M:DeliveryPlan(j, s)
    if s.kind ~= 5 then return; end
    local city = self.cities[j.options.city];
    local current = me.GetWorldPos();
    local selected, rank;
    for _, row in ipairs(j.deliveryRoutes or {}) do
        if row.id == s.id and row.npc == s.npc and (s.map == 0 or s.map == row.map) then
            local priority = row.map == current and 1 or (row.map == city.map and 2 or 3);
            if not rank or priority < rank then selected, rank = row, priority; end
        end
    end
    return selected;
end

function M:BeginDelivery(j, s)
    if j.deliveryError then self:Stop(j.deliveryError); return; end
    local row = self:DeliveryPlan(j, s);
    if not row then
        self:Stop("merchant_delivery.txt: chưa có tuyến đang bật khớp TaskId " .. s.id ..
            ", NPC " .. s.npc .. ". Kiểm tra khai báo theo newtype_deliveritem.txt.");
        return;
    end
    j.deliveryRoute = row;
    if me.GetWorldPos() == row.map then
        self:NativePath({map = row.map, x = row.x, y = row.y, name = row.name}, "npc");
        j.npcSearched = true;
    elseif #row.route > 0 then
        self:BeginTransfer({map = row.map, label = row.name, route = row.route}, "delivery");
    else
        self:Travel({map = row.map, x = row.x, y = row.y, name = row.name}, "npc");
        j.npcSearched = true;
    end
end

function M:DeliveryArrived(j)
    local row = j.deliveryRoute;
    if not row or me.GetWorldPos() ~= row.map then
        self:Stop("Đã dùng phù nhưng bản đồ đến chưa khớp tuyến đưa thư.");
        return;
    end
    if self:FindNpc(row.npc) then
        self:Phase("npc");
    else
        self:NativePath({map = row.map, x = row.x, y = row.y, name = row.name}, "npc");
    end
    -- Do not replace the custom coordinates with the old activity's NPC metadata.
    j.npcSearched = true;
end
