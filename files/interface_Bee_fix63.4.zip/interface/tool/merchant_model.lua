-- Read-only task model. Server task variables remain authoritative.
if not Ui.WJXMerchant or not Ui.WJXMerchant.loading then return; end
local M = Ui.WJXMerchant;
M.cities = {
    {name = "Tương Dương", map = 25}, {name = "Biện Kinh", map = 23},
    {name = "Dương Châu", map = 26}, {name = "Đại Lý", map = 28},
    {name = "Lâm An", map = 29}, {name = "Thành Đô", map = 27},
    {name = "Phượng Tường", map = 24},
};
M.files = {"type_deliveritem.txt", "type_buyitem.txt", "type_finditem.txt", "type_collectitem.txt",
    "newtype_deliveritem.txt", "newtype_buyitem.txt", "newtype_finditem.txt", "newtype_collectitem.txt"};

function M:Clean(text)
    return (Ui.WJXTransfer:Clean(text):gsub("%[nhiệm vụ%]%s*", ""));
end

function M:Options(raw)
    raw = type(raw) == "table" and raw or {};
    local city = tonumber(raw.city) or 1;
    if not self.cities[city] then city = 1; end
    return {city = city, route = raw.route == 2 and 2 or 1,
        box = raw.box == 0 and 0 or 1, withdraw = raw.withdraw == 0 and 0 or 1,
        buy = raw.buy == 1 and 1 or 0};
end

function M:LoadOptions()
    return self:Options(Ui(Ui.UI_AUTOFIGHT):Load("Merchant"));
end

function M:SaveOptions(raw)
    local ui = Ui(Ui.UI_AUTOFIGHT);
    ui:Load("Merchant");
    return ui:Save("Merchant", self:Options(raw));
end

function M:Box()
    local bag = me.FindItemInBags(18, 1, 288, 1) or {};
    local repository = me.FindItemInRepository(18, 1, 288, 1) or {};
    return bag[1] and bag[1].pItem, #repository > 0;
end

function M:Row(kind, step, level, id)
    local data = Merchant and Merchant.TaskFile;
    data = data and data[step];
    data = data and data.TypeClass and data.TypeClass[kind];
    data = data and data[level];
    data = data and data.TaskEvent and data.TaskEvent[id];
    if data then return data; end
    -- Some clients load the task object after the replicated variables.
    -- Static data can display the request, but never completes a task locally.
    self.tables = self.tables or {};
    local filename = self.files[kind];
    if not filename then return; end
    if not self.tables[kind] then
        local rows = Lib:LoadTabFile("\\setting\\task\\merchant\\" .. filename);
        if type(rows) ~= "table" then return; end
        local out = {};
        for _, row in ipairs(rows) do
            local taskId = tonumber(row.TaskId);
            if taskId then out[taskId] = row; end
        end
        self.tables[kind] = out;
    end
    return self.tables[kind][id];
end

function M:Matches(item, snapshot)
    if snapshot.byName then
        return item.szOrgName == snapshot.itemName and (item.szSuffix or "") == snapshot.suffix;
    end
    return item.nGenre == snapshot.g and item.nDetail == snapshot.d and item.nParticular == snapshot.p and
        (snapshot.l == -1 or item.nLevel == snapshot.l) and
        (snapshot.series == -1 or item.nSeries == snapshot.series);
end

function M:GiftRequestMatches(job)
    local s = job.request;
    if not s or not s.active or job.action ~= "task" or not job.taskChosen then
        return false, "Chưa xác nhận luồng giao nhiệm vụ Thương Hội.";
    end
    -- Native OpenItemGift resolves this exact table via KLib.GetValByStr.
    -- Content/name text is display-only; it may differ from the task-table alias.
    local form = Task and Task.GiveItemTag and Task.GiveItemTag.tbGiveForm;
    if not form or job.gift ~= form then
        return false, "Cửa sổ giao đồ không thuộc luồng nhiệm vụ.";
    end
    local playerTask = Task:GetPlayerTask(me);
    local task = playerTask and playerTask.tbTasks and playerTask.tbTasks[50000];
    local step = task and task.tbSubData and task.tbSubData.tbSteps and task.tbSubData.tbSteps[1];
    local targets = step and step.tbTargets;
    local target = targets and #targets == 1 and targets[1];
    if not target or type(target.ItemList) ~= "table" then
        return false, "Chưa đồng bộ yêu cầu giao vật phẩm của nhiệm vụ 50000; hãy chạy lại sau.";
    end
    if tonumber(target.nNpcTempId) ~= s.npc or tonumber(target.nMapId) ~= s.map then
        return false, "NPC/bản đồ giao không khớp nhiệm vụ hiện tại.";
    end
    if s.byName then
        -- Genuine GiveItemWithName tasks require original name + suffix by design.
        local list = target.ItemList;
        if target.szTargetName == "GiveItemWithName" and list[1] == s.itemName and
            (list[2] or "") == s.suffix and tonumber(list[3]) == s.need then return true; end
    elseif target.szTargetName == "GiveItem" and #target.ItemList == 1 then
        local list = target.ItemList[1];
        if type(list) == "table" and tonumber(list[1]) == s.g and tonumber(list[2]) == s.d and
            tonumber(list[3]) == s.p and tonumber(list[4]) == s.l and
            tonumber(list[5]) == s.series and tonumber(list[6]) == s.need then return true; end
    end
    return false, "Mã hoặc số lượng vật phẩm không khớp dữ liệu nhiệm vụ đang hoạt động.";
end

function M:BagItems(snapshot)
    local found = {};
    if snapshot.byName or snapshot.l == -1 then
        for _, room in ipairs(Item.BAG_ROOM) do
            for _, index in ipairs(me.FindAllItem(room) or {}) do
                local item = KItem.GetItemObj(index);
                if item and self:Matches(item, snapshot) then found[#found + 1] = item; end
            end
        end
    else
        for _, row in ipairs(me.FindItemInBags(snapshot.g, snapshot.d, snapshot.p, snapshot.l) or {}) do
            if row.pItem and self:Matches(row.pItem, snapshot) then found[#found + 1] = row.pItem; end
        end
    end
    return found;
end

-- UI objects carry the actual room/coordinates, including mapped bag slots.
-- Never assume a raw room coordinate has a clickable object at the same UI cell.
function M:BagCells()
    local result, seen = {}, {};
    for _, group in ipairs({Ui.UI_ITEMBOX, Ui.UI_EXTBAG1, Ui.UI_EXTBAG2, Ui.UI_EXTBAG3}) do
        local window = Ui(group);
        local container = window and (window.tbMainBagCont or window.tbExtBagCont);
        if container then
            for y = 0, container.nLine - 1 do
                for x = 0, container.nRow - 1 do
                    local object = container:GetObj(x, y);
                    if object and object.nType == Ui.OBJ_OWNITEM then
                        local item = me.GetItem(object.nRoom, object.nX, object.nY);
                        local key = item and (item.dwId or item.nIndex or item);
                        if item and not seen[key] then
                            seen[key] = true;
                            result[#result + 1] = {item = item, object = object,
                                container = container, group = group, x = x, y = y};
                        end
                    end
                end
            end
        end
    end
    return result;
end

function M:WaitGiftBag(j, offered)
    if not j.giftReadAt or j.giftReadCount ~= offered then
        j.giftReadAt, j.giftReadCount = GetTime(), offered;
        for _, group in ipairs({Ui.UI_ITEMBOX, Ui.UI_EXTBAG1, Ui.UI_EXTBAG2, Ui.UI_EXTBAG3}) do
            local window = Ui(group);
            local container = window and (window.tbMainBagCont or window.tbExtBagCont);
            if container and UiManager:WindowVisible(group) == 1 then
                container:UpdateRoom();
            end
        end
    elseif GetTime() - j.giftReadAt >= 8 then
        self:Stop("Chưa đồng bộ được ô vật phẩm cần giao sau 8 giây; hãy mở lại hành trang rồi chạy lại.");
    end
end

function M:Snapshot()
    local s = {step = me.GetTask(2036, 2), kind = me.GetTask(2036, 4), id = me.GetTask(2036, 3),
        stepType = me.GetTask(2036, 5), levelType = me.GetTask(2036, 6), closed = me.GetTask(2036, 1) == 1};
    s.key = table.concat({s.step, s.kind, s.id, s.stepType, s.levelType}, ":");
    s.boxItem, s.boxRepository = self:Box();
    s.active = s.kind > 0 and s.id > 0 and not s.closed;
    if not s.active then return s; end
    local row = self:Row(s.kind, s.stepType, s.levelType, s.id);
    if not row then s.error = "Chưa đọc được dữ liệu nhiệm vụ " .. s.key; return s; end
    local function txt(key)
        return tostring(row[key] or ""):gsub('^"(.*)"$', "%1");
    end
    s.title, s.hint = txt("TaskName"), txt("StepDesc");
    s.byName = txt("TaskType") == "GiveItemWithName";
    s.itemName, s.suffix = txt("ItemName"), txt("Suffix");
    s.delivery = s.kind == 1 or s.kind == 5;
    s.collect = s.kind == 4 or s.kind == 8;
    s.g, s.d = tonumber(row.Genre) or 20, tonumber(row.Detail) or 1;
    s.p, s.l = tonumber(row.Particular) or 481, tonumber(row.Level) or 1;
    s.series, s.need = tonumber(row.Series) or 0, tonumber(row.Num) or 1;
    s.npc, s.map = tonumber(row.NpcId) or 2965, tonumber(row.MapId) or 0;
    if s.itemName == "" then s.itemName = KItem.GetNameById(s.g, s.d, s.p, s.l) or "Thư Thương Hội"; end
    s.bag = 0;
    for _, item in ipairs(self:BagItems(s)) do s.bag = s.bag + item.nCount; end
    if not s.byName and s.g == 18 and s.d == 1 and s.p == 289 then
        local token = Merchant and Merchant.TASK_ITEM_FIX and Merchant.TASK_ITEM_FIX[s.l];
        if token then
            s.token = token;
            s.stored = me.GetTask(2036, token.nTask);
        end
    end
    s.missing = math.max(0, s.need - s.bag - (s.stored or 0));
    local name, map, x, y = s.hint:match("<pos=([^,>]+),(%d+),(%d+),(%d+)>");
    if map then s.point = {map = tonumber(map), x = tonumber(x), y = tonumber(y)}; end
    if s.collect and s.p >= 469 and s.p <= 480 then s.collectNpc = s.p + 1155; end
    return s;
end

function M:FindNpc(id)
    local closest, distance;
    local x, y = me.GetNpc().GetMpsPos();
    for _, npc in pairs(KNpc.GetAroundNpcList(me, 1500) or {}) do
        if npc.nTemplateId == id then
            local nx, ny = npc.GetMpsPos();
            local d = (nx - x)^2 + (ny - y)^2;
            if not distance or d < distance then closest, distance = npc, d; end
        end
    end
    return closest, distance and math.sqrt(distance);
end

function M:NpcPoint(map, id)
    local x, y = KNpc.ClientGetNpcPos(map, id);
    if type(x) == "number" and type(y) == "number" and x > 0 and y > 0 then
        return {map = map, x = x, y = y};
    end
end
