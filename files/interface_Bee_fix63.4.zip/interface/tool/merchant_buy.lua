-- Purchase definitions are data, never executable Lua.
if not Ui.WJXMerchant or not Ui.WJXMerchant.loading then return; end
local M = Ui.WJXMerchant;
M.BUY_FILE = "\\interface\\tool\\merchant_shop.txt";

local function trim(text)
    return (text:gsub("^%s+", ""):gsub("%s+$", ""));
end

local function split(text, separator)
    local parts, start = {}, 1;
    while true do
        local at = text:find(separator, start, true);
        if not at then
            parts[#parts + 1] = trim(text:sub(start));
            return parts;
        end
        parts[#parts + 1] = trim(text:sub(start, at - 1));
        start = at + #separator;
    end
end

local function integer(text, minimum)
    if not text:match("^%d+$") then return; end
    local value = tonumber(text);
    if value and value >= minimum and value <= 2147483647 then return value; end
end

function M:ParseBuyCatalog(source)
    local function bad(line, why)
        return nil, "merchant_shop.txt dòng " .. line .. ": " .. why;
    end
    if type(source) ~= "string" or #source == 0 then return bad(1, "file trống hoặc chưa đọc được."); end
    if #source > 262144 then return bad(1, "file vượt 256 KB."); end
    source = source:gsub("^\239\187\191", "");
    if source:find("\0", 1, true) then return bad(1, "hãy lưu file bằng UTF-8."); end
    local catalog, seen, header, line, rows = {}, {}, false, 0, 0;
    for raw in (source .. "\n"):gmatch("([^\n]*)\n") do
        line = line + 1;
        raw = raw:gsub("\r$", "");
        local stripped = trim(raw);
        if stripped ~= "" and stripped:sub(1, 1) ~= "#" then
            local cells = split(raw, "\t");
            if not header then
                local names = {"ItemID", "MenuPath", "Quantity", "Coins", "Enabled"};
                if #cells < 5 or #cells > 6 then return bad(line, "cần 5 cột chính, cách nhau bằng TAB."); end
                for index, name in ipairs(names) do
                    if cells[index] ~= name then return bad(line, "sai tiêu đề cột " .. name .. "."); end
                end
                if cells[6] and cells[6] ~= "ConfirmationAliases" then return bad(line, "sai cột ConfirmationAliases."); end
                header = #cells;
            else
                rows = rows + 1;
                if rows > 512 then return bad(line, "tối đa 512 dòng vật phẩm."); end
                if #cells < 5 or #cells > header then return bad(line, "thiếu/thừa cột; dùng TAB để ngăn cột."); end
                local ids = split(cells[1], ",");
                if #ids ~= 4 then return bad(line, "ItemID cần đủ Genre,Detail,Particular,Level."); end
                for index = 1, 4 do
                    ids[index] = integer(ids[index], 0);
                    if not ids[index] then return bad(line, "ItemID phải gồm 4 số nguyên không âm."); end
                end
                local key = table.concat(ids, ":");
                if seen[key] then return bad(line, "ItemID trùng dòng " .. seen[key] .. "."); end
                seen[key] = line;
                local count, price = integer(cells[3], 1), integer(cells[4], 1);
                if not count or not price then return bad(line, "Quantity và Coins phải là số nguyên dương."); end
                if cells[5] ~= "0" and cells[5] ~= "1" then return bad(line, "Enabled chỉ nhận 0 hoặc 1."); end
                local path = split(cells[2], "\\");
                if #path < 2 then return bad(line, "cần thêm tầng chọn số lượng ở cuối MenuPath."); end
                if #path > 9 then return bad(line, "đường dẫn vượt 9 tầng."); end
                for _, label in ipairs(path) do
                    if self:Clean(label) == "" then return bad(line, "đường dẫn có tầng trống."); end
                end
                if self:Clean(path[1]) == self:Clean("Shop lệnh bài thương hội") then
                    return bad(line, "không lặp Shop lệnh bài thương hội ở đầu MenuPath.");
                end
                local leaf = path[#path];
                if self:Clean(leaf):match("^mua%s") then
                    return bad(line, "tầng cuối phải là dòng chọn số lượng, không phải dòng Mua vật phẩm.");
                end
                local name, suffixCount = leaf:gsub("%s*[xX]1$", "");
                name = trim(name);
                local quantity, suffix = name:match("^(%d+)%s+(.+)$");
                if quantity then
                    if tonumber(quantity) ~= count then return bad(line, "số lượng ở tầng cuối khác Quantity."); end
                    if suffix:match("^[xX]%s*%d") then return bad(line, "chưa hỗ trợ dòng nhân nhiều gói."); end
                    name = suffix;
                elseif suffixCount == 0 then
                    return bad(line, "tầng cuối cần số lượng hoặc hậu tố x1 để kiểm tra gói.");
                end
                if name == "" then return bad(line, "thiếu tên ở tầng chọn số lượng."); end
                local aliases = {name};
                if cells[6] and cells[6] ~= "" then
                    for _, alias in ipairs(split(cells[6], "|")) do
                        if alias == "" then return bad(line, "ConfirmationAliases có tên trống."); end
                        aliases[#aliases + 1] = alias;
                    end
                end
                if cells[5] == "1" then
                    catalog[key] = {count = count, price = price, name = name,
                        aliases = aliases, path = path, line = line};
                end
            end
        end
    end
    if not header or rows == 0 then return bad(line, "chưa có dòng vật phẩm."); end
    return catalog;
end

function M:ReadBuyCatalog()
    local ok, source = pcall(KFile.ReadTxtFile, self.BUY_FILE);
    if not ok or type(source) ~= "string" then
        return nil, "Không đọc được " .. self.BUY_FILE .. "; hãy kiểm tra file cấu hình.";
    end
    return self:ParseBuyCatalog(source);
end

function M:BuyText(text)
    return (self:Clean(text):gsub("%s*%(%s*", "("):gsub("%s*%)", ")"));
end

function M:BuyPlan(s)
    if not s.active or s.error or s.byName or s.delivery then return; end
    if not s.g or not s.d or not s.p or not s.l then return; end
    local catalog = self.job and self.job.buyCatalog;
    local entry = catalog and catalog[table.concat({s.g, s.d, s.p, s.l}, ":")];
    if not entry or s.need ~= entry.count then return; end
    local route = {"Shop lệnh bài thương hội"};
    for _, label in ipairs(entry.path) do route[#route + 1] = label; end
    return {entry = entry, route = route, step = 1, phase = "route", key = s.key,
        before = s.bag, count = entry.count, price = entry.price, pages = {}};
end


function M:BuyFunds(plan)
    local coin = tonumber(me.nCoin);
    if not coin then return false, "Chưa đọc được số Đồng thường; chưa mua."; end
    if coin < plan.price then return false, "Cần " .. plan.price .. " Đồng thường; hiện có " .. coin .. "."; end
    if me.CountFreeBagCell() < 5 then return false, "Cần ít nhất 5 ô trống hành trang để mua tại NPC."; end
    return true;
end

function M:BeginBuy(s)
    local plan = self:BuyPlan(s);
    if not plan then
        self:Stop("merchant_shop.txt: chưa có gói đang bật khớp " .. s.itemName .. " x" .. s.need .. ". Không tự chọn loại khác.");
        return;
    end
    local allowed, why = self:BuyFunds(plan);
    if not allowed then self:Stop(why); return; end
    local j = self.job;
    j.buyAttempts = j.buyAttempts or {};
    if j.buyAttempts[s.key] then self:Stop("Đã gửi mua cho bước này; không mua lặp."); return; end
    j.buy = plan;
    self:GoNpc(2965, 0, "buy", s);
    self.status = "Đến Chủ Thương Hội mua gói " .. plan.count .. " " .. plan.entry.name ..
        " — " .. plan.price .. " Đồng thường.";
end

function M:BuyFailure(text)
    local clean = self:BuyText(text);
    for _, marker in ipairs({"không đủ", "chưa đủ", "không còn chỗ", "túi đầy", "hành trang đầy", "cần ít nhất"}) do
        if clean:find(marker, 1, true) then return true; end
    end
    return clean:find("cần ", 1, true) and
        (clean:find("đồng", 1, true) or clean:find("ô trống", 1, true));
end

function M:BuyStop(message)
    -- Keep the server's explanation visible when it refuses the purchase.
    if self.job then self.job.ownedSay = nil; end
    self:Stop(message);
end

function M:BuyAnswer(j, index)
    if not j.say or UiManager:WindowVisible(Ui.UI_SAYPANEL) ~= 1 then return false; end
    j.say, j.ownedSay = nil, nil;
    j.buy.sentAt = GetTime();
    Ui(Ui.UI_SAYPANEL):OnListSel("LstSelectArray", index);
    return true;
end

function M:BuyMenuLabel(text, plan)
    local clean = self:BuyText(text);
    -- The root's three low-price entries include a second line "giá: 2000 Đồng".
    local label, amount = clean:match("^(.-)%s+giá%s*:%s*([%d%.,]+)%s+đồng$");
    if label then
        if tonumber((amount:gsub("[.,]", ""))) ~= plan.price then return nil; end
        return label;
    end
    return clean;
end

function M:BuyConfirmation(caption, plan)
    local text = self:BuyText(caption);
    if text:find("đồng khóa", 1, true) or text:find("đồng khoá", 1, true) then return false; end
    local cost, occurrences = nil, 0;
    for amount in text:gmatch("(%d[%d%.,]*)%s+đồng") do
        occurrences = occurrences + 1;
        cost = tonumber((amount:gsub("[.,]", "")));
    end
    if occurrences ~= 1 or cost ~= plan.price then return false; end
    -- The server can describe one package as "1 x 3 <item>" instead of "3 <item>".
    -- Quantity in the TXT is the item count in ONE package, not a multiplier.
    local purchase = text:gsub("×", "x");
    local packages, count, name = purchase:match("mua%s+(%d+)%s*x%s*(%d+)%s+(.+)");
    if packages then
        if tonumber(packages) ~= 1 then return false; end
    else
        count, name = purchase:match("mua%s+(%d+)%s+(.+)");
    end
    if tonumber(count) ~= plan.count or not name then return false; end
    name = name:gsub("%s+không%s*%??%s*$", ""):gsub("[%?%.!]%s*$", "");
    for _, alias in ipairs(plan.entry.aliases) do
        if name == self:BuyText(alias) then return true; end
    end
    return false;
end

function M:BuyDialogTick(j, s)
    local plan = j.buy;
    if not plan or s.key ~= plan.key then self:BuyStop("Nhiệm vụ đã đổi; không mua theo yêu cầu cũ."); return; end
    if s.bag >= s.need then
        if j.ownedSay and UiManager:WindowVisible(Ui.UI_SAYPANEL) == 1 then UiManager:CloseWindow(Ui.UI_SAYPANEL); end
        j.buy = nil;
        self:Phase("evaluate", "Đã có đủ vật phẩm; không cần mua.");
        return;
    end
    if GetTime() - j.at > 60 or (plan.sentAt and GetTime() - plan.sentAt > 12) then
        self:BuyStop("Chưa nhận được đối thoại mua phù hợp; đã dừng, không mua lặp."); return;
    end
    if not j.say or UiManager:WindowVisible(Ui.UI_SAYPANEL) ~= 1 then return; end
    local caption, options = j.say[1] or "", j.say[2] or {};
    if self:BuyFailure(caption) then self:BuyStop("NPC từ chối: " .. self:Clean(caption)); return; end
    local allowed, why = self:BuyFunds(plan);
    if not allowed then self:BuyStop(why); return; end
    if plan.phase == "route" then
        local expected = self:BuyText(plan.route[plan.step]);
        local chosen, other;
        for index, answer in ipairs(options) do
            local label = self:BuyMenuLabel(answer, plan);
            if label == expected then
                if chosen then self:BuyStop("Có nhiều lựa chọn mua trùng tên; đã dừng."); return; end
                chosen = index;
            end
            if label == self:BuyText("Ta muốn hỏi chuyện khác") then other = index; end
        end
        if not chosen and plan.step == 1 and other and not plan.askedOther then
            plan.askedOther = true;
            self:BuyAnswer(j, other);
            return;
        end
        if not chosen then self:BuyStop("merchant_shop.txt dòng " .. plan.entry.line .. ", bước " .. plan.step .. ": không có lựa chọn " .. plan.route[plan.step] .. "."); return; end
        if plan.step == #plan.route then plan.phase = "confirm";
        else plan.step = plan.step + 1; end
        self:BuyAnswer(j, chosen);
    elseif plan.phase == "confirm" then
        if not self:BuyConfirmation(caption, plan) then
            self:BuyStop("Giá / vật phẩm / số lượng xác nhận không khớp gói nhiệm vụ. Chưa bấm Đồng ý."); return;
        end
        local confirm;
        for index, answer in ipairs(options) do
            if self:BuyText(answer) == self:BuyText("Đồng ý") then
                if confirm then self:BuyStop("Có nhiều dòng Đồng ý; không tự xác nhận."); return; end
                confirm = index;
            end
        end
        if not confirm then self:BuyStop("Chưa thấy Đồng ý trong lời xác nhận mua."); return; end
        -- Reserve the attempt BEFORE dispatch so synchronous callbacks cannot buy twice.
        plan.before, plan.confirmed = s.bag, true;
        j.buyAttempts = j.buyAttempts or {};
        j.buyAttempts[s.key] = true;
        self:BuyAnswer(j, confirm);
        if self.job == j then
            -- Preserve any synchronous rejection captured by say.OnOpen.
            j.phase, j.at = "buywait", GetTime();
            self.status = "Đã xác nhận một gói; đang chờ " .. plan.count .. " " .. plan.entry.name .. " vào túi.";
        end
    end
end

function M:BuyWaitTick(j, s)
    local plan = j.buy;
    if not plan or not plan.confirmed then self:BuyStop("Không có lượt mua hợp lệ để xác nhận."); return; end
    if s.key ~= plan.key then self:BuyStop("Nhiệm vụ đổi sau khi gửi mua; kiểm tra hành trang rồi chạy lại."); return; end
    if not s.error and s.bag >= plan.before + plan.count then
        if j.ownedSay and UiManager:WindowVisible(Ui.UI_SAYPANEL) == 1 then UiManager:CloseWindow(Ui.UI_SAYPANEL); end
        j.buy = nil;
        self:Phase("evaluate", "Đã nhận đủ gói mua; chuẩn bị giao nhiệm vụ.");
        return;
    end
    if j.say and self:BuyFailure(j.say[1]) then
        self:BuyStop("NPC từ chối: " .. self:Clean(j.say[1])); return;
    end
    if GetTime() - j.at > 15 then
        self:BuyStop("Chưa xác nhận vật phẩm mua vào túi. Đã dừng, không tự mua lại.");
    end
end
