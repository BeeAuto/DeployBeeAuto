if not Ui.WJXMerchant or not Ui.WJXMerchant.loading then return; end
local M = Ui.WJXMerchant;
local V = Ui:GetClass("merchant");

function V:ReadOptions()
    return M:Options({city = self.city, route = self.route, buy = self.buy,
        box = Btn_GetCheck(self.UIGROUP, "BtnBox"), withdraw = Btn_GetCheck(self.UIGROUP, "BtnWithdraw")});
end

function V:RefreshStatus()
    local s = M:Snapshot();
    local title = s.error or s.title or (s.closed and "Không còn lượt / đã hoàn thành." or "Chưa nhận nhiệm vụ Thương Hội.");
    Txt_SetTxt(self.UIGROUP, "TxtTask", "Nhiệm vụ: " .. title);
    Txt_SetTxt(self.UIGROUP, "TxtStep", "Tiến độ: " .. tostring(s.step) .. "/" .. tostring(Merchant and Merchant.TASKDATA_MAXCOUNT or 40));
    local map = s.map and s.map > 0 and s.map or M.cities[self.city or 1].map;
    local destination = s.delivery and ("NPC " .. s.npc .. (s.map == 0 and " — trong hoạt động" or " — " .. GetMapNameFormId(map))) or
        ("Chủ Thương Hội — " .. M.cities[self.city or 1].name);
    Txt_SetTxt(self.UIGROUP, "TxtDestination", "Nơi giao: " .. destination);
    Txt_SetTxt(self.UIGROUP, "TxtItem", s.itemName or "—");
    Wnd_SetTip(self.UIGROUP, "TxtItem", (s.itemName or "") .. (s.suffix and s.suffix ~= "" and " - " .. s.suffix or ""));
    for name, key in pairs({TxtNeed = "need", TxtBag = "bag", TxtStored = "stored", TxtMissing = "missing"}) do
        Txt_SetTxt(self.UIGROUP, name, s[key] ~= nil and tostring(s[key]) or "—");
    end
    local hint = s.hint and s.hint:gsub("<pos=([^,]+),[^>]+>", "%1") or "";
    Txt_SetTxt(self.UIGROUP, "TxtHint", "Hướng dẫn: " .. hint);
    Txt_SetTxt(self.UIGROUP, "TxtBox", "Hộp lệnh bài: " .. (s.boxItem and "Trong hành trang" or s.boxRepository and "Trong rương chứa đồ" or "Chưa có") ..
        " | Ô trống: " .. me.CountFreeBagCell());
    local status = M.status or "Lưu cài đặt rồi Bắt Đầu để nhận / tiếp tục nhiệm vụ.";
    if s.active and not s.error and s.bag < s.need and s.missing == 0 and (s.stored or 0) > 0 and not M.job then
        status = "Cần rút " .. (s.need - s.bag) .. " lệnh bài từ hộp trước khi giao.";
    end
    if self.dirty then status = "Có cài đặt chưa lưu. " .. status; end
    Txt_SetTxt(self.UIGROUP, "TxtStatus", (M.job and "Đang chạy | " or "Đang dừng | ") .. status);
    Wnd_SetEnable(self.UIGROUP, "BtnStop", M.job and 1 or 0);
end

function V:OnOpen()
    self.updating = true;
    if self.owner ~= me.szName or self.faction ~= me.nFaction then
        self.owner, self.faction = me.szName, me.nFaction;
        local options = M:LoadOptions();
        self.city, self.route = options.city, options.route;
        self.buy = options.buy;
        Btn_Check(self.UIGROUP, "BtnBox", options.box);
        Btn_Check(self.UIGROUP, "BtnWithdraw", options.withdraw);
        self.dirty = false;
    end
    Btn_Check(self.UIGROUP, "BtnGather", self.buy == 1 and 0 or 1);
    Btn_Check(self.UIGROUP, "BtnBuy", self.buy == 1 and 1 or 0);
    ClearComboBoxItem(self.UIGROUP, "CmbCity");
    for i, city in ipairs(M.cities) do ComboBoxAddItem(self.UIGROUP, "CmbCity", i, city.name); end
    ClearComboBoxItem(self.UIGROUP, "CmbRoute");
    ComboBoxAddItem(self.UIGROUP, "CmbRoute", 1, "Thương Hội Cấp 60");
    ComboBoxAddItem(self.UIGROUP, "CmbRoute", 2, "Qua Thành");
    ComboBoxSelectItem(self.UIGROUP, "CmbCity", self.city - 1);
    ComboBoxSelectItem(self.UIGROUP, "CmbRoute", self.route - 1);
    self.updating = nil;
    self:RefreshStatus();
    if self.timer then Ui.tbLogic.tbTimer:Close(self.timer); end
    self.timer = Ui.tbLogic.tbTimer:Register(Env.GAME_FPS, function()
        if UiManager:WindowVisible(M.GROUP) ~= 1 then self.timer = nil; return 0; end
        local ok, why = pcall(V.RefreshStatus, self);
        if not ok then
            self.timer = nil;
            me.Msg("[Thương Hội] Lỗi đọc giao diện: " .. tostring(why));
            return 0;
        end
        return Env.GAME_FPS;
    end);
end

function V:OnClose()
    if self.timer then Ui.tbLogic.tbTimer:Close(self.timer); self.timer = nil; end
    -- The controller owns a separate timer and survives closing this view.
end

function V:OnEscExclusiveWnd()
    UiManager:CloseWindow(self.UIGROUP);
end

function V:OnComboBoxIndexChange(name, index)
    if self.updating then return; end
    local value = index + 1;
    if name == "CmbCity" and M.cities[value] then self.city = value;
    elseif name == "CmbRoute" and (value == 1 or value == 2) then self.route = value;
    else return; end
    self.dirty = true;
    self:RefreshStatus(); -- Never rebuild a combo during dropdown callbacks.
end

function V:OnButtonClick(name)
    if name == "BtnClose" or name == "BtnCloseX" then
        UiManager:CloseWindow(self.UIGROUP);
        return;
    elseif name == "BtnStop" then
        M:Stop("Đã dừng Auto Thương Hội.");
    elseif name == "BtnSave" or name == "BtnStart" then
        local options = self:ReadOptions();
        if not M:SaveOptions(options) then return; end
        self.dirty = false;
        if name == "BtnStart" then M:Start(options);
        else M:Message("Đã lưu cài đặt. Phiên đang chạy giữ cấu hình lúc Bắt Đầu."); end
    elseif name == "BtnBox" or name == "BtnWithdraw" then
        self.dirty = true;
    elseif name == "BtnGather" or name == "BtnBuy" then
        self.buy = name == "BtnBuy" and 1 or 0;
        Btn_Check(self.UIGROUP, "BtnGather", 1 - self.buy);
        Btn_Check(self.UIGROUP, "BtnBuy", self.buy);
        self.dirty = true;
    else
        return; -- Dropdown child buttons must keep their native behavior.
    end
    self:RefreshStatus();
end
