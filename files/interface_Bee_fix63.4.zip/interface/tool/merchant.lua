-- Entry point loaded by the Tools plugin; all runtime state belongs to this module.
Ui.WJXMerchant = Ui.WJXMerchant or {};
local M = Ui.WJXMerchant;
M.GROUP = "UI_WJXMERCHANT";
M.VERSION = "1.4.0";

function M:EnsureModules()
    if self.ready then return; end
    local ok, why = pcall(function()
        self.loading = true;
        if not Ui.WJXTransfer then Require("\\interface\\btssl_autofight\\script\\window\\autofight_transfer.lua"); end
        for _, name in ipairs({"merchant_model.lua", "merchant_buy.lua", "merchant_delivery.lua", "merchant_controller.lua", "merchant_view.lua"}) do
            local path = "\\interface\\tool\\" .. name;
            local source = assert(KFile.ReadTxtFile(path), "Không đọc được " .. path);
            assert(loadstring(source:gsub("^\239\187\191", ""), "@" .. path))();
        end
    end);
    self.loading = nil;
    if not ok then error(why); end
    self.ready = true;
end

function M:RegisterWindow()
    self:EnsureModules();
    local native = LoadUiGroup;
    local filename = "merchant.ini";
    local buffer = filename .. string.rep("\0", 256 - #filename);
    LoadUiGroup = function(group, name, ...)
        if group == M.GROUP then name = buffer; end
        return native(group, name, unpack(arg));
    end;
    local ok, why = pcall(Ui.RegisterNewUiWindow, Ui, self.GROUP, "merchant",
        {"a", 140, 70}, {"b", 252, 154}, {"c", 380, 220});
    LoadUiGroup = native;
    if not ok then error(why); end
    local w, h = Wnd_GetSize(self.GROUP, "Main");
    assert(w and w > 0 and h and h > 0, "Chưa nạp merchant.ini; hãy thoát hẳn game rồi vào lại.");
    local v = Ui.tbWnd[self.GROUP];
    assert(v and v.OnOpen and v.OnButtonClick and v.OnComboBoxIndexChange, "Đăng ký UI chưa đầy đủ.");
    if GetUiMode() == "d" then
        Ui:AddExWndConfig(self.GROUP, {"d", 700, 356});
        Ui:LoadExWndConfig(self.GROUP);
    end
    self.windowReady = true;
end

function M:Open()
    local ok, why = pcall(function()
        if not self.windowReady then self:RegisterWindow(); end
        self:Install();
        if UiManager:WindowVisible(self.GROUP) == 1 then Wnd_BringTop(self.GROUP, "Main");
        else UiManager:OpenWindow(self.GROUP); end
    end);
    if not ok then me.Msg("[Thương Hội] Không mở được giao diện: " .. tostring(why)); end
end
