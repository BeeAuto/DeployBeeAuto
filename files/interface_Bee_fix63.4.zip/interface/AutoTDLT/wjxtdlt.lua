-- Auto Tranh Đoạt Lãnh Thổ (by HUKT) — file vào. Chỉ file này tự chạy khi client nạp plugin; các file wjxtdlt_*.lua
-- có lính gác "loading" và chỉ được nạp qua M:EnsureModules() (mở cửa sổ lần đầu hoặc nhận lệnh đội trưởng).
-- Cửa sổ kiểu tab BOSS của CheckBOSS: lọc theo nước → lãnh thổ → trụ + toạ độ; phân công từng thành viên sang bản đồ khác.
-- Plugin RIÊNG: không sửa, không gọi lệnh của Điều Phối / TDC / CheckBOSS / Auto6 cũ. Auto khác đang điều khiển nhân vật
-- thì chỉ quan sát. Lệnh đội dùng tiền tố riêng [WJXTD:...] trên kênh Đội, không đụng [WJXPT:]/[WJXXY:].
Ui.WJXTDLT = Ui.WJXTDLT or {};
local M = Ui.WJXTDLT;
M.GROUP = "UI_WJXTDLT";
M.CLASS = "wjxtdlt_main";
M.INI = "wjxtdlt_main.ini";
M.DIR = "\\interface\\AutoTDLT\\";
M.VERSION = "0.4.2";
M.TOOL_BUTTON = "BtnTDLT";
M.MODULES = {"wjxtdlt_data.lua", "wjxtdlt_model.lua", "wjxtdlt_controller.lua", "wjxtdlt_view.lua"};
M.PREFIX = "[WJXTD:";

function M:Message(text)
    self.status = tostring(text);
    if me and me.Msg then me.Msg("[Auto TĐLT] " .. self.status); end
end

function M:EnsureModules()
    if self.ready then return; end
    local ok, why = pcall(function()
        self.loading = true;
        for _, name in ipairs(self.MODULES) do
            local path = self.DIR .. name;
            local source = assert(KFile.ReadTxtFile(path), "Không đọc được " .. path);
            assert(loadstring(string.gsub(source, "^\239\187\191", ""), "@" .. path))();
        end
    end);
    self.loading = nil;
    if not ok then error(why); end
    self.ready = true;
end

function M:RegisterWindow()
    self:EnsureModules();
    local native = LoadUiGroup;
    -- Game.exe chép cố định 256 byte từ con trỏ tên INI: đệm NUL như tool/merchant.
    local buffer = self.INI .. string.rep("\0", 256 - string.len(self.INI));
    LoadUiGroup = function(group, name, a, b)
        if group == M.GROUP then name = buffer; end
        return native(group, name, a, b);
    end;
    local ok, why = pcall(Ui.RegisterNewUiWindow, Ui, self.GROUP, self.CLASS,
        {"a", 90, 20}, {"b", 200, 90}, {"c", 330, 150});
    LoadUiGroup = native;
    if not ok then error(why); end
    local w, h = Wnd_GetSize(self.GROUP, "Main");
    assert(w and w > 0 and h and h > 0, "Chưa nạp " .. self.INI .. "; hãy thoát hẳn game rồi vào lại.");
    local v = Ui.tbWnd[self.GROUP];
    assert(v and v.OnOpen and v.OnButtonClick and v.OnComboBoxIndexChange, "Đăng ký cửa sổ Auto TĐLT chưa đầy đủ.");
    if GetUiMode() == "d" then
        Ui:AddExWndConfig(self.GROUP, {"d", 650, 260});
        Ui:LoadExWndConfig(self.GROUP);
    end
    self.windowReady = true;
end

function M:Open()
    local ok, why = pcall(function()
        if not self.windowReady then self:RegisterWindow(); end
        if UiManager:WindowVisible(self.GROUP) == 1 then Wnd_BringTop(self.GROUP, "Main");
        else UiManager:OpenWindow(self.GROUP); end
    end);
    if not ok then self:Message("Không mở được giao diện: " .. tostring(why)); end
end

-- ---------------------------------------------------------------- nhận lệnh đội trưởng (kênh Đội)
-- Bọc Ui(UI_MSGPAD).OnSendMsgToChannel đúng 1 lớp cho mỗi đối tượng bảng chat (như Điều Phối): hàm cũ luôn chạy trước,
-- chỉ tin nhắn kênh Đội bắt đầu bằng [WJXTD: mới được xử lý — ở nhịp hẹn giờ kế tiếp, lỗi không làm vỡ khung chat.
local C = Ui.WJXTDLTChat or {};
Ui.WJXTDLTChat = C;
function C:Install()
    if not Ui.UI_MSGPAD then return false; end
    local okPad, pad = pcall(Ui, Ui.UI_MSGPAD);
    if not okPad or type(pad) ~= "table" or type(pad.OnSendMsgToChannel) ~= "function" then return false; end
    if pad == self.pad then return true; end
    local old = pad.OnSendMsgToChannel;
    pad.OnSendMsgToChannel = function(w, channel, sender, msg, gateway)
        local result = old(w, channel, sender, msg, gateway);
        if channel == "Team" and type(msg) == "string" and string.sub(msg, 1, 7) == M.PREFIX then
            Ui.tbLogic.tbTimer:Register(1, function()
                local ok, err = pcall(function()
                    M:EnsureModules();
                    M:Receive(sender, msg);
                end);
                if not ok then M:Message("Lỗi nhận lệnh đội: " .. tostring(err)); end
                return 0;
            end);
        end
        return result;
    end;
    self.pad = pad;
    return true;
end

-- ---------------------------------------------------------------- nút "Auto TĐLT" ở thanh End
-- Dùng CHUNG bộ chia Ui.WJXToolButtons với Chính Tuyến / Tiêu Dao v2: chỉ bọc UI_TOOL.OnButtonClick đúng 1 lớp.
local D = Ui.WJXToolButtons or {handlers = {}};
Ui.WJXToolButtons = D;
if not D.Install then
    function D:Install()
        local w = Ui.tbWnd and Ui.tbWnd["UI_TOOL"];
        if type(w) ~= "table" or type(w.OnButtonClick) ~= "function" then return false; end
        if w.OnButtonClick == self.hook then return true; end
        local original = w.OnButtonClick;
        local hook;
        hook = function(window, name, param, extra)
            local handler = D.handlers[name];
            if handler then handler(); return; end
            return original(window, name, param, extra);
        end;
        self.hook = hook;
        w.OnButtonClick = hook;
        return true;
    end
end
if not D.Watch then
    function D:Watch()
        if self.watch then return; end
        local timer = Ui.tbLogic and Ui.tbLogic.tbTimer;
        if not timer then return; end
        local checks = 0;
        self.watch = timer:Register(Env.GAME_FPS, function()
            checks = checks + 1;
            local ok, hooked = pcall(D.Install, D);
            if (ok and hooked and checks >= 120) or checks >= 600 then D.watch = nil; return 0; end
            return Env.GAME_FPS;
        end);
    end
end

D.handlers[M.TOOL_BUTTON] = function() M:Open(); end;
pcall(D.Install, D);
pcall(D.Watch, D);

-- Gác bảng chat: thử mỗi 5 giây (bảng chat có thể dựng lại sau khi vào game); rẻ, chỉ so sánh 1 đối tượng.
if not C.watch and Ui.tbLogic and Ui.tbLogic.tbTimer then
    C.watch = Ui.tbLogic.tbTimer:Register(Env.GAME_FPS * 5, function()
        pcall(C.Install, C);
        return Env.GAME_FPS * 5;
    end);
end
pcall(C.Install, C);
