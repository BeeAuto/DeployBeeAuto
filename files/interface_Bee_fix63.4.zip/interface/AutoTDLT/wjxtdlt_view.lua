-- Auto TĐLT — VIEW (kiểu CheckBOSS + ô tìm của Auto Du Long):
--   tab Điều Phối: tuỳ chọn bản thân + bảng thành viên (phân công, trạng thái báo về, PT Tập Trung, Dừng từng người);
--   tab Tọa Độ: [Tìm] [Đang Đứng] + combo Khu vực lọc danh sách bản đồ (trái, phân trang) → trụ + toạ độ (phải):
--   tick chọn trụ, Đến (bản thân), PT Tập Trung (cả đội tới toạ độ trụ);
--   thanh Phân công: chọn người + chế độ → Giao (sang được bản đồ khác). Đóng cửa sổ không dừng auto.
if not Ui.WJXTDLT or not Ui.WJXTDLT.loading then return; end
local M = Ui.WJXTDLT;
local V = Ui:GetClass(M.CLASS);
-- Hàng trái đang chọn: nền sáng + chữ vàng (như Auto Du Long); không thêm "> " để chữ không bị xô lệch.
local function markRow(group, row, bg, on)
    (on and Wnd_Show or Wnd_Hide)(group, bg);
    if Btn_SetTextColor then pcall(Btn_SetTextColor, group, row, on and 0xFFD482 or 0xE6E6B4); end
end
local CHECKS = {BtnAuto6 = "auto6", BtnDismount = "dismount", BtnPvp = "pvp", BtnRevive = "revive", BtnAccept = "accept",
    BtnScroll = "scroll", BtnHelpful = "helpful", BtnSupplyReturn = "sret"};
local SIZE = 6;
local TABS = {0, 1, 2};
local PAGE2 = {"TxtCity", "CmbCity", "BtnSupplyGather", "TxtJunXu", "CmbJunXu", "BtnHelpful", "BtnSupplyReturn",
    "BtnSupplySelf", "BtnSupplyTeam", "BtnMedOpen", "BtnMedOpenPT", "TxtSupplyNote"};
local REGIONS = {0, 1, 2, 3, 4};      -- 0 = mọi khu vực; còn lại = M.COUNTRY
local PAGE0 = {"BtnAuto6", "BtnDismount", "BtnPvp", "BtnRevive", "BtnAccept", "BtnScroll", "TxtRange", "CmbRange", "TxtTowersHere"};
local PAGEC = {"SearchBg", "BtnFind", "BtnClear", "BtnHere", "TxtRegion", "CmbRegion", "TxtCount", "BtnAllTowers", "BtnNoTowers",
    "BtnMapPrev", "TxtMapPage", "BtnMapNext", "TxtSelected"};

local function fillCombo(group, name, items, selected)
    ClearComboBoxItem(group, name);
    for i, text in ipairs(items) do ComboBoxAddItem(group, name, i, text); end
    ComboBoxSelectItem(group, name, math.max(0, (selected or 1) - 1));
end

local function contains(list, v) for _, x in ipairs(list or {}) do if x == v then return true; end end return false; end

local function short(s, n)
    s = tostring(s or "");
    if string.len(s) <= n then return s; end
    -- cắt theo byte nhưng không cắt giữa ký tự UTF-8
    local cut = n;
    while cut > 0 and string.byte(s, cut + 1) and string.byte(s, cut + 1) >= 128 and string.byte(s, cut + 1) < 192 do cut = cut - 1; end
    return string.sub(s, 1, cut) .. "…";
end

-- ---------------------------------------------------------------- tuỳ chọn
function V:ReadOptions()
    local o = self.draft or M:LoadOptions();
    for name, key in pairs(CHECKS) do o[key] = Btn_GetCheck(self.UIGROUP, name); end
    o.range = self.range or o.range;
    o.city, o.jx = self.city or o.city, self.jx or o.jx;
    self.draft = M:Options(o);
    return self.draft;
end

function V:Fill()
    local o = self.draft;
    self.updating = true;
    for name, key in pairs(CHECKS) do Btn_Check(self.UIGROUP, name, o[key]); end
    self.range = o.range;
    local ranges, index = {}, 1;
    for i, r in ipairs(M.RANGES) do ranges[i] = r .. " MPS"; if r == self.range then index = i; end end
    fillCombo(self.UIGROUP, "CmbRange", ranges, index);
    self.mode = self.mode or o.mode;
    fillCombo(self.UIGROUP, "CmbMode", M.MODES, self.mode);
    local regions, rindex = {}, 1;
    for i, r in ipairs(REGIONS) do regions[i] = r == 0 and "Tất cả khu vực" or M.COUNTRY[r]; if r == (self.region or 0) then rindex = i; end end
    fillCombo(self.UIGROUP, "CmbRegion", regions, rindex);
    local cities, cindex = {}, 1;
    self.city, self.jx = o.city, o.jx;
    for i, c in ipairs(M.CITIES) do cities[i] = c[2]; if c[1] == self.city then cindex = i; end end
    fillCombo(self.UIGROUP, "CmbCity", cities, cindex);
    fillCombo(self.UIGROUP, "CmbJunXu", M.JX_KINDS, self.jx);
    Edt_SetTxt(self.UIGROUP, "EdtSearch", self.query or "");
    self.updating = nil;
    self.teamKey = nil;
    self:RefreshTeam();
end

-- ---------------------------------------------------------------- đội (combo chỉ dựng lại khi đội đổi, để không đóng danh sách đang mở)
function V:RefreshTeam()
    local members, leader = M:Team();
    local names = {me.szName};
    for _, m in ipairs(members) do names[#names + 1] = m.szName; end
    local key = table.concat(names, "\1") .. "\2" .. tostring(leader);
    if key == self.teamKey then return; end
    self.teamKey, self.names, self.leader = key, names, leader;
    local items = {};
    for i, n in ipairs(names) do items[i] = i == 1 and "Bản thân" or n; end
    local keep = 1;
    for i, n in ipairs(names) do if n == self.memberName then keep = i; end end
    self.memberName = names[keep];
    self.updating = true;
    fillCombo(self.UIGROUP, "CmbMember", items, keep);
    self.updating = nil;
end

-- ---------------------------------------------------------------- vẽ
function V:CurrentMap()
    local map = me.GetWorldPos();
    return M.MAPS[map] and map or nil;
end

-- Lọc danh sách bản đồ: khu vực (combo) + từ khoá (không phân biệt hoa thường / dấu; khớp tên, số map, thôn trấn/dã ngoại).
-- "Đang Đứng" = chỉ bản đồ hiện tại.
function V:Filter()
    local list = {};
    if self.onlyHere then
        if self:CurrentMap() then list[1] = self:CurrentMap(); end
    else
        local q = M:Fold(self.query or "");
        local regions = (self.region or 0) == 0 and {1, 2, 3, 4} or {self.region};
        for _, r in ipairs(regions) do
            for _, map in ipairs(M:CountryMaps(r)) do
                local info = M.MAPS[map];
                local hay = M:Fold(info.name .. " " .. map .. " " .. (info.kind == "village" and "thôn trấn" or "dã ngoại") ..
                    " " .. (M.COUNTRY[info.country] or ""));
                if q == "" or string.find(hay, q, 1, true) then list[#list + 1] = map; end
            end
        end
    end
    self.filtered = list;
    local keep;
    for k, map in ipairs(list) do if map == self.selMap then keep = k; end end
    if not keep and list[1] then
        if self.selMap ~= list[1] then self.selMask = 0; end
        self.selMap, keep = list[1], 1;
    end
    self.mapPage = keep and (math.floor((keep - 1) / SIZE) + 1) or 1;
end

function V:SelectMap(map)
    if not M.MAPS[map] then return; end
    self.selMap = map;
    self:Filter();
end

function V:Render()
    local country = self.tab == 1;
    for _, t in ipairs(TABS) do Btn_Check(self.UIGROUP, "Tab" .. t, t == self.tab and 1 or 0); end
    for _, n in ipairs(PAGE0) do (self.tab == 0 and Wnd_Show or Wnd_Hide)(self.UIGROUP, n); end
    for _, n in ipairs(PAGEC) do (country and Wnd_Show or Wnd_Hide)(self.UIGROUP, n); end
    for _, n in ipairs(PAGE2) do (self.tab == 2 and Wnd_Show or Wnd_Hide)(self.UIGROUP, n); end
    if self.tab == 2 then Wnd_SetEnable(self.UIGROUP, "BtnMedOpenPT", M:IsLeader() and 1 or 0); end
    if self.tab == 2 then Wnd_SetEnable(self.UIGROUP, "BtnSupplyTeam", M:IsLeader() and 1 or 0); Wnd_SetEnable(self.UIGROUP, "BtnSupplyGather", M:IsLeader() and 1 or 0); end
    self.mapSlots, self.towerSlots = {}, {};
    if not self.filtered then self:Filter(); end
    local maps = country and self.filtered or {};
    Txt_SetTxt(self.UIGROUP, "TxtCount", self.onlyHere and (#maps > 0 and "Đang đứng" or "Không ở bản đồ tranh đoạt") or (#maps .. " bản đồ"));
    local pages = math.max(1, math.ceil(#maps / SIZE));
    self.mapPage = math.max(1, math.min(self.mapPage or 1, pages));
    local here = me.GetWorldPos();
    for slot = 1, SIZE do
        local map = maps[(self.mapPage - 1) * SIZE + slot];
        local row = "BtnMapRow" .. slot;
        if map then
            local info = M.MAPS[map];
            self.mapSlots[slot] = map;
            Wnd_Show(self.UIGROUP, row);
            markRow(self.UIGROUP, row, "MapSel" .. slot, map == self.selMap);
            Btn_SetTxt(self.UIGROUP, row, short(info.name, 26) ..
                (map == here and " [đang đứng]" or "") .. "\n" .. (info.kind == "village" and "Thôn trấn" or "Dã ngoại") ..
                " · " .. #info.towers .. " trụ · map " .. map);
            Wnd_SetTip(self.UIGROUP, row, info.name .. " (map " .. map .. ", lãnh thổ " .. info.domain .. ")\nBấm để xem các trụ.");
        else
            Wnd_Hide(self.UIGROUP, row); Wnd_Hide(self.UIGROUP, "MapSel" .. slot);
        end
    end
    Txt_SetTxt(self.UIGROUP, "TxtMapPage", self.mapPage .. "/" .. pages);
    Wnd_SetEnable(self.UIGROUP, "BtnMapPrev", self.mapPage > 1 and 1 or 0);
    Wnd_SetEnable(self.UIGROUP, "BtnMapNext", self.mapPage < pages and 1 or 0);
    local info = country and self.selMap and M.MAPS[self.selMap];
    if info and not contains(maps, self.selMap) then info = nil; end
    local mask = self.selMask or 0;
    local canLead = M:IsLeader();
    for slot = 1, SIZE do
        local check, go, gather = "ChkTower" .. slot, "BtnGo" .. slot, "BtnTowerGather" .. slot;
        local p = info and info.towers[slot];
        if p then
            self.towerSlots[slot] = slot;
            Wnd_Show(self.UIGROUP, check); Wnd_Show(self.UIGROUP, go); Wnd_Show(self.UIGROUP, gather);
            Wnd_SetEnable(self.UIGROUP, gather, canLead and 1 or 0);
            Wnd_SetTip(self.UIGROUP, gather, "Gọi cả đội (kể cả bạn) tới trụ " .. slot .. " — " .. info.name .. " (" ..
                M:ShowPos(p[1], p[2]) .. "); tới nơi trụ địch thì đánh, không thì giữ điểm.");
            Btn_Check(self.UIGROUP, check, M:HasBit(mask, slot) and 1 or 0);
            Wnd_SetTip(self.UIGROUP, check, info.name .. " — Trụ " .. slot .. "\nToạ độ (" .. M:ShowPos(p[1], p[2]) .. ")" ..
                "\nKhông tick trụ nào = mọi trụ của bản đồ.");
            Wnd_SetTip(self.UIGROUP, go, "Bản thân tới giữ trụ " .. slot .. " (" .. info.name .. ").");
        else
            Wnd_Hide(self.UIGROUP, check); Wnd_Hide(self.UIGROUP, go); Wnd_Hide(self.UIGROUP, gather);
        end
    end
    self:Status();
end

function V:TowerMark(map, i)
    local s = M:TowerState(M:MemoryFor(map), i);
    if not s then return "?"; end
    return s.down and "đổ" or (s.enemy and "địch" or "ta");
end

function V:SelectionText()
    if not self.selMap then return "Chưa chọn lãnh thổ: Giao = bản đồ người nhận đang đứng, mọi trụ."; end
    return "Đã chọn: " .. M:MapName(self.selMap) .. " · " .. M:TowerLabel(self.selMask or 0) ..
        " · " .. (M.MODES[self.mode or 1] or "?");
end

function V:MemberLine(i, name)
    local r = M.reports and M.reports[name];
    local a = M.assignments and M.assignments[name];
    local leader = self.leader == name;
    local title = i .. ". " .. (i == 1 and "Bản thân" or short(name, 18)) .. (leader and " [ĐT]" or "");
    local plan;
    if i == 1 then
        local j = M.job;
        plan = j and M:PlanLabel(j.options.mode, j.options.mask, j.fixed and j.map or 0) or "đang dừng";
    elseif a then plan = M:PlanLabel(a.mode, a.mask, a.map);
    elseif r and r.mode and r.mode > 0 then plan = M:PlanLabel(r.mode, r.mask, r.goal); end
    title = title .. " — " .. (plan or "chưa phân công");
    local line;
    if i == 1 then
        line = (M.job and (M.work or "—") or "—");
    elseif a and (not r or r.at < a.at) then
        line = GetTime() - a.at > 30 and ("Chưa phản hồi (" .. math.floor(GetTime() - a.at) .. "s) — cần cài Auto TĐLT, tick Nhận phân công")
            or "Chờ nhận lệnh";
    elseif r then
        line = (M.STATES[r.state] or "?") .. (r.tower and r.tower > 0 and (" trụ " .. r.tower) or "") ..
            " | " .. M:MapName(r.map) .. " (" .. M:ShowPos(r.x, r.y) .. ")";
        local age = math.floor(GetTime() - r.at);
        if age > 60 then line = "Cũ " .. age .. "s: " .. line; end
    else
        line = "Chưa có tin (chỉ hiện khi thành viên đang chạy Auto TĐLT).";
    end
    return title, line;
end

function V:Status()
    self:RefreshTeam();
    local map = me.GetWorldPos();
    local info = M.MAPS[map];
    local score, towers, kills = M:MyScore();
    local battle = M:Campaign();
    Txt_SetTxt(self.UIGROUP, "TxtInfo", (info and ("Đang ở: " .. info.name .. " (" .. #info.towers .. " trụ)") or "Đang ở: ngoài bản đồ tranh đoạt") ..
        " · " .. (battle and "có dữ liệu trận" or "chưa có dữ liệu trận") ..
        " · Công trận " .. score .. " · Đội hạ trụ " .. towers .. " · hạ địch " .. kills);
    local rows, top = M:Scoreboard(3), {};
    for i, r in ipairs(rows) do top[#top + 1] = i .. ". " .. short(r.name, 16) .. " " .. r.score; end
    Txt_SetTxt(self.UIGROUP, "TxtScore", "Xếp hạng bản đồ: " .. (#top > 0 and table.concat(top, " · ") or "—"));
    local country = self.tab == 1;
    if country then
        local sel = self.selMap and M.MAPS[self.selMap];
        for slot = 1, SIZE do
            local p = sel and contains(self.filtered, self.selMap) and sel.towers[slot];
            if p then
                Btn_SetTxt(self.UIGROUP, "ChkTower" .. slot, "Trụ " .. slot .. " · " .. self:TowerMark(self.selMap, slot) ..
                    "\n(" .. M:ShowPos(p[1], p[2]) .. ")");
            end
        end
        Txt_SetTxt(self.UIGROUP, "TxtSelected", self:SelectionText());
    else
        Txt_SetTxt(self.UIGROUP, "TxtTowersHere", info and ("Trụ: " .. M:TowerText(info, M:MemoryFor(map))) or "");
    end
    local canLead = M:IsLeader();
    for i = 1, SIZE do
        local name = self.names and self.names[i];
        local show = self.tab == 0 and name ~= nil;
        for _, prefix in ipairs({"TxtMember", "TxtState", "BtnStopMember", "BtnGatherMember"}) do (show and Wnd_Show or Wnd_Hide)(self.UIGROUP, prefix .. i); end
        if show then
            local title, line = self:MemberLine(i, name);
            Txt_SetTxt(self.UIGROUP, "TxtMember" .. i, title);
            Txt_SetTxt(self.UIGROUP, "TxtState" .. i, short(line, 110));
            Wnd_SetEnable(self.UIGROUP, "BtnStopMember" .. i, (i == 1 and M.job) and 1 or ((i > 1 and canLead) and 1 or 0));
            Wnd_SetEnable(self.UIGROUP, "BtnGatherMember" .. i, canLead and 1 or 0);
        end
    end
    Wnd_SetEnable(self.UIGROUP, "BtnStopPT", canLead and 1 or 0);
    Wnd_SetEnable(self.UIGROUP, "BtnAssignAll", canLead and 1 or 0);
    Wnd_SetEnable(self.UIGROUP, "BtnStop", M.job and 1 or 0);
    local status = M.status or "Chọn lãnh thổ / trụ ở tab nước, chọn người + chế độ rồi bấm Giao.";
    if self.dirty then status = "Có cài đặt chưa lưu. " .. status; end
    Txt_SetTxt(self.UIGROUP, "TxtStatus", short((M.job and "Đang chạy | " or "Đang dừng | ") .. status, 200));
end

-- ---------------------------------------------------------------- sự kiện
function V:OnOpen()
    if self.owner ~= me.szName or not self.draft then
        self.owner = me.szName;
        self.draft = M:LoadOptions();
        self.dirty = false;
        self.mode = self.draft.mode;
        self.tab, self.selMap, self.selMask, self.region, self.query, self.onlyHere = 0, nil, 0, 0, "", nil;
        if self.draft.map ~= 0 then self:SelectMap(self.draft.map); self.selMask = self.draft.mask;
        elseif self:CurrentMap() then self:SelectMap(self:CurrentMap()); end
    end
    -- Ô tick do Game.exe dựng lại khi mở cửa sổ (mất trạng thái): luôn đổ lại từ bản nháp đang giữ trong Lua.
    self:Fill();
    self:Render();
    if self.timer then Ui.tbLogic.tbTimer:Close(self.timer); end
    local window = self;
    self.timer = Ui.tbLogic.tbTimer:Register(Env.GAME_FPS, function()
        if UiManager:WindowVisible(M.GROUP) ~= 1 then window.timer = nil; return 0; end
        local ok, why = pcall(V.Status, window);
        if not ok then window.timer = nil; M:Message("Lỗi đọc giao diện: " .. tostring(why)); return 0; end
        return Env.GAME_FPS;
    end);
end

function V:OnClose()
    if self.timer then Ui.tbLogic.tbTimer:Close(self.timer); self.timer = nil; end
end

function V:OnEscExclusiveWnd()
    UiManager:CloseWindow(self.UIGROUP);
end

function V:OnComboBoxIndexChange(name, index)
    if self.updating then return; end
    local value = (tonumber(index) or 0) + 1;
    if name == "CmbRange" and M.RANGES[value] then
        self.range = M.RANGES[value];
        self.dirty = true;
        self:ReadOptions();
    elseif name == "CmbRegion" and REGIONS[value] then
        self.region, self.onlyHere = REGIONS[value], nil;
        self.query = Edt_GetTxt(self.UIGROUP, "EdtSearch") or "";
        self:Filter();
        self:Render();
        return;
    elseif name == "CmbCity" and M.CITIES[value] then
        self.city = M.CITIES[value][1];
        self.dirty = true;
        self:ReadOptions();
    elseif name == "CmbJunXu" and M.JX_KINDS[value] then
        self.jx = value;
        self.dirty = true;
        self:ReadOptions();
    elseif name == "CmbMode" and M.MODES[value] then
        self.mode = value;
    elseif name == "CmbMember" and self.names and self.names[value] then
        self.memberName = self.names[value];
    else
        return;
    end
    self:Status();
end

function V:Plan()
    return {mode = self.mode or 1, mask = self.selMask or 0, map = self.selMap or 0};
end

function V:OnButtonClick(name)
    local tab = tonumber(string.sub(name, 4)) ;
    if string.sub(name, 1, 3) ~= "Tab" then tab = nil; end
    local function slot(prefix)
        if string.sub(name, 1, string.len(prefix)) ~= prefix then return nil; end
        return tonumber(string.sub(name, string.len(prefix) + 1));
    end
    local mapRow, towerCheck, go, stopMember = slot("BtnMapRow"), slot("ChkTower"), slot("BtnGo"), slot("BtnStopMember");
    local gatherMember, towerGather = slot("BtnGatherMember"), slot("BtnTowerGather");
    if name == "BtnClose" or name == "BtnCloseX" then
        UiManager:CloseWindow(self.UIGROUP);
        return;
    elseif tab then
        self.tab = tab;
    elseif name == "BtnFind" then
        self.query, self.onlyHere = Edt_GetTxt(self.UIGROUP, "EdtSearch") or "", nil;
        self:Filter();
    elseif name == "BtnClear" then
        self.query, self.onlyHere, self.region = "", nil, 0;
        Edt_SetTxt(self.UIGROUP, "EdtSearch", "");
        self.updating = true;
        ComboBoxSelectItem(self.UIGROUP, "CmbRegion", 0);
        self.updating = nil;
        self:Filter();
    elseif name == "BtnHere" then
        local here = self:CurrentMap();
        if not here then M:Message("Bạn không đứng ở bản đồ tranh đoạt lãnh thổ."); end
        if here and self.selMap ~= here then self.selMask = 0; end
        self.onlyHere = true;
        if here then self.selMap = here; end
        self:Filter();
    elseif towerGather and self.towerSlots[towerGather] and self.selMap then
        local p = M.MAPS[self.selMap].towers[towerGather];
        M:SendGatherPoint(self.selMap, p[1], p[2]);
    elseif mapRow and self.mapSlots[mapRow] then
        if self.selMap ~= self.mapSlots[mapRow] then self.selMask = 0; end
        self.selMap = self.mapSlots[mapRow];
    elseif towerCheck and self.towerSlots[towerCheck] then
        local mask = self.selMask or 0;
        local on = M:HasBit(mask, towerCheck);
        if Btn_GetCheck(self.UIGROUP, name) == 1 and not on then mask = mask + M:Bit(towerCheck);
        elseif Btn_GetCheck(self.UIGROUP, name) ~= 1 and on then mask = mask - M:Bit(towerCheck); end
        self.selMask = mask;
    elseif name == "BtnAllTowers" or name == "BtnNoTowers" then
        local info = self.selMap and M.MAPS[self.selMap];
        self.selMask = (name == "BtnAllTowers" and info) and (M:Bit(#info.towers + 1) - 1) or 0;
    elseif name == "BtnMapPrev" or name == "BtnMapNext" then
        self.mapPage = (self.mapPage or 1) + (name == "BtnMapPrev" and -1 or 1);
    elseif go and self.towerSlots[go] then
        M:RunPlan(self:ReadOptions(), 2, M:Bit(go), self.selMap);
        self.dirty = false;
    elseif stopMember and self.names and self.names[stopMember] then
        if stopMember == 1 then M:Stop("Đã dừng Auto TĐLT.");
        else M:SendStop(self.names[stopMember]); end
    elseif gatherMember and self.names and self.names[gatherMember] then
        M:SendGather(self.names[gatherMember]);
    elseif name == "BtnMedOpen" or name == "BtnMedOpenPT" then
        -- Mở rương máu: Quân Nhu TĐLT → Thường Dùng (HP rồi HP+MP), mở tới khi đầy hành trang (module máu chung của Tổ Đội).
        local ok, why = pcall(function()
            if not Ui.WJXParty then Require("\\interface\\tool\\party.lua"); end
            local X = assert(Ui.WJXParty and Ui.WJXParty.actions, "Chưa nạp Tổ Đội.");
            if name == "BtnMedOpenPT" then X:CommandSource(4); else X:OpenSelf(4); end
        end);
        if not ok then M:Message("Không mở được máu: " .. tostring(why)); end
        return;
    elseif name == "BtnSupplySelf" or name == "BtnSupplyTeam" or name == "BtnSupplyGather" then
        local o = M:SaveOptions(self:ReadOptions());
        if o then
            self.dirty = false;
            if name == "BtnSupplyTeam" then M:SendSupply(o);
            elseif name == "BtnSupplyGather" then
                local x, y = M:CityPoint(o.city);
                M:SendGatherPoint(o.city, x, y);
            else M:StartSupply(o.city, o.jx, o.helpful, o.sret); end
        end
    elseif name == "BtnAssign" then
        local p = self:Plan();
        if not self.memberName or self.memberName == me.szName then
            M:RunPlan(self:ReadOptions(), p.mode, p.mask, p.map);
            self.dirty = false;
        else
            M:SendPlan({[self.memberName] = p});
        end
    elseif name == "BtnAssignAll" then
        local plan = {};
        for i, n in ipairs(self.names or {}) do if i > 1 then plan[n] = self:Plan(); end end
        M:SendPlan(plan);
    elseif name == "BtnStart" then
        local p = self:Plan();
        M:RunPlan(self:ReadOptions(), p.mode, p.mask, p.map);
        self.dirty = false;
    elseif name == "BtnStop" then
        if M.job then M:Stop("Đã dừng Auto TĐLT."); end
    elseif name == "BtnStopPT" then
        M:SendStop();
    elseif name == "BtnSave" then
        local o = self:ReadOptions();
        if M:SaveOptions(o) then
            self.dirty = false;
            if M.job then
                local j = M.job;
                o.mode, o.mask, o.map = j.options.mode, j.options.mask, j.options.map;
                j.options = M:Options(o);
            end
            M:Message("Đã lưu cài đặt." .. (M.job and " Áp dụng ngay cho phiên đang chạy." or ""));
        end
    elseif CHECKS[name] then
        self.dirty = true;
        self:ReadOptions();
    else
        return;           -- nút con của combo: vẽ lại sẽ đóng danh sách đang mở
    end
    self:Render();
end
