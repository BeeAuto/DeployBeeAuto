-- Auto TĐLT — MODEL: cài đặt, dữ liệu trận (bản đồ / trụ / bảng điểm), trạng thái trụ, mã hoá lệnh đội.
-- Chỉ đọc dữ liệu client; toạ độ trụ sinh sẵn từ máy chủ trong wjxtdlt_data.lua.
if not Ui.WJXTDLT or not Ui.WJXTDLT.loading then return; end
local M = Ui.WJXTDLT;

M.CONFIG_KEY = "TranhDoatLanhTho";
M.RANGES = {300, 400, 500, 600, 700, 800, 900, 1000, 1100, 1200};   -- MPS, như Bách Man Sơn
M.RANGE_DEFAULT = 600;
M.MODES = {"Đánh chiếm trụ", "Giữ trụ", "Tuần tra các trụ"};
M.MODE_SHORT = {"Đánh chiếm", "Giữ trụ", "Tuần tra"};
M.MAX_TOWERS = 6;
M.TASK_GROUP, M.TASK_SCORE, M.TASK_TOWER, M.TASK_KILL = 2059, 1, 2, 3;   -- domainbattle_def.lua

-- ---------------------------------------------------------------- cài đặt (lưu theo nhân vật, kho btssl_autofight như Auto6)
function M:Options(raw)
    raw = type(raw) == "table" and raw or {};
    local function flag(v, default) if v == nil then return default; end return v == 0 and 0 or 1; end
    local range = tonumber(raw.range) or self.RANGE_DEFAULT;
    if range ~= range then range = self.RANGE_DEFAULT; end
    range = math.max(300, math.min(1200, math.floor(range / 100) * 100));
    local mode = math.floor(tonumber(raw.mode) or 1);
    if mode < 1 or mode > 3 then mode = 1; end
    local mask = math.floor(tonumber(raw.mask) or 0);
    if mask < 0 or mask > self.ALL_MASK then mask = 0; end
    if raw.mask == nil and tonumber(raw.tower) and raw.tower >= 1 and raw.tower <= self.MAX_TOWERS then
        mask = self:Bit(raw.tower);                -- cài đặt bản 0.1 (1 trụ)
    end
    local map = math.floor(tonumber(raw.map) or 0);
    if not (self.MAPS and self.MAPS[map]) then map = 0; end
    return {mode = mode, mask = mask, map = map, auto6 = flag(raw.auto6, 1), dismount = flag(raw.dismount, 1),
        pvp = flag(raw.pvp, 1), revive = flag(raw.revive, 1), accept = flag(raw.accept, 1), scroll = flag(raw.scroll, 1),
        range = range, city = M:City(raw.city) and math.floor(raw.city) or 23,
        jx = (tonumber(raw.jx) == 2 or tonumber(raw.jx) == 3) and math.floor(raw.jx) or 1,
        helpful = flag(raw.helpful, 1), sret = flag(raw.sret, 1)};
end

function M:ConfigStore()
    local ok, ui = pcall(Ui, Ui.UI_AUTOFIGHT);
    if ok and type(ui) == "table" and ui.Load and ui.Save then return ui; end
end

function M:LoadOptions()
    local ui = self:ConfigStore();
    if not ui then return self:Options(self.memoryOptions); end
    local ok, raw = pcall(ui.Load, ui, self.CONFIG_KEY);
    return self:Options(ok and raw or nil);
end

function M:SaveOptions(raw)
    local options = self:Options(raw);
    local ui = self:ConfigStore();
    if not ui then
        self.memoryOptions = options;
        self:Message("Không có nơi lưu cấu hình (btssl_autofight); cài đặt chỉ giữ đến khi thoát game.");
        return options;
    end
    pcall(ui.Load, ui, self.CONFIG_KEY);      -- đọc lại ngay trước khi ghi để giữ cài đặt của auto khác
    local ok, saved = pcall(ui.Save, ui, self.CONFIG_KEY, options);
    if not ok or saved == false then self:Message("Không ghi được cài đặt."); return nil; end
    return options;
end

-- ---------------------------------------------------------------- Hậu Cần: Quan Lãnh Thổ (NPC 3406, lớp "xuanzhan")
-- Phát quân nhu Lãnh Thổ Chiến (domainbattle_npc.lua: Domain:DlgJunXu / FatchJunXu): mỗi trận mỗi người 1 rương thuốc miễn phí,
-- thêm rương / Hành Quân Đan nếu bang chủ đã đặt; chỉ trong giờ tuyên chiến + tranh đoạt (T7, CN 20:00–21:30), cần là bang
-- chúng chính thức và còn ô trống. Toạ độ = setting\map\map_info\<thành>\info.txt (MPS / 32).
M.JX_NPC = 3406;
M.CITIES = {{23, "Biện Kinh Phủ", 1539, 3234}, {24, "Phượng Tường Phủ", 1830, 3656}, {25, "Tương Dương Phủ", 1744, 3148},
    {26, "Dương Châu Phủ", 1509, 3266}, {27, "Thành Đô Phủ", 1543, 3255}, {28, "Đại Lý Phủ", 1406, 3350}, {29, "Lâm An Phủ", 1606, 4020}};
M.JX_KINDS = {"Hồi Huyết Đan (máu)", "Hồi Nội Đan (nội lực)", "Càn Khôn Tạo Hoá Hoàn (cả hai)"};
function M:City(map)
    map = tonumber(map);
    for i, c in ipairs(self.CITIES) do if c[1] == map then return c, i; end end
end

-- Lựa chọn hội thoại quân nhu: so khớp cả bản Việt hoá (bỏ dấu) lẫn bản gốc tiếng Trung của máy chủ.
M.JX_WORDS = {
    claim = {"领取军需", "nhan quan nhu", "linh quan nhu", "lanh quan nhu"},
    menu = {"军需", "quan nhu"},
    setup = {"设置", "thiet lap", "cai dat", "dat them", "dat quan nhu"},
    free = {"免费", "mien phi"},
    med = {"领取药", "nhan thuoc", "linh thuoc", "lanh thuoc"},
    helpful = {"行军丹", "hanh quan"},
    kind = {{"回血丹", "hoi huyet", "huyet dan"}, {"回内丹", "hoi noi", "noi dan"}, {"乾坤造化丸", "can khon", "tao hoa"}},
    confirm = {"确认领取", "xac nhan", "dong y", "chac chan"},
    full = {"已经领取过", "da nhan het", "da nhan toan bo", "da linh", "da lanh"},
};
function M:Plain(text)
    local t = string.gsub(tostring(text or ""), "<[^>]*>", " ");
    t = string.gsub(t, "[ \t\r\n]+", " ");
    return (string.gsub(t, "^ *(.-) *$", "%1"));
end

function M:Has(text, words)
    local t = self:Fold(text);
    for _, w in ipairs(words) do if string.find(t, self:Fold(w), 1, true) then return true; end end
    return false;
end

-- Chọn dòng hội thoại cho bước nhận quân nhu. Trả (chỉ số, nhãn) hoặc (nil, "done"/"unknown").
function M:PickJunXu(text, options, s)
    local W = self.JX_WORDS;
    local function find(test) for i, o in ipairs(options) do if test(o) then return i; end end end
    local i = find(function(o) return self:Has(o, W.confirm); end);
    if i then return i, "confirm"; end
    i = find(function(o) return self:Has(o, W.kind[s.kind] or W.kind[1]); end);
    if i then return i, "kind"; end
    i = find(function(o) return self:Has(o, W.free); end);
    if i then return i, "free"; end
    i = find(function(o) return self:Has(o, W.med) and not self:Has(o, W.helpful); end);
    if i then return i, "med"; end
    if s.helpful == 1 and not s.gotHelpful then
        i = find(function(o) return self:Has(o, W.helpful) and not self:Has(o, W.setup); end);
        if i then return i, "helpful"; end
    end
    i = find(function(o) return self:Has(o, W.claim) and not self:Has(o, W.setup); end);
    if i then return i, "claim"; end
    i = find(function(o) return self:Has(o, W.menu) and not self:Has(o, W.setup); end);
    if i then return i, "menu"; end
    if self:Has(text, W.full) then return nil, "done"; end
    return nil, "unknown";
end

-- Mặt nạ trụ: bit (i-1) = trụ i; 0 = tất cả trụ của bản đồ.
M.ALL_MASK = 63;
function M:Bit(i) return math.pow(2, i - 1); end
function M:HasBit(mask, i) return math.floor(mask / self:Bit(i)) - math.floor(mask / self:Bit(i + 1)) * 2 == 1; end
function M:Towers(mask, count)
    local list = {};
    for i = 1, count or self.MAX_TOWERS do
        if mask == 0 or self:HasBit(mask, i) then list[#list + 1] = i; end
    end
    if #list == 0 then for i = 1, count or self.MAX_TOWERS do list[i] = i; end end
    return list;
end

function M:TowerLabel(mask)
    mask = tonumber(mask) or 0;
    if mask == 0 or mask == self.ALL_MASK then return "mọi trụ"; end
    return "trụ " .. table.concat(self:Towers(mask), ",");
end

function M:MapName(map)
    local info = self.MAPS and self.MAPS[map or 0];
    return info and info.name or "bản đồ đang đứng";
end

function M:PlanLabel(mode, mask, map)
    local where = map and map ~= 0 and (" · " .. self:MapName(map)) or "";
    if mode == 4 then return "PT Tập Trung" .. where; end
    if mode == 5 then return "Nhận quân nhu" .. where; end
    if mode == 3 then return "Tuần tra " .. self:TowerLabel(mask) .. where; end
    return (mode == 2 and "Giữ " or "Đánh chiếm ") .. self:TowerLabel(mask) .. where;
end

-- Toạ độ hiển thị như bản đồ nhỏ trong game (X/8, Y/16), giống CheckBOSS.
function M:ShowPos(x, y) return math.floor(x / 8) .. "," .. math.floor(y / 16); end

-- Chuỗi để tìm kiếm: chữ thường, bỏ dấu tiếng Việt, gộp khoảng trắng ("Đại Tán Quan" ~ "dai tan quan").
local FOLD;
function M:Fold(text)
    if not FOLD then
        FOLD = {};
        local groups = {a = "àáạảãâầấậẩẫăằắặẳẵÀÁẠẢÃÂẦẤẬẨẪĂẰẮẶẲẴ", e = "èéẹẻẽêềếệểễÈÉẸẺẼÊỀẾỆỂỄ", i = "ìíịỉĩÌÍỊỈĨ",
            o = "òóọỏõôồốộổỗơờớợởỡÒÓỌỎÕÔỒỐỘỔỖƠỜỚỢỞỠ", u = "ùúụủũưừứựửữÙÚỤỦŨƯỪỨỰỬỮ", y = "ỳýỵỷỹỲÝỴỶỸ", d = "đĐ"};
        for base, chars in pairs(groups) do
            for c in (string.gmatch or string.gfind)(chars, "[\192-\244][\128-\191]*") do FOLD[c] = base; end
        end
    end
    local s = string.gsub(tostring(text or ""), "[\192-\244][\128-\191]*", function(c) return FOLD[c]; end);
    s = string.lower(s);
    s = string.gsub(s, "\226\128\147", " ");          -- gạch "–"
    s = string.gsub(s, "[%s%-]+", " ");
    return (string.gsub(s, "^ *(.-) *$", "%1"));
end

-- Danh sách lãnh thổ theo nước (tab lọc), thôn trấn trước rồi dã ngoại, theo tên.
function M:CountryMaps(country)
    self.countryMaps = self.countryMaps or {};
    if self.countryMaps[country] then return self.countryMaps[country]; end
    local list = {};
    for map, info in pairs(self.MAPS) do if info.country == country then list[#list + 1] = map; end end
    local maps = self.MAPS;
    table.sort(list, function(a, b)
        local x, y = maps[a], maps[b];
        if x.kind ~= y.kind then return x.kind == "village"; end
        if x.name ~= y.name then return x.name < y.name; end
        return a < b;
    end);
    self.countryMaps[country] = list;
    return list;
end

-- ---------------------------------------------------------------- NPC (pNpc trên Game.exe là userdata → đọc qua pcall)
local function field(o, k)
    local ok, v = pcall(function() return o[k]; end);
    if ok then return v; end
end
M.Field = field;

function M:IsPlayer(npc)
    return (tonumber(field(npc, "nKind")) or 0) == 1;
end

function M:Alive(npc)
    local life = tonumber(field(npc, "nCurLife"));
    if life and life <= 0 then return false; end
    return (tonumber(field(npc, "nDoing")) or 0) ~= 10;
end

function M:CanAttack(npc)
    if not npc or not self:Alive(npc) then return false; end
    if AutoAi.AiTargetCanAttack then
        local ok, v = pcall(AutoAi.AiTargetCanAttack, npc.nIndex);
        if ok and v ~= nil then return v == 1; end
    end
    return not self:IsPlayer(npc) and (tonumber(field(npc, "nKind")) or 0) == 0;
end

function M:Around()
    local list = {};
    local mine = me.GetNpc and me.GetNpc();
    local myId = mine and field(mine, "dwId");
    for _, npc in pairs(KNpc.GetAroundNpcList(me, 600) or {}) do
        if npc and (not myId or field(npc, "dwId") ~= myId) then list[#list + 1] = npc; end
    end
    return list;
end

function M:Pos(npc)
    local x, y = npc.GetMpsPos();
    return x / 32, y / 32;
end

function M:MyPos()
    local map, x, y = me.GetWorldPos();
    return map, x, y;
end

function M:DistTo(x, y)
    local _, mx, my = me.GetWorldPos();
    return math.sqrt((x - mx) ^ 2 + (y - my) ^ 2);
end

-- ---------------------------------------------------------------- trận / bản đồ / trụ
function M:MapInfo(map)
    return self.MAPS[map or (me.GetWorldPos())];
end

-- Dữ liệu máy chủ đồng bộ cho người đang tham chiến (domainbattle_c.lua): bảng điểm bản đồ hiện tại.
function M:Campaign()
    if type(me.GetCampaignDate) ~= "function" then return nil; end
    local ok, kind, data = pcall(me.GetCampaignDate);
    if ok and kind == "DomainBattle" and type(data) == "table" then return data; end
end

function M:Scoreboard(limit)
    local data = self:Campaign();
    local rows = {};
    for i, row in ipairs(data and data.tbSortInfo or {}) do
        if i > (limit or 3) then break; end
        if type(row) == "table" then rows[#rows + 1] = {name = tostring(row.szName or "?"), score = tonumber(row.nScore) or 0}; end
    end
    return rows;
end

function M:MyScore()
    local function task(id)
        local ok, v = pcall(me.GetTask, self.TASK_GROUP, id);
        return ok and tonumber(v) or 0;
    end
    return task(self.TASK_SCORE), task(self.TASK_TOWER), task(self.TASK_KILL);
end

-- Trụ đang đứng ở toạ độ i (máy chủ dựng lại trụ đúng toạ độ cũ 5 giây sau khi bị hạ).
function M:TowerNpc(npcs, tx, ty)
    local best, bd;
    for _, npc in ipairs(npcs) do
        local tid = tonumber(field(npc, "nTemplateId")) or 0;
        if self.TOWER_TPL[tid] and self:Alive(npc) then
            local x, y = self:Pos(npc);
            local d = math.sqrt((x - tx) ^ 2 + (y - ty) ^ 2);
            if d <= 6 and (not bd or d < bd) then best, bd = npc, d; end
        end
    end
    return best;
end

-- Quét các trụ trong tầm nhìn, ghi nhớ phe: đánh được = trụ địch, không đánh được = trụ ta / đồng minh.
function M:ScanTowers(info, npcs, memory)
    local t = GetTime();
    for i, p in ipairs(info.towers) do
        if self:DistTo(p[1], p[2]) <= 40 then
            local npc = self:TowerNpc(npcs, p[1], p[2]);
            if npc then
                memory[i] = {enemy = self:CanAttack(npc), owner = tostring(field(npc, "szName") or ""), at = t};
            else
                memory[i] = {down = true, at = t};      -- vừa bị hạ, đang chờ dựng lại
            end
        end
    end
end

-- Trạng thái trụ (đã quan sát trong 90 giây gần nhất), nil = chưa biết.
function M:TowerState(memory, i)
    local s = memory and memory[i];
    if s and GetTime() - s.at <= 90 then return s; end
end

function M:TowerText(info, memory)
    local parts = {};
    for i = 1, #info.towers do
        local s = self:TowerState(memory, i);
        local mark = "?";
        if s then mark = s.down and "đổ" or (s.enemy and "địch" or "ta"); end
        parts[#parts + 1] = i .. ":" .. mark;
    end
    return table.concat(parts, "  ");
end

-- ---------------------------------------------------------------- đội
function M:Team()
    local ok, list = pcall(me.GetTeamMemberInfo);
    local members, leader = {}, nil;
    if ok and type(list) == "table" then
        for _, m in ipairs(list) do
            if type(m) == "table" and m.szName and m.szName ~= "" then
                members[#members + 1] = m;
                if m.nLeader == 1 then leader = m.szName; end
            end
        end
    end
    -- GetTeamMemberInfo không có bản thân; không ai mang cờ đội trưởng nghĩa là mình là đội trưởng.
    if #members > 0 and not leader then leader = me.szName; end
    return members, leader;
end

function M:IsLeader()
    local members, leader = self:Team();
    return #members > 0 and leader == me.szName;
end

-- ---------------------------------------------------------------- mã hoá lệnh (chữ số → a..j như [WJXPT:])
local A = string.byte("a");
local gmatch = string.gmatch or string.gfind;
local function mod(a, b) return a - math.floor(a / b) * b; end
function M:EncNum(n)
    n = math.max(0, math.floor(tonumber(n) or 0));
    return (string.gsub(tostring(n), "%d", function(d) return string.char(A + tonumber(d)); end));
end

function M:DecNum(s)
    if type(s) ~= "string" or s == "" or string.find(s, "[^a-j]") then return nil; end
    return tonumber((string.gsub(s, ".", function(c) return tostring(string.byte(c) - A); end)));
end

-- Mã 4 chữ cái từ tên nhân vật (để lệnh không chứa tên thật).
function M:NameKey(name)
    local h = 5381;
    name = tostring(name or "");
    for i = 1, string.len(name) do h = mod(h * 33 + string.byte(name, i), 456976); end
    local s = "";
    for _ = 1, 4 do s = s .. string.char(A + mod(h, 26)); h = math.floor(h / 26); end
    return s;
end

-- Mỗi thành viên 1 mục: <khoá 4 chữ><chế độ a-c><mặt nạ trụ 2 chữ a-h><bản đồ a-j…>, các mục cách nhau bằng ".".
-- plan = {[tên] = {mode, mask, map}} → "[WJXTD:AS:<seq>:<mục>.<mục>]"
function M:EncodeAssign(seq, plan)
    local parts = {};
    for name, p in pairs(plan) do
        local mask = math.floor(p.mask or 0);
        parts[#parts + 1] = self:NameKey(name) .. string.char(A + p.mode) .. string.char(A + math.floor(mask / 8)) ..
            string.char(A + mask - math.floor(mask / 8) * 8) .. self:EncNum(p.map or 0);
    end
    table.sort(parts);
    return self.PREFIX .. "AS:" .. self:EncNum(seq) .. ":" .. table.concat(parts, ".") .. "]";
end

-- Dừng: cả đội (không khoá) hoặc 1 thành viên (khoá tên).
function M:EncodeStop(seq, name)
    return self.PREFIX .. "ST:" .. self:EncNum(seq) .. (name and (":" .. self:NameKey(name)) or "") .. "]";
end

-- Báo trạng thái (thành viên → đội trưởng): trạng thái, bản đồ, toạ độ, trụ đang nhắm, chế độ, mặt nạ, bản đồ được giao.
M.STATES = {[0] = "Đã dừng", [1] = "Đang di chuyển", [2] = "Đang đánh trụ", [3] = "Đang giữ trụ",
    [4] = "Bị hạ gục / về thành", [5] = "Quan sát (auto khác)", [6] = "Chờ vào bản đồ", [7] = "Đã nhận lệnh", [8] = "Đang nhận quân nhu"};
function M:EncodeReport(seq, r)
    local v = {seq, r.state, r.map, r.x, r.y, r.tower or 0, r.mode or 0, r.mask or 0, r.goal or 0};
    for i = 1, #v do v[i] = self:EncNum(v[i]); end
    return self.PREFIX .. "RP:" .. self:NameKey(r.name) .. ":" .. table.concat(v, ":") .. "]";
end

-- Gọi tập trung (GA, đội trưởng → đội) / trả toạ độ (PO, người làm đích → đội): "[WJXTD:GA:<seq>:<khoá>:<map>:<x>:<y>]".
function M:EncodePos(kind, seq, name, map, x, y)
    return self.PREFIX .. kind .. ":" .. self:EncNum(seq) .. ":" .. self:NameKey(name) .. ":" .. self:EncNum(map) .. ":" ..
        self:EncNum(math.max(0, x)) .. ":" .. self:EncNum(math.max(0, y)) .. "]";
end

-- PT Nhận Máu: "[WJXTD:SU:<seq>:<thành>:<loại 1-3>:<hành quân đan 0/1>]".
function M:EncodeSupply(seq, city, kind, helpful)
    return self.PREFIX .. "SU:" .. self:EncNum(seq) .. ":" .. self:EncNum(city) .. ":" .. self:EncNum(kind) .. ":" .. self:EncNum(helpful) .. "]";
end

-- Càn Khôn Phù (18,1,85: 10 lần / 18,1,91: 100 lần) — bay tới 1 đồng đội đang online (như CheckBOSS:ScrollItem).
function M:KinScrollItem()
    if type(me.FindItemInBags) ~= "function" then return nil; end
    for _, id in ipairs({85, 91}) do
        for _, entry in ipairs(me.FindItemInBags(18, 1, id, 1) or {}) do
            local item = entry.pItem;
            if item and item.nGenre == 18 and item.nDetail == 1 and item.nParticular == id and
                item.nLevel == 1 and type(item.GetGenInfo) == "function" then
                local used = item.GetGenInfo(1, 0);
                if type(used) == "number" and used >= 0 and used < (id == 85 and 10 or 100) then return item; end
            end
        end
    end
end

-- Tên đồng đội theo khoá 4 chữ (lệnh đội không mang tên thật).
function M:TeamName(key)
    for _, m in ipairs((self:Team())) do if self:NameKey(m.szName) == key then return m.szName; end end
end

-- Trả {kind = "AS"/"ST"/"RP"/"GA"/"PO"/"GP"/"SU", seq, ...} hoặc nil.
function M:Decode(msg)
    if type(msg) ~= "string" then return nil; end
    local _, _, kind, rest = string.find(msg, "^%[WJXTD:(%u%u):(.-)%]$");
    if kind == "ST" then
        local _, _, s, key = string.find(rest, "^([a-j]+):?(%l*)$");
        local seq = self:DecNum(s);
        if seq and (key == "" or string.len(key) == 4) then return {kind = "ST", seq = seq, key = key ~= "" and key or nil}; end
    elseif kind == "AS" then
        local _, _, s, body = string.find(rest, "^([a-j]+):([a-z%.]*)$");
        local seq = self:DecNum(s);
        if not seq then return nil; end
        local plan = {};
        for key, mode, m1, m2, map in gmatch(body, "(%l%l%l%l)(%l)(%l)(%l)([a-j]+)") do
            mode = string.byte(mode) - A;
            local mask = (string.byte(m1) - A) * 8 + string.byte(m2) - A;
            map = self:DecNum(map);
            if mode >= 1 and mode <= 3 and mask >= 0 and mask <= self.ALL_MASK and map then
                plan[key] = {mode = mode, mask = mask, map = map};
            end
        end
        return {kind = "AS", seq = seq, plan = plan};
    elseif kind == "SU" then
        local _, _, s, c, k, h = string.find(rest, "^([a-j]+):([a-j]+):([a-j]+):([a-j]+)$");
        if not s then return nil; end
        local cmd = {kind = "SU", seq = self:DecNum(s), city = self:DecNum(c), jx = self:DecNum(k), helpful = self:DecNum(h)};
        if not self:City(cmd.city) or cmd.jx < 1 or cmd.jx > 3 or cmd.helpful > 1 then return nil; end
        return cmd;
    elseif kind == "GA" or kind == "PO" or kind == "GP" then
        local _, _, s, key, m, x, y = string.find(rest, "^([a-j]+):(%l%l%l%l):([a-j]+):([a-j]+):([a-j]+)$");
        if not s then return nil; end
        return {kind = kind, seq = self:DecNum(s), key = key, map = self:DecNum(m), x = self:DecNum(x), y = self:DecNum(y)};
    elseif kind == "RP" then
        local _, _, key, body = string.find(rest, "^(%l%l%l%l):([a-j:]+)$");
        if not key then return nil; end
        local v = {};
        for piece in gmatch(body, "([a-j]+)") do v[#v + 1] = self:DecNum(piece); end
        if #v ~= 9 then return nil; end
        return {kind = "RP", key = key, seq = v[1], state = v[2], map = v[3], x = v[4], y = v[5], tower = v[6],
            mode = v[7], mask = v[8], goal = v[9]};
    end
end

-- ---------------------------------------------------------------- ai đang điều khiển nhân vật?
function M:OtherOwner()
    local a = Ui.WJXAuto6;
    local own = self:OwnsAuto6();
    local party = Ui.WJXParty;
    local dispatch = party and party.dispatch;
    if dispatch and dispatch.job then return "Điều Phối Tổ Đội"; end
    if dispatch and type(dispatch.Owns) == "function" and a and a.session and not own then
        local ok, owns = pcall(dispatch.Owns, dispatch, a);
        if ok and owns then return "Điều Phối Tổ Đội"; end
    end
    if Ui.WJXXoyo and Ui.WJXXoyo.job then return "TDC (lệnh đội trưởng)"; end
    local b = Ui.WJXCheckBoss;
    if b and (b.job or b.patrol or b.gather) then return "CheckBOSS"; end
    if Ui.WJXMainQuest and Ui.WJXMainQuest.job then return "Auto Chính Tuyến"; end
    if Ui.WJXTieuDao and Ui.WJXTieuDao.job then return "Tiêu Dao v2"; end
    local t = Ui.WJXTongKim;
    if t and (t.job or t.patrol) then return "Tống Kim"; end
    if a and a.session and not own then return "Auto6 / Theo Sau"; end
    if me.nAutoFightState == 1 and not own then return "Tự Đánh"; end
    if Map and Map.tbAutoAim and Map.tbAutoAim.nFollowState == 1 then return "Hộ Tống / Theo Sau cũ"; end
end
