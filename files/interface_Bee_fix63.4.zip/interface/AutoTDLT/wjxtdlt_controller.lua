-- Auto TĐLT — CONTROLLER. Mỗi nhịp (~0,5 giây):
--   chết → (tuỳ chọn) về điểm hồi sinh 1 lần → sống lại thì tự quay về bản đồ tranh đoạt và trụ được giao;
--   được giao bản đồ khác → dùng Vô Hạn Phù (như CheckBOSS / Chính Tuyến; lỗi thì chạy bộ) rồi tự tìm đường tới trụ;
--   PT Tập Trung → cả đội tới toạ độ mới nhất của 1 thành viên rồi giữ điểm đó;
--   ở bản đồ được giao → quét trụ (ta / địch / đổ) → chọn trụ trong nhóm được giao → đi tới → đánh trụ địch / giữ trụ ta.
-- Chế độ: 1 Đánh chiếm (lần lượt các trụ được giao chưa phải của ta), 2 Giữ trụ, 3 Tuần tra vòng qua các trụ được giao.
-- Thành viên báo trạng thái về đội trưởng (kênh Đội, [WJXTD:RP:]) khi đổi trạng thái và mỗi 45 giây.
-- Nguyên tắc: auto khác đang điều khiển (Điều Phối, TDC, CheckBOSS, Auto6 của người khác...) thì CHỈ QUAN SÁT.
if not Ui.WJXTDLT or not Ui.WJXTDLT.loading then return; end
local M = Ui.WJXTDLT;

M.TICK = 9;             -- ~0,5 giây
M.NEAR = 10;            -- toạ độ thế giới: coi là đã tới trụ
M.GUARD = 16;           -- bán kính giữ trụ: kẻ địch trong vòng này quanh trụ thì đánh
M.SELF_DEFEND = 5;      -- đang đi đường mà người chơi địch áp sát trong vòng này thì đánh trả
M.PATROL_DWELL = 6;     -- tuần tra: đứng giữ trụ của ta bao nhiêu giây rồi sang trụ kế
M.REVIVE_DELAY = 3;     -- chết bao nhiêu giây thì bấm về điểm hồi sinh
M.RETURN_WINDOW = 900;  -- sau khi chết, còn tự quay lại bản đồ tranh đoạt trong bao lâu (giây)

local function now() return GetTime(); end

-- ---------------------------------------------------------------- mượn Auto6 (đúng cách CheckBOSS:StartCombat)
function M:OwnsAuto6(job)
    local j, a = job or self.job, Ui.WJXAuto6;
    return j and j.auto6 and a and a.session and a.active == j.auto6 and true or false;
end

function M:Auto6Config(options)
    local a = Ui.WJXAuto6;
    if not a or type(a.Normalize) ~= "function" or type(a.Copy) ~= "function" or not AutoAi.UpdateCfg then return nil, "chưa nạp Auto6"; end
    local ok, c = pcall(function()
        local c = a:Normalize(a:Copy(Ui(Ui.UI_AUTOFIGHT):Load("AutoFight") or {}));
        c.nAutoFight, c.nCombatEnabled = 1, 1;
        c.nPvpMode = options.pvp == 1 and 1 or 0;
        c.nFollow, c.nFollowLeader, c.nTrain, c.nAssistLeader = 0, 0, 0, 0;
        c.nSupply, c.nRevive, c.nDead, c.nCreateTeam, c.nJoin = 0, 0, 0, 0, 0;
        c.nLockTarget, c.nSkipNormal = 0, 0;
        c.nScanRange = options.range or M.RANGE_DEFAULT;
        c.nDismount = options.dismount == 0 and 0 or 1;
        return c;
    end);
    if not ok or type(c) ~= "table" then return nil, "không đọc được cài đặt Auto6"; end
    if type(a.SkillPreflight) == "function" then
        local okPre, valid, why = pcall(a.SkillPreflight, a, c, true);
        if not okPre or not valid then return nil, tostring(why or "Auto6 báo chưa có kỹ năng hợp lệ"); end
    end
    return c;
end

-- Bật Auto6 neo tại chỗ đứng hiện tại (gọi khi đã ở trụ). foe có thể nil (giữ trụ, để Auto6 tự tìm địch).
function M:UseAuto6(j, foe)
    if j.options.auto6 ~= 1 then return false; end
    local a = Ui.WJXAuto6;
    if j.auto6 and not self:OwnsAuto6(j) then
        j.auto6, j.auto6Off = nil, now();          -- bị tắt giữa chừng (F / đổi bản đồ / vùng an toàn): tự đánh 60 giây
    end
    if not j.auto6 then
        if j.auto6Off and now() - j.auto6Off < 60 then return false; end
        if me.nFightState ~= 1 or (a and a.session) or me.nAutoFightState == 1 then return false; end
        local config, why = self:Auto6Config(j.options);
        if not config then
            if not j.auto6Said then j.auto6Said = true; self:Message("Không bật được Auto6 (" .. tostring(why) .. "); tự đánh bằng kỹ năng tay trái."); end
            j.auto6Off = now();
            return false;
        end
        self:StopAttack(j);
        self:StopPath(j);
        local ok = pcall(AutoAi.UpdateCfg, AutoAi, config);
        if not ok or not a.session then j.auto6Off = now(); return false; end
        j.auto6 = a.active;
    end
    local id = foe and self.Field(foe, "dwId");
    if id and a.targetId ~= id then a.targetId = id; end
    return true;
end

function M:ReleaseAuto6(j)
    local a = Ui.WJXAuto6;
    local mine = self:OwnsAuto6(j);
    j.auto6 = nil;
    if mine then pcall(a.Stop, a, "WJXTDLT_RELEASE"); end
end

-- ---------------------------------------------------------------- di chuyển / đánh tay
local function riding()
    local ok, v = pcall(function() return me.GetNpc().nIsRideHorse; end);
    return ok and tonumber(v) == 1;
end

function M:StopPath(j)
    local path = Ui.tbLogic and Ui.tbLogic.tbAutoPath;
    if j.path and path and path.tbGotoPos == j.path then pcall(path.StopGoto, path, "WJXTDLTStop"); end
    j.path = nil;
end

-- Đi tới (map, x, y). Cùng bản đồ & gần: bước ngắn; xa hoặc khác bản đồ: tbAutoPath:GotoPos (tự tìm đường liên bản đồ).
function M:MoveTo(j, map, x, y)
    local here = me.GetWorldPos();
    if map == here and self:DistTo(x, y) <= 30 then
        self:StopPath(j);
        if j.stepAt and now() - j.stepAt < 1 and j.stepX == x and j.stepY == y then return; end
        j.stepAt, j.stepX, j.stepY = now(), x, y;
        pcall(me.StartAutoPath, math.floor(x), math.floor(y));
        return;
    end
    if map ~= here then
        if j.transfer or j.settleAt then return; end           -- TravelTick đang lo
        if self:TryScroll(j, map) then return; end
    end
    local path = Ui.tbLogic and Ui.tbLogic.tbAutoPath;
    if not path then pcall(me.StartAutoPath, math.floor(x), math.floor(y)); return; end
    local busy = j.path and path.tbGotoPos == j.path and j.pathX == x and j.pathY == y and j.pathMap == map;
    if busy and j.pathAt and now() - j.pathAt < 15 then return; end
    if j.pathAt and now() - j.pathAt < 3 then return; end
    j.pathAt, j.pathX, j.pathY, j.pathMap = now(), x, y, map;
    pcall(path.GotoPos, path, {nMapId = map, nX = math.floor(x), nY = math.floor(y)});
    j.path = path.tbGotoPos;
end

-- ---------------------------------------------------------------- Vô Hạn Phù (dịch vụ chung Ui.WJXTransfer của Auto6)
-- Chỉ dùng khi khác bản đồ. Menu phù do Game.exe mở được bắt qua hook UI_SAYPANEL (M:Install) và chọn từng bước theo
-- tuyến trong setting\map\chuansongmapinfo.txt — cả 49 bản đồ tranh đoạt đều có trong đó.
function M:Install()
    if self.installed then return; end
    local okSay, say = pcall(Ui, Ui.UI_SAYPANEL);
    if not okSay or type(say) ~= "table" or type(say.OnOpen) ~= "function" then return; end
    self.installed = true;
    local onSay = say.OnOpen;
    say.OnOpen = function(window, param, a, b)
        local result = onSay(window, param, a, b);       -- luôn để chuỗi hook cũ chạy trước
        local j = M.job;
        if j and j.transfer and Ui.WJXTransfer then pcall(Ui.WJXTransfer.Capture, Ui.WJXTransfer, j.transfer, param);
        elseif j and j.kin and j.kin.stage == "menu" then j.kin.say = param;
        elseif j and j.supply and j.supply.sayUntil and now() <= j.supply.sayUntil then j.supply.say = param; end
        return result;
    end;
end

function M:TryScroll(j, map)
    local T = Ui.WJXTransfer;
    if j.options.scroll ~= 1 or not T or type(T.Plan) ~= "function" then return false; end
    if j.scrollBlock and now() < j.scrollBlock then return false; end
    if UiManager:WindowVisible(Ui.UI_SKILLPROGRESS) == 1 then return true; end
    if j.scrollAt and now() - j.scrollAt < 3 then return true; end
    local ok, dest, item = pcall(T.Plan, T, map);
    if not ok or not dest or not item then
        j.scrollBlock = now() + 60;
        if not j.scrollSaid then j.scrollSaid = true; self:Message("Không dùng được Vô Hạn Phù tới " .. self:MapName(map) .. " (không có phù / nơi này cấm); chạy bộ."); end
        return false;
    end
    self:StopPath(j);
    self:StopAttack(j);
    j.scrollAt = now();
    j.transfer = T:Begin(dest, item);
    local okUse, used = pcall(me.UseItem, item);
    if not okUse or used == 0 then
        T:Cancel(j.transfer); j.transfer = nil;
        j.scrollBlock = now() + 60;
        return false;
    end
    self.work = "Dùng Vô Hạn Phù tới " .. self:MapName(map) .. ".";
    return true;
end

-- Trả mã trạng thái nếu đang truyền tống / chờ tải cảnh (nhịp này chỉ lo việc đó), nil nếu rảnh.
function M:TravelTick(j)
    if j.kin then
        local state = self:KinTick(j);
        if state then return state; end
    end
    local T = Ui.WJXTransfer;
    if j.transfer then
        local ok, state, why = pcall(T.Tick, T, j.transfer);
        if not ok then state, why = "fatal", state; end
        if state == "wait" then self.work = "Đang dùng Vô Hạn Phù…"; return 1; end
        pcall(T.Cancel, T, j.transfer);
        j.transfer = nil;
        if state == "done" then
            j.settleAt, j.scrollFails = now(), 0;
        else
            j.scrollFails = (j.scrollFails or 0) + 1;
            if state == "fatal" or j.scrollFails >= 3 then
                j.scrollBlock, j.scrollFails = now() + 120, 0;
                self:Message("Vô Hạn Phù lỗi (" .. tostring(why) .. "); chạy bộ.");
            end
        end
    end
    if j.settleAt then
        local map, x, y = me.GetWorldPos();
        if not map or map <= 0 or (x or 0) <= 0 or UiManager:WindowVisible(Ui.UI_SKILLPROGRESS) == 1 then j.settleAt = now(); end
        if now() - j.settleAt < 2 then self.work = "Đã truyền tống; chờ tải cảnh."; return 1; end
        j.settleAt = nil;
    end
end

-- ---------------------------------------------------------------- Càn Khôn Phù (bay tới đồng đội; như CheckBOSS PT Tập Trung)
local function clean(text)
    if Ui.WJXTransfer and type(Ui.WJXTransfer.Clean) == "function" then return Ui.WJXTransfer:Clean(text); end
    return M:Fold(M:Plain(text));
end

function M:TryKinScroll(j, person)
    if j.options.scroll ~= 1 or (j.kinBlock and now() < j.kinBlock) then return false; end
    if UiManager:WindowVisible(Ui.UI_SKILLPROGRESS) == 1 then return true; end
    local item = self:KinScrollItem();
    if not item then j.kinBlock = now() + 300; return false; end
    if UiManager:WindowVisible(Ui.UI_SAYPANEL) == 1 then j.kinBlock = now() + 30; return false; end   -- không chen hội thoại khác
    self:StopPath(j);
    self:StopAttack(j);
    j.kin = {target = person, stage = "menu", at = now(), from = me.GetWorldPos()};
    local ok, used = pcall(me.UseItem, item);
    if not ok or used == 0 then j.kin, j.kinBlock = nil, now() + 120; return false; end
    self.work = "Dùng Càn Khôn Phù bay tới đồng đội.";
    return true;
end

function M:KinFail(j, why)
    local k = j.kin;
    j.kin, j.kinBlock = nil, now() + 120;
    if k and k.owned and UiManager:WindowVisible(Ui.UI_SAYPANEL) == 1 then UiManager:CloseWindow(Ui.UI_SAYPANEL); end
    self:Message("Càn Khôn Phù: " .. why .. "; dùng Vô Hạn Phù / chạy bộ.");
end

-- Trả mã trạng thái khi đang dùng Càn Khôn Phù, nil khi xong / lỗi (để đi cách khác).
function M:KinTick(j)
    local k = j.kin;
    local map = me.GetWorldPos();
    if k.stage == "menu" then
        if k.say then
            local param = k.say;
            k.say = nil;
            if type(param) ~= "table" or type(param[2]) ~= "table" then self:KinFail(j, "hội thoại không đúng"); return nil; end
            k.owned = true;
            local want = clean(k.target .. "[Online]");
            for i, o in ipairs(param[2]) do
                if clean(o) == want then
                    k.stage, k.teleAt = "tele", now();
                    Ui(Ui.UI_SAYPANEL):OnListSel("LstSelectArray", i);
                    self.work = "Càn Khôn Phù: đang bay tới đồng đội.";
                    return 1;
                end
            end
            self:KinFail(j, "đồng đội không online / không có trong danh sách");
            return nil;
        end
        if now() - k.at > 6 then self:KinFail(j, "không thấy bảng chọn đồng đội"); return nil; end
        return 1;
    end
    if map and map > 0 and map ~= k.from then j.kin, j.settleAt = nil, now(); return 1; end
    if UiManager:WindowVisible(Ui.UI_SKILLPROGRESS) == 1 then k.teleAt = now(); return 1; end
    if now() - k.teleAt > 12 then self:KinFail(j, "bị ngắt / không bay được"); return nil; end
    return 1;
end

function M:CancelTravel(j)
    if j.transfer and Ui.WJXTransfer then pcall(Ui.WJXTransfer.Cancel, Ui.WJXTransfer, j.transfer); end
    if j.kin and j.kin.owned and UiManager:WindowVisible(Ui.UI_SAYPANEL) == 1 then UiManager:CloseWindow(Ui.UI_SAYPANEL); end
    j.transfer, j.settleAt, j.kin = nil, nil, nil;
end

function M:Attack(j, npc)
    local idx = npc.nIndex;
    if j.attackIdx ~= idx or not j.attackAt or now() - j.attackAt >= 2 then
        j.attackIdx, j.attackAt, j.attacking = idx, now(), true;
        if j.options.dismount == 1 and riding() and type(Switch) == "function" and
            (not j.dismountAt or now() - j.dismountAt >= 2) then
            j.dismountAt = now(); pcall(Switch, "horse");
        end
        local skill = tonumber(me.nLeftSkill) or 0;
        if skill > 0 and AutoAi.SetActiveSkill and me.CanCastSkill and me.CanCastSkill(skill) == 1 then
            pcall(AutoAi.SetActiveSkill, skill, 600);
        end
        AutoAi.SetTargetIndex(idx);
    end
end

function M:StopAttack(j)
    if j.attacking then j.attacking, j.attackIdx = nil, nil; pcall(AutoAi.SetTargetIndex, 0); end
end

function M:Idle(j)
    self:StopAttack(j);
    if j.auto6 then self:ReleaseAuto6(j); end
end

-- Kẻ địch gần (x, y) nhất trong bán kính r: NPC đánh được (lính, tướng) và — nếu bật — người chơi đánh được.
function M:Hostile(j, npcs, x, y, r)
    local best, bd;
    for _, npc in ipairs(npcs) do
        local tid = tonumber(self.Field(npc, "nTemplateId")) or 0;
        local player = self:IsPlayer(npc);
        if not self.TOWER_TPL[tid] and (not player or j.options.pvp == 1) and self:CanAttack(npc) then
            local nx, ny = self:Pos(npc);
            local d = math.sqrt((nx - x) ^ 2 + (ny - y) ^ 2);
            if d <= r and (not bd or d < bd) then best, bd = npc, d; end
        end
    end
    return best;
end

M.REPORT_BEAT = 45;     -- giây: nhịp báo trạng thái khi không đổi gì
M.REPORT_MIN = 10;      -- giây: báo dồn tối thiểu (tránh spam kênh Đội)

-- ---------------------------------------------------------------- bắt đầu / dừng / đổi phân công
function M:Start(raw)
    local options = self:Options(raw);
    local owner = self:OtherOwner();
    self:Stop();
    self:Install();
    local here = me.GetWorldPos();
    local fixed = options.map ~= 0;
    self.job = {options = options, owner = me.szName, started = now(), memory = {}, fixed = fixed,
        map = fixed and options.map or (self.MAPS[here] and here) or nil};
    self.status, self.work = "Đang chạy.", "—";
    self.timer = Ui.tbLogic.tbTimer:Register(self.TICK, function()
        local ok, result = pcall(M.Tick, M);
        if not ok then M:Stop("Lỗi: " .. tostring(result)); return 0; end
        return result;
    end);
    self:Message((owner and ("Đã bật; " .. owner .. " đang điều khiển nên tạm chỉ quan sát. ") or "Đã bật. ") ..
        self:PlanLabel(options.mode, options.mask, options.map) .. ".");
    self:Report(7, true);
    return true;
end

function M:Stop(reason)
    local j = self.job;
    self.job = nil;
    if self.timer then Ui.tbLogic.tbTimer:Close(self.timer); self.timer = nil; end
    if j then
        self:StopAttack(j);
        if j.auto6 then pcall(M.ReleaseAuto6, M, j); end
        self:StopPath(j);
        self:CancelTravel(j);
        pcall(M.Report, M, 0, true);
    end
    self.work = "—";
    if reason then self:Message(reason); end
end

-- Đổi phân công khi đang chạy (không dừng phiên).
function M:Assign(mode, mask, map)
    local j = self.job;
    if not j then return; end
    j.options.mode, j.options.mask, j.options.map = mode, mask or 0, map or 0;
    j.fixed = (map or 0) ~= 0;
    if j.fixed then j.map = map; end
    j.target, j.dwellUntil, j.patrolNext, j.pIdx, j.gather = nil, nil, nil, nil, nil;
    self:Idle(j);
    self:StopPath(j);
    self:Report(7, true);
end

-- Áp dụng 1 kế hoạch cho bản thân: lưu vào cài đặt rồi chạy (đang chạy thì đổi luôn).
function M:RunPlan(raw, mode, mask, map)
    raw = self:Options(raw);
    raw.mode, raw.mask, raw.map = mode, mask or 0, map or 0;
    local options = self:SaveOptions(raw);
    if not options then return false; end
    if self.job then
        self.job.options = options;
        self:Assign(options.mode, options.mask, options.map);
        self:Message("Bản thân: " .. self:PlanLabel(options.mode, options.mask, options.map) .. ".");
    else
        self:Start(options);
    end
    return true;
end

-- ---------------------------------------------------------------- lệnh đội
function M:NextSeq()
    self.seq = math.max((self.seq or 0) + 1, math.floor(now()));
    return self.seq;
end

function M:SendTeam(text, quiet)
    if type(SendChannelMsg) ~= "function" then if not quiet then self:Message("Client không có SendChannelMsg."); end return false; end
    SendChannelMsg("Team", text);
    return true;
end

function M:SendCommand(text)
    if self.sentAt and now() - self.sentAt < 2 then self:Message("Gửi chậm lại một chút (2 giây/lệnh)."); return false; end
    self.sentAt = now();
    return self:SendTeam(text);
end

-- Đội trưởng gửi phân công: plan = {[tên] = {mode, mask, map}} (map 0 = bản đồ thành viên đang đứng).
function M:SendPlan(plan)
    if not self:IsLeader() then self:Message("Chỉ đội trưởng mới gửi phân công được."); return false; end
    local count = 0;
    for name, p in pairs(plan) do
        count = count + 1;
        self.assignments = self.assignments or {};
        self.assignments[name] = {mode = p.mode, mask = p.mask or 0, map = p.map or 0, at = now()};
    end
    if count == 0 then self:Message("Chưa chọn thành viên nào."); return false; end
    if not self:SendCommand(self:EncodeAssign(self:NextSeq(), plan)) then return false; end
    self:Message("Đã gửi phân công cho " .. count .. " thành viên.");
    return true;
end

function M:SendStop(name)
    if not self:IsLeader() then self:Message("Chỉ đội trưởng mới gọi dừng được."); return false; end
    if not self:SendCommand(self:EncodeStop(self:NextSeq(), name)) then return false; end
    if name then
        if self.assignments then self.assignments[name] = nil; end
        self:Message("Đã gọi 1 thành viên dừng.");
    else
        self.assignments = {};
        self:Message("Đã gọi cả đội dừng Auto TĐLT.");
    end
    return true;
end

-- Trạng thái của bản thân (để hiện ở hàng "Bản thân" và báo cho đội trưởng).
function M:Report(state, force)
    local j = self.job;
    local map, x, y = me.GetWorldPos();
    local o = j and j.options or {};
    local r = {name = me.szName, state = state, map = map or 0, x = math.max(0, x or 0), y = math.max(0, y or 0),
        tower = j and j.target or 0, mode = o.mode or 0, mask = o.mask or 0, goal = j and j.map or 0, at = now()};
    if j and j.gather then r.mode, r.mask, r.tower, r.goal = 4, 0, 0, j.gather.map; end
    if j and j.supply then r.mode, r.mask, r.tower, r.goal = 5, 0, 0, j.supply.map; if state ~= 0 and state ~= 4 then r.state = 8; end end
    self.reports = self.reports or {};
    self.reports[me.szName] = r;
    local members, leader = self:Team();
    if #members == 0 or leader == me.szName then return; end      -- chỉ thành viên mới báo về đội trưởng
    local key = state .. ":" .. r.goal .. ":" .. r.tower .. ":" .. r.mode .. ":" .. r.mask;
    local last = self.reportAt or -1000;
    if not force then
        if key == self.reportKey and now() - last < self.REPORT_BEAT then return; end
        if now() - last < self.REPORT_MIN then return; end
    end
    self.reportAt, self.reportKey = now(), key;
    self:SendTeam(self:EncodeReport(self:NextSeq(), r), true);
end

-- Lệnh / báo cáo từ kênh Đội (hook ở wjxtdlt.lua). Lệnh: chỉ tin đội trưởng hiện tại. Báo cáo: chỉ đội trưởng nhận.
function M:Receive(sender, msg)
    if not sender or sender == me.szName then return; end
    local cmd = self:Decode(msg);
    if not cmd then return; end
    local members, leader = self:Team();
    if cmd.kind == "RP" then
        if leader ~= me.szName then return; end
        for _, m in ipairs(members) do
            if m.szName == sender and self:NameKey(sender) == cmd.key then
                cmd.name, cmd.at = sender, now();
                self.reports = self.reports or {};
                self.reports[sender] = cmd;
            end
        end
        return;
    end
    if cmd.kind == "PO" then
        local g = self.pendingGather;
        if g and g.seq == cmd.seq and g.key == cmd.key and self:NameKey(sender) == cmd.key then
            self.pendingGather = nil;
            self:StartGather(cmd.map, cmd.x, cmd.y, g.person or sender);
        end
        return;
    end
    if sender ~= leader then return; end
    if self.lastSeq == cmd.seq then return; end
    self.lastSeq = cmd.seq;
    local mine = self:NameKey(me.szName);
    if cmd.kind == "ST" then
        if (not cmd.key or cmd.key == mine) and self.job then self:Stop("Đội trưởng gọi dừng Auto TĐLT."); end
        return;
    end
    if cmd.kind == "SU" then
        if self:LoadOptions().accept ~= 1 then self:Message("Đội trưởng gọi PT Nhận Máu nhưng bạn đang tắt \"Nhận phân công\"."); return; end
        local o = self:LoadOptions();
        self:StartSupply(cmd.city, cmd.jx, cmd.helpful, o.sret);
        return;
    end
    if cmd.kind == "GA" then
        if cmd.key == mine then
            -- Mình là người làm đích: gửi toạ độ mới nhất cho cả đội, giữ nguyên việc đang làm.
            local map, x, y = me.GetWorldPos();
            self:SendTeam(self:EncodePos("PO", cmd.seq, me.szName, map or 0, x or 0, y or 0), true);
            return;
        end
        if self:LoadOptions().accept ~= 1 then self:Message("Đội trưởng gọi PT Tập Trung nhưng bạn đang tắt \"Nhận phân công\"."); return; end
        local exact = cmd.key == self:NameKey(sender);
        self:BeginGather(cmd.seq, cmd.key, cmd.map, cmd.x, cmd.y, exact, exact and sender or self:TeamName(cmd.key));
        return;
    end
    if cmd.kind == "GP" then
        if self:LoadOptions().accept ~= 1 then self:Message("Đội trưởng gọi PT Tập Trung nhưng bạn đang tắt \"Nhận phân công\"."); return; end
        self.pendingGather = nil;
        self:StartGather(cmd.map, cmd.x, cmd.y);
        return;
    end
    local p = cmd.plan[mine];
    if not p then return; end
    local options = self:LoadOptions();
    if options.accept ~= 1 then
        self:Message("Đội trưởng giao " .. self:PlanLabel(p.mode, p.mask, p.map) .. " nhưng bạn đang tắt \"Nhận phân công\".");
        return;
    end
    if p.map ~= 0 and not self.MAPS[p.map] then p.map = 0; end
    if self.job then
        self.job.options = options;
        self:Assign(p.mode, p.mask, p.map);
        self:Message("Đội trưởng giao: " .. self:PlanLabel(p.mode, p.mask, p.map) .. ".");
    else
        options.mode, options.mask, options.map = p.mode, p.mask, p.map;
        self:Start(options);
        self.status = "Đội trưởng giao: " .. self:PlanLabel(p.mode, p.mask, p.map) .. ".";
    end
end

-- ---------------------------------------------------------------- PT Tập Trung
-- Đội trưởng bấm PT Tập Trung ở hàng 1 thành viên: gửi [GA] kèm toạ độ đã biết; người làm đích trả lời [PO] toạ độ mới
-- nhất, cả đội (kể cả đội trưởng) đi tới đó và giữ điểm. Không có [PO] sau 10 giây thì dùng toạ độ trong [GA].
M.GATHER_WAIT = 10;

function M:SendGather(name)
    if not self:IsLeader() then self:Message("Chỉ đội trưởng mới gọi PT Tập Trung được."); return false; end
    local map, x, y;
    if name == me.szName then map, x, y = me.GetWorldPos();
    else
        local r = self.reports and self.reports[name];
        if r then map, x, y = r.map, r.x, r.y; end
    end
    local seq = self:NextSeq();
    if not self:SendCommand(self:EncodePos("GA", seq, name, map or 0, x or 0, y or 0)) then return false; end
    if name == me.szName then
        self:Message("Đã gọi cả đội tập trung tới chỗ bạn.");
    else
        self:BeginGather(seq, self:NameKey(name), map or 0, x or 0, y or 0, false, name);
        self:Message("Đang gọi cả đội tập trung tới 1 thành viên; chờ toạ độ mới nhất.");
    end
    return true;
end

-- PT Tập Trung tới 1 toạ độ cố định (trụ trong tab Tọa Độ): đội trưởng là "đích" nên thành viên đi ngay, đội trưởng cũng đi.
function M:SendGatherPoint(map, x, y)
    if not self:IsLeader() then self:Message("Chỉ đội trưởng mới gọi PT Tập Trung được."); return false; end
    if not self:SendCommand(self:EncodePos("GP", self:NextSeq(), me.szName, map, x, y)) then return false; end
    self:StartGather(map, x, y);
    return true;
end

function M:BeginGather(seq, key, map, x, y, exact, person)
    if exact then self.pendingGather = nil; self:StartGather(map, x, y, person); return; end
    local g = {seq = seq, key = key, map = map, x = x, y = y, at = now(), person = person};
    self.pendingGather = g;
    Ui.tbLogic.tbTimer:Register(Env.GAME_FPS, function()
        if M.pendingGather == g and now() - g.at < M.GATHER_WAIT then return Env.GAME_FPS; end
        if M.pendingGather == g then
            M.pendingGather = nil;
            if g.map > 0 and g.x > 0 then M:StartGather(g.map, g.x, g.y, g.person);
            else M:Message("Không nhận được toạ độ của thành viên làm đích (máy đó chưa chạy Auto TĐLT?)."); end
        end
        return 0;
    end);
end

-- person = tên đồng đội ở điểm tập trung (nếu có): khác bản đồ thì ưu tiên Càn Khôn Phù bay thẳng tới người đó.
function M:StartGather(map, x, y, person)
    if not map or map <= 0 or not x or x <= 0 then return false; end
    if not self.job then self:Start(self:LoadOptions()); end
    local j = self.job;
    if not j then return false; end
    j.gather = {map = map, x = x, y = y, person = person ~= me.szName and person or nil};
    j.kinBlock = nil;
    j.target = nil;
    self:Idle(j);
    self:StopPath(j);
    self:Message("PT Tập Trung: " .. self:MapName(map) .. " (" .. self:ShowPos(x, y) .. ").");
    self:Report(7, true);
    return true;
end

-- ---------------------------------------------------------------- Hậu Cần: nhận quân nhu ở Quan Lãnh Thổ
-- Chạy như 1 lớp phủ lên phiên: xong thì (tuỳ chọn) quay lại việc đang làm; nếu bật riêng để nhận thì xong là dừng.
M.SUPPLY_TALKS = 12;       -- số lần mở hội thoại tối đa mỗi chuyến
M.SUPPLY_TIMEOUT = 300;    -- giây

function M:CityPoint(city)
    local c = self:City(city);
    if not c then return nil; end
    local x, y = c[3], c[4];
    if KNpc and type(KNpc.ClientGetNpcPos) == "function" then
        local ok, nx, ny = pcall(KNpc.ClientGetNpcPos, city, self.JX_NPC);
        if ok and type(nx) == "number" and type(ny) == "number" and nx > 0 and ny > 0 then x, y = nx, ny; end
    end
    return x, y, c[2];
end

function M:StartSupply(city, kind, helpful, sret)
    local x, y, name = self:CityPoint(city);
    if not x then self:Message("Thành nhận quân nhu không hợp lệ."); return false; end
    local fresh = not self.job;
    if fresh then self:Start(self:LoadOptions()); end
    local j = self.job;
    if not j then return false; end
    j.supply = {map = city, x = x, y = y, name = name, kind = kind or 1, helpful = helpful or 1, claims = 0, talks = 0,
        only = fresh or sret == 0, started = now()};
    self:Idle(j);
    self:StopPath(j);
    self:Message("Đi nhận quân nhu ở Quan Lãnh Thổ — " .. name .. ".");
    self:Report(8, true);
    return true;
end

function M:SendSupply(raw)
    local o = self:Options(raw);
    if not self:IsLeader() then self:Message("Chỉ đội trưởng mới gọi PT Nhận Máu được."); return false; end
    if not self:SendCommand(self:EncodeSupply(self:NextSeq(), o.city, o.jx, o.helpful)) then return false; end
    self:StartSupply(o.city, o.jx, o.helpful, o.sret);
    return true;
end

function M:FinishSupply(j, text)
    local s = j.supply;
    j.supply = nil;
    if UiManager:WindowVisible(Ui.UI_SAYPANEL) == 1 and s and s.owned then UiManager:CloseWindow(Ui.UI_SAYPANEL); end
    pcall(AutoAi.SetTargetIndex, 0);
    self:Message(text);
    if s and s.only then self:Stop(); else self:Report(7, true); end
    return 7;
end

function M:SupplyStep(j)
    local s = j.supply;
    local map = me.GetWorldPos();
    self.status = "Nhận quân nhu — " .. s.name .. (s.claims > 0 and (" (đã nhận " .. s.claims .. ")") or "") .. ".";
    if now() - s.started > self.SUPPLY_TIMEOUT then return self:FinishSupply(j, "Nhận quân nhu quá thời gian; đã bỏ qua."); end
    if map ~= s.map or (not s.near and self:DistTo(s.x, s.y) > 6) then
        self:StopAttack(j);
        if j.auto6 then self:ReleaseAuto6(j); end
        self:MoveTo(j, s.map, s.x, s.y);
        if not j.transfer then self.work = "Đi tới Quan Lãnh Thổ (" .. self:ShowPos(s.x, s.y) .. ")."; end
        return 8;
    end
    self:StopPath(j);
    s.near = true;
    if s.say then
        local param = s.say;
        s.say = nil;
        local text, options = tostring(param[1] or ""), param[2] or {};
        local index, step = self:PickJunXu(text, options, s);
        if not index then
            if step == "done" or s.claims > 0 then
                return self:FinishSupply(j, s.claims > 0 and ("Đã nhận " .. s.claims .. " lần quân nhu.") or "Đã nhận hết quân nhu của trận này.");
            end
            local list = {};
            for i, o in ipairs(options) do list[i] = M:Plain(o); end
            return self:FinishSupply(j, "Không nhận được quân nhu: " .. self:Plain(text) .. " [" .. table.concat(list, " | ") .. "]");
        end
        if step == "confirm" then s.claims = s.claims + 1; end
        if step == "helpful" then s.gotHelpful = true; end
        s.owned, s.sayUntil = true, now() + 6;
        Ui(Ui.UI_SAYPANEL):OnListSel("LstSelectArray", index);
        self.work = "Hội thoại quân nhu: " .. step .. ".";
        return 8;
    end
    if UiManager:WindowVisible(Ui.UI_SAYPANEL) == 1 then
        if s.owned then self.work = "Chờ hội thoại quân nhu."; return 8; end
        self.work = "Có hội thoại khác đang mở; chờ bạn đóng.";
        return 8;
    end
    s.owned = nil;
    if s.talkAt and now() - s.talkAt < 4 then return 8; end
    if s.talks >= self.SUPPLY_TALKS then
        return self:FinishSupply(j, s.claims > 0 and ("Đã nhận " .. s.claims .. " lần quân nhu.") or "Quan Lãnh Thổ không phản hồi; đã bỏ qua.");
    end
    local npc;
    for _, n in ipairs(self:Around()) do
        if tonumber(self.Field(n, "nTemplateId")) == self.JX_NPC then npc = n; break; end
    end
    if not npc then
        s.near = nil;
        if self:DistTo(s.x, s.y) <= 3 then s.talks = s.talks + 1; s.talkAt = now(); self.work = "Không thấy Quan Lãnh Thổ quanh đây."; end
        return 8;
    end
    s.talks, s.talkAt, s.sayUntil = s.talks + 1, now(), now() + 8;
    AutoAi.SetTargetIndex(npc.nIndex);
    self.work = "Nói chuyện với Quan Lãnh Thổ.";
    return 8;
end

-- ---------------------------------------------------------------- chọn trụ (chỉ trong nhóm trụ được giao)
local function ours(M, j, i)
    local s = M:TowerState(j.memory, i);
    return s and not s.down and not s.enemy;
end

local function nearest(M, info, list, ok)
    local best, bd;
    for _, i in ipairs(list) do
        local p = info.towers[i];
        if p and (not ok or ok(i)) then
            local d = M:DistTo(p[1], p[2]);
            if not bd or d < bd then best, bd = i, d; end
        end
    end
    return best;
end

local function contains(list, v) for _, x in ipairs(list) do if x == v then return true; end end return false; end

function M:PickTower(j, info)
    local o = j.options;
    local list = self:Towers(o.mask, #info.towers);
    j.cands = list;
    if o.mode == 2 then
        if not (j.target and contains(list, j.target)) then j.target = nearest(self, info, list); end
        return j.target;
    end
    if o.mode == 3 then
        if not j.pIdx then
            local first = nearest(self, info, list);
            for k, i in ipairs(list) do if i == first then j.pIdx = k; end end
            j.pIdx = j.pIdx or 1;
        end
        if j.patrolNext then
            j.pIdx = j.pIdx >= #list and 1 or j.pIdx + 1;
            j.patrolNext, j.dwellUntil = nil, nil;
        end
        if j.pIdx > #list then j.pIdx = 1; end
        j.target = list[j.pIdx];
        return j.target;
    end
    -- Đánh chiếm: giữ trụ đang nhắm tới khi nó thành của ta, rồi sang trụ gần nhất (trong nhóm) chưa chắc là của ta.
    if j.target and contains(list, j.target) and not ours(self, j, j.target) then return j.target; end
    j.target = nearest(self, info, list, function(i) return not ours(self, j, i); end) or
        (j.target and contains(list, j.target) and j.target) or nearest(self, info, list);
    return j.target;
end

-- ---------------------------------------------------------------- tại trụ
function M:Guard(j, npcs, tx, ty, label)
    local foe = self:Hostile(j, npcs, tx, ty, self.GUARD);
    if foe then
        local name = self:IsPlayer(foe) and "người chơi phe địch" or tostring(self.Field(foe, "szName") or "địch");
        if self:UseAuto6(j, foe) then self.work = label .. ": Auto6 đánh " .. name .. "."; return 3; end
        self:Attack(j, foe);
        self.work = label .. ": đánh " .. name .. ".";
        return 3;
    end
    self:StopAttack(j);
    if j.options.auto6 == 1 and self:UseAuto6(j, nil) then self.work = label .. " (Auto6 canh tại chỗ)."; return 3; end
    if self:DistTo(tx, ty) > 4 then self:MoveTo(j, me.GetWorldPos(), tx, ty); end
    self.work = label .. ": không có địch.";
    return 3;
end

function M:AtTower(j, info, npcs, i)
    local p = info.towers[i];
    local npc = self:TowerNpc(npcs, p[1], p[2]);
    local mode = j.options.mode;
    if npc and self:CanAttack(npc) then
        j.dwellUntil = nil;
        -- Trụ là NPC đặc biệt (Auto6 có thể bỏ qua): luôn đánh tay — chọn mục tiêu + kỹ năng tay trái như người chơi.
        if j.auto6 then self:ReleaseAuto6(j); end
        self:Attack(j, npc);
        self.work = "Đánh trụ " .. i .. " (địch).";
        return 2;
    end
    if not npc then return self:Guard(j, npcs, p[1], p[2], "Trụ " .. i .. " vừa đổ, chờ dựng lại"); end
    -- Trụ của ta.
    if mode == 3 and #j.cands > 1 then
        j.dwellUntil = j.dwellUntil or (now() + self.PATROL_DWELL);
        if now() >= j.dwellUntil and not self:Hostile(j, npcs, p[1], p[2], self.GUARD) then
            j.patrolNext = true;
            self:Idle(j);
            self.work = "Trụ " .. i .. " an toàn, sang trụ kế.";
            return 1;
        end
    elseif mode == 1 then
        local other = nearest(self, info, j.cands, function(k) return k ~= i and not ours(self, j, k); end);
        if other then
            j.target = other;
            self:Idle(j);
            self.work = "Trụ " .. i .. " đã là của ta, sang trụ " .. other .. ".";
            return 1;
        end
    end
    return self:Guard(j, npcs, p[1], p[2], "Giữ trụ " .. i);
end

-- ---------------------------------------------------------------- nhịp chính
function M:Tick()
    local j = self.job;
    if not j then return 0; end
    local name = me.szName;
    if name and name ~= "" and name ~= j.owner then
        j.otherSince = j.otherSince or now();
        if now() - j.otherSince >= 5 then self:Stop("Đã đổi nhân vật."); return 0; end
        return self.TICK;
    end
    j.otherSince = nil;
    local state = self:Step(j);
    self:Report(state);
    return self.TICK;
end

-- Một nhịp; trả mã trạng thái (M.STATES) để báo đội trưởng.
function M:Step(j)
    local map = me.GetWorldPos();
    local info = self.MAPS[map];

    if me.IsDead and me.IsDead() == 1 then
        self:Idle(j);
        self:StopPath(j);
        self:CancelTravel(j);
        if info and not j.fixed then j.map = map; end
        j.diedAt = j.diedAt or now();
        if j.options.revive == 1 and not j.reviveSent and now() - j.diedAt >= self.REVIVE_DELAY and
            type(me.SendClientCmdRevive) == "function" then
            j.reviveSent = true;                  -- 1 lần mỗi lần chết; bản đồ tranh đoạt cấm Cửu Chuyển
            pcall(me.SendClientCmdRevive, 0);
        end
        self.status = "Bị hạ gục" .. (j.options.revive == 1 and "; về điểm hồi sinh rồi quay lại." or "; chờ hồi sinh.");
        self.work = "—";
        return 4;
    end
    j.reviveSent = nil;

    local owner = self:OtherOwner();
    if owner then
        self:Idle(j);
        self.status, self.work = "Quan sát: " .. owner .. " đang điều khiển.", "—";
        return 5;
    end

    local travelling = self:TravelTick(j);
    if travelling then return travelling; end

    if j.supply then return self:SupplyStep(j); end

    if j.gather then
        local g = j.gather;
        self.status = "PT Tập Trung tại " .. self:MapName(g.map) .. " (" .. self:ShowPos(g.x, g.y) .. ").";
        if map ~= g.map or self:DistTo(g.x, g.y) > 4 then
            self:Idle(j);
            if map ~= g.map and g.person and self:TryKinScroll(j, g.person) then return 1; end
            self:MoveTo(j, g.map, g.x, g.y);
            if not j.transfer then self.work = "Đi tới điểm tập trung."; end
            return 1;
        end
        self:StopPath(j);
        local npcs = self:Around();
        if info then self:ScanTowers(info, npcs, j.memory); end
        local tower = self:TowerNpc(npcs, g.x, g.y);
        if tower and self:CanAttack(tower) then
            if j.auto6 then self:ReleaseAuto6(j); end
            self:Attack(j, tower);
            self.work = "Tập trung: đánh trụ địch tại điểm.";
            return 2;
        end
        return self:Guard(j, npcs, g.x, g.y, "Giữ điểm tập trung");
    end

    if info and not j.fixed and j.map ~= map then j.map, j.target, j.pIdx, j.memory = map, nil, nil, {}; end
    if not j.map or map ~= j.map then
        self:Idle(j);
        -- Được giao bản đồ cố định: luôn tự sang. Không cố định: chỉ quay lại sau khi chết (còn trận / trong 15 phút).
        local back = j.map and (j.fixed or self:Campaign() or (j.diedAt and now() - j.diedAt <= self.RETURN_WINDOW));
        if back and (j.fixed or j.options.revive == 1) then
            local target = self.MAPS[j.map];
            local list = self:Towers(j.options.mask, #target.towers);
            local i = j.target and contains(list, j.target) and j.target or list[1];
            local p = target.towers[i] or target.center;
            self:MoveTo(j, j.map, p[1], p[2]);
            self.status = "Đang sang " .. target.name .. ".";
            self.work = "Đi về trụ " .. i .. " (" .. self:ShowPos(p[1], p[2]) .. ").";
            return 1;
        end
        self:StopPath(j);
        self.status, self.work = "Chưa ở bản đồ tranh đoạt lãnh thổ; chờ vào bản đồ.", "—";
        return 6;
    end
    j.diedAt = nil;
    self.status = "Đang chạy · " .. self:PlanLabel(j.options.mode, j.options.mask, j.fixed and j.map or 0) .. ".";

    if UiManager:WindowVisible(Ui.UI_SKILLPROGRESS) == 1 then self.work = "Đang thao tác (thanh tiến trình)."; return 3; end
    local npcs = self:Around();
    self:ScanTowers(info, npcs, j.memory);
    local i = self:PickTower(j, info);
    if not i then self:Idle(j); self.work = "Bản đồ không có trụ."; return 6; end
    local p = info.towers[i];
    local d = self:DistTo(p[1], p[2]);
    -- Auto6 neo ở chỗ bật với bán kính = Phạm vi: lạc quá xa trụ thì trả Auto6, đi về trụ.
    local leash = (j.options.range or self.RANGE_DEFAULT) / 32 + 6;
    if d <= self.NEAR or (j.auto6 and d <= leash) then
        self:StopPath(j);
        return self:AtTower(j, info, npcs, i);
    end
    if j.auto6 then self:ReleaseAuto6(j); end
    local foe;
    local _, mx, my = me.GetWorldPos();
    if j.options.pvp == 1 then
        for _, npc in ipairs(npcs) do
            if self:IsPlayer(npc) and self:CanAttack(npc) then
                local x, y = self:Pos(npc);
                if math.sqrt((x - mx) ^ 2 + (y - my) ^ 2) <= self.SELF_DEFEND then foe = npc; break; end
            end
        end
    end
    if foe then
        self:StopPath(j);
        self:Attack(j, foe);
        self.work = "Đang tới trụ " .. i .. ": đánh trả người chơi áp sát.";
        return 1;
    end
    self:StopAttack(j);
    self:MoveTo(j, map, p[1], p[2]);
    self.work = "Đi tới trụ " .. i .. " (" .. self:ShowPos(p[1], p[2]) .. ", " .. math.floor(d) .. " bước).";
    return 1;
end

-- Trạng thái trụ của 1 bản đồ cho cửa sổ (bản đồ đang chạy dùng bộ nhớ của phiên).
function M:MemoryFor(map)
    self.viewMemory = self.viewMemory or {};
    local j = self.job;
    if j and j.map == map then return j.memory; end
    self.viewMemory[map] = self.viewMemory[map] or {};
    local here = me.GetWorldPos();
    if here == map and self.MAPS[map] and not j then pcall(self.ScanTowers, self, self.MAPS[map], self:Around(), self.viewMemory[map]); end
    return self.viewMemory[map];
end
