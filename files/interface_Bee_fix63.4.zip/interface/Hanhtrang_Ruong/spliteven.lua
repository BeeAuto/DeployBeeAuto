-- [WJX] Tách vật phẩm "Dàn đều" (by HUKT)
-- Khi tách (F2 > Tách > chọn món) hiện thêm ô [ ] Dàn đều bên trái nút Đồng ý (cửa sổ riêng của plugin,
-- KHÔNG sửa textinput_banner.ini của game). Tick + nhập n: tách thành các ô mỗi ô n, phần dư nằm lại ô gốc
-- (5 nhập 2 -> 2,2 + gốc 1; 10 nhập 3 -> 3,3,3 + gốc 1; chia hết thì ô gốc giữ n). Kiểm tra đủ ô trống trước, rồi tách lần lượt từng ô chờ server trả kết quả.
local tbItemBox = Ui(Ui.UI_ITEMBOX);
local tbBanner  = Ui(Ui.UI_TEXTINPUT_BANNER);
local SE = Ui.WJXSplitEven or {};
Ui.WJXSplitEven = SE;
local INI = "\\interface\\Hanhtrang_Ruong\\001a\\window\\wjxspliteven.ini";
local OFFSET_X, OFFSET_Y = 8, 85;     -- vị trí trong cửa sổ nhập số: bên trái nút Đồng ý (x=88,y=86)
local WAIT_FRAMES = 2 * Env.GAME_FPS;  -- chờ server tối đa 2 giây cho mỗi lần tách

local function Msg(s) me.Msg("<color=yellow>[Tách]<color> "..s) end
-- Số ô MỚI cần: mỗi ô n, phần dư (T mod n) ở lại ô gốc; chia hết thì ô gốc giữ đúng n.
local function NeedCells(T, n)
	local k = math.floor(T / n);
	if T - k * n > 0 then return k end
	return k - 1;
end

function SE:EnsureWnd()
	if not Ui.UI_WJXSPLITEVEN then
		local cls = Ui:GetClass("wjxspliteven");
		function cls:OnButtonClick(szWnd, nParam)
			if szWnd == "BtnEven" then SE.bEven = (nParam == 1) end
		end
		Ui:RegisterNewUiWindow("UI_WJXSPLITEVEN", "wjxspliteven", {"a",0,0}, {"b",0,0}, {"c",0,0});
		Ui:AddExWndConfig("UI_WJXSPLITEVEN", {"d",0,0});
		Ui:LoadExWndConfig("UI_WJXSPLITEVEN");
	end
	if not self.bLoaded then
		local w, h = Wnd_GetSize(Ui.UI_WJXSPLITEVEN, "Main");
		if not w or w <= 0 or not h or h <= 0 then
			if LoadUiGroup(Ui.UI_WJXSPLITEVEN, INI) == 0 then error("không nạp được wjxspliteven.ini") end
		end
		self.bLoaded = true;
	end
end

function SE:Follow()
	local x, y = Wnd_GetPos(Ui.UI_TEXTINPUT_BANNER, "Main");
	if x and y then Wnd_SetPos(Ui.UI_WJXSPLITEVEN, "Main", x + OFFSET_X, y + OFFSET_Y) end
end

function SE:Hide()
	self.bActive = nil;
	if Ui.UI_WJXSPLITEVEN and UiManager:WindowVisible(Ui.UI_WJXSPLITEVEN) == 1 then
		UiManager:CloseWindow(Ui.UI_WJXSPLITEVEN);
	end
end

function SE:OnFollowTimer()
	if not self.bActive or UiManager:WindowVisible(Ui.UI_TEXTINPUT_BANNER) ~= 1 then
		self.nFollowTimer = nil;
		self:Hide();
		return 0;
	end
	pcall(self.Follow, self);
	return 4;
end

function SE:Show()
	if self.bFail then return end
	local ok, err = pcall(self.EnsureWnd, self);
	if not ok then
		self.bFail = true;
		Msg("Không mở được ô Dàn đều: "..tostring(err));
		return;
	end
	self.bEven = false;                 -- mặc định không tick, không nhớ
	self.bActive = true;
	UiManager:OpenWindow(Ui.UI_WJXSPLITEVEN);
	Btn_Check(Ui.UI_WJXSPLITEVEN, "BtnEven", 0);
	pcall(self.Follow, self);
	if not self.nFollowTimer then
		self.nFollowTimer = Ui.tbLogic.tbTimer:Register(4, self.OnFollowTimer, self);
	end
end

-- ---------- tách lần lượt ----------
function SE:JobFinish(szWhy)
	local j = self.tbJob; self.tbJob = nil;
	if not j then return end
	local nLeft = 0;
	pcall(function() nLeft = j.pItem.nCount end);
	local s = string.format("Đã tách %d ô (mỗi ô %d), ô gốc còn %d.", j.nDone, j.n, nLeft);
	if szWhy then s = s.." Dừng: "..szWhy end
	Msg(s);
end

function SE:OnJobTimer()
	local j = self.tbJob;
	if not j then self.nJobTimer = nil; return 0 end
	local ok, nCount = pcall(function() return j.pItem.nCount end);
	if not ok or type(nCount) ~= "number" then
		self.nJobTimer = nil; self:JobFinish("vật phẩm không còn trong hành trang"); return 0;
	end
	if j.bPending then
		if nCount < j.nLast then
			j.bPending = nil; j.nDone = j.nDone + 1; j.nLast = nCount;
		elseif GetFrame() - j.nSentFrame > WAIT_FRAMES then
			self.nJobTimer = nil; self:JobFinish("server không phản hồi lệnh tách"); return 0;
		else
			return 2;
		end
	end
	if j.nDone >= j.nNeed or nCount <= j.n then
		self.nJobTimer = nil; self:JobFinish(); return 0;
	end
	if me.CountFreeBagCell() < 1 then
		self.nJobTimer = nil; self:JobFinish("hết ô trống"); return 0;
	end
	j.bPending = true; j.nSentFrame = GetFrame();
	me.SplitItem(j.pItem, j.n);
	return 2;
end

function SE:SplitEven(n, pItem)
	if self.tbJob then Msg("Đang tách dở, chờ xong rồi thử lại."); return 1 end
	local T = pItem.nCount;
	local nNeed = NeedCells(T, n);          -- số ô mới; phần dư ở lại ô gốc
	local nFree = me.CountFreeBagCell();
	if nFree < nNeed then
		Msg(string.format("Cần %d ô trống để dàn đều (mỗi ô %d), hành trang chỉ còn %d ô.", nNeed, n, nFree));
		return 1;                            -- giữ cửa sổ nhập để chọn lại
	end
	self.tbJob = {pItem = pItem, n = n, nNeed = nNeed, nDone = 0, nLast = T};
	if not self.nJobTimer then
		self.nJobTimer = Ui.tbLogic.tbTimer:Register(1, self.OnJobTimer, self);
	end
	return 0;
end

-- ---------- móc vào luồng tách gốc ----------
if tbItemBox.SplitItem ~= SE.fnSplit then
	local fnOld = tbItemBox.SplitItem;
	SE.fnSplitOld = fnOld;
	SE.fnSplit = function(self, nSplitCount, pItem)
		local bEven = SE.bActive and SE.bEven;
		if bEven and pItem and type(nSplitCount) == "number" and nSplitCount >= 1 and
		   NeedCells(pItem.nCount, nSplitCount) >= 1 then
			return SE:SplitEven(nSplitCount, pItem);
		end
		return fnOld(self, nSplitCount, pItem);   -- không tick: tách 1 lần như cũ
	end;
	tbItemBox.SplitItem = SE.fnSplit;
end

if tbBanner.OnOpen ~= SE.fnBannerOpen then
	local fnOld = tbBanner.OnOpen;
	SE.fnBannerOpen = function(self, tbParam, ...)
		local r = fnOld(self, tbParam, unpack(arg));
		if tbParam and tbParam.fnAccept == tbItemBox.SplitItem then
			SE:Show();
		else
			SE:Hide();
		end
		return r;
	end;
	tbBanner.OnOpen = SE.fnBannerOpen;
end
