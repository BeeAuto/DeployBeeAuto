-- Auto Đoán Hoa Đăng (by HUKT) — thay cho Ctrl+M của plugin cũ AutoAnswer (giữ nguyên file cũ, chỉ tắt phần tự trả lời).
-- Theo script\KiemThe\Npc\npc_vandap.lua (server, lớp npc_vandap):
--   Lễ Quan (2601, Tân Thủ Thôn 1–8 / Thành Thị 23–29) → "Đoán Hoa Đăng (Thứ 2, 4 và 5)"
--   → "Bắt đầu trả lời (n/30)" → "Câu k: …" 3 lựa chọn (cả 3 đều tính Đúng; đáp án thật tô <color=yellow>)
--   → server tự mở lại bảng Đoán Hoa Đăng → lặp tới 30/30 → "Nhận thưởng Đoán Hoa Đăng" (cần số câu đúng + 1 ô trống).
--   Mở từ 01h00 Thứ 2, 4, 5; mỗi câu cần ≥ 5 ô trống.
-- API: Ui.WJXHoaDang:Start(opt, fnDone) / :Stop(why) / :Toggle() / :Busy()
--   opt = {owner = "Auto6", quiet = false, noReward = false}; fnDone(result) với result = {ok, why, answered, owner}
Ui.WJXHoaDang = Ui.WJXHoaDang or {};
local A = Ui.WJXHoaDang;
A.VERSION = "1.0.1";
A.NPC = 2601;                                   -- Lễ Quan (setting\npc\npc.txt, lớp liguan)
A.TOWNS = {23, 24, 25, 26, 27, 28, 29, 1, 2, 3, 4, 5, 6, 7, 8};
A.TOWN_NAMES = {[23] = "Biện Kinh", [24] = "Phượng Tường", [25] = "Tương Dương", [26] = "Dương Châu", [27] = "Thành Đô", [28] = "Đại Lý", [29] = "Lâm An",
    [1] = "Vân Trung Trấn", [2] = "Long Môn Trấn", [3] = "Vĩnh Lạc Trấn", [4] = "Đạo Hương Thôn", [5] = "Giang Tân Thôn", [6] = "Thạch Cổ Trấn", [7] = "Long Tuyền Thôn", [8] = "Ba Lăng Huyện"};
A.HOME_TOWN = 26;                               -- chưa ghé Thành Thị / Tân Thủ Thôn nào thì về Dương Châu
A.MAX = 30;
A.MIN_FREE = 5;
A.SAY_WAIT = 8;
A.WALK_TIMEOUT = 300;
A.DAYS = {[1] = true, [3] = true, [4] = true};  -- %w: Thứ 2, 4, 5

local function now() return GetTime(); end
local function visible(group) return group and UiManager:WindowVisible(group) == 1; end
local function isTown(map)
    for _, m in ipairs(A.TOWNS) do if m == map then return true; end end
    return false;
end

function A:Message(text, board)
    self.status = tostring(text);
    if self.job and self.job.opt.quiet then return; end
    if me and me.Msg then me.Msg("[Hoa Đăng] " .. self.status); end
    if board then pcall(UiManager.OpenWindow, UiManager, "UI_INFOBOARD", "<bclr=Black><color=yellow>" .. self.status .. "<color>"); end
end

-- Bỏ thẻ màu, gộp khoảng trắng, chữ thường (dùng bảng của Vô Hạn Phù nếu có)
local function fold(s)
    local T = Ui.WJXTransfer;
    if T and T.Clean then local ok, f = pcall(T.Clean, T, s); if ok and f then return f; end end
    s = string.gsub(tostring(s or ""), "<[^>]*>", "");
    s = string.gsub(s, "%s+", " ");
    return string.lower((string.gsub(s, "^ *(.-) *$", "%1")));
end
local function starts(s, w) return string.sub(s, 1, string.len(w)) == w; end

function A:FreeCells()
    local ok, n = pcall(me.CountFreeBagCell);
    return ok and tonumber(n) or 0;
end

-- Đúng ngày / giờ hoạt động? (giờ máy chủ gửi qua GetTime)
function A:Open()
    local ok, w, hm = pcall(function()
        local t = GetTime();
        return tonumber(os.date("%w", t)), tonumber(os.date("%H%M", t));
    end);
    if not ok or not w then return true; end       -- không đọc được giờ: để Lễ Quan tự báo
    if not self.DAYS[w] then return false, "Đoán Hoa Đăng chỉ mở Thứ 2, 4 và 5 hàng tuần."; end
    if hm < 100 then return false, "Đoán Hoa Đăng mở từ 01h00."; end
    return true;
end

function A:Busy() return self.job and (self.job.opt.owner or "Auto Hoa Đăng") or nil; end

-- ---------------------------------------------------------------- bắt đầu / dừng
function A:Start(opt, fnDone)
    if self.job then return false, "Đang chạy Auto Hoa Đăng (" .. tostring(self:Busy()) .. ")."; end
    opt = opt or {};
    if me.IsDead and me.IsDead() == 1 then return false, "Nhân vật đang bị hạ gục."; end
    if not opt.owner and me.nAutoFightState == 1 then return false, "Đang bật Tự Đánh: tắt (F) trước."; end
    local open, why = self:Open();
    if not open then return false, why; end
    if self:FreeCells() < self.MIN_FREE then return false, "Hành trang cần ít nhất " .. self.MIN_FREE .. " ô trống."; end
    local G = Ui.WJXGhepHT;
    if G and G.Busy and G:Busy() then return false, "Auto Ghép HT đang chạy."; end
    local H = Ui.WJXHomeBar;
    if H and H.job then return false, "Thanh Home đang di chuyển tới " .. tostring(H.job.name) .. "."; end
    if visible(Ui.UI_SAYPANEL) or visible(Ui.UI_SHOP) then pcall(UiManager.CloseWindow, UiManager, Ui.UI_SAYPANEL); end
    self:InstallSay();
    self.job = {opt = opt, cb = fnDone, phase = "go", started = now(), answered = 0, others = 0, roots = 0};
    self:Message("Bắt đầu Đoán Hoa Đăng: tìm Lễ Quan ở Tân Thủ Thôn / Thành Thị.", true);
    return true;
end

function A:Finish(ok, why)
    local j = self.job;
    if not j then return; end
    self.job = nil;
    if j.transfer and Ui.WJXTransfer then pcall(Ui.WJXTransfer.Cancel, Ui.WJXTransfer, j.transfer); end
    self:StopWalk(j);
    if j.talked and visible(Ui.UI_SAYPANEL) then pcall(UiManager.CloseWindow, UiManager, Ui.UI_SAYPANEL); end
    local text = (ok and "Xong" or "Dừng") .. (why and why ~= "" and (": " .. why) or "")
        .. (j.answered > 0 and (" · lần này trả lời " .. j.answered .. " câu") or "") .. ".";
    self.lastJob = j;
    j.result = {ok = ok and true or false, why = why, answered = j.answered, owner = j.opt.owner};
    self.status = text;
    if not j.opt.quiet then
        if me and me.Msg then me.Msg("[Hoa Đăng] " .. text); end
        pcall(UiManager.OpenWindow, UiManager, "UI_INFOBOARD", "<bclr=Black><color=" .. (ok and "yellow" or "white") .. ">Hoa Đăng — " .. text .. "<color>");
    end
    if j.cb then pcall(j.cb, j.result); end
end

function A:Stop(why) if self.job then self:Finish(false, why or "người chơi dừng"); end end

function A:Toggle()
    if self.job then self:Stop("đã tắt (Ctrl+M)"); return; end
    local ok, why = self:Start();
    if not ok then self:Message(why, true); end
end

-- ---------------------------------------------------------------- đi tới Lễ Quan
function A:NpcPoint(map)
    if not KNpc or not KNpc.ClientGetNpcPos then return nil; end
    local ok, x, y = pcall(KNpc.ClientGetNpcPos, map, self.NPC);
    if ok and type(x) == "number" and type(y) == "number" and x > 0 and y > 0 then return {map = map, x = x, y = y}; end
end

function A:FindNpc()
    if not KNpc or not KNpc.GetAroundNpcList then return nil; end
    local okPos, x, y = pcall(function() return me.GetNpc().GetMpsPos(); end);
    if not okPos then return nil; end
    local best, bestD;
    for _, npc in pairs(KNpc.GetAroundNpcList(me, 1000) or {}) do
        local ok, tid = pcall(function() return npc.nTemplateId; end);
        if ok and tonumber(tid) == self.NPC then
            local nx, ny = npc.GetMpsPos();
            local d = (nx - x) ^ 2 + (ny - y) ^ 2;
            if not bestD or d < bestD then best, bestD = npc, d; end
        end
    end
    if best then return best, math.sqrt(bestD); end
end

function A:StopWalk(j)
    local path = Ui.tbLogic and Ui.tbLogic.tbAutoPath;
    if j and j.path and path and path.tbGotoPos == j.path then pcall(path.StopGoto, path, "WJXHOADANG"); end
    if j then j.path = nil; end
end

-- Đang ở Thành Thị / Tân Thủ Thôn → đi bộ; ngoài ra dùng Vô Hạn Phù về thành gần nhất đã ghé (không có phù → tự tìm đường)
function A:Route(j)
    local here = me.GetMapTemplateId and me.GetMapTemplateId() or me.GetWorldPos();
    if isTown(here) then
        j.point = self:NpcPoint(here);
        if j.point then return true; end
    end
    local town = isTown(self.lastTown or 0) and self.lastTown or self.HOME_TOWN;
    local T = Ui.WJXTransfer;
    if T and T.Begin and T.Destinations then
        local dest = T:Destinations()[town];
        local item = dest and T:Item();
        if dest and item and T:Check(dest) == true then
            local route = {};
            for i, r in ipairs(dest.route) do route[i] = r; end
            j.transfer, j.phase = T:Begin({map = dest.map, x = dest.x, y = dest.y, route = route}, item), "transfer";
            if me.UseItem(item) ~= 0 then
                self:Message("Dùng Vô Hạn Phù về " .. (self.TOWN_NAMES[town] or tostring(route[#route])) .. ".");
                return true;
            end
            j.transfer, j.phase = nil, "go";
        end
    end
    j.point = self:NpcPoint(town);
    for _, m in ipairs(self.TOWNS) do
        if j.point then break; end
        j.point = self:NpcPoint(m);
    end
    if not j.point then return false; end
    self:Message("Không dùng được Vô Hạn Phù: tự tìm đường tới Lễ Quan.");
    return true;
end

-- ---------------------------------------------------------------- hội thoại
function A:InstallSay()
    local ok, say = pcall(Ui, Ui.UI_SAYPANEL);
    if not ok or type(say) ~= "table" or type(say.OnOpen) ~= "function" then return; end
    if say.OnOpen == self.sayHook then return; end
    local onSay = say.OnOpen;
    self.sayHook = function(window, param, a, b)
        local result = onSay(window, param, a, b);      -- luôn để chuỗi hook cũ chạy trước
        local j = A.job;
        if j then
            if j.phase == "transfer" and j.transfer then pcall(Ui.WJXTransfer.Capture, Ui.WJXTransfer, j.transfer, param);
            elseif j.sayUntil and now() <= j.sayUntil then
                A.saySeq = (A.saySeq or 0) + 1;
                j.say, j.saySeq = param, A.saySeq;
            end
        end
        return result;
    end;
    say.OnOpen = self.sayHook;
end

function A:Pick(j, index)
    j.say, j.sayUntil, j.pickAt = nil, now() + self.SAY_WAIT, now();
    Ui(Ui.UI_SAYPANEL):OnListSel("LstSelectArray", index);
end

local function option(opts, wanted, prefix)
    local w = fold(wanted);
    for i, o in ipairs(opts) do
        local f = fold(o);
        if (prefix and starts(f, w)) or (not prefix and f == w) then return i; end
    end
end

function A:OnSay(j, param)
    local opts = type(param and param[2]) == "table" and param[2] or {};
    local text = fold(param and param[1]);
    -- 1. câu hỏi: chọn dòng tô vàng (đáp án thật), không có thì dòng 1
    if string.find(text, "^câu %d+:") then
        if self:FreeCells() < self.MIN_FREE then return self:Finish(false, "hành trang còn dưới " .. self.MIN_FREE .. " ô trống"); end
        if #opts == 0 then return self:Finish(false, "câu hỏi không có lựa chọn"); end
        local pick = 1;
        for i, o in ipairs(opts) do
            if string.find(string.lower(tostring(o)), "<color=yellow>", 1, true) then pick = i; break; end
        end
        j.answered = j.answered + 1;
        local _, _, k = string.find(text, "^câu (%d+):");
        self.status = "Trả lời câu " .. tostring(k) .. "/" .. self.MAX;
        return self:Pick(j, pick);
    end
    -- 2. bảng Đoán Hoa Đăng (OnDialog)
    if string.find(text, "hoàn thành 30 câu", 1, true) or option(opts, "Bắt đầu trả lời", true) or option(opts, "Nhận thưởng Đoán Hoa Đăng", true) then
        local _, _, n = string.find(text, "(%d+)/30");
        local _, _, d = string.find(text, "trả lời đúng (%d+) câu");
        n, d = tonumber(n) or 0, tonumber(d) or self.MAX;
        local i = option(opts, "Bắt đầu trả lời", true);
        if i then
            if self:FreeCells() < self.MIN_FREE then return self:Finish(false, "hành trang cần ít nhất " .. self.MIN_FREE .. " ô trống (đang " .. n .. "/30)"); end
            self.status = "Đã trả lời " .. n .. "/30";
            return self:Pick(j, i);
        end
        i = option(opts, "Nhận thưởng Đoán Hoa Đăng", true);
        if i then
            if j.opt.noReward then return self:Finish(true, "đủ 30/30 (chưa nhận thưởng)"); end
            if j.rewardTried then return self:Finish(false, "đã bấm Nhận thưởng nhưng chưa nhận được"); end
            local need = d + 1;
            if self:FreeCells() < need then return self:Finish(false, "đủ 30/30 — cần " .. need .. " ô trống để nhận thưởng (đang có " .. self:FreeCells() .. ")"); end
            j.rewardTried = true;
            self:Pick(j, i);
            j.phase, j.afterAt = "after", now();      -- server không mở lại bảng: nói chuyện lại để kiểm tra
            return;
        end
        return self:Finish(true, "hôm nay đã trả lời " .. n .. "/30 và đã nhận thưởng");
    end
    -- 3. menu gốc của Lễ Quan
    local i = option(opts, "Đoán Hoa Đăng", true);
    if i and j.roots < 3 then
        j.roots = j.roots + 1;
        return self:Pick(j, i);
    end
    -- 4. Lễ Quan đang có nhiệm vụ / hoạt động: bấm qua bảng "Đến thật đúng lúc…" (script\npc\npc.lua)
    for _, w in ipairs({"Ta muốn hỏi chuyện khác", "Không muốn tham gia", "Không muốn làm"}) do
        i = option(opts, w);
        if i and j.others < 3 then j.others = j.others + 1; return self:Pick(j, i); end
    end
    -- 5. thông báo của server (sai ngày / chưa tới giờ / thiếu ô / đã nhận thưởng …)
    if string.find(text, "đã nhận phần thưởng", 1, true) then return self:Finish(true, "hôm nay đã nhận thưởng Đoán Hoa Đăng"); end
    return self:Finish(false, "Lễ Quan báo: " .. string.sub(text, 1, 120));
end

-- ---------------------------------------------------------------- nhịp chạy
-- ---------------------------------------------------------------- người chơi giành lại quyền điều khiển
-- Bấm chuột / phím đi khi đang tự tìm đường → engine gọi tbAutoPath:OnStop("User"). Bọc OnStop đúng 1 lớp (dùng chung các
-- plugin: đếm vào tbAutoPath.wjxUserStops). Ngoài ra đứng yên mà vị trí đổi (đang dùng phù / nói chuyện) cũng tính.
local function hookUserStop()
    local path = Ui.tbLogic and Ui.tbLogic.tbAutoPath;
    if type(path) ~= "table" or type(path.OnStop) ~= "function" or path.OnStop == path.wjxStopHook then return; end
    local onStop = path.OnStop;
    local hook = function(self, reason, ...)
        if reason == "User" then self.wjxUserStops = (self.wjxUserStops or 0) + 1; end
        return onStop(self, reason, ...);
    end;
    path.OnStop, path.wjxStopHook = hook, hook;
end
local function userStops()
    hookUserStop();
    local path = Ui.tbLogic and Ui.tbLogic.tbAutoPath;
    return path and path.wjxUserStops or 0;
end
local function myPos()
    local ok, m, x, y = pcall(me.GetWorldPos);
    if ok then return m, x, y; end
end
-- true nếu người chơi đã tự di chuyển kể từ lần đánh dấu gần nhất (j.mark…)
local function userMoved(j, standing)
    if not j.markStops then j.markStops = userStops(); end
    if userStops() > j.markStops then return true; end
    local m, x, y = myPos();
    if not standing or not m then j.markMap = nil; return false; end
    if j.markMap ~= m then j.markMap, j.markX, j.markY = m, x, y; return false; end
    return math.abs(x - j.markX) > 4 or math.abs(y - j.markY) > 4;
end

function A:Tick()
    local j = self.job;
    if not j then return; end
    local t = now();
    if me.IsDead and me.IsDead() == 1 then return self:Finish(false, "nhân vật bị hạ gục"); end
    -- người chơi tự đi (ngắt tìm đường / bước ra khi đang dùng phù) → dừng, không cố làm nốt
    if userMoved(j, j.phase == "transfer") then return self:Finish(false, "bạn đã tự di chuyển — dừng auto"); end
    if j.phase == "transfer" then
        local state, why = Ui.WJXTransfer:Tick(j.transfer);
        if state == "done" then j.transfer, j.phase, j.point = nil, "go", nil;
        elseif state == "fatal" or state == "fail" then return self:Finish(false, why); end
        return;
    end
    if j.phase == "go" then
        local npc, d = self:FindNpc();
        if npc and d <= 300 then self:StopWalk(j); j.phase, j.talks, j.talkAt = "talk", 0, nil; return; end
        if not j.point and not j.routed then
            j.routed = true;
            if not self:Route(j) then return self:Finish(false, "không tìm được Lễ Quan ở Tân Thủ Thôn / Thành Thị"); end
            if j.phase ~= "go" then return; end
        end
        if not j.point then j.routed = nil; return; end        -- vừa tới thành bằng phù: tính lại điểm đến
        local path = Ui.tbLogic.tbAutoPath;
        if not j.path or path.tbGotoPos ~= j.path then
            if j.walkAt and t - j.walkAt < 3 then return; end
            j.walkAt, j.walkStart = t, j.walkStart or t;
            path:GotoPos({nMapId = j.point.map, nX = j.point.x, nY = j.point.y});
            j.path = path.tbGotoPos;
        end
        if t - (j.walkStart or t) > self.WALK_TIMEOUT then return self:Finish(false, "đi tới Lễ Quan quá lâu"); end
        self.status = "Đi tới Lễ Quan";
        return;
    end
    if j.phase == "after" then
        if t - j.afterAt >= 2 then j.phase, j.talks, j.talkAt = "talk", 0, nil; end
        return;
    end
    if j.phase == "talk" then
        if j.talkAt and t - j.talkAt < 4 then
            if j.say then j.phase = "dialog"; end
            return;
        end
        j.talks = (j.talks or 0) + 1;
        if j.talks > 3 then return self:Finish(false, "Lễ Quan không mở hội thoại"); end
        local npc, d = self:FindNpc();
        if not npc or d > 450 then return self:Finish(false, "bạn đã tự đi xa Lễ Quan — dừng auto"); end
        self:InstallSay();
        j.talkAt, j.sayUntil, j.say, j.talked = t, t + self.SAY_WAIT, nil, true;
        pcall(AutoAi.SetTargetIndex, npc.nIndex);
        self.status = "Nói chuyện với Lễ Quan";
        return;
    end
    if j.phase == "dialog" then
        if j.say and j.saySeq ~= j.doneSeq then
            j.doneSeq = j.saySeq;
            local param = j.say;
            j.say = nil;
            return self:OnSay(j, param);
        end
        if t > (j.sayUntil or t) then j.phase, j.talkAt, j.talks = "talk", nil, 0; end     -- không có bảng mới: nói chuyện lại
        return;
    end
end

-- ---------------------------------------------------------------- Ctrl+M: chuyển sang auto mới, tắt auto cũ (AutoAnswer)
-- Plugin cũ đăng ký Ctrl+M → alias "AutoAnswerSwitch" → chuỗi "UiManager:AutoAnswerSwitch()" (đọc lại mỗi lần bấm),
-- và tự trả lời MỌI hội thoại khi biến nSwitch (local, mặc định 1) = 1. Gọi hàm cũ đúng 1 lần (ẩn bảng thông báo) để nSwitch = 0,
-- rồi thay UiManager.AutoAnswerSwitch bằng hàm mới → Ctrl+M và mọi chỗ gọi cũ đều chạy auto mới. Không sửa file cũ.
if not A.switchFn then
    A.switchFn = function()
        local ok, why = pcall(function() Ui.WJXHoaDang:Toggle(); end);
        if not ok and me and me.Msg then me.Msg("[Hoa Đăng] " .. tostring(why)); end
    end;
end

function A:TakeOverOld()
    local old = UiManager.AutoAnswerSwitch;
    if old == self.switchFn then return true; end
    if type(old) ~= "function" then return false; end
    local raw = rawget(UiManager, "OpenWindow");
    local open = UiManager.OpenWindow;
    UiManager.OpenWindow = function(manager, group, ...)
        if group == "UI_INFOBOARD" then return; end
        return open(manager, group, ...);
    end;
    pcall(old, UiManager);                           -- nSwitch 1 → 0: auto cũ không tự trả lời nữa
    UiManager.OpenWindow = raw;
    UiManager.AutoAnswerSwitch = self.switchFn;
    self.oldHidden = true;
    return true;
end

-- Không có plugin cũ: tự đăng ký Ctrl+M
function A:BindOwnKey()
    if self.keyBound or not AddCommand or not UiShortcutAlias then return; end
    self.keyBound = true;
    UiManager.AutoAnswerSwitch = self.switchFn;
    pcall(AddCommand, "Ctrl+M", "", "WJXHoaDangSwitch", UiShortcutAlias.emKSTATE_INGAME);
    pcall(UiShortcutAlias.AddAlias, UiShortcutAlias, "WJXHoaDangSwitch", "UiManager:AutoAnswerSwitch()");
end

-- Nhớ thành / thôn gần nhất đã ghé (để dùng Vô Hạn Phù về đó)
function A:Watch()
    local okMap, map = pcall(function() return me.GetMapTemplateId(); end);
    if okMap and isTown(map) then self.lastTown = map; end
end

if not A.timer and Ui.tbLogic and Ui.tbLogic.tbTimer then
    local checks = 0;
    A.timer = Ui.tbLogic.tbTimer:Register(6, function()
        local S = Ui.WJXHoaDang;
        checks = checks + 1;
        if checks % 3 == 1 then                      -- ~1 giây
            local ok, taken = pcall(S.TakeOverOld, S);
            if ok and not taken and checks > 30 and not S.oldHidden then pcall(S.BindOwnKey, S); end
            if me and me.szName and me.szName ~= "" then pcall(S.Watch, S); end
        end
        if S.job then
            local ok, why = pcall(S.Tick, S);
            if not ok then
                S.tickErr = (S.tickErr or 0) + 1;
                if S.tickErr >= 3 then S.tickErr = 0; pcall(S.Finish, S, false, "lỗi: " .. tostring(why)); end
            else
                S.tickErr = 0;
            end
        end
        return 6;
    end);
end
pcall(A.TakeOverOld, A);
