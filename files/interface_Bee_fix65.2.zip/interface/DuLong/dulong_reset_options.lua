return { auto = 1, count = 1, bronze = 0, ghep = 1, ghepLv = 12, ghepBind = 1, ghepMoney = 1, egg = 1 }
